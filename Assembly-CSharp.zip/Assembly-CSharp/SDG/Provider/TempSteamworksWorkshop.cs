﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using SDG.SteamworksProvider;
using SDG.Unturned;
using Steamworks;
using UnityEngine;

namespace SDG.Provider
{
	// Token: 0x0200003A RID: 58
	public class TempSteamworksWorkshop
	{
		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x000084AB File Offset: 0x000066AB
		public bool canOpenWorkshop
		{
			get
			{
				return true;
			}
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x000084AE File Offset: 0x000066AE
		public void open(PublishedFileId_t id)
		{
			SteamFriends.ActivateGameOverlayToWebPage("https://steamcommunity.com/sharedfiles/filedetails/?id=" + id.m_PublishedFileId.ToString(), EActivateGameOverlayToWebPageMode.k_EActivateGameOverlayToWebPageMode_Default);
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x000084CC File Offset: 0x000066CC
		public List<SteamContent> ugc
		{
			get
			{
				return this._ugc;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x000084D4 File Offset: 0x000066D4
		public List<SteamPublished> published
		{
			get
			{
				return this._published;
			}
		}

		/// <summary>
		/// Get compatibility version from workshop query, or zero if unset.
		/// </summary>
		// Token: 0x060001A9 RID: 425 RVA: 0x000084DC File Offset: 0x000066DC
		public static byte getCompatibilityVersion(UGCQueryHandle_t queryHandle, uint index)
		{
			uint num = Dedicator.IsDedicatedServer ? SteamGameServerUGC.GetQueryUGCNumKeyValueTags(queryHandle, index) : SteamUGC.GetQueryUGCNumKeyValueTags(queryHandle, index);
			uint num2 = 0U;
			while (num2 < num)
			{
				string text;
				string text2;
				if ((Dedicator.IsDedicatedServer ? SteamGameServerUGC.GetQueryUGCKeyValueTag(queryHandle, index, num2, out text, 255U, out text2, 255U) : SteamUGC.GetQueryUGCKeyValueTag(queryHandle, index, num2, out text, 255U, out text2, 255U)) && text.Equals(TempSteamworksWorkshop.COMPATIBILITY_VERSION_KVTAG, StringComparison.InvariantCultureIgnoreCase))
				{
					byte result;
					if (byte.TryParse(text2, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
					{
						return result;
					}
					UnturnedLog.warn("Unable to parse workshop item compatibility version from '{0}'", new object[]
					{
						text2
					});
					return 0;
				}
				else
				{
					num2 += 1U;
				}
			}
			return 0;
		}

		// Token: 0x060001AA RID: 426 RVA: 0x00008580 File Offset: 0x00006780
		private static void DumpDetails(in SteamUGCDetails_t details)
		{
			string format = "{0} \"{1}\"";
			object[] array = new object[2];
			array[0] = details.m_nPublishedFileId;
			int num = 1;
			SteamUGCDetails_t steamUGCDetails_t = details;
			array[num] = steamUGCDetails_t.m_rgchTitle;
			UnturnedLog.info(format, array);
			UnturnedLog.info("\tBanned: {0}", new object[]
			{
				details.m_bBanned
			});
			UnturnedLog.info("\tResult: {0}", new object[]
			{
				details.m_eResult
			});
			UnturnedLog.info("\tVisibility: {0}", new object[]
			{
				details.m_eVisibility
			});
		}

		/// <summary>
		/// Save the details from a workshop query for lookup later.
		/// Allows game to inspect the installed files before deciding if they are
		/// compatible, since maps and localization are not affected by unity upgrades.
		/// Previously the compatibility test occurred before downloading the content.
		/// </summary>
		// Token: 0x060001AB RID: 427 RVA: 0x00008618 File Offset: 0x00006818
		public static bool cacheDetails(UGCQueryHandle_t queryHandle, uint index, out CachedUGCDetails cachedDetails)
		{
			cachedDetails = default(CachedUGCDetails);
			SteamUGCDetails_t steamUGCDetails_t;
			bool flag = Dedicator.IsDedicatedServer ? SteamGameServerUGC.GetQueryUGCResult(queryHandle, index, out steamUGCDetails_t) : SteamUGC.GetQueryUGCResult(queryHandle, index, out steamUGCDetails_t);
			if (flag)
			{
				PublishedFileId_t nPublishedFileId = steamUGCDetails_t.m_nPublishedFileId;
				byte compatibilityVersion = TempSteamworksWorkshop.getCompatibilityVersion(queryHandle, index);
				cachedDetails.fileId = nPublishedFileId;
				cachedDetails.name = steamUGCDetails_t.m_rgchTitle;
				cachedDetails.compatibilityVersion = compatibilityVersion;
				cachedDetails.isBannedOrPrivate = (steamUGCDetails_t.m_bBanned || steamUGCDetails_t.m_eVisibility == ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityPrivate || steamUGCDetails_t.m_eResult == EResult.k_EResultAccessDenied);
				cachedDetails.updateTimestamp = MathfEx.Max(steamUGCDetails_t.m_rtimeCreated, steamUGCDetails_t.m_rtimeUpdated);
				TempSteamworksWorkshop.cachedUGCDetails[nPublishedFileId.m_PublishedFileId] = cachedDetails;
				if (!string.IsNullOrEmpty(cachedDetails.name))
				{
					AssetOrigin assetOrigin = Assets.FindWorkshopFileOrigin(nPublishedFileId.m_PublishedFileId);
					if (assetOrigin != null)
					{
						assetOrigin.name = string.Format("Workshop File \"{0}\" ({1})", cachedDetails.name, cachedDetails.fileId);
						return flag;
					}
				}
			}
			else
			{
				UnturnedLog.warn("Unable to get query UGC result for caching");
			}
			return flag;
		}

		/// <summary>
		/// Get cached workshop item details.
		/// </summary>
		// Token: 0x060001AC RID: 428 RVA: 0x00008710 File Offset: 0x00006910
		public static bool getCachedDetails(PublishedFileId_t fileId, out CachedUGCDetails cachedDetails)
		{
			return TempSteamworksWorkshop.cachedUGCDetails.TryGetValue(fileId.m_PublishedFileId, out cachedDetails);
		}

		// Token: 0x060001AD RID: 429 RVA: 0x00008724 File Offset: 0x00006924
		public static AssetOrigin FindOrAddOrigin(ulong fileId)
		{
			AssetOrigin assetOrigin = Assets.FindOrAddWorkshopFileOrigin(fileId, true);
			CachedUGCDetails cachedUGCDetails;
			if (TempSteamworksWorkshop.cachedUGCDetails.TryGetValue(fileId, out cachedUGCDetails) && !string.IsNullOrEmpty(cachedUGCDetails.name))
			{
				assetOrigin.name = string.Format("Workshop File \"{0}\" ({1})", cachedUGCDetails.name, cachedUGCDetails.fileId);
			}
			return assetOrigin;
		}

		// Token: 0x060001AE RID: 430 RVA: 0x00008778 File Offset: 0x00006978
		public static bool isCompatible(PublishedFileId_t fileId, ESteamUGCType type, string dir, out string explanation)
		{
			CachedUGCDetails cachedUGCDetails;
			if (!TempSteamworksWorkshop.getCachedDetails(fileId, out cachedUGCDetails))
			{
				explanation = null;
				return true;
			}
			bool flag;
			if (type != ESteamUGCType.MAP)
			{
				flag = (type != ESteamUGCType.LOCALIZATION);
			}
			else
			{
				flag = Directory.Exists(dir + "/Bundles");
			}
			if (flag)
			{
				if (cachedUGCDetails.compatibilityVersion < 2)
				{
					explanation = string.Format("Workshop version of \"{0}\" has not yet been updated from Unity 5.5 and cannot be loaded.", cachedUGCDetails.GetTitle());
					return false;
				}
				if (cachedUGCDetails.compatibilityVersion > 6)
				{
					explanation = string.Format("Workshop version of \"{0}\" has been updated to an unknown future version of Unity and cannot be loaded.", cachedUGCDetails.GetTitle());
					return false;
				}
			}
			explanation = null;
			return true;
		}

		/// <summary>
		/// Should caller skip loading a given workshop file?
		///
		/// Used to skip workshop version of map if the map is locally installed,
		/// e.g. Canyon Arena moved to workshop and auto-subscribed.
		/// </summary>
		// Token: 0x060001AF RID: 431 RVA: 0x000087F9 File Offset: 0x000069F9
		public static bool shouldIgnoreFile(PublishedFileId_t fileId, out string explanation)
		{
			if (fileId == TempSteamworksWorkshop.FRANCE && ReadWrite.fileExists("/Maps/France/Config.json", false, true))
			{
				explanation = "non-Workshop version of France is still installed";
				return true;
			}
			explanation = null;
			return false;
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x00008824 File Offset: 0x00006A24
		private void onCreateItemResult(CreateItemResult_t callback, bool io)
		{
			if (callback.m_bUserNeedsToAcceptWorkshopLegalAgreement)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_NeedsToAcceptWorkshopLegalAgreement"));
				return;
			}
			if (callback.m_eResult != EResult.k_EResultOK)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_UnknownResult", callback.m_eResult));
				return;
			}
			if (io)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_IOError"));
				return;
			}
			this.publishedFileID = callback.m_nPublishedFileId;
			this.updateUGC();
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x000088A4 File Offset: 0x00006AA4
		private void onSubmitItemUpdateResult(SubmitItemUpdateResult_t callback, bool io)
		{
			if (callback.m_bUserNeedsToAcceptWorkshopLegalAgreement)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_NeedsToAcceptWorkshopLegalAgreement"));
				return;
			}
			if (callback.m_eResult != EResult.k_EResultOK)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_UnknownResult", callback.m_eResult));
				return;
			}
			if (io)
			{
				MenuUI.alert(MenuDashboardUI.localization.format("UGC_IOError"));
				return;
			}
			MenuUI.alert(MenuDashboardUI.localization.format("UGC_Success"));
			Provider.provider.workshopService.open(this.publishedFileID);
			this.refreshPublished();
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00008940 File Offset: 0x00006B40
		private void onQueryCompleted(SteamUGCQueryCompleted_t callback, bool io)
		{
			if (callback.m_eResult != EResult.k_EResultOK || io)
			{
				return;
			}
			if (callback.m_unNumResultsReturned < 1U)
			{
				return;
			}
			for (uint num = 0U; num < callback.m_unNumResultsReturned; num += 1U)
			{
				SteamUGCDetails_t steamUGCDetails_t;
				SteamUGC.GetQueryUGCResult(this.ugcRequest, num, out steamUGCDetails_t);
				SteamPublished item = new SteamPublished(steamUGCDetails_t.m_rgchTitle, steamUGCDetails_t.m_nPublishedFileId);
				this.published.Add(item);
			}
			TempSteamworksWorkshop.PublishedAdded publishedAdded = this.onPublishedAdded;
			if (publishedAdded != null)
			{
				publishedAdded();
			}
			this.cleanupUGCRequest();
			this.shouldRequestAnotherPage = true;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x000089C8 File Offset: 0x00006BC8
		public void update()
		{
			if (this.shouldRequestAnotherPage)
			{
				this.shouldRequestAnotherPage = false;
				this.ugcRequestPage += 1U;
				this.ugcRequest = SteamUGC.CreateQueryUserUGCRequest(Provider.client.GetAccountID(), EUserUGCList.k_EUserUGCList_Published, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items, EUserUGCListSortOrder.k_EUserUGCListSortOrder_CreationOrderAsc, SteamUtils.GetAppID(), SteamUtils.GetAppID(), this.ugcRequestPage);
				SteamAPICall_t hAPICall = SteamUGC.SendQueryUGCRequest(this.ugcRequest);
				this.queryCompleted.Set(hAPICall, null);
			}
			ulong num;
			ulong num2;
			if (this.currentlyDownloadingFileId != PublishedFileId_t.Invalid && SteamUGC.GetItemDownloadInfo(this.currentlyDownloadingFileId, out num, out num2) && num2 > 0UL)
			{
				this.currentlyDownloadingFileEstimatedProgress = (float)(num / num2);
				if (num >= num2)
				{
					this.currentlyDownloadingFileId = PublishedFileId_t.Invalid;
				}
				this.UpdateEstimatedDownloadProgress();
			}
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x00008A84 File Offset: 0x00006C84
		private void UpdateEstimatedDownloadProgress()
		{
			float num = this.progressPerFileDownloaded * (float)(this.totalNumberOfFilesToDownload - this.installing.Count) + this.progressPerFileDownloaded * this.currentlyDownloadingFileEstimatedProgress;
			int num2 = Mathf.RoundToInt(num * 100f);
			if (this.previousEstimatedDownloadProgress != num2)
			{
				this.previousEstimatedDownloadProgress = num2;
				LoadingUI.NotifyDownloadProgress(num);
			}
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x00008ADD File Offset: 0x00006CDD
		private void OnFinishedDownloadingItems()
		{
			if (Assets.ShouldWaitForNewAssetsToFinishLoading)
			{
				UnturnedLog.info("Client UGC waiting for assets to finish loading...");
				Assets.OnNewAssetsFinishedLoading = (System.Action)Delegate.Combine(Assets.OnNewAssetsFinishedLoading, new System.Action(this.OnNewAssetsFinishedLoading));
				return;
			}
			this.OnNewAssetsFinishedLoading();
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x00008B17 File Offset: 0x00006D17
		private void OnNewAssetsFinishedLoading()
		{
			Assets.OnNewAssetsFinishedLoading = (System.Action)Delegate.Remove(Assets.OnNewAssetsFinishedLoading, new System.Action(this.OnNewAssetsFinishedLoading));
			Provider.launch();
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x00008B40 File Offset: 0x00006D40
		public void downloadNextItem()
		{
			if (this.installing.Count == 0)
			{
				LoadingUI.SetIsDownloading(false);
				this.OnFinishedDownloadingItems();
				return;
			}
			PublishedFileId_t publishedFileId_t = this.installing[0];
			CachedUGCDetails cachedUGCDetails;
			string downloadFileName;
			if (TempSteamworksWorkshop.getCachedDetails(publishedFileId_t, out cachedUGCDetails))
			{
				downloadFileName = cachedUGCDetails.GetTitle();
			}
			else
			{
				string str = "Unknown ID ";
				PublishedFileId_t publishedFileId_t2 = publishedFileId_t;
				downloadFileName = str + publishedFileId_t2.ToString();
			}
			LoadingUI.SetDownloadFileName(downloadFileName);
			this.currentlyDownloadingFileId = publishedFileId_t;
			this.currentlyDownloadingFileEstimatedProgress = 0f;
			SteamUGC.DownloadItem(publishedFileId_t, true);
		}

		/// <summary>
		/// Helper for downloadServerItems.
		/// Called for each workshop item we want to download for the server.
		/// </summary>
		// Token: 0x060001B8 RID: 440 RVA: 0x00008BC4 File Offset: 0x00006DC4
		private void enqueueServerItemDownloadOrInstallFromCache(PublishedFileId_t fileId)
		{
			bool flag = this.isInstalledItemAlreadyRegistered(fileId);
			string text;
			if (TempSteamworksWorkshop.shouldIgnoreFile(fileId, out text))
			{
				UnturnedLog.info("Ignoring server download {0} because '{1}'", new object[]
				{
					fileId,
					text
				});
				return;
			}
			ulong num;
			string path;
			uint num2;
			if (SteamUGC.GetItemInstallInfo(fileId, out num, out path, 1024U, out num2) && ReadWrite.folderExists(path, false))
			{
				CachedUGCDetails cachedUGCDetails;
				if ((SteamUGC.GetItemState(fileId) & 8U) == 8U)
				{
					if (flag)
					{
						UnturnedLog.info(string.Format("Server workshop file {0} is already loaded, but was flagged as needing update", fileId));
						return;
					}
					UnturnedLog.info("Server workshop item {0} found in cache, but was flagged as needing update", new object[]
					{
						fileId
					});
					this.installing.Add(fileId);
					return;
				}
				else if (TempSteamworksWorkshop.getCachedDetails(fileId, out cachedUGCDetails) && cachedUGCDetails.updateTimestamp > num2)
				{
					if (flag)
					{
						UnturnedLog.info("Server workshop file {0} is already loaded, but remote ({1}) is newer than local ({2})", new object[]
						{
							fileId,
							DateTimeEx.FromUtcUnixTimeSeconds(cachedUGCDetails.updateTimestamp).ToLocalTime(),
							DateTimeEx.FromUtcUnixTimeSeconds(num2).ToLocalTime()
						});
						return;
					}
					UnturnedLog.info("Server workshop item {0} found in cache, but remote ({1}) is newer than local ({2})", new object[]
					{
						fileId,
						DateTimeEx.FromUtcUnixTimeSeconds(cachedUGCDetails.updateTimestamp).ToLocalTime(),
						DateTimeEx.FromUtcUnixTimeSeconds(num2).ToLocalTime()
					});
					this.installing.Add(fileId);
					return;
				}
				else if (!flag)
				{
					string str = "Installing cached server workshop item: ";
					PublishedFileId_t publishedFileId_t = fileId;
					UnturnedLog.info(str + publishedFileId_t.ToString());
					this.installItemDownloadedFromServer(fileId, path);
					return;
				}
			}
			else
			{
				this.installing.Add(fileId);
			}
		}

		/// <summary>
		/// Called once we know which items the server is allowed to use (queryServerItems),
		/// or the query has failed in which case we proceed with all items it told us.
		/// </summary>
		// Token: 0x060001B9 RID: 441 RVA: 0x00008D70 File Offset: 0x00006F70
		private void downloadServerItems(List<PublishedFileId_t> itemIDs)
		{
			this.installing = new List<PublishedFileId_t>();
			Assets.loadingStats.Reset();
			foreach (PublishedFileId_t fileId in itemIDs)
			{
				this.enqueueServerItemDownloadOrInstallFromCache(fileId);
			}
			if (this.installing.Count < 1)
			{
				UnturnedLog.info("Server has {0} valid workshop item(s), but we already have them downloaded", new object[]
				{
					itemIDs.Count
				});
				this.OnFinishedDownloadingItems();
				return;
			}
			UnturnedLog.info("Server has {0} valid workshop item(s), of which {1} need to be downloaded", new object[]
			{
				itemIDs.Count,
				this.installing.Count
			});
			this.totalNumberOfFilesToDownload = this.installing.Count;
			this.progressPerFileDownloaded = 1f / (float)this.totalNumberOfFilesToDownload;
			this.previousEstimatedDownloadProgress = 0;
			LoadingUI.SetIsDownloading(true);
			LoadingUI.NotifyDownloadProgress(0f);
			this.downloadNextItem();
		}

		/// <summary>
		/// Is currently connected server allowed to auto-download the workshop item?
		/// Requested by mod authors so that they can whitelist/blacklist access.
		/// </summary>
		// Token: 0x060001BA RID: 442 RVA: 0x00008E78 File Offset: 0x00007078
		private bool testDownloadRestrictions(UGCQueryHandle_t queryHandle, uint resultIndex, uint ip, string itemDisplayText)
		{
			if (ip == 0U)
			{
				return true;
			}
			EWorkshopDownloadRestrictionResult restrictionResult = WorkshopDownloadRestrictions.getRestrictionResult(queryHandle, resultIndex, ip);
			switch (restrictionResult)
			{
			case EWorkshopDownloadRestrictionResult.NoRestrictions:
				return true;
			case EWorkshopDownloadRestrictionResult.NotWhitelisted:
				UnturnedLog.warn("Server is not authorized in the IP whitelist for " + itemDisplayText);
				return false;
			case EWorkshopDownloadRestrictionResult.Blacklisted:
				UnturnedLog.warn("Server is blocked in IP blacklist from downloading " + itemDisplayText);
				return false;
			case EWorkshopDownloadRestrictionResult.Allowed:
				UnturnedLog.info("Server is authorized to download " + itemDisplayText);
				return true;
			case EWorkshopDownloadRestrictionResult.Banned:
				UnturnedLog.warn("Workshop file is banned " + itemDisplayText);
				return false;
			case EWorkshopDownloadRestrictionResult.PrivateVisibility:
				UnturnedLog.warn("Workshop file is private " + itemDisplayText);
				return false;
			default:
				UnturnedLog.warn("Unknown restriction result '{0}' for '{1}'", new object[]
				{
					restrictionResult,
					itemDisplayText
				});
				return true;
			}
		}

		/// <summary>
		/// Successfully queried details of the items current server is using.
		/// Ensure server has permission to use these items, then proceed with downloading.
		/// Also caches item titles for use on the loading screen.
		/// </summary>
		// Token: 0x060001BB RID: 443 RVA: 0x00008F34 File Offset: 0x00007134
		private void handleServerItemsQuerySuccess(SteamUGCQueryCompleted_t callback)
		{
			string ipfromUInt = Parser.getIPFromUInt32(this.serverDownloadIP);
			UnturnedLog.info("Server's allowed IP for Workshop downloads: " + ipfromUInt);
			this.serverPendingIDs = new List<PublishedFileId_t>((int)callback.m_unNumResultsReturned);
			for (uint num = 0U; num < callback.m_unNumResultsReturned; num += 1U)
			{
				CachedUGCDetails cachedUGCDetails;
				TempSteamworksWorkshop.cacheDetails(callback.m_handle, num, out cachedUGCDetails);
				if (this.testDownloadRestrictions(callback.m_handle, num, this.serverDownloadIP, cachedUGCDetails.GetTitle()))
				{
					this.serverPendingIDs.Add(cachedUGCDetails.fileId);
				}
				else
				{
					int serverInvalidItemsCount = this.serverInvalidItemsCount + 1;
					this.serverInvalidItemsCount = serverInvalidItemsCount;
				}
			}
			this.downloadServerItems(this.serverPendingIDs);
		}

		/// <summary>
		/// IO or bad result occurred when querying items the current server is using.
		/// We do not know the file details, but we proceed with downloading them all.
		/// </summary>
		// Token: 0x060001BC RID: 444 RVA: 0x00008FD9 File Offset: 0x000071D9
		private void handleServerItemsQueryFailed()
		{
			this.downloadServerItems(this.serverPendingIDs);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00008FE8 File Offset: 0x000071E8
		private void onServerItemsQueryCompleted(SteamUGCQueryCompleted_t callback, bool ioFailure)
		{
			if (callback.m_handle != this.serverItemsQueryHandle)
			{
				return;
			}
			if (ioFailure)
			{
				UnturnedLog.error("IO error querying workshop for server items!");
				this.handleServerItemsQueryFailed();
			}
			else if (callback.m_eResult == EResult.k_EResultOK)
			{
				this.handleServerItemsQuerySuccess(callback);
			}
			else
			{
				UnturnedLog.error("Error querying workshop for server items: " + callback.m_eResult.ToString());
				this.handleServerItemsQueryFailed();
			}
			SteamUGC.ReleaseQueryUGCRequest(this.serverItemsQueryHandle);
			this.serverItemsQueryHandle = UGCQueryHandle_t.Invalid;
		}

		/// <summary>
		/// Number of items currently connected server was not authorized to download.
		/// </summary>
		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060001BE RID: 446 RVA: 0x0000906E File Offset: 0x0000726E
		// (set) Token: 0x060001BF RID: 447 RVA: 0x00009076 File Offset: 0x00007276
		public int serverInvalidItemsCount { get; protected set; }

		/// <summary>
		/// Called prior to downloading, and after a connection failure.
		/// </summary>
		// Token: 0x060001C0 RID: 448 RVA: 0x0000907F File Offset: 0x0000727F
		public void resetServerInvalidItems()
		{
			this.serverPendingIDs = null;
			this.serverInvalidItemsCount = 0;
		}

		/// <summary>
		/// Client now knows the published file IDs the server is using, but
		/// queries the workshop for additional information before installing.
		/// </summary>
		// Token: 0x060001C1 RID: 449 RVA: 0x00009090 File Offset: 0x00007290
		public void queryServerWorkshopItems(List<PublishedFileId_t> fileIDs, uint serverIP)
		{
			this.serverPendingIDs = fileIDs;
			this.serverDownloadIP = serverIP;
			this.serverItemsQueryHandle = SteamUGC.CreateQueryUGCDetailsRequest(fileIDs.ToArray(), (uint)fileIDs.Count);
			SteamUGC.SetReturnKeyValueTags(this.serverItemsQueryHandle, true);
			SteamUGC.SetAllowCachedResponse(this.serverItemsQueryHandle, 60U);
			SteamAPICall_t hAPICall = SteamUGC.SendQueryUGCRequest(this.serverItemsQueryHandle);
			this.serverItemsQueryCompleted.Set(hAPICall, null);
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x000090F8 File Offset: 0x000072F8
		private void installItemDownloadedFromServer(PublishedFileId_t fileId, string path)
		{
			ESteamUGCType esteamUGCType;
			if (WorkshopTool.detectUGCMetaType(path, false, out esteamUGCType))
			{
				this.ugc.Add(new SteamContent(fileId, path, esteamUGCType));
				this.LoadFileIfAssetStartupAlreadyRan(fileId, path, esteamUGCType);
				return;
			}
			string str = "Unable to determine UGC type for downloaded item: ";
			PublishedFileId_t publishedFileId_t = fileId;
			UnturnedLog.warn(str + publishedFileId_t.ToString());
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000914C File Offset: 0x0000734C
		private void onItemDownloaded(DownloadItemResult_t callback)
		{
			if (this.installing == null || this.installing.Count == 0)
			{
				return;
			}
			if (callback.m_unAppID.m_AppId != this.appInfo.id)
			{
				return;
			}
			string str = "Workshop item downloaded: ";
			PublishedFileId_t nPublishedFileId = callback.m_nPublishedFileId;
			UnturnedLog.info(str + nPublishedFileId.ToString());
			if (callback.m_nPublishedFileId == this.currentlyDownloadingFileId)
			{
				this.currentlyDownloadingFileId = PublishedFileId_t.Invalid;
				this.currentlyDownloadingFileEstimatedProgress = 0f;
			}
			this.installing.Remove(callback.m_nPublishedFileId);
			this.UpdateEstimatedDownloadProgress();
			if (callback.m_eResult == EResult.k_EResultOK)
			{
				string text;
				ulong num;
				string text2;
				uint num2;
				if (this.isInstalledItemAlreadyRegistered(callback.m_nPublishedFileId))
				{
					UnturnedLog.warn("Already registered newly downloaded workshop item '{0}', so ignoring this callback", new object[]
					{
						callback.m_nPublishedFileId
					});
				}
				else if (TempSteamworksWorkshop.shouldIgnoreFile(callback.m_nPublishedFileId, out text))
				{
					UnturnedLog.info("Ignoring newly downloaded workshop item {0} because '{1}'", new object[]
					{
						callback.m_nPublishedFileId,
						text
					});
				}
				else if (SteamUGC.GetItemInstallInfo(callback.m_nPublishedFileId, out num, out text2, 1024U, out num2))
				{
					if (ReadWrite.folderExists(text2, false))
					{
						this.installItemDownloadedFromServer(callback.m_nPublishedFileId, text2);
					}
					else
					{
						UnturnedLog.warn("Finished downloading workshop item {0}, but unable to find the files on disk ({1})", new object[]
						{
							callback.m_nPublishedFileId,
							text2
						});
					}
				}
				else
				{
					UnturnedLog.warn("Finished downloading workshop item {0}, but unable get install info", new object[]
					{
						callback.m_nPublishedFileId
					});
				}
			}
			else
			{
				UnturnedLog.warn("Download workshop item {0} failed, result: {1}", new object[]
				{
					callback.m_nPublishedFileId,
					callback.m_eResult
				});
			}
			this.downloadNextItem();
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00009308 File Offset: 0x00007508
		private void onItemInstalled(ItemInstalled_t callback)
		{
			if (callback.m_unAppID.m_AppId != this.appInfo.id)
			{
				return;
			}
			string str = "Workshop item installed: ";
			PublishedFileId_t nPublishedFileId = callback.m_nPublishedFileId;
			UnturnedLog.info(str + nPublishedFileId.ToString());
			if (this.isInstalledItemAlreadyRegistered(callback.m_nPublishedFileId))
			{
				UnturnedLog.warn("Already registered newly installed workshop item '{0}', so ignoring this callback", new object[]
				{
					callback.m_nPublishedFileId
				});
				return;
			}
			string text;
			if (TempSteamworksWorkshop.shouldIgnoreFile(callback.m_nPublishedFileId, out text))
			{
				UnturnedLog.info("Ignoring newly installed workshop item because '{0}'", new object[]
				{
					text
				});
				return;
			}
			string text2;
			if (!this.getInstalledItemPath(callback.m_nPublishedFileId, out text2))
			{
				UnturnedLog.warn("Unable to determine newly installed workshop item '{0}' file path", new object[]
				{
					callback.m_nPublishedFileId
				});
				return;
			}
			ESteamUGCType esteamUGCType;
			if (!WorkshopTool.detectUGCMetaType(text2, false, out esteamUGCType))
			{
				UnturnedLog.warn("Unable to determine newly installed workshop item '{0}' type", new object[]
				{
					callback.m_nPublishedFileId
				});
				return;
			}
			this.ugc.Add(new SteamContent(callback.m_nPublishedFileId, text2, esteamUGCType));
			this.LoadFileIfAssetStartupAlreadyRan(callback.m_nPublishedFileId, text2, esteamUGCType);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x00009424 File Offset: 0x00007624
		private void LoadFileIfAssetStartupAlreadyRan(PublishedFileId_t fileId, string path, ESteamUGCType type)
		{
			if (!((type == ESteamUGCType.MAP) ? Assets.hasLoadedMaps : Assets.hasLoadedUgc))
			{
				UnturnedLog.info(string.Format("Workshop file {0} not requesting load because asset refresh is in progress", fileId));
				return;
			}
			if (type != ESteamUGCType.MAP)
			{
				if (type != ESteamUGCType.LOCALIZATION)
				{
					Assets.RequestAddSearchLocation(path, TempSteamworksWorkshop.FindOrAddOrigin(fileId.m_PublishedFileId));
				}
				return;
			}
			WorkshopTool.loadMapBundlesAndContent(path, fileId.m_PublishedFileId);
			Level.broadcastLevelsRefreshed();
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x00009484 File Offset: 0x00007684
		private void cleanupUGCRequest()
		{
			if (this.ugcRequest == UGCQueryHandle_t.Invalid)
			{
				return;
			}
			SteamUGC.ReleaseQueryUGCRequest(this.ugcRequest);
			this.ugcRequest = UGCQueryHandle_t.Invalid;
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x000094B0 File Offset: 0x000076B0
		public void prepareUGC(string name, string description, string path, string preview, string change, ESteamUGCType type, List<string> tags, string allowedIPs, ESteamUGCVisibility visibility)
		{
			bool verified = File.Exists(path + "/Skin.kvt");
			this.prepareUGC(name, description, path, preview, change, type, tags, allowedIPs, visibility, verified);
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x000094E4 File Offset: 0x000076E4
		public void prepareUGC(string name, string description, string path, string preview, string change, ESteamUGCType type, List<string> tags, string allowedIPs, ESteamUGCVisibility visibility, bool verified)
		{
			this.ugcName = name;
			this.ugcDescription = description;
			this.ugcPath = path;
			this.ugcPreview = preview;
			this.ugcChange = change;
			this.ugcType = type;
			this.ugcTags = tags;
			this.ugcAllowedIPs = allowedIPs;
			this.ugcVisibility = visibility;
			this.ugcVerified = verified;
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000953E File Offset: 0x0000773E
		public void prepareUGC(PublishedFileId_t id)
		{
			this.publishedFileID = id;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00009548 File Offset: 0x00007748
		public void createUGC(bool ugcFor)
		{
			SteamAPICall_t hAPICall = SteamUGC.CreateItem(SteamUtils.GetAppID(), ugcFor ? EWorkshopFileType.k_EWorkshopFileTypeMicrotransaction : EWorkshopFileType.k_EWorkshopFileTypeFirst);
			this.createItemResult.Set(hAPICall, null);
		}

		// Token: 0x060001CB RID: 459 RVA: 0x00009574 File Offset: 0x00007774
		public void updateUGC()
		{
			UGCUpdateHandle_t ugcupdateHandle_t = SteamUGC.StartItemUpdate(SteamUtils.GetAppID(), this.publishedFileID);
			if (this.ugcType == ESteamUGCType.MAP)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Map.meta", false, false, new byte[1]);
			}
			else if (this.ugcType == ESteamUGCType.LOCALIZATION)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Localization.meta", false, false, new byte[1]);
			}
			else if (this.ugcType == ESteamUGCType.OBJECT)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Object.meta", false, false, new byte[1]);
			}
			else if (this.ugcType == ESteamUGCType.ITEM)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Item.meta", false, false, new byte[1]);
			}
			else if (this.ugcType == ESteamUGCType.VEHICLE)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Vehicle.meta", false, false, new byte[1]);
			}
			else if (this.ugcType == ESteamUGCType.SKIN)
			{
				ReadWrite.writeBytes(this.ugcPath + "/Skin.meta", false, false, new byte[1]);
			}
			SteamUGC.SetItemContent(ugcupdateHandle_t, this.ugcPath);
			if (this.ugcDescription.Length > 0)
			{
				SteamUGC.SetItemDescription(ugcupdateHandle_t, this.ugcDescription);
			}
			if (this.ugcPreview.Length > 0)
			{
				SteamUGC.SetItemPreview(ugcupdateHandle_t, this.ugcPreview);
			}
			List<string> list = new List<string>();
			if (this.ugcTags != null)
			{
				foreach (string text in this.ugcTags)
				{
					if (!string.IsNullOrWhiteSpace(text))
					{
						list.Add(text);
					}
				}
			}
			if (this.ugcVerified)
			{
				list.Add("Verified");
			}
			SteamUGC.SetItemTags(ugcupdateHandle_t, list.ToArray());
			if (this.ugcName.Length > 0)
			{
				SteamUGC.SetItemTitle(ugcupdateHandle_t, this.ugcName);
			}
			SteamUGC.RemoveItemKeyValueTags(ugcupdateHandle_t, WorkshopDownloadRestrictions.IP_RESTRICTIONS_KVTAG);
			if (!string.IsNullOrEmpty(this.ugcAllowedIPs))
			{
				SteamUGC.AddItemKeyValueTag(ugcupdateHandle_t, WorkshopDownloadRestrictions.IP_RESTRICTIONS_KVTAG, this.ugcAllowedIPs);
			}
			SteamUGC.RemoveItemKeyValueTags(ugcupdateHandle_t, TempSteamworksWorkshop.COMPATIBILITY_VERSION_KVTAG);
			SteamUGC.AddItemKeyValueTag(ugcupdateHandle_t, TempSteamworksWorkshop.COMPATIBILITY_VERSION_KVTAG, 6.ToString());
			if (this.ugcVisibility == ESteamUGCVisibility.PUBLIC)
			{
				SteamUGC.SetItemVisibility(ugcupdateHandle_t, ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityPublic);
			}
			else if (this.ugcVisibility == ESteamUGCVisibility.FRIENDS_ONLY)
			{
				SteamUGC.SetItemVisibility(ugcupdateHandle_t, ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityFriendsOnly);
			}
			else if (this.ugcVisibility == ESteamUGCVisibility.PRIVATE)
			{
				SteamUGC.SetItemVisibility(ugcupdateHandle_t, ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityPrivate);
			}
			else if (this.ugcVisibility == ESteamUGCVisibility.UNLISTED)
			{
				SteamUGC.SetItemVisibility(ugcupdateHandle_t, ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityUnlisted);
			}
			SteamAPICall_t hAPICall = SteamUGC.SubmitItemUpdate(ugcupdateHandle_t, this.ugcChange);
			this.submitItemUpdateResult.Set(hAPICall, null);
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00009814 File Offset: 0x00007A14
		private bool isInstalledItemAlreadyRegistered(PublishedFileId_t fileId)
		{
			using (List<SteamContent>.Enumerator enumerator = this.ugc.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.publishedFileID == fileId)
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Get path to an already-installed workshop item.
		/// </summary>
		/// <returns>True if the path was found.</returns>
		// Token: 0x060001CD RID: 461 RVA: 0x00009874 File Offset: 0x00007A74
		private bool getInstalledItemPath(PublishedFileId_t fileId, out string path)
		{
			EItemState itemState = (EItemState)SteamUGC.GetItemState(fileId);
			if ((itemState & EItemState.k_EItemStateInstalled) != EItemState.k_EItemStateInstalled)
			{
				UnturnedLog.warn("Installed item {0} state flags missing k_EItemStateInstalled: {1}", new object[]
				{
					fileId,
					itemState
				});
			}
			ulong num;
			uint num2;
			return SteamUGC.GetItemInstallInfo(fileId, out num, out path, 1024U, out num2) && ReadWrite.folderExists(path, false);
		}

		/// <summary>
		/// Used during startup to register subscribed workshop items.
		/// Given a workshop item file id, if its files exist on disk then register it.
		/// </summary>
		// Token: 0x060001CE RID: 462 RVA: 0x000098CC File Offset: 0x00007ACC
		private void registerInstalledItem(PublishedFileId_t fileId)
		{
			if (this.isInstalledItemAlreadyRegistered(fileId))
			{
				return;
			}
			string text;
			if (TempSteamworksWorkshop.shouldIgnoreFile(fileId, out text))
			{
				UnturnedLog.info("Ignoring subscribed item {0} because '{1}'", new object[]
				{
					fileId,
					text
				});
				return;
			}
			string text2;
			if (!this.getInstalledItemPath(fileId, out text2))
			{
				UnturnedLog.warn("Unable to register installed item during startup: {0}\nPath:{1}", new object[]
				{
					fileId,
					text2
				});
				return;
			}
			ESteamUGCType esteamUGCType;
			if (!WorkshopTool.detectUGCMetaType(text2, false, out esteamUGCType))
			{
				string str = "Unable to determine UGC type for installed item: ";
				PublishedFileId_t publishedFileId_t = fileId;
				UnturnedLog.warn(str + publishedFileId_t.ToString());
				return;
			}
			string error;
			if (!TempSteamworksWorkshop.isCompatible(fileId, esteamUGCType, text2, out error))
			{
				Assets.reportError(error);
				return;
			}
			this.ugc.Add(new SteamContent(fileId, text2, esteamUGCType));
			if (!LocalWorkshopSettings.get().getEnabled(fileId))
			{
				return;
			}
			this.LoadFileIfAssetStartupAlreadyRan(fileId, text2, esteamUGCType);
		}

		/// <summary>
		/// Called when subscribed items callback was successful to register all compatible files.
		/// </summary>
		// Token: 0x060001CF RID: 463 RVA: 0x0000999C File Offset: 0x00007B9C
		private void handleSubscribedItemsCallbackSuccess(SteamUGCQueryCompleted_t callback)
		{
			UnturnedLog.info(string.Format("Received details for {0} subscribed workshop file(s)", callback.m_unNumResultsReturned));
			for (uint num = 0U; num < callback.m_unNumResultsReturned; num += 1U)
			{
				CachedUGCDetails cachedUGCDetails;
				if (TempSteamworksWorkshop.cacheDetails(callback.m_handle, num, out cachedUGCDetails))
				{
					UnturnedLog.info(string.Format("Subscribed workshop file {0} of {1}: \"{2}\" ({3})", new object[]
					{
						num + 1U,
						callback.m_unNumResultsReturned,
						cachedUGCDetails.name,
						cachedUGCDetails.fileId
					}));
					this.registerInstalledItem(cachedUGCDetails.fileId);
				}
			}
		}

		/// <summary>
		/// Called when subscribed items callback did not execute as expected,
		/// maybe because steam's servers are offline. In this case we can't check
		/// compatibility so we register all the locally subscribed items as compatible.
		/// </summary>
		// Token: 0x060001D0 RID: 464 RVA: 0x00009A38 File Offset: 0x00007C38
		private void handleSubscribedItemsCallbackFailed()
		{
			UnturnedLog.info("Registering {0} locally subscribed item(s)", new object[]
			{
				this.locallySubscribedFileIds.Length
			});
			foreach (PublishedFileId_t fileId in this.locallySubscribedFileIds)
			{
				this.registerInstalledItem(fileId);
			}
		}

		/// <summary>
		/// Register any localization-type workshop content before waiting for the steam callbacks.
		/// Important so that localizations are available for loading screens and whatnot during startup.
		/// Any items we register now will be skipped later.
		/// </summary>
		// Token: 0x060001D1 RID: 465 RVA: 0x00009A8C File Offset: 0x00007C8C
		private void registerLocalizations()
		{
			foreach (PublishedFileId_t fileId in this.locallySubscribedFileIds)
			{
				string path;
				ESteamUGCType esteamUGCType;
				if (this.getInstalledItemPath(fileId, out path) && WorkshopTool.detectUGCMetaType(path, false, out esteamUGCType) && esteamUGCType == ESteamUGCType.LOCALIZATION)
				{
					this.registerInstalledItem(fileId);
				}
			}
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00009AD8 File Offset: 0x00007CD8
		private void onSubscribedQueryCompleted(SteamUGCQueryCompleted_t callback, bool ioFailure)
		{
			if (callback.m_handle != this.subscribedQueryHandle)
			{
				return;
			}
			if (!ioFailure)
			{
				if (callback.m_eResult == EResult.k_EResultOK)
				{
					this.handleSubscribedItemsCallbackSuccess(callback);
				}
				else
				{
					UnturnedLog.error("Encountered an error when querying workshop for subscribed items: " + callback.m_eResult.ToString());
					this.handleSubscribedItemsCallbackFailed();
				}
			}
			else
			{
				UnturnedLog.error("Encountered an IO error when querying workshop for subscribed items!");
				this.handleSubscribedItemsCallbackFailed();
			}
			SteamUGC.ReleaseQueryUGCRequest(this.subscribedQueryHandle);
			this.subscribedQueryHandle = UGCQueryHandle_t.Invalid;
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00009B60 File Offset: 0x00007D60
		public void refreshUGC()
		{
			this._ugc = new List<SteamContent>();
			uint numSubscribedItems = SteamUGC.GetNumSubscribedItems();
			if (numSubscribedItems < 1U)
			{
				UnturnedLog.info("Found zero workshop file subscriptions");
				return;
			}
			if (TempSteamworksWorkshop.shouldIgnoreSubscribedItems)
			{
				UnturnedLog.info("Ignoring all workshop file subscriptions");
				return;
			}
			this.locallySubscribedFileIds = new PublishedFileId_t[numSubscribedItems];
			SteamUGC.GetSubscribedItems(this.locallySubscribedFileIds, numSubscribedItems);
			UnturnedLog.info("Subscribed workshop file ID(s): " + string.Join<PublishedFileId_t>(", ", this.locallySubscribedFileIds));
			this.registerLocalizations();
			UnturnedLog.info("Querying details for subscribed workshop files...");
			this.subscribedQueryHandle = SteamUGC.CreateQueryUGCDetailsRequest(this.locallySubscribedFileIds, numSubscribedItems);
			SteamUGC.SetReturnKeyValueTags(this.subscribedQueryHandle, true);
			SteamAPICall_t hAPICall = SteamUGC.SendQueryUGCRequest(this.subscribedQueryHandle);
			this.subscribedQueryCompleted.Set(hAPICall, null);
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x00009C24 File Offset: 0x00007E24
		public void refreshPublished()
		{
			TempSteamworksWorkshop.PublishedRemoved publishedRemoved = this.onPublishedRemoved;
			if (publishedRemoved != null)
			{
				publishedRemoved();
			}
			this.cleanupUGCRequest();
			this._published = new List<SteamPublished>();
			this.ugcRequestPage = 1U;
			this.shouldRequestAnotherPage = false;
			this.ugcRequest = SteamUGC.CreateQueryUserUGCRequest(Provider.client.GetAccountID(), EUserUGCList.k_EUserUGCList_Published, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items, EUserUGCListSortOrder.k_EUserUGCListSortOrder_CreationOrderAsc, SteamUtils.GetAppID(), SteamUtils.GetAppID(), this.ugcRequestPage);
			SteamAPICall_t hAPICall = SteamUGC.SendQueryUGCRequest(this.ugcRequest);
			this.queryCompleted.Set(hAPICall, null);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00009CA8 File Offset: 0x00007EA8
		public bool getSubscribed(ulong fileId)
		{
			if (this.ugc == null)
			{
				return false;
			}
			PublishedFileId_t publishedFileId_t = new PublishedFileId_t(fileId);
			bool result;
			if (this.ingameSubscriptions.TryGetValue(publishedFileId_t, out result))
			{
				return result;
			}
			using (List<SteamContent>.Enumerator enumerator = this.ugc.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.publishedFileID == publishedFileId_t)
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Called by us when we subscribe to an item from in-game.
		/// If item already exists on-disk steam doesn't always call onItemInstalled, so we do our own check and potentially load.
		/// </summary>
		// Token: 0x060001D6 RID: 470 RVA: 0x00009D2C File Offset: 0x00007F2C
		private void gameSubscribed(PublishedFileId_t fileId)
		{
			if (this.isInstalledItemAlreadyRegistered(fileId))
			{
				return;
			}
			EItemState itemState = (EItemState)SteamUGC.GetItemState(fileId);
			if ((itemState & EItemState.k_EItemStateInstalled) != EItemState.k_EItemStateInstalled)
			{
				return;
			}
			if ((itemState & EItemState.k_EItemStateDownloading) == EItemState.k_EItemStateDownloading)
			{
				return;
			}
			if ((itemState & EItemState.k_EItemStateDownloadPending) == EItemState.k_EItemStateDownloading)
			{
				return;
			}
			UnturnedLog.info("Triggering a fake onItemInstalled callback for {0} because game subscribed to a pre-installed item", new object[]
			{
				fileId
			});
			ItemInstalled_t callback;
			callback.m_unAppID.m_AppId = this.appInfo.id;
			callback.m_nPublishedFileId = fileId;
			this.onItemInstalled(callback);
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00009DA4 File Offset: 0x00007FA4
		public void setSubscribed(ulong fileId, bool subscribe)
		{
			PublishedFileId_t publishedFileId_t = new PublishedFileId_t(fileId);
			if (subscribe)
			{
				SteamUGC.SubscribeItem(publishedFileId_t);
				UnturnedLog.info("Game subscribed to " + fileId.ToString());
				this.gameSubscribed(publishedFileId_t);
			}
			else
			{
				SteamUGC.UnsubscribeItem(publishedFileId_t);
				UnturnedLog.info("Game un-subscribed from " + fileId.ToString());
			}
			this.ingameSubscriptions[publishedFileId_t] = subscribe;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x00009E0C File Offset: 0x0000800C
		public TempSteamworksWorkshop(SteamworksAppInfo newAppInfo)
		{
			this.appInfo = newAppInfo;
			this.downloaded = new List<PublishedFileId_t>();
			if (!this.appInfo.isDedicated)
			{
				this.createItemResult = CallResult<CreateItemResult_t>.Create(new CallResult<CreateItemResult_t>.APIDispatchDelegate(this.onCreateItemResult));
				this.submitItemUpdateResult = CallResult<SubmitItemUpdateResult_t>.Create(new CallResult<SubmitItemUpdateResult_t>.APIDispatchDelegate(this.onSubmitItemUpdateResult));
				this.queryCompleted = CallResult<SteamUGCQueryCompleted_t>.Create(new CallResult<SteamUGCQueryCompleted_t>.APIDispatchDelegate(this.onQueryCompleted));
				this.itemDownloaded = Callback<DownloadItemResult_t>.Create(new Callback<DownloadItemResult_t>.DispatchDelegate(this.onItemDownloaded));
				this.itemInstalled = Callback<ItemInstalled_t>.Create(new Callback<ItemInstalled_t>.DispatchDelegate(this.onItemInstalled));
				this.subscribedQueryCompleted = CallResult<SteamUGCQueryCompleted_t>.Create(new CallResult<SteamUGCQueryCompleted_t>.APIDispatchDelegate(this.onSubscribedQueryCompleted));
				this.serverItemsQueryCompleted = CallResult<SteamUGCQueryCompleted_t>.Create(new CallResult<SteamUGCQueryCompleted_t>.APIDispatchDelegate(this.onServerItemsQueryCompleted));
			}
		}

		/// <summary>
		/// Used when transitioning Unity versions breaks asset bundles. Replaced by AssetBundleVersion const values.
		/// </summary>
		// Token: 0x040000D5 RID: 213
		[Obsolete]
		public static readonly byte COMPATIBILITY_VERSION = 3;

		/// <summary>
		/// Workshop item key-value tag storing the version number.
		/// </summary>
		// Token: 0x040000D6 RID: 214
		public static readonly string COMPATIBILITY_VERSION_KVTAG = "compatibility_version";

		// Token: 0x040000D7 RID: 215
		private SteamworksAppInfo appInfo;

		// Token: 0x040000D8 RID: 216
		public TempSteamworksWorkshop.PublishedAdded onPublishedAdded;

		// Token: 0x040000D9 RID: 217
		public TempSteamworksWorkshop.PublishedRemoved onPublishedRemoved;

		// Token: 0x040000DA RID: 218
		private PublishedFileId_t publishedFileID;

		// Token: 0x040000DB RID: 219
		private UGCQueryHandle_t ugcRequest;

		// Token: 0x040000DC RID: 220
		private uint ugcRequestPage;

		// Token: 0x040000DD RID: 221
		private bool shouldRequestAnotherPage;

		// Token: 0x040000DE RID: 222
		private string ugcName;

		// Token: 0x040000DF RID: 223
		private string ugcDescription;

		// Token: 0x040000E0 RID: 224
		private string ugcPath;

		// Token: 0x040000E1 RID: 225
		private string ugcPreview;

		// Token: 0x040000E2 RID: 226
		private string ugcChange;

		// Token: 0x040000E3 RID: 227
		private ESteamUGCType ugcType;

		// Token: 0x040000E4 RID: 228
		private List<string> ugcTags;

		// Token: 0x040000E5 RID: 229
		private string ugcAllowedIPs;

		// Token: 0x040000E6 RID: 230
		private ESteamUGCVisibility ugcVisibility;

		// Token: 0x040000E7 RID: 231
		private bool ugcVerified;

		// Token: 0x040000E8 RID: 232
		public int totalNumberOfFilesToDownload;

		// Token: 0x040000E9 RID: 233
		private float progressPerFileDownloaded;

		// Token: 0x040000EA RID: 234
		public List<PublishedFileId_t> downloaded;

		// Token: 0x040000EB RID: 235
		public List<PublishedFileId_t> installing;

		// Token: 0x040000EC RID: 236
		private List<SteamContent> _ugc;

		// Token: 0x040000ED RID: 237
		private List<SteamPublished> _published;

		/// <summary>
		/// Maps published file id to name, version, etc.
		/// </summary>
		// Token: 0x040000EE RID: 238
		private static Dictionary<ulong, CachedUGCDetails> cachedUGCDetails = new Dictionary<ulong, CachedUGCDetails>();

		// Token: 0x040000EF RID: 239
		private static readonly PublishedFileId_t FRANCE = new PublishedFileId_t(1975500516UL);

		// Token: 0x040000F0 RID: 240
		private CallResult<CreateItemResult_t> createItemResult;

		// Token: 0x040000F1 RID: 241
		private CallResult<SubmitItemUpdateResult_t> submitItemUpdateResult;

		// Token: 0x040000F2 RID: 242
		private CallResult<SteamUGCQueryCompleted_t> queryCompleted;

		// Token: 0x040000F3 RID: 243
		private float currentlyDownloadingFileEstimatedProgress;

		// Token: 0x040000F4 RID: 244
		private int previousEstimatedDownloadProgress;

		// Token: 0x040000F5 RID: 245
		private PublishedFileId_t currentlyDownloadingFileId;

		// Token: 0x040000F6 RID: 246
		private UGCQueryHandle_t serverItemsQueryHandle;

		// Token: 0x040000F7 RID: 247
		private CallResult<SteamUGCQueryCompleted_t> serverItemsQueryCompleted;

		/// <summary>
		/// File IDs the client knows the server is using. Fallback in-case the query fails.
		/// </summary>
		// Token: 0x040000F8 RID: 248
		internal List<PublishedFileId_t> serverPendingIDs;

		/// <summary>
		/// IP of the currently connected server, or zero if unable to retrieve from network system.
		/// Used for testing download restrictions.
		/// </summary>
		// Token: 0x040000F9 RID: 249
		protected uint serverDownloadIP;

		// Token: 0x040000FB RID: 251
		private Callback<DownloadItemResult_t> itemDownloaded;

		/// <summary>
		/// Callback when player subscribes to an item and it finishes downloading.
		/// Different than the game-managed DownloadItem calls.
		/// </summary>
		// Token: 0x040000FC RID: 252
		private Callback<ItemInstalled_t> itemInstalled;

		/// <summary>
		/// Workshop file ids we were locally subscribed to during startup.
		/// These items are queried for compatibility before registering.
		/// </summary>
		// Token: 0x040000FD RID: 253
		private PublishedFileId_t[] locallySubscribedFileIds;

		// Token: 0x040000FE RID: 254
		private UGCQueryHandle_t subscribedQueryHandle;

		// Token: 0x040000FF RID: 255
		private CallResult<SteamUGCQueryCompleted_t> subscribedQueryCompleted;

		/// <summary>
		/// If specified, player's workshop file subscriptions are not registered at startup.
		/// </summary>
		// Token: 0x04000100 RID: 256
		private static CommandLineFlag shouldIgnoreSubscribedItems = new CommandLineFlag(false, "-NoWorkshopSubscriptions");

		/// <summary>
		/// Map of subscriptions added/removed by the player through the in-game client API, as opposed to the web browser.
		/// </summary>
		// Token: 0x04000101 RID: 257
		private Dictionary<PublishedFileId_t, bool> ingameSubscriptions = new Dictionary<PublishedFileId_t, bool>();

		// Token: 0x020008F4 RID: 2292
		// (Invoke) Token: 0x0600507C RID: 20604
		public delegate void PublishedAdded();

		// Token: 0x020008F5 RID: 2293
		// (Invoke) Token: 0x06005080 RID: 20608
		public delegate void PublishedRemoved();
	}
}
