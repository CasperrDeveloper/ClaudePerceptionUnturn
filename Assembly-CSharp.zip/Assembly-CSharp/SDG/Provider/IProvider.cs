﻿using System;
using SDG.Provider.Services.Achievements;
using SDG.Provider.Services.Browser;
using SDG.Provider.Services.Cloud;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Multiplayer;
using SDG.Provider.Services.Statistics;
using SDG.Provider.Services.Store;
using SDG.Provider.Services.Translation;

namespace SDG.Provider
{
	// Token: 0x02000030 RID: 48
	public interface IProvider
	{
		/// <summary>
		/// Current achievements implementation.
		/// </summary>
		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000127 RID: 295
		IAchievementsService achievementsService { get; }

		/// <summary>
		/// Current browser implementation.
		/// </summary>
		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000128 RID: 296
		IBrowserService browserService { get; }

		/// <summary>
		/// Current cloud implementation.
		/// </summary>
		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000129 RID: 297
		ICloudService cloudService { get; }

		/// <summary>
		/// Current community implementation.
		/// </summary>
		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600012A RID: 298
		ICommunityService communityService { get; }

		/// <summary>
		/// Current economy implementation.
		/// </summary>
		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600012B RID: 299
		TempSteamworksEconomy economyService { get; }

		/// <summary>
		/// Current matchmaking implementation.
		/// </summary>
		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600012C RID: 300
		TempSteamworksMatchmaking matchmakingService { get; }

		/// <summary>
		/// Current multiplayer implementation.
		/// </summary>
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600012D RID: 301
		IMultiplayerService multiplayerService { get; }

		/// <summary>
		/// Current statistics implementation.
		/// </summary>
		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600012E RID: 302
		IStatisticsService statisticsService { get; }

		/// <summary>
		/// Current store implementation.
		/// </summary>
		// Token: 0x1700003B RID: 59
		// (get) Token: 0x0600012F RID: 303
		IStoreService storeService { get; }

		/// <summary>
		/// Current translation implementation.
		/// </summary>
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000130 RID: 304
		ITranslationService translationService { get; }

		/// <summary>
		/// Current workshop implementation.
		/// </summary>
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000131 RID: 305
		TempSteamworksWorkshop workshopService { get; }

		/// <summary>
		/// Initialize this provider's external API. Should be called before using provider features.
		/// </summary>
		/// <exception cref="T:System.Exception">Thrown if initializing fails.</exception>
		// Token: 0x06000132 RID: 306
		void intialize();

		/// <summary>
		/// Update this provider's external API. Should be called every frame if using provider features.
		/// </summary>
		// Token: 0x06000133 RID: 307
		void update();

		/// <summary>
		/// Shutdown this provider's external API. Should be called before closing the program if using provider features.
		/// </summary>
		// Token: 0x06000134 RID: 308
		void shutdown();
	}
}
