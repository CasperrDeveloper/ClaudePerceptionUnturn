﻿using System;

namespace SDG.Provider
{
	// Token: 0x02000035 RID: 53
	public enum EStatTrackerType
	{
		// Token: 0x04000090 RID: 144
		NONE,
		// Token: 0x04000091 RID: 145
		TOTAL,
		// Token: 0x04000092 RID: 146
		PLAYER
	}
}
