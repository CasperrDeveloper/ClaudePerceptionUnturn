﻿using System;

namespace SDG.Provider.Services.Browser
{
	// Token: 0x02000068 RID: 104
	public interface IBrowserService : IService
	{
		/// <summary>
		/// Whether the user has their overlay enabled.
		/// </summary>
		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600025A RID: 602
		bool canOpenBrowser { get; }

		// Token: 0x0600025B RID: 603
		void open(string url);
	}
}
