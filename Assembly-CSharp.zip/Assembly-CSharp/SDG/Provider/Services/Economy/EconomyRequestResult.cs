﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x0200005D RID: 93
	public class EconomyRequestResult : IEconomyRequestResult
	{
		// Token: 0x17000068 RID: 104
		// (get) Token: 0x0600023F RID: 575 RVA: 0x00009FED File Offset: 0x000081ED
		// (set) Token: 0x06000240 RID: 576 RVA: 0x00009FF5 File Offset: 0x000081F5
		public EEconomyRequestState economyRequestState { get; protected set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000241 RID: 577 RVA: 0x00009FFE File Offset: 0x000081FE
		// (set) Token: 0x06000242 RID: 578 RVA: 0x0000A006 File Offset: 0x00008206
		public IEconomyItem[] items { get; protected set; }

		// Token: 0x06000243 RID: 579 RVA: 0x0000A00F File Offset: 0x0000820F
		public EconomyRequestResult(EEconomyRequestState newEconomyRequestState, IEconomyItem[] newItems)
		{
			this.economyRequestState = newEconomyRequestState;
			this.items = newItems;
		}
	}
}
