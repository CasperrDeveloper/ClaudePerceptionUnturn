﻿using System;
using SDG.Framework.IO.Streams;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x02000060 RID: 96
	public interface IEconomyItemDefinition : INetworkStreamable
	{
		// Token: 0x06000246 RID: 582
		string getPropertyValue(string key);
	}
}
