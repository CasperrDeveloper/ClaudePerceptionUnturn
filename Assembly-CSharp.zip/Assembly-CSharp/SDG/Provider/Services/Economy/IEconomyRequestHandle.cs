﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x02000062 RID: 98
	public interface IEconomyRequestHandle
	{
	}
}
