﻿using System;
using SDG.Framework.IO.Streams;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x0200005F RID: 95
	public interface IEconomyItem : INetworkStreamable
	{
		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000244 RID: 580
		IEconomyItemDefinition itemDefinitionID { get; }

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000245 RID: 581
		IEconomyItemInstance itemInstanceID { get; }
	}
}
