﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x02000063 RID: 99
	public interface IEconomyRequestResult
	{
		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000247 RID: 583
		EEconomyRequestState economyRequestState { get; }

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000248 RID: 584
		IEconomyItem[] items { get; }
	}
}
