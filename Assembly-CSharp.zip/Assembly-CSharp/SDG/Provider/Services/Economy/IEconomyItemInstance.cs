﻿using System;
using SDG.Framework.IO.Streams;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x02000061 RID: 97
	public interface IEconomyItemInstance : INetworkStreamable
	{
	}
}
