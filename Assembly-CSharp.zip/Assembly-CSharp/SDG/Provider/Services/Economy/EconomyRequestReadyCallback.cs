﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x0200005C RID: 92
	// (Invoke) Token: 0x0600023C RID: 572
	public delegate void EconomyRequestReadyCallback(IEconomyRequestHandle economyRequestHandle, IEconomyRequestResult economyRequestResult);
}
