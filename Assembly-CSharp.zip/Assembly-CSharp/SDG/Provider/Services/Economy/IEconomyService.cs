﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x02000064 RID: 100
	public interface IEconomyService : IService
	{
		/// <summary>
		/// Whether the user has their overlay enabled.
		/// </summary>
		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000249 RID: 585
		bool canOpenInventory { get; }

		/// <summary>
		/// Requests the user's inventory.
		/// </summary>
		/// <param name="economyRequestReadyCallback">Called when the request is completed.</param>
		/// <returns>Handle for checking the owner of the callback.</returns>
		// Token: 0x0600024A RID: 586
		IEconomyRequestHandle requestInventory(EconomyRequestReadyCallback economyRequestReadyCallback);

		/// <summary>
		/// Requests a check for promotional items.
		/// </summary>
		/// <param name="economyRequestReadyCallback">Called when the request is completed.</param>
		/// <returns>Handle for checking the owner of the callback.</returns>
		// Token: 0x0600024B RID: 587
		IEconomyRequestHandle requestPromo(EconomyRequestReadyCallback economyRequestReadyCallback);

		/// <summary>
		/// Converts the input items into the output items.
		/// </summary>
		/// <param name="inputItemInstanceIDs">Items to be converted from.</param>
		/// <param name="inputItemQuantities">Item amounts to be consumed.</param>
		/// <param name="outputItemDefinitionIDs">Items to be converted to.</param>
		/// <param name="outputItemQuantities">Item amounts to be generated.</param>
		/// <param name="economyRequestReadyCallback">Called when the exchange is completed.</param>
		// Token: 0x0600024C RID: 588
		IEconomyRequestHandle exchangeItems(IEconomyItemInstance[] inputItemInstanceIDs, uint[] inputItemQuantities, IEconomyItemDefinition[] outputItemDefinitionIDs, uint[] outputItemQuantities, EconomyRequestReadyCallback economyRequestReadyCallback);

		// Token: 0x0600024D RID: 589
		void open(ulong id);
	}
}
