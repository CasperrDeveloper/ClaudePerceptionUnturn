﻿using System;

namespace SDG.Provider.Services.Economy
{
	// Token: 0x0200005E RID: 94
	public enum EEconomyRequestState
	{
		// Token: 0x0400012A RID: 298
		SUCCESS,
		// Token: 0x0400012B RID: 299
		FAILURE
	}
}
