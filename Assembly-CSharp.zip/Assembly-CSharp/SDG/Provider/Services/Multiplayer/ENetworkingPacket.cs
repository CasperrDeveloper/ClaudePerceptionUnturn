﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000053 RID: 83
	public enum ENetworkingPacket
	{

	}
}
