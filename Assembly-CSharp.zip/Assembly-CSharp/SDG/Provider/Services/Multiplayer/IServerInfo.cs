﻿using System;
using SDG.Provider.Services.Community;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000052 RID: 82
	public interface IServerInfo
	{
		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600020B RID: 523
		ICommunityEntity entity { get; }

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600020C RID: 524
		string name { get; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x0600020D RID: 525
		byte players { get; }

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600020E RID: 526
		byte capacity { get; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600020F RID: 527
		int ping { get; }
	}
}
