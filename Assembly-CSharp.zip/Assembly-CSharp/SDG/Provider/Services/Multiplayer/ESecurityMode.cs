﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x0200004F RID: 79
	public enum ESecurityMode
	{
		// Token: 0x04000119 RID: 281
		LAN,
		// Token: 0x0400011A RID: 282
		SECURE,
		// Token: 0x0400011B RID: 283
		INSECURE
	}
}
