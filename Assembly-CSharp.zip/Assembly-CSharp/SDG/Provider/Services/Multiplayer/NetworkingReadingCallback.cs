﻿using System;
using System.IO;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000057 RID: 87
	// (Invoke) Token: 0x06000219 RID: 537
	public delegate void NetworkingReadingCallback(MemoryStream bufferStream, BinaryReader bufferReader);
}
