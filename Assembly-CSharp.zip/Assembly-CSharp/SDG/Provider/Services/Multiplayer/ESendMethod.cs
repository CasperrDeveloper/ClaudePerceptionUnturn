﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000050 RID: 80
	public enum ESendMethod
	{
		// Token: 0x0400011D RID: 285
		RELIABLE,
		// Token: 0x0400011E RID: 286
		RELIABLE_NODELAY,
		// Token: 0x0400011F RID: 287
		UNRELIABLE,
		// Token: 0x04000120 RID: 288
		UNRELIABLE_NODELAY
	}
}
