﻿using System;
using SDG.Provider.Services.Multiplayer.Client;
using SDG.Provider.Services.Multiplayer.Server;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000051 RID: 81
	public interface IMultiplayerService : IService
	{
		/// <summary>
		/// Current client multiplayer implementation.
		/// </summary>
		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000209 RID: 521
		IClientMultiplayerService clientMultiplayerService { get; }

		/// <summary>
		/// Current server multiplayer implementation.
		/// </summary>
		// Token: 0x17000057 RID: 87
		// (get) Token: 0x0600020A RID: 522
		IServerMultiplayerService serverMultiplayerService { get; }
	}
}
