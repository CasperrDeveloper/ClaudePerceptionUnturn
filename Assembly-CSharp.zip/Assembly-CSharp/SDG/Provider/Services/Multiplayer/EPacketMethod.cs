﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000054 RID: 84
	public enum EPacketMethod
	{
		// Token: 0x04000123 RID: 291
		UNRELIABLE,
		// Token: 0x04000124 RID: 292
		UNRELIABLE_NODELAY,
		// Token: 0x04000125 RID: 293
		RELIABLE,
		// Token: 0x04000126 RID: 294
		RELIABLE_NODELAY
	}
}
