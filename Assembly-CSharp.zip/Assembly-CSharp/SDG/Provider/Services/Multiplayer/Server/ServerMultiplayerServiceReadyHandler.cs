﻿using System;

namespace SDG.Provider.Services.Multiplayer.Server
{
	// Token: 0x02000059 RID: 89
	// (Invoke) Token: 0x06000221 RID: 545
	public delegate void ServerMultiplayerServiceReadyHandler();
}
