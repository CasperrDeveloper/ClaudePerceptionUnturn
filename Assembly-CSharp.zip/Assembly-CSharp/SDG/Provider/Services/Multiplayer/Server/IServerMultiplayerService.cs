﻿using System;
using System.IO;
using SDG.Provider.Services.Community;

namespace SDG.Provider.Services.Multiplayer.Server
{
	// Token: 0x0200005A RID: 90
	public interface IServerMultiplayerService : IService
	{
		/// <summary>
		/// Information about currently hosted server.
		/// </summary>
		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000224 RID: 548
		IServerInfo serverInfo { get; }

		/// <summary>
		/// Whether a server is open.
		/// </summary>
		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000225 RID: 549
		bool isHosting { get; }

		/// <summary>
		/// Network buffer memory stream.
		/// </summary>
		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000226 RID: 550
		MemoryStream stream { get; }

		/// <summary>
		/// Network buffer memory stream reader.
		/// </summary>
		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000227 RID: 551
		BinaryReader reader { get; }

		/// <summary>
		/// Network buffer memory stream writer.
		/// </summary>
		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000228 RID: 552
		BinaryWriter writer { get; }

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000229 RID: 553
		// (remove) Token: 0x0600022A RID: 554
		event ServerMultiplayerServiceReadyHandler ready;

		/// <summary>
		/// Open a new server.
		/// </summary>
		// Token: 0x0600022B RID: 555
		void open(uint ip, ushort port, ESecurityMode security);

		/// <summary>
		/// Close an existing server.
		/// </summary>
		// Token: 0x0600022C RID: 556
		void close();

		/// <summary>
		/// Receive a packet from an entity across the network.
		/// </summary>
		/// <param name="entity">Sender of data.</param>
		/// <param name="data"></param>
		/// <param name="length"></param>
		/// <returns>Whether any data was read.</returns>
		// Token: 0x0600022D RID: 557
		bool read(out ICommunityEntity entity, byte[] data, out ulong length, int channel);

		/// <summary>
		/// Send a packet to an entity across the network.
		/// </summary>
		/// <param name="entity">Recipient of data.</param>
		/// <param name="data">Packet to send.</param>
		/// <param name="length">Size of data in array.</param>
		// Token: 0x0600022E RID: 558
		void write(ICommunityEntity entity, byte[] data, ulong length);

		/// <summary>
		/// Send a packet to an entity across the network.
		/// </summary>
		/// <param name="entity">Recipient of data.</param>
		/// <param name="data">Packet to send.</param>
		/// <param name="length">Size of data in array.</param>
		/// <param name="method">Type of send to use.</param>
		// Token: 0x0600022F RID: 559
		[Obsolete("Used by old multiplayer code, please use send without method instead.")]
		void write(ICommunityEntity entity, byte[] data, ulong length, ESendMethod method, int channel);
	}
}
