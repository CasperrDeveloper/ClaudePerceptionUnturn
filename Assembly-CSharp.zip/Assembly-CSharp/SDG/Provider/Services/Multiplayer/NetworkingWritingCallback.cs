﻿using System;
using System.IO;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000058 RID: 88
	// (Invoke) Token: 0x0600021D RID: 541
	public delegate void NetworkingWritingCallback(MemoryStream bufferStream, BinaryWriter bufferWriter);
}
