﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000055 RID: 85
	// (Invoke) Token: 0x06000211 RID: 529
	public delegate void NetworkingConnected();
}
