﻿using System;

namespace SDG.Provider.Services.Multiplayer
{
	// Token: 0x02000056 RID: 86
	// (Invoke) Token: 0x06000215 RID: 533
	public delegate void NetworkingDisconnected();
}
