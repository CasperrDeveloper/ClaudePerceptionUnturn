﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x02000049 RID: 73
	public interface IServerInfoRequestHandle
	{
	}
}
