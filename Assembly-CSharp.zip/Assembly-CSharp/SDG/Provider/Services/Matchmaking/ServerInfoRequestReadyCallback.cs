﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x0200004B RID: 75
	// (Invoke) Token: 0x060001FF RID: 511
	public delegate void ServerInfoRequestReadyCallback(IServerInfoRequestHandle handle, IServerInfoRequestResult result);
}
