﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x0200004D RID: 77
	public interface IMatchmakingFilter
	{
		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000202 RID: 514
		string key { get; }

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000203 RID: 515
		string value { get; }
	}
}
