﻿using System;
using SDG.Provider.Services.Multiplayer;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x0200004A RID: 74
	public interface IServerInfoRequestResult
	{
		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060001FD RID: 509
		IServerInfo serverInfo { get; }
	}
}
