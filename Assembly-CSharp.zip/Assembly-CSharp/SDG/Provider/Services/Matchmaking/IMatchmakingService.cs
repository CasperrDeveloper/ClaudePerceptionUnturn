﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x02000048 RID: 72
	public interface IMatchmakingService : IService
	{
		// Token: 0x060001FC RID: 508
		IServerInfoRequestHandle requestServerInfo(uint ip, ushort port, ServerInfoRequestReadyCallback callback);
	}
}
