﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x0200004C RID: 76
	public enum EServerList
	{
		// Token: 0x04000111 RID: 273
		INTERNET,
		// Token: 0x04000112 RID: 274
		LAN,
		// Token: 0x04000113 RID: 275
		HISTORY,
		// Token: 0x04000114 RID: 276
		FAVORITES,
		// Token: 0x04000115 RID: 277
		FRIENDS
	}
}
