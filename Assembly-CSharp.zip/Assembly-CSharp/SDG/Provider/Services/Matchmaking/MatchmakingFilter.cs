﻿using System;

namespace SDG.Provider.Services.Matchmaking
{
	// Token: 0x0200004E RID: 78
	public class MatchmakingFilter : IMatchmakingFilter
	{
		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000204 RID: 516 RVA: 0x00009FB5 File Offset: 0x000081B5
		// (set) Token: 0x06000205 RID: 517 RVA: 0x00009FBD File Offset: 0x000081BD
		public string key { get; protected set; }

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000206 RID: 518 RVA: 0x00009FC6 File Offset: 0x000081C6
		// (set) Token: 0x06000207 RID: 519 RVA: 0x00009FCE File Offset: 0x000081CE
		public string value { get; protected set; }

		// Token: 0x06000208 RID: 520 RVA: 0x00009FD7 File Offset: 0x000081D7
		public MatchmakingFilter(string newKey, string newValue)
		{
			this.key = newKey;
			this.value = newValue;
		}
	}
}
