﻿using System;

namespace SDG.Provider.Services.Translation
{
	// Token: 0x02000040 RID: 64
	public interface ITranslationService : IService
	{
		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060001E4 RID: 484
		string language { get; }
	}
}
