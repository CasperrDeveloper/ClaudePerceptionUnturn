﻿using System;

namespace SDG.Provider.Services.Workshop
{
	// Token: 0x0200003E RID: 62
	public interface IWorkshopFile
	{
	}
}
