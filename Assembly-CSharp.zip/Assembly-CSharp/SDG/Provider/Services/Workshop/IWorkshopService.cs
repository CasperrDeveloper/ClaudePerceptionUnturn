﻿using System;
using Steamworks;

namespace SDG.Provider.Services.Workshop
{
	// Token: 0x0200003F RID: 63
	public interface IWorkshopService : IService
	{
		/// <summary>
		/// Whether the user has their overlay enabled.
		/// </summary>
		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060001E2 RID: 482
		bool canOpenWorkshop { get; }

		// Token: 0x060001E3 RID: 483
		void open(PublishedFileId_t id);
	}
}
