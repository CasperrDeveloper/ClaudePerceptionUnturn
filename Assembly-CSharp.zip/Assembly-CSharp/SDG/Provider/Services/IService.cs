﻿using System;

namespace SDG.Provider.Services
{
	// Token: 0x0200003C RID: 60
	public interface IService
	{
		/// <summary>
		/// Initialize this service's external API. Should be called before using.
		/// </summary>
		// Token: 0x060001DB RID: 475
		void initialize();

		/// <summary>
		/// Update this service's external API. Should be called every frame.
		/// </summary>
		// Token: 0x060001DC RID: 476
		void update();

		/// <summary>
		/// Shutdown this service's external API. Should be called before closing the program.
		/// </summary>
		// Token: 0x060001DD RID: 477
		void shutdown();
	}
}
