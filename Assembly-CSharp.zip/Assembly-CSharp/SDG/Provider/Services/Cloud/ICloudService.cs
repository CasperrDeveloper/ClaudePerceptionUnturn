﻿using System;

namespace SDG.Provider.Services.Cloud
{
	// Token: 0x02000067 RID: 103
	public interface ICloudService : IService
	{
		/// <summary>
		/// Reads data into the data array.
		/// </summary>
		/// <param name="path">The file path to read from.</param>
		/// <param name="data">The array to read into.</param>
		/// <returns>Whether the read succesfully executed.</returns>
		// Token: 0x06000255 RID: 597
		bool read(string path, byte[] data);

		/// <summary>
		/// Writes data out of data array.
		/// </summary>
		/// <param name="path">The file path to write to.</param>
		/// <param name="data">The array to write from.</param>
		/// <param name="size">The length of the array with data.</param>
		/// <returns>Whether the write succesfully executed.</returns>
		// Token: 0x06000256 RID: 598
		bool write(string path, byte[] data, int size);

		/// <summary>
		/// Checks the size of a file.
		/// </summary>
		/// <param name="path">The file path to check.</param>
		/// <param name="size">The size of the file.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x06000257 RID: 599
		bool getSize(string path, out int size);

		/// <summary>
		/// Checks whether the path already exists.
		/// </summary>
		/// <param name="path">The file path to check.</param>
		/// <param name="exists">Whether the file exists.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x06000258 RID: 600
		bool exists(string path, out bool exists);

		/// <summary>
		/// Deletes the path.
		/// </summary>
		/// <param name="path">The file path to delete.</param>
		/// <returns>Whether the deletion succesfully executed.</returns>
		// Token: 0x06000259 RID: 601
		bool delete(string path);
	}
}
