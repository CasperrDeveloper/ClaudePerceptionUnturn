﻿using System;
using SDG.Unturned;
using Steamworks;
using UnityEngine;

namespace SDG.Provider.Services.Community
{
	// Token: 0x02000066 RID: 102
	public interface ICommunityService : IService
	{
		// Token: 0x0600024F RID: 591
		void setStatus(string status);

		// Token: 0x06000250 RID: 592
		Texture2D getIcon(int id);

		// Token: 0x06000251 RID: 593
		Texture2D getIcon(CSteamID steamID, bool shouldCache = false);

		// Token: 0x06000252 RID: 594
		SteamGroup getCachedGroup(CSteamID steamID);

		// Token: 0x06000253 RID: 595
		SteamGroup[] getGroups();

		// Token: 0x06000254 RID: 596
		bool checkGroup(CSteamID steamID);
	}
}
