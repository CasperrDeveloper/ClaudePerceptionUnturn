﻿using System;
using SDG.Framework.IO.Streams;

namespace SDG.Provider.Services.Community
{
	// Token: 0x02000065 RID: 101
	public interface ICommunityEntity : INetworkStreamable
	{
		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600024E RID: 590
		bool isValid { get; }
	}
}
