﻿using System;

namespace SDG.Provider.Services
{
	// Token: 0x0200003D RID: 61
	public class Service : IService
	{
		// Token: 0x060001DE RID: 478 RVA: 0x00009FA7 File Offset: 0x000081A7
		public virtual void initialize()
		{
		}

		// Token: 0x060001DF RID: 479 RVA: 0x00009FA9 File Offset: 0x000081A9
		public virtual void update()
		{
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00009FAB File Offset: 0x000081AB
		public virtual void shutdown()
		{
		}
	}
}
