﻿using System;

namespace SDG.Provider.Services.Store
{
	// Token: 0x02000042 RID: 66
	public interface IStoreService : IService
	{
		/// <summary>
		/// View a package on the store.
		/// </summary>
		/// <param name="packageID">Package to view.</param>
		// Token: 0x060001E5 RID: 485
		void open(IStorePackageID packageID);
	}
}
