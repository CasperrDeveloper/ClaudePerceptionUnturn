﻿using System;

namespace SDG.Provider.Services.Store
{
	// Token: 0x02000041 RID: 65
	public interface IStorePackageID
	{
	}
}
