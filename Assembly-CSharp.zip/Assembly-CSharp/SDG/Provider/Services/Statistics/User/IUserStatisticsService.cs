﻿using System;

namespace SDG.Provider.Services.Statistics.User
{
	// Token: 0x02000044 RID: 68
	public interface IUserStatisticsService : IService
	{
		/// <summary>
		/// Triggered when the user's statistics are available.
		/// </summary>
		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060001E8 RID: 488
		// (remove) Token: 0x060001E9 RID: 489
		event UserStatisticsRequestReady onUserStatisticsRequestReady;

		/// <summary>
		/// Checks the current user's statistics with this name.
		/// </summary>
		/// <param name="name">The name of the statistic.</param>
		/// <param name="data">The value of the statistic.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x060001EA RID: 490
		bool getStatistic(string name, out int data);

		/// <summary>
		/// Assigns the current user's statistics with this name.
		/// </summary>
		/// <param name="name">The name of the statistic.</param>
		/// <param name="data">The value of the statistic.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x060001EB RID: 491
		bool setStatistic(string name, int data);

		/// <summary>
		/// Checks the current user's statistics with this name.
		/// </summary>
		/// <param name="name">The name of the statistic.</param>
		/// <param name="data">The value of the statistic.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x060001EC RID: 492
		bool getStatistic(string name, out float data);

		/// <summary>
		/// Assigns the current user's statistics with this name.
		/// </summary>
		/// <param name="name">The name of the statistic.</param>
		/// <param name="data">The value of the statistic.</param>
		/// <returns>Whether the check succesfully executed.</returns>
		// Token: 0x060001ED RID: 493
		bool setStatistic(string name, float data);

		/// <summary>
		/// Requests the user's statistics.
		/// </summary>
		/// <returns>Whether the refresh succesfully executed.</returns>
		// Token: 0x060001EE RID: 494
		bool requestStatistics();
	}
}
