﻿using System;
using SDG.Provider.Services.Community;

namespace SDG.Provider.Services.Statistics.User
{
	// Token: 0x02000045 RID: 69
	// (Invoke) Token: 0x060001F0 RID: 496
	public delegate void UserStatisticsRequestReady(ICommunityEntity entityID);
}
