﻿using System;

namespace SDG.Provider.Services.Statistics.Global
{
	// Token: 0x02000046 RID: 70
	// (Invoke) Token: 0x060001F4 RID: 500
	public delegate void GlobalStatisticsRequestReady();
}
