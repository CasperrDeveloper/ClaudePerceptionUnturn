﻿using System;
using SDG.Provider.Services.Statistics.Global;
using SDG.Provider.Services.Statistics.User;

namespace SDG.Provider.Services.Statistics
{
	// Token: 0x02000043 RID: 67
	public interface IStatisticsService : IService
	{
		/// <summary>
		/// Current user statistics implementation.
		/// </summary>
		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060001E6 RID: 486
		IUserStatisticsService userStatisticsService { get; }

		/// <summary>
		/// Current global statistics implementation.
		/// </summary>
		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060001E7 RID: 487
		IGlobalStatisticsService globalStatisticsService { get; }
	}
}
