﻿using System;

namespace SDG.Provider
{
	// Token: 0x02000033 RID: 51
	public struct StatTrackerTotalKillsJson
	{
		// Token: 0x0400008D RID: 141
		public int total_kills;
	}
}
