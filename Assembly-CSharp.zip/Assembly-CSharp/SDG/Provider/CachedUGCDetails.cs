﻿using System;
using Steamworks;

namespace SDG.Provider
{
	/// <summary>
	/// Details of a workshop item that the game may want to refer to later.
	/// Cached during client startup after getting installed items, and while
	/// downloading UGC for the dedicated server.
	/// </summary>
	// Token: 0x02000039 RID: 57
	public struct CachedUGCDetails
	{
		/// <summary>
		/// Some workshop copyright infringers use an empty title, in which case we show the file ID as title text.
		/// </summary>
		// Token: 0x060001A4 RID: 420 RVA: 0x00008484 File Offset: 0x00006684
		public string GetTitle()
		{
			if (!string.IsNullOrEmpty(this.name))
			{
				return this.name;
			}
			return this.fileId.ToString();
		}

		// Token: 0x040000D0 RID: 208
		public PublishedFileId_t fileId;

		// Token: 0x040000D1 RID: 209
		public string name;

		// Token: 0x040000D2 RID: 210
		public byte compatibilityVersion;

		/// <summary>
		/// Banned workshop files are shown in red.
		/// </summary>
		// Token: 0x040000D3 RID: 211
		public bool isBannedOrPrivate;

		/// <summary>
		/// Used on dedicated server to test whether map has been updated, and whether local copy of file is out-of-date.
		/// </summary>
		// Token: 0x040000D4 RID: 212
		public uint updateTimestamp;
	}
}
