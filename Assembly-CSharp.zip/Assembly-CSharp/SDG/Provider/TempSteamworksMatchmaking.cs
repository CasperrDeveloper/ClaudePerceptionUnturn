﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using SDG.HostBans;
using SDG.Unturned;
using Steamworks;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Provider
{
	// Token: 0x02000038 RID: 56
	public class TempSteamworksMatchmaking
	{
		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000181 RID: 385 RVA: 0x000072A4 File Offset: 0x000054A4
		// (remove) Token: 0x06000182 RID: 386 RVA: 0x000072DC File Offset: 0x000054DC
		public event TempSteamworksMatchmaking.AttemptUpdated onAttemptUpdated;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000183 RID: 387 RVA: 0x00007314 File Offset: 0x00005514
		// (remove) Token: 0x06000184 RID: 388 RVA: 0x0000734C File Offset: 0x0000554C
		public event TempSteamworksMatchmaking.TimedOut onTimedOut;

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000185 RID: 389 RVA: 0x00007381 File Offset: 0x00005581
		public ESteamServerList currentList
		{
			get
			{
				return this._currentList;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000186 RID: 390 RVA: 0x00007389 File Offset: 0x00005589
		public List<SteamServerAdvertisement> serverList
		{
			get
			{
				return this._serverList;
			}
		}

		/// <summary>
		/// Used to show a warning when a lot of servers are blocked by curation list.
		/// </summary>
		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000187 RID: 391 RVA: 0x00007391 File Offset: 0x00005591
		// (set) Token: 0x06000188 RID: 392 RVA: 0x00007399 File Offset: 0x00005599
		public int CuratorBlockedServerCount { get; private set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000189 RID: 393 RVA: 0x000073A2 File Offset: 0x000055A2
		// (set) Token: 0x0600018A RID: 394 RVA: 0x000073AA File Offset: 0x000055AA
		public bool isAttemptingServerQuery { get; private set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600018B RID: 395 RVA: 0x000073B3 File Offset: 0x000055B3
		public IComparer<SteamServerAdvertisement> serverInfoComparer
		{
			get
			{
				return this._serverInfoComparer;
			}
		}

		// Token: 0x0600018C RID: 396 RVA: 0x000073BB File Offset: 0x000055BB
		public void sortMasterServer(IComparer<SteamServerAdvertisement> newServerInfoComparer)
		{
			this._serverInfoComparer = newServerInfoComparer;
			this.serverList.Sort(this.serverInfoComparer);
			TempSteamworksMatchmaking.MasterServerResorted masterServerResorted = this.onMasterServerResorted;
			if (masterServerResorted == null)
			{
				return;
			}
			masterServerResorted();
		}

		// Token: 0x0600018D RID: 397 RVA: 0x000073E5 File Offset: 0x000055E5
		private void cleanupServerQuery()
		{
			if (this.serverQuery == HServerQuery.Invalid)
			{
				return;
			}
			SteamMatchmakingServers.CancelServerQuery(this.serverQuery);
			this.serverQuery = HServerQuery.Invalid;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00007410 File Offset: 0x00005610
		private void cleanupPlayersQuery()
		{
			if (this.playersQuery == HServerQuery.Invalid)
			{
				return;
			}
			SteamMatchmakingServers.CancelServerQuery(this.playersQuery);
			this.playersQuery = HServerQuery.Invalid;
		}

		// Token: 0x0600018F RID: 399 RVA: 0x0000743B File Offset: 0x0000563B
		private void cleanupRulesQuery()
		{
			if (this.rulesQuery == HServerQuery.Invalid)
			{
				return;
			}
			SteamMatchmakingServers.CancelServerQuery(this.rulesQuery);
			this.rulesQuery = HServerQuery.Invalid;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00007466 File Offset: 0x00005666
		private void cleanupServerListRequest()
		{
			if (this.serverListRequest == HServerListRequest.Invalid)
			{
				return;
			}
			SteamMatchmakingServers.ReleaseRequest(this.serverListRequest);
			this.serverListRequest = HServerListRequest.Invalid;
			this.serverListRefreshIndex = -1;
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00007498 File Offset: 0x00005698
		public void connect(SteamConnectionInfo info)
		{
			if (Provider.isConnected)
			{
				return;
			}
			this.connectionInfo = info;
			this.serverQueryAttempts = 0;
			this.isAttemptingServerQuery = true;
			this.autoJoinServerQuery = false;
			this.serverQueryContext = MenuPlayServerInfoUI.EServerInfoOpenContext.CONNECT;
			this.attemptServerQuery();
		}

		// Token: 0x06000192 RID: 402 RVA: 0x000074CB File Offset: 0x000056CB
		public void cancel()
		{
			if (!this.isAttemptingServerQuery)
			{
				return;
			}
			this.serverQueryAttempts = 99;
			this.onPingFailedToRespond();
		}

		// Token: 0x06000193 RID: 403 RVA: 0x000074E4 File Offset: 0x000056E4
		private void attemptServerQuery()
		{
			this.cleanupServerQuery();
			this.serverQuery = SteamMatchmakingServers.PingServer(this.connectionInfo.ip, this.connectionInfo.port, this.serverPingResponse);
			this.serverQueryAttempts++;
			TempSteamworksMatchmaking.AttemptUpdated attemptUpdated = this.onAttemptUpdated;
			if (attemptUpdated == null)
			{
				return;
			}
			attemptUpdated(this.serverQueryAttempts);
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00007542 File Offset: 0x00005742
		public void cancelRequest()
		{
			if (this.serverListRequest != HServerListRequest.Invalid)
			{
				SteamMatchmakingServers.CancelQuery(this.serverListRequest);
				this.cleanupServerListRequest();
			}
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00007568 File Offset: 0x00005768
		public void refreshMasterServer(ServerListFilters inputFilters)
		{
			this._currentList = inputFilters.listSource;
			this.currentPluginsFilter = inputFilters.plugins;
			this.currentNameFilter = inputFilters.serverName;
			this.isCurrentNameFilterSet = !string.IsNullOrEmpty(this.currentNameFilter);
			ServerListCuration serverListCuration = ServerListCuration.Get();
			this.curationDefaultBehavior = serverListCuration.DefaultBehavior;
			this.curationDenyMode = serverListCuration.DenyMode;
			this.currentNameRegex = null;
			string text = "regex:";
			if (this.isCurrentNameFilterSet && this.currentNameFilter.StartsWith(text))
			{
				string text2 = this.currentNameFilter.Substring(text.Length);
				try
				{
					this.currentNameRegex = new Regex(text2);
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e, "Caught exception parsing server name regex \"" + text2 + "\":");
					this.isCurrentNameFilterSet = false;
				}
			}
			this.currentMaxPingFilter = inputFilters.maxPing;
			this._serverList.Clear();
			this.CuratorBlockedServerCount = 0;
			TempSteamworksMatchmaking.MasterServerRemoved masterServerRemoved = this.onMasterServerRemoved;
			if (masterServerRemoved != null)
			{
				masterServerRemoved();
			}
			this.cleanupServerListRequest();
			if (inputFilters.listSource == ESteamServerList.LAN)
			{
				this.serverListRequest = SteamMatchmakingServers.RequestLANServerList(Provider.APP_ID, this.serverListResponse);
				return;
			}
			this.filters = new List<MatchMakingKeyValuePair_t>();
			MatchMakingKeyValuePair_t item = default(MatchMakingKeyValuePair_t);
			item.m_szKey = "gamedir";
			item.m_szValue = "unturned";
			this.filters.Add(item);
			if (inputFilters.mapNames != null && inputFilters.mapNames.Count > 0)
			{
				List<LevelInfo> list = new List<LevelInfo>();
				inputFilters.GetLevels(list);
				if (list.Count > 0)
				{
					if (list.Count > 1)
					{
						int num = list.Count * 3;
						this.filters.Add(new MatchMakingKeyValuePair_t
						{
							m_szKey = "or",
							m_szValue = num.ToString()
						});
					}
					foreach (LevelInfo levelInfo in list)
					{
						this.filters.Add(new MatchMakingKeyValuePair_t
						{
							m_szKey = "and",
							m_szValue = "2"
						});
						MatchMakingKeyValuePair_t item2 = default(MatchMakingKeyValuePair_t);
						item2.m_szKey = "map";
						item2.m_szValue = levelInfo.name.ToLower();
						this.filters.Add(item2);
						MatchMakingKeyValuePair_t item3 = default(MatchMakingKeyValuePair_t);
						item3.m_szKey = "gamedataand";
						item3.m_szValue = "MAP_VERSION_" + VersionUtils.binaryToHexadecimal(levelInfo.configData.PackedVersion);
						this.filters.Add(item3);
					}
				}
			}
			if (inputFilters.attendance == EAttendance.Empty)
			{
				MatchMakingKeyValuePair_t item4 = default(MatchMakingKeyValuePair_t);
				item4.m_szKey = "noplayers";
				item4.m_szValue = "1";
				this.filters.Add(item4);
			}
			else if (inputFilters.attendance == EAttendance.HasPlayers)
			{
				MatchMakingKeyValuePair_t item5 = default(MatchMakingKeyValuePair_t);
				item5.m_szKey = "hasplayers";
				item5.m_szValue = "1";
				this.filters.Add(item5);
			}
			if (inputFilters.notFull)
			{
				MatchMakingKeyValuePair_t item6 = default(MatchMakingKeyValuePair_t);
				item6.m_szKey = "notfull";
				item6.m_szValue = "1";
				this.filters.Add(item6);
			}
			MatchMakingKeyValuePair_t matchMakingKeyValuePair_t = default(MatchMakingKeyValuePair_t);
			matchMakingKeyValuePair_t.m_szKey = "gamedataand";
			if (inputFilters.password == EPassword.YES)
			{
				matchMakingKeyValuePair_t.m_szValue = "PASS";
			}
			else if (inputFilters.password == EPassword.NO)
			{
				matchMakingKeyValuePair_t.m_szValue = "SSAP";
			}
			if (inputFilters.vacProtection == EVACProtectionFilter.Secure)
			{
				matchMakingKeyValuePair_t.m_szValue += ",";
				matchMakingKeyValuePair_t.m_szValue += "VAC_ON";
				MatchMakingKeyValuePair_t item7 = default(MatchMakingKeyValuePair_t);
				item7.m_szKey = "secure";
				item7.m_szValue = "1";
				this.filters.Add(item7);
			}
			else if (inputFilters.vacProtection == EVACProtectionFilter.Insecure)
			{
				matchMakingKeyValuePair_t.m_szValue += ",";
				matchMakingKeyValuePair_t.m_szValue += "VAC_OFF";
			}
			matchMakingKeyValuePair_t.m_szValue += ",GAME_VERSION_";
			matchMakingKeyValuePair_t.m_szValue += VersionUtils.binaryToHexadecimal(Provider.APP_VERSION_PACKED);
			if (!string.IsNullOrEmpty(matchMakingKeyValuePair_t.m_szValue))
			{
				this.filters.Add(matchMakingKeyValuePair_t);
			}
			MatchMakingKeyValuePair_t matchMakingKeyValuePair_t2 = default(MatchMakingKeyValuePair_t);
			matchMakingKeyValuePair_t2.m_szKey = "gametagsand";
			if (inputFilters.workshop == EWorkshop.YES)
			{
				matchMakingKeyValuePair_t2.m_szValue = "WSy";
			}
			else if (inputFilters.workshop == EWorkshop.NO)
			{
				matchMakingKeyValuePair_t2.m_szValue = "WSn";
			}
			if (inputFilters.combat == ECombat.PVP)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",PVP";
			}
			else if (inputFilters.combat == ECombat.PVE)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",PVE";
			}
			if (inputFilters.cheats == ECheats.YES)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",CHy";
			}
			else if (inputFilters.cheats == ECheats.NO)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",CHn";
			}
			if (inputFilters.camera != ECameraMode.ANY)
			{
				matchMakingKeyValuePair_t2.m_szValue = matchMakingKeyValuePair_t2.m_szValue + "," + Provider.getCameraModeTagAbbreviation(inputFilters.camera);
			}
			if (inputFilters.monetization == EServerMonetizationTag.None)
			{
				matchMakingKeyValuePair_t2.m_szValue = matchMakingKeyValuePair_t2.m_szValue + "," + Provider.GetMonetizationTagAbbreviation(inputFilters.monetization);
			}
			else
			{
				bool flag = inputFilters.monetization == EServerMonetizationTag.NonGameplay;
				if (!LiveConfig.Get().shouldServersWithoutMonetizationTagBeVisibleInInternetServerList)
				{
					flag |= this.isCurrentNameFilterSet;
				}
				if (flag)
				{
					this.filters.Add(new MatchMakingKeyValuePair_t
					{
						m_szKey = "or",
						m_szValue = "2"
					});
					this.filters.Add(new MatchMakingKeyValuePair_t
					{
						m_szKey = "gametagsand",
						m_szValue = Provider.GetMonetizationTagAbbreviation(EServerMonetizationTag.None)
					});
					this.filters.Add(new MatchMakingKeyValuePair_t
					{
						m_szKey = "gametagsand",
						m_szValue = Provider.GetMonetizationTagAbbreviation(EServerMonetizationTag.NonGameplay)
					});
				}
			}
			if (inputFilters.gold == EServerListGoldFilter.RequiresGold)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",GLD";
			}
			else if (inputFilters.gold == EServerListGoldFilter.DoesNotRequireGold)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",F2P";
			}
			if (inputFilters.battlEyeProtection == EBattlEyeProtectionFilter.Secure)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",BEy";
			}
			else if (inputFilters.battlEyeProtection == EBattlEyeProtectionFilter.Insecure)
			{
				matchMakingKeyValuePair_t2.m_szValue += ",BEn";
			}
			if (!string.IsNullOrEmpty(matchMakingKeyValuePair_t2.m_szValue))
			{
				this.filters.Add(matchMakingKeyValuePair_t2);
			}
			StringBuilder stringBuilder = new StringBuilder(128);
			stringBuilder.Append("Refreshing server list with filters:");
			foreach (MatchMakingKeyValuePair_t matchMakingKeyValuePair_t3 in this.filters)
			{
				stringBuilder.Append(' ');
				stringBuilder.Append(matchMakingKeyValuePair_t3.m_szKey);
				stringBuilder.Append('=');
				stringBuilder.Append(matchMakingKeyValuePair_t3.m_szValue);
			}
			UnturnedLog.info(stringBuilder.ToString());
			if (inputFilters.listSource == ESteamServerList.HISTORY)
			{
				this.serverListRequest = SteamMatchmakingServers.RequestHistoryServerList(Provider.APP_ID, this.filters.ToArray(), (uint)this.filters.Count, this.serverListResponse);
				return;
			}
			if (inputFilters.listSource == ESteamServerList.FAVORITES)
			{
				this.serverListRequest = SteamMatchmakingServers.RequestFavoritesServerList(Provider.APP_ID, this.filters.ToArray(), (uint)this.filters.Count, this.serverListResponse);
				return;
			}
			if (inputFilters.listSource == ESteamServerList.INTERNET)
			{
				serverListCuration.RefreshIfDirty();
				serverListCuration.MergeRulesIfDirty();
				serverListCuration.ResetBlockedServerCounts();
				this.serverListRequest = SteamMatchmakingServers.RequestInternetServerList(Provider.APP_ID, this.filters.ToArray(), (uint)this.filters.Count, this.serverListResponse);
				return;
			}
			if (inputFilters.listSource == ESteamServerList.FRIENDS)
			{
				this.serverListRequest = SteamMatchmakingServers.RequestFriendsServerList(Provider.APP_ID, this.filters.ToArray(), (uint)this.filters.Count, this.serverListResponse);
				return;
			}
		}

		// Token: 0x06000196 RID: 406 RVA: 0x00007DAC File Offset: 0x00005FAC
		public void refreshPlayers(uint ip, ushort port)
		{
			this.cleanupPlayersQuery();
			this.playersQuery = SteamMatchmakingServers.PlayerDetails(ip, port, this.playersResponse);
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00007DC7 File Offset: 0x00005FC7
		public void refreshRules(uint ip, ushort port)
		{
			this.cleanupRulesQuery();
			this.rulesMap = new Dictionary<string, string>();
			this.rulesQuery = SteamMatchmakingServers.ServerRules(ip, port, this.rulesResponse);
		}

		// Token: 0x06000198 RID: 408 RVA: 0x00007DF0 File Offset: 0x00005FF0
		private void onPingResponded(gameserveritem_t data)
		{
			this.isAttemptingServerQuery = false;
			this.cleanupServerQuery();
			if (data.m_nAppID == Provider.APP_ID.m_AppId)
			{
				SteamServerAdvertisement steamServerAdvertisement = new SteamServerAdvertisement(data, SteamServerAdvertisement.EInfoSource.DirectConnect);
				if (!steamServerAdvertisement.isPro || Provider.isPro)
				{
					bool flag = false;
					if (this.autoJoinServerQuery && (!steamServerAdvertisement.isPassworded || !string.IsNullOrEmpty(this.connectionInfo.password)))
					{
						flag = true;
					}
					if (flag)
					{
						Provider.connect(new ServerConnectParameters(new IPv4Address(steamServerAdvertisement.ip), steamServerAdvertisement.queryPort, steamServerAdvertisement.connectionPort, this.connectionInfo.password), steamServerAdvertisement, null);
					}
					else
					{
						ServerListCurationInput serverListCurationInput = new ServerListCurationInput(steamServerAdvertisement);
						ServerListCurationOutput serverListCurationOutput = default(ServerListCurationOutput);
						ServerListCuration.Get().EvaluateMergedRules(serverListCurationInput, ref serverListCurationOutput);
						steamServerAdvertisement.serverCurationLabels = serverListCurationOutput.labels;
						MenuUI.closeAll();
						MenuUI.closeAlert();
						MenuPlayServerInfoUI.open(steamServerAdvertisement, this.connectionInfo.password, this.serverQueryContext);
					}
				}
				else
				{
					Provider._connectionFailureInfo = ESteamConnectionFailureInfo.PRO_SERVER;
				}
			}
			else
			{
				Provider._connectionFailureInfo = ESteamConnectionFailureInfo.TIMED_OUT;
			}
			TempSteamworksMatchmaking.TimedOut timedOut = this.onTimedOut;
			if (timedOut == null)
			{
				return;
			}
			timedOut();
		}

		// Token: 0x06000199 RID: 409 RVA: 0x00007EFF File Offset: 0x000060FF
		private void onPingFailedToRespond()
		{
			if (this.serverQueryAttempts < 10)
			{
				this.attemptServerQuery();
				return;
			}
			this.isAttemptingServerQuery = false;
			this.cleanupServerQuery();
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.TIMED_OUT;
			TempSteamworksMatchmaking.TimedOut timedOut = this.onTimedOut;
			if (timedOut == null)
			{
				return;
			}
			timedOut();
		}

		// Token: 0x0600019A RID: 410 RVA: 0x00007F38 File Offset: 0x00006138
		private void onServerListResponded(HServerListRequest request, int index)
		{
			if (request != this.serverListRequest)
			{
				return;
			}
			gameserveritem_t serverDetails = SteamMatchmakingServers.GetServerDetails(request, index);
			if (this._currentList == ESteamServerList.INTERNET && !serverDetails.m_steamID.BPersistentGameServerAccount())
			{
				return;
			}
			if (serverDetails.m_nAppID != Provider.APP_ID.m_AppId)
			{
				UnturnedLog.info(string.Format("Ignoring server \"{0}\" because it has a different AppID ({1})", serverDetails.GetServerName(), serverDetails.m_nAppID));
				return;
			}
			IPv4Address ip = new IPv4Address(serverDetails.m_NetAdr.GetIP());
			EHostBanFlags ehostBanFlags = HostBansManager.Get().MatchBasicDetails(ip, serverDetails.m_NetAdr.GetQueryPort(), serverDetails.GetServerName(), serverDetails.m_steamID.m_SteamID);
			if (ehostBanFlags.HasFlag(EHostBanFlags.HiddenFromAllServerLists) || ehostBanFlags.HasFlag(EHostBanFlags.Blocked) || (this._currentList == ESteamServerList.INTERNET && ehostBanFlags.HasFlag(EHostBanFlags.HiddenFromInternetServerList)))
			{
				return;
			}
			SteamServerAdvertisement.EInfoSource infoSource;
			switch (this._currentList)
			{
			default:
				infoSource = SteamServerAdvertisement.EInfoSource.InternetServerList;
				break;
			case ESteamServerList.LAN:
				infoSource = SteamServerAdvertisement.EInfoSource.LanServerList;
				break;
			case ESteamServerList.HISTORY:
				infoSource = SteamServerAdvertisement.EInfoSource.HistoryServerList;
				break;
			case ESteamServerList.FAVORITES:
				infoSource = SteamServerAdvertisement.EInfoSource.FavoriteServerList;
				break;
			case ESteamServerList.FRIENDS:
				infoSource = SteamServerAdvertisement.EInfoSource.FriendServerList;
				break;
			}
			SteamServerAdvertisement steamServerAdvertisement = new SteamServerAdvertisement(serverDetails, infoSource);
			ehostBanFlags |= HostBansManager.Get().MatchExtendedDetails(steamServerAdvertisement.descText, steamServerAdvertisement.thumbnailURL);
			if (ehostBanFlags.HasFlag(EHostBanFlags.HiddenFromAllServerLists) || ehostBanFlags.HasFlag(EHostBanFlags.Blocked) || (this._currentList == ESteamServerList.INTERNET && ehostBanFlags.HasFlag(EHostBanFlags.HiddenFromInternetServerList)))
			{
				return;
			}
			steamServerAdvertisement.SetServerListHostBanFlags(ehostBanFlags);
			string serverCurationLabels = null;
			if (this._currentList == ESteamServerList.INTERNET)
			{
				ServerListCuration serverListCuration = ServerListCuration.Get();
				ServerListCurationInput serverListCurationInput = new ServerListCurationInput(steamServerAdvertisement);
				ServerListCurationOutput serverListCurationOutput = default(ServerListCurationOutput);
				serverListCuration.EvaluateMergedRules(serverListCurationInput, ref serverListCurationOutput);
				serverCurationLabels = serverListCurationOutput.labels;
				if (!serverListCurationOutput.allowed)
				{
					int curatorBlockedServerCount = this.CuratorBlockedServerCount + 1;
					this.CuratorBlockedServerCount = curatorBlockedServerCount;
					if (serverListCurationOutput.allowOrDenyRule != null)
					{
						serverListCurationOutput.allowOrDenyRule.latestBlockedServerCount++;
						serverListCurationOutput.allowOrDenyRule.owner.latestBlockedServerCount++;
					}
					if (this.curationDenyMode == EServerListCurationDenyMode.Hide)
					{
						return;
					}
					steamServerAdvertisement.isDeniedByServerCurationRule = true;
					steamServerAdvertisement.isDeprioritizedByServerCuration = true;
					steamServerAdvertisement.deniedByRule = serverListCurationOutput.allowOrDenyRule;
				}
				if (!serverListCurationOutput.matchedAnyRules)
				{
					if (this.curationDefaultBehavior == EServerListCurationDefaultBehavior.MoveToBottom)
					{
						steamServerAdvertisement.isDeprioritizedByServerCuration = true;
					}
					else if (this.curationDefaultBehavior == EServerListCurationDefaultBehavior.Hide)
					{
						return;
					}
				}
			}
			steamServerAdvertisement.serverCurationLabels = serverCurationLabels;
			if (index == this.serverListRefreshIndex)
			{
				TempSteamworksMatchmaking.MasterServerQueryRefreshed masterServerQueryRefreshed = this.onMasterServerQueryRefreshed;
				if (masterServerQueryRefreshed == null)
				{
					return;
				}
				masterServerQueryRefreshed(steamServerAdvertisement);
				return;
			}
			else
			{
				if (this.currentPluginsFilter == EPlugins.NO)
				{
					if (steamServerAdvertisement.pluginFramework != SteamServerAdvertisement.EPluginFramework.None)
					{
						return;
					}
				}
				else if (this.currentPluginsFilter == EPlugins.YES && steamServerAdvertisement.pluginFramework == SteamServerAdvertisement.EPluginFramework.None)
				{
					return;
				}
				if (steamServerAdvertisement.maxPlayers < (int)CommandMaxPlayers.MIN_NUMBER)
				{
					return;
				}
				if (this.isCurrentNameFilterSet)
				{
					if (this.currentNameRegex != null)
					{
						if (!this.currentNameRegex.IsMatch(steamServerAdvertisement.name))
						{
							return;
						}
					}
					else if (steamServerAdvertisement.name.IndexOf(this.currentNameFilter, StringComparison.OrdinalIgnoreCase) == -1)
					{
						return;
					}
				}
				else if (Mathf.Max(steamServerAdvertisement.players, steamServerAdvertisement.maxPlayers) > (int)CommandMaxPlayers.MAX_NUMBER)
				{
					return;
				}
				if (this.currentMaxPingFilter > 0 && steamServerAdvertisement.PingMs > this.currentMaxPingFilter)
				{
					return;
				}
				steamServerAdvertisement.CalculateUtilityScore();
				int num = this.serverList.BinarySearch(steamServerAdvertisement, this.serverInfoComparer);
				if (num < 0)
				{
					num = ~num;
				}
				this.serverList.Insert(num, steamServerAdvertisement);
				TempSteamworksMatchmaking.MasterServerAdded masterServerAdded = this.onMasterServerAdded;
				if (masterServerAdded == null)
				{
					return;
				}
				masterServerAdded(num, steamServerAdvertisement);
				return;
			}
		}

		// Token: 0x0600019B RID: 411 RVA: 0x000082AC File Offset: 0x000064AC
		private void onServerListFailedToRespond(HServerListRequest request, int index)
		{
		}

		// Token: 0x0600019C RID: 412 RVA: 0x000082B0 File Offset: 0x000064B0
		private void onRefreshComplete(HServerListRequest request, EMatchMakingServerResponse response)
		{
			if (request == this.serverListRequest)
			{
				TempSteamworksMatchmaking.MasterServerRefreshed masterServerRefreshed = this.onMasterServerRefreshed;
				if (masterServerRefreshed != null)
				{
					masterServerRefreshed(response);
				}
				if (response == EMatchMakingServerResponse.eNoServersListedOnMasterServer || this.serverList.Count == 0)
				{
					UnturnedLog.info("No servers found on the master server.");
					return;
				}
				if (response == EMatchMakingServerResponse.eServerFailedToRespond)
				{
					UnturnedLog.error("Failed to connect to the master server.");
					return;
				}
				if (response == EMatchMakingServerResponse.eServerResponded)
				{
					UnturnedLog.info("Successfully refreshed the master server.");
					return;
				}
			}
		}

		// Token: 0x0600019D RID: 413 RVA: 0x00008316 File Offset: 0x00006516
		private void onAddPlayerToList(string name, int score, float time)
		{
			TempSteamworksMatchmaking.PlayersQueryRefreshed playersQueryRefreshed = this.onPlayersQueryRefreshed;
			if (playersQueryRefreshed == null)
			{
				return;
			}
			playersQueryRefreshed(name, score, time);
		}

		// Token: 0x0600019E RID: 414 RVA: 0x0000832B File Offset: 0x0000652B
		private void onPlayersFailedToRespond()
		{
			UnturnedLog.warn("Server players query failed to respond");
		}

		// Token: 0x0600019F RID: 415 RVA: 0x00008337 File Offset: 0x00006537
		private void onPlayersRefreshComplete()
		{
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x00008339 File Offset: 0x00006539
		private void onRulesResponded(string key, string value)
		{
			if (this.rulesMap == null)
			{
				return;
			}
			this.rulesMap.Add(key, value);
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x00008351 File Offset: 0x00006551
		private void onRulesFailedToRespond()
		{
			UnturnedLog.warn("Server rules query failed to respond");
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x0000835D File Offset: 0x0000655D
		private void onRulesRefreshComplete()
		{
			TempSteamworksMatchmaking.RulesQueryRefreshed rulesQueryRefreshed = this.onRulesQueryRefreshed;
			if (rulesQueryRefreshed == null)
			{
				return;
			}
			rulesQueryRefreshed(this.rulesMap);
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x00008378 File Offset: 0x00006578
		public TempSteamworksMatchmaking()
		{
			this.serverPingResponse = new ISteamMatchmakingPingResponse(new ISteamMatchmakingPingResponse.ServerResponded(this.onPingResponded), new ISteamMatchmakingPingResponse.ServerFailedToRespond(this.onPingFailedToRespond));
			this.serverListResponse = new ISteamMatchmakingServerListResponse(new ISteamMatchmakingServerListResponse.ServerResponded(this.onServerListResponded), new ISteamMatchmakingServerListResponse.ServerFailedToRespond(this.onServerListFailedToRespond), new ISteamMatchmakingServerListResponse.RefreshComplete(this.onRefreshComplete));
			this.playersResponse = new ISteamMatchmakingPlayersResponse(new ISteamMatchmakingPlayersResponse.AddPlayerToList(this.onAddPlayerToList), new ISteamMatchmakingPlayersResponse.PlayersFailedToRespond(this.onPlayersFailedToRespond), new ISteamMatchmakingPlayersResponse.PlayersRefreshComplete(this.onPlayersRefreshComplete));
			this.rulesResponse = new ISteamMatchmakingRulesResponse(new ISteamMatchmakingRulesResponse.RulesResponded(this.onRulesResponded), new ISteamMatchmakingRulesResponse.RulesFailedToRespond(this.onRulesFailedToRespond), new ISteamMatchmakingRulesResponse.RulesRefreshComplete(this.onRulesRefreshComplete));
		}

		// Token: 0x040000AC RID: 172
		public TempSteamworksMatchmaking.MasterServerAdded onMasterServerAdded;

		// Token: 0x040000AD RID: 173
		public TempSteamworksMatchmaking.MasterServerRemoved onMasterServerRemoved;

		// Token: 0x040000AE RID: 174
		public TempSteamworksMatchmaking.MasterServerResorted onMasterServerResorted;

		// Token: 0x040000AF RID: 175
		public TempSteamworksMatchmaking.MasterServerRefreshed onMasterServerRefreshed;

		// Token: 0x040000B0 RID: 176
		public TempSteamworksMatchmaking.MasterServerQueryRefreshed onMasterServerQueryRefreshed;

		// Token: 0x040000B3 RID: 179
		public TempSteamworksMatchmaking.PlayersQueryRefreshed onPlayersQueryRefreshed;

		// Token: 0x040000B4 RID: 180
		public TempSteamworksMatchmaking.RulesQueryRefreshed onRulesQueryRefreshed;

		// Token: 0x040000B5 RID: 181
		private SteamConnectionInfo connectionInfo;

		// Token: 0x040000B6 RID: 182
		private ESteamServerList _currentList;

		// Token: 0x040000B7 RID: 183
		private string currentNameFilter;

		// Token: 0x040000B8 RID: 184
		private Regex currentNameRegex;

		// Token: 0x040000B9 RID: 185
		private bool isCurrentNameFilterSet;

		// Token: 0x040000BA RID: 186
		private int currentMaxPingFilter;

		// Token: 0x040000BB RID: 187
		private EPlugins currentPluginsFilter;

		// Token: 0x040000BC RID: 188
		private EServerListCurationDefaultBehavior curationDefaultBehavior;

		// Token: 0x040000BD RID: 189
		private EServerListCurationDenyMode curationDenyMode;

		// Token: 0x040000BE RID: 190
		private List<SteamServerAdvertisement> _serverList = new List<SteamServerAdvertisement>();

		// Token: 0x040000C0 RID: 192
		private List<MatchMakingKeyValuePair_t> filters;

		// Token: 0x040000C1 RID: 193
		private ISteamMatchmakingPingResponse serverPingResponse;

		// Token: 0x040000C2 RID: 194
		private ISteamMatchmakingServerListResponse serverListResponse;

		// Token: 0x040000C3 RID: 195
		private ISteamMatchmakingPlayersResponse playersResponse;

		// Token: 0x040000C4 RID: 196
		private ISteamMatchmakingRulesResponse rulesResponse;

		// Token: 0x040000C5 RID: 197
		private HServerQuery playersQuery = HServerQuery.Invalid;

		// Token: 0x040000C6 RID: 198
		private HServerQuery rulesQuery = HServerQuery.Invalid;

		// Token: 0x040000C7 RID: 199
		private Dictionary<string, string> rulesMap;

		// Token: 0x040000C8 RID: 200
		private HServerQuery serverQuery = HServerQuery.Invalid;

		// Token: 0x040000C9 RID: 201
		private int serverQueryAttempts;

		/// <summary>
		/// Reset after starting connection attempt, so set to true afterwards to auto join the server.
		/// </summary>
		// Token: 0x040000CB RID: 203
		public bool autoJoinServerQuery;

		// Token: 0x040000CC RID: 204
		public MenuPlayServerInfoUI.EServerInfoOpenContext serverQueryContext;

		// Token: 0x040000CD RID: 205
		private HServerListRequest serverListRequest = HServerListRequest.Invalid;

		// Token: 0x040000CE RID: 206
		private int serverListRefreshIndex = -1;

		// Token: 0x040000CF RID: 207
		private IComparer<SteamServerAdvertisement> _serverInfoComparer = new ServerListComparer_UtilityScore();

		// Token: 0x020008EB RID: 2283
		// (Invoke) Token: 0x06005058 RID: 20568
		public delegate void MasterServerAdded(int insert, SteamServerAdvertisement server);

		// Token: 0x020008EC RID: 2284
		// (Invoke) Token: 0x0600505C RID: 20572
		public delegate void MasterServerRemoved();

		// Token: 0x020008ED RID: 2285
		// (Invoke) Token: 0x06005060 RID: 20576
		public delegate void MasterServerResorted();

		// Token: 0x020008EE RID: 2286
		// (Invoke) Token: 0x06005064 RID: 20580
		public delegate void MasterServerRefreshed(EMatchMakingServerResponse response);

		// Token: 0x020008EF RID: 2287
		// (Invoke) Token: 0x06005068 RID: 20584
		public delegate void MasterServerQueryRefreshed(SteamServerAdvertisement server);

		// Token: 0x020008F0 RID: 2288
		// (Invoke) Token: 0x0600506C RID: 20588
		public delegate void AttemptUpdated(int attempt);

		// Token: 0x020008F1 RID: 2289
		// (Invoke) Token: 0x06005070 RID: 20592
		public delegate void TimedOut();

		// Token: 0x020008F2 RID: 2290
		// (Invoke) Token: 0x06005074 RID: 20596
		public delegate void PlayersQueryRefreshed(string name, int score, float time);

		// Token: 0x020008F3 RID: 2291
		// (Invoke) Token: 0x06005078 RID: 20600
		public delegate void RulesQueryRefreshed(Dictionary<string, string> rulesMap);
	}
}
