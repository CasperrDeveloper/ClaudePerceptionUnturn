﻿using System;

namespace SDG.Provider
{
	// Token: 0x02000032 RID: 50
	public struct EconExchangePair
	{
		// Token: 0x06000137 RID: 311 RVA: 0x00005264 File Offset: 0x00003464
		public EconExchangePair(ulong newInstanceId, ushort newQuantity)
		{
			this.instanceId = newInstanceId;
			this.quantity = newQuantity;
		}

		// Token: 0x0400008B RID: 139
		public ulong instanceId;

		// Token: 0x0400008C RID: 140
		public ushort quantity;
	}
}
