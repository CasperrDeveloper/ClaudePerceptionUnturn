﻿using System;

namespace SDG.Provider
{
	// Token: 0x0200003B RID: 59
	public class UnturnedEconInfo
	{
		// Token: 0x060001DA RID: 474 RVA: 0x00009F2C File Offset: 0x0000812C
		public UnturnedEconInfo()
		{
			this.name = "";
			this.display_type = "";
			this.description = "";
			this.name_color = "";
			this.itemdefid = 0;
			this.scraps = 0;
			this.target_game_asset_guid = Guid.Empty;
			this.item_skin = 0;
			this.item_effect = 0;
			this.quality = UnturnedEconInfo.EQuality.None;
			this.econ_type = -1;
		}

		// Token: 0x04000102 RID: 258
		public string name;

		// Token: 0x04000103 RID: 259
		public string display_type;

		// Token: 0x04000104 RID: 260
		public string description;

		// Token: 0x04000105 RID: 261
		public string name_color;

		// Token: 0x04000106 RID: 262
		public int itemdefid;

		// Token: 0x04000107 RID: 263
		public bool marketable;

		// Token: 0x04000108 RID: 264
		public int scraps;

		// Token: 0x04000109 RID: 265
		public Guid target_game_asset_guid;

		// Token: 0x0400010A RID: 266
		public int item_skin;

		// Token: 0x0400010B RID: 267
		public int item_effect;

		// Token: 0x0400010C RID: 268
		public UnturnedEconInfo.EQuality quality;

		/// <summary>
		/// EItemType
		/// </summary>
		// Token: 0x0400010D RID: 269
		public int econ_type;

		/// <summary>
		/// Nelson 2024-12-06: This was added 2023-06-19, so unfortunately it will be inaccurate for older items.
		/// </summary>
		// Token: 0x0400010E RID: 270
		public DateTime creationTimeUtc;

		// Token: 0x0400010F RID: 271
		public bool isEligibleForPromotion = true;

		// Token: 0x020008F6 RID: 2294
		public enum EQuality
		{
			// Token: 0x040036A1 RID: 13985
			None,
			// Token: 0x040036A2 RID: 13986
			Common,
			// Token: 0x040036A3 RID: 13987
			Uncommon,
			// Token: 0x040036A4 RID: 13988
			Gold,
			// Token: 0x040036A5 RID: 13989
			Rare,
			// Token: 0x040036A6 RID: 13990
			Epic,
			// Token: 0x040036A7 RID: 13991
			Legendary,
			// Token: 0x040036A8 RID: 13992
			Mythical,
			// Token: 0x040036A9 RID: 13993
			Premium,
			// Token: 0x040036AA RID: 13994
			Achievement
		}

		/// <summary>
		/// This enum exists for sorting items based on rarity, and is derived from quality.
		/// Quality order cannot be changed due to loading from older files, but this one is ordered
		/// from lowest rarity to highest rarity and should match entries in quality.
		/// </summary>
		// Token: 0x020008F7 RID: 2295
		public enum ERarity
		{
			// Token: 0x040036AC RID: 13996
			Common,
			// Token: 0x040036AD RID: 13997
			Uncommon,
			// Token: 0x040036AE RID: 13998
			Achievement,
			// Token: 0x040036AF RID: 13999
			Unknown,
			// Token: 0x040036B0 RID: 14000
			Gold,
			// Token: 0x040036B1 RID: 14001
			Premium,
			// Token: 0x040036B2 RID: 14002
			Rare,
			// Token: 0x040036B3 RID: 14003
			Epic,
			// Token: 0x040036B4 RID: 14004
			Legendary,
			// Token: 0x040036B5 RID: 14005
			Mythical
		}
	}
}
