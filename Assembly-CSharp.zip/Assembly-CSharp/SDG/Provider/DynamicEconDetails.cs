﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Provider
{
	// Token: 0x02000036 RID: 54
	public struct DynamicEconDetails
	{
		// Token: 0x06000138 RID: 312 RVA: 0x00005274 File Offset: 0x00003474
		public bool getStatTrackerType(out EStatTrackerType type)
		{
			type = EStatTrackerType.NONE;
			if (this.tags.Contains("stat_tracker:total_kills"))
			{
				type = EStatTrackerType.TOTAL;
				return true;
			}
			if (this.tags.Contains("stat_tracker:player_kills"))
			{
				type = EStatTrackerType.PLAYER;
				return true;
			}
			return false;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x000052A8 File Offset: 0x000034A8
		public bool getRagdollEffect(out ERagdollEffect effect)
		{
			int num = this.tags.IndexOf("ragdoll_effect:");
			if (num >= 0)
			{
				num += "ragdoll_effect:".Length;
				if (num < this.tags.Length - 1)
				{
					ReadOnlySpan<char> span = this.tags.AsSpan(num, this.tags.Length - num);
					if (span.StartsWith("zero_kelvin"))
					{
						effect = ERagdollEffect.ZERO_KELVIN;
						return true;
					}
					if (span.StartsWith("jaded"))
					{
						effect = ERagdollEffect.JADED;
						return true;
					}
					if (span.StartsWith("soulcrystal_green"))
					{
						effect = ERagdollEffect.SOUL_CRYSTAL_GREEN;
						return true;
					}
					if (span.StartsWith("soulcrystal_magenta"))
					{
						effect = ERagdollEffect.SOUL_CRYSTAL_MAGENTA;
						return true;
					}
					if (span.StartsWith("soulcrystal_red"))
					{
						effect = ERagdollEffect.SOUL_CRYSTAL_RED;
						return true;
					}
					if (span.StartsWith("soulcrystal_yellow"))
					{
						effect = ERagdollEffect.SOUL_CRYSTAL_YELLOW;
						return true;
					}
				}
			}
			effect = ERagdollEffect.NONE;
			return false;
		}

		/// <summary>
		/// Parse dynamic tag mythic effect.
		/// </summary>
		/// <returns>ID of mythical asset, or zero if not in tags.</returns>
		// Token: 0x0600013A RID: 314 RVA: 0x00005398 File Offset: 0x00003598
		public ushort getParticleEffect()
		{
			int num = this.tags.IndexOf("particle_effect:");
			if (num < 0)
			{
				return 0;
			}
			int num2 = num + "particle_effect:".Length;
			if (num2 >= this.tags.Length)
			{
				return 0;
			}
			int num3 = this.tags.IndexOf(';', num2);
			if (num3 < 0)
			{
				num3 = this.tags.Length;
			}
			int length = num3 - num2;
			ushort result;
			if (ushort.TryParse(this.tags.Substring(num2, length), out result))
			{
				return result;
			}
			return 0;
		}

		// Token: 0x0600013B RID: 315 RVA: 0x00005418 File Offset: 0x00003618
		public bool getStatTrackerValue(out EStatTrackerType type, out int kills)
		{
			kills = -1;
			if (!this.getStatTrackerType(out type))
			{
				return false;
			}
			EStatTrackerType estatTrackerType = type;
			if (estatTrackerType == EStatTrackerType.TOTAL)
			{
				if (string.IsNullOrEmpty(this.dynamic_props))
				{
					kills = 0;
				}
				else
				{
					StatTrackerTotalKillsJson statTrackerTotalKillsJson = JsonUtility.FromJson<StatTrackerTotalKillsJson>(this.dynamic_props);
					kills = statTrackerTotalKillsJson.total_kills;
				}
				return true;
			}
			if (estatTrackerType != EStatTrackerType.PLAYER)
			{
				return false;
			}
			if (string.IsNullOrEmpty(this.dynamic_props))
			{
				kills = 0;
			}
			else
			{
				StatTrackerPlayerKillsJson statTrackerPlayerKillsJson = JsonUtility.FromJson<StatTrackerPlayerKillsJson>(this.dynamic_props);
				kills = statTrackerPlayerKillsJson.player_kills;
			}
			return true;
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00005494 File Offset: 0x00003694
		public string getPredictedDynamicPropsJsonForStatTracker(EStatTrackerType type, int kills)
		{
			if (type == EStatTrackerType.TOTAL)
			{
				return JsonUtility.ToJson(new StatTrackerTotalKillsJson
				{
					total_kills = kills
				});
			}
			if (type != EStatTrackerType.PLAYER)
			{
				return string.Empty;
			}
			return JsonUtility.ToJson(new StatTrackerPlayerKillsJson
			{
				player_kills = kills
			});
		}

		// Token: 0x0600013D RID: 317 RVA: 0x000054E8 File Offset: 0x000036E8
		public DynamicEconDetails(string tags, string dynamic_props)
		{
			this.tags = (string.IsNullOrEmpty(tags) ? string.Empty : tags);
			this.dynamic_props = (string.IsNullOrEmpty(dynamic_props) ? string.Empty : dynamic_props);
		}

		// Token: 0x04000093 RID: 147
		public string tags;

		// Token: 0x04000094 RID: 148
		public string dynamic_props;
	}
}
