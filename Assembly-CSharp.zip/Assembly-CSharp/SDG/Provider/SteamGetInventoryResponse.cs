﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace SDG.Provider
{
	/// <summary>
	/// Response data from IInventoryService GetInventory web API.
	///
	/// One player's inventory became so large that the Steam client's built-in GetInventory fails,
	/// so as temporary fix we can send them a json file with their inventory.
	/// </summary>
	// Token: 0x02000031 RID: 49
	public class SteamGetInventoryResponse
	{
		/// <summary>
		/// Parse response from json file.
		/// </summary>
		// Token: 0x06000135 RID: 309 RVA: 0x000051F0 File Offset: 0x000033F0
		public static List<SteamGetInventoryResponse.Item> parse(string path)
		{
			List<SteamGetInventoryResponse.Item> result;
			using (StreamReader streamReader = new StreamReader(path))
			{
				using (JsonReader jsonReader = new JsonTextReader(streamReader))
				{
					result = JsonConvert.DeserializeObject<List<SteamGetInventoryResponse.Item>>(new JsonSerializer().Deserialize<SteamGetInventoryResponse>(jsonReader).response.item_json);
				}
			}
			return result;
		}

		// Token: 0x0400008A RID: 138
		public SteamGetInventoryResponse.InnerResponse response;

		// Token: 0x020008E5 RID: 2277
		public class Item
		{
			// Token: 0x0400369C RID: 13980
			public ulong itemid;

			// Token: 0x0400369D RID: 13981
			public ushort quantity;

			// Token: 0x0400369E RID: 13982
			public int itemdefid;
		}

		// Token: 0x020008E6 RID: 2278
		public class InnerResponse
		{
			/// <summary>
			/// Json string representation of the contained items.
			/// </summary>
			// Token: 0x0400369F RID: 13983
			public string item_json;
		}
	}
}
