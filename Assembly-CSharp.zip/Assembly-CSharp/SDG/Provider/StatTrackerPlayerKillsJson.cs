﻿using System;

namespace SDG.Provider
{
	// Token: 0x02000034 RID: 52
	public struct StatTrackerPlayerKillsJson
	{
		// Token: 0x0400008E RID: 142
		public int player_kills;
	}
}
