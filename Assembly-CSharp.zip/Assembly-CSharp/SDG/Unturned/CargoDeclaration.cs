﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002AE RID: 686
	internal class CargoDeclaration
	{
		// Token: 0x0600151A RID: 5402 RVA: 0x000521FC File Offset: 0x000503FC
		public void Append(string key, bool value)
		{
			string str = value ? "yes" : "no";
			this.lines.Add("| " + key + " = " + str);
		}

		// Token: 0x0600151B RID: 5403 RVA: 0x00052235 File Offset: 0x00050435
		public void Append(string key, string value)
		{
			this.lines.Add("| " + key + " = " + value);
		}

		// Token: 0x0600151C RID: 5404 RVA: 0x00052253 File Offset: 0x00050453
		public void Append(string key, Guid guid)
		{
			this.lines.Add(string.Format("| {0} = {1:N}", key, guid));
		}

		// Token: 0x0600151D RID: 5405 RVA: 0x00052271 File Offset: 0x00050471
		public void Append(string key, byte value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x0600151E RID: 5406 RVA: 0x0005228F File Offset: 0x0005048F
		public void Append(string key, ushort value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x0600151F RID: 5407 RVA: 0x000522AD File Offset: 0x000504AD
		public void Append(string key, uint value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001520 RID: 5408 RVA: 0x000522CB File Offset: 0x000504CB
		public void Append(string key, ulong value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001521 RID: 5409 RVA: 0x000522E9 File Offset: 0x000504E9
		public void Append(string key, sbyte value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001522 RID: 5410 RVA: 0x00052307 File Offset: 0x00050507
		public void Append(string key, short value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001523 RID: 5411 RVA: 0x00052325 File Offset: 0x00050525
		public void Append(string key, int value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001524 RID: 5412 RVA: 0x00052343 File Offset: 0x00050543
		public void Append(string key, long value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001525 RID: 5413 RVA: 0x00052361 File Offset: 0x00050561
		public void Append(string key, float value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001526 RID: 5414 RVA: 0x0005237F File Offset: 0x0005057F
		public void Append(string key, double value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x06001527 RID: 5415 RVA: 0x0005239D File Offset: 0x0005059D
		public void Append(string key, Color32 value)
		{
			this.lines.Add("| " + key + " = " + Palette.hex(value));
		}

		// Token: 0x06001528 RID: 5416 RVA: 0x000523C0 File Offset: 0x000505C0
		public void Append(string key, object value)
		{
			this.lines.Add(string.Format("| {0} = {1}", key, value));
		}

		// Token: 0x04000778 RID: 1912
		internal List<string> lines = new List<string>();
	}
}
