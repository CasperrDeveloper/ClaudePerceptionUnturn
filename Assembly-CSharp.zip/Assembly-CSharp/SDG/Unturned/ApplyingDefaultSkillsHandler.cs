﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020006D2 RID: 1746
	// (Invoke) Token: 0x06003C54 RID: 15444
	public delegate void ApplyingDefaultSkillsHandler(Player forPlayer, Skill[][] newSkills);
}
