﻿using System;
using System.Collections.Generic;

namespace SDG.Unturned
{
	/// <summary>
	/// Replacement for enum origin.
	/// </summary>
	// Token: 0x0200029D RID: 669
	public class AssetOrigin
	{
		// Token: 0x06001419 RID: 5145 RVA: 0x0004D3E4 File Offset: 0x0004B5E4
		public IReadOnlyList<Asset> GetAssets()
		{
			return this.assets;
		}

		/// <summary>
		/// Hardcoded built-in name, or name of workshop file if known.
		/// </summary>
		// Token: 0x0400070C RID: 1804
		public string name;

		/// <summary>
		/// Steam file ID if loaded from the workshop, zero otherwise.
		/// </summary>
		// Token: 0x0400070D RID: 1805
		public ulong workshopFileId;

		/// <summary>
		/// If true, when added to asset mapping the new assets will override existing ones.
		/// This ensures workshop files installed by servers take priority and disables warnings about overlapping IDs.
		/// </summary>
		// Token: 0x0400070E RID: 1806
		internal bool shouldAssetsOverrideExistingIds;

		/// <summary>
		/// If true, we can re-save .dat/.asset files from this origin.
		/// Defaults to false. Only true for assets in the game install folder.
		/// </summary>
		// Token: 0x0400070F RID: 1807
		internal bool canResave;

		// Token: 0x04000710 RID: 1808
		internal List<Asset> assets = new List<Asset>();
	}
}
