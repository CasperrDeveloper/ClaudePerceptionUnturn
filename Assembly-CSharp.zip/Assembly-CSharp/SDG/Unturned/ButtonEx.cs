﻿using System;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SDG.Unturned
{
	// Token: 0x02000181 RID: 385
	internal class ButtonEx : Button
	{
		// Token: 0x06000A76 RID: 2678 RVA: 0x0002636D File Offset: 0x0002456D
		public override void OnPointerClick(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Right)
			{
				base.OnPointerClick(eventData);
				return;
			}
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			this.onRightClick.Invoke();
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x0002639C File Offset: 0x0002459C
		public override void OnPointerDown(PointerEventData eventData)
		{
			PointerEventData.InputButton button = eventData.button;
			eventData.button = PointerEventData.InputButton.Left;
			base.OnPointerDown(eventData);
			eventData.button = button;
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x000263C8 File Offset: 0x000245C8
		public override void OnPointerUp(PointerEventData eventData)
		{
			PointerEventData.InputButton button = eventData.button;
			eventData.button = PointerEventData.InputButton.Left;
			base.OnPointerUp(eventData);
			eventData.button = button;
		}

		// Token: 0x0400043E RID: 1086
		public Button.ButtonClickedEvent onRightClick = new Button.ButtonClickedEvent();
	}
}
