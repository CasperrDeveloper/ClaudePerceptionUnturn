﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000791 RID: 1937
	// (Invoke) Token: 0x060042DF RID: 17119
	public delegate void BlueprintItemIconsReady();
}
