﻿using System;

namespace SDG.Unturned
{
	/// <summary>
	/// • Does not support legacy ID.
	/// • Caches resolved asset and updates if asset has been reloaded.
	/// • See CachingBcAssetRef if legacy ID support is necessary.
	/// </summary>
	// Token: 0x020002AC RID: 684
	public struct CachingAssetRef : IEquatable<CachingAssetRef>, IDatParseable
	{
		/// <summary>
		/// If true, doesn't reference anything.
		/// Could also be called "IsZero" or "IsNull".
		/// </summary>
		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x060014E5 RID: 5349 RVA: 0x00051968 File Offset: 0x0004FB68
		public bool IsEmpty
		{
			get
			{
				return this.guid == Guid.Empty;
			}
		}

		/// <summary>
		/// Opposite of IsEmpty.
		/// </summary>
		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x060014E6 RID: 5350 RVA: 0x0005197A File Offset: 0x0004FB7A
		public bool IsAssigned
		{
			get
			{
				return this.guid != Guid.Empty;
			}
		}

		/// <summary>
		/// Assigned GUID, not the referenced asset's GUID.
		/// </summary>
		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x060014E7 RID: 5351 RVA: 0x0005198C File Offset: 0x0004FB8C
		public Guid Guid
		{
			get
			{
				return this.guid;
			}
		}

		// Token: 0x060014E8 RID: 5352 RVA: 0x00051994 File Offset: 0x0004FB94
		public Asset Get()
		{
			if (this.cachedAsset == null || this.cachedAsset.hasBeenReplaced)
			{
				this.cachedAsset = Assets.find(this.guid);
			}
			return this.cachedAsset;
		}

		// Token: 0x060014E9 RID: 5353 RVA: 0x000519C2 File Offset: 0x0004FBC2
		public T Get<T>() where T : class
		{
			return this.Get() as T;
		}

		/// <summary>
		/// Doesn't only check (Get() == asset) because a new asset may have loaded.
		/// Rather, checks whether GUID points at asset.
		/// If asset is null, returns true if GUID and legacy ID are zero.
		/// </summary>
		// Token: 0x060014EA RID: 5354 RVA: 0x000519D4 File Offset: 0x0004FBD4
		public bool IsReferenceTo(Asset asset)
		{
			if (asset == null)
			{
				return this.guid == Guid.Empty;
			}
			if (!asset.hasBeenReplaced && this.cachedAsset != null)
			{
				return this.cachedAsset == asset;
			}
			return this.guid == asset.GUID;
		}

		// Token: 0x060014EB RID: 5355 RVA: 0x00051A20 File Offset: 0x0004FC20
		public void Clear()
		{
			this.guid = Guid.Empty;
			this.cachedAsset = null;
		}

		// Token: 0x060014EC RID: 5356 RVA: 0x00051A34 File Offset: 0x0004FC34
		public static bool operator ==(CachingAssetRef lhs, CachingAssetRef rhs)
		{
			return lhs.guid == rhs.guid;
		}

		// Token: 0x060014ED RID: 5357 RVA: 0x00051A47 File Offset: 0x0004FC47
		public static bool operator !=(CachingAssetRef lhs, CachingAssetRef rhs)
		{
			return !(lhs == rhs);
		}

		// Token: 0x060014EE RID: 5358 RVA: 0x00051A54 File Offset: 0x0004FC54
		public override bool Equals(object obj)
		{
			if (obj is CachingAssetRef)
			{
				CachingAssetRef rhs = (CachingAssetRef)obj;
				return this == rhs;
			}
			return false;
		}

		// Token: 0x060014EF RID: 5359 RVA: 0x00051A7E File Offset: 0x0004FC7E
		public bool Equals(CachingAssetRef other)
		{
			return this == other;
		}

		// Token: 0x060014F0 RID: 5360 RVA: 0x00051A8C File Offset: 0x0004FC8C
		public override int GetHashCode()
		{
			return this.guid.GetHashCode();
		}

		// Token: 0x060014F1 RID: 5361 RVA: 0x00051AA0 File Offset: 0x0004FCA0
		public override string ToString()
		{
			Asset asset = this.Get();
			string arg = ((asset != null) ? asset.FriendlyName : null) ?? "null";
			return string.Format("(ID: {0:N}, Asset: {1})", this.guid, arg);
		}

		// Token: 0x060014F2 RID: 5362 RVA: 0x00051AE0 File Offset: 0x0004FCE0
		public bool TryParse(IDatNode node)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				return CachingAssetRef.TryParse(datValue.Value, out this);
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			return datDictionary != null && datDictionary.TryParseGuid("GUID", out this.guid);
		}

		// Token: 0x060014F3 RID: 5363 RVA: 0x00051B24 File Offset: 0x0004FD24
		public static bool TryParse(IDatNode node, out CachingAssetRef result)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				return CachingAssetRef.TryParse(datValue.Value, out result);
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			Guid guid;
			if (datDictionary != null && datDictionary.TryParseGuid("GUID", out guid))
			{
				result = new CachingAssetRef(guid);
				return true;
			}
			result = CachingAssetRef.Empty;
			return false;
		}

		// Token: 0x060014F4 RID: 5364 RVA: 0x00051B7C File Offset: 0x0004FD7C
		public static bool TryParse(string input, out CachingAssetRef result)
		{
			Guid guid;
			if (!string.IsNullOrEmpty(input) && !string.Equals(input, "0") && Guid.TryParse(input, out guid))
			{
				result = new CachingAssetRef(guid);
				return true;
			}
			result = CachingAssetRef.Empty;
			return false;
		}

		/// <summary>
		/// Returns Empty if TryParse returns false.
		/// </summary>
		// Token: 0x060014F5 RID: 5365 RVA: 0x00051BC4 File Offset: 0x0004FDC4
		public static CachingAssetRef Parse(string input)
		{
			CachingAssetRef result;
			CachingAssetRef.TryParse(input, out result);
			return result;
		}

		// Token: 0x060014F6 RID: 5366 RVA: 0x00051BDB File Offset: 0x0004FDDB
		public CachingAssetRef(Asset asset)
		{
			this.guid = ((asset != null) ? asset.GUID : Guid.Empty);
			this.cachedAsset = asset;
		}

		// Token: 0x060014F7 RID: 5367 RVA: 0x00051BFA File Offset: 0x0004FDFA
		public CachingAssetRef(Guid guid)
		{
			this.guid = guid;
			this.cachedAsset = null;
		}

		/// <summary>
		/// Enables assigning assetRef from an existing asset without manually calling constructor.
		/// </summary>
		// Token: 0x060014F8 RID: 5368 RVA: 0x00051C0A File Offset: 0x0004FE0A
		public static implicit operator CachingAssetRef(Asset asset)
		{
			return new CachingAssetRef(asset);
		}

		/// <summary>
		/// Enables assigning assetRef from an asset GUID without manually calling constructor.
		/// </summary>
		// Token: 0x060014F9 RID: 5369 RVA: 0x00051C12 File Offset: 0x0004FE12
		public static implicit operator CachingAssetRef(Guid guid)
		{
			return new CachingAssetRef(guid);
		}

		// Token: 0x04000770 RID: 1904
		public static readonly CachingAssetRef Empty;

		// Token: 0x04000771 RID: 1905
		private Guid guid;

		/// <summary>
		/// Internal so that CachingBcAssetRef can copy cachedAsset.
		/// </summary>
		// Token: 0x04000772 RID: 1906
		internal Asset cachedAsset;
	}
}
