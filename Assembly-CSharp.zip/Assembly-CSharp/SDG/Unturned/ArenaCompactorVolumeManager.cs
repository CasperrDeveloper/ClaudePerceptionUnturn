﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004FD RID: 1277
	public class ArenaCompactorVolumeManager : VolumeManager<ArenaCompactorVolume, ArenaCompactorVolumeManager>
	{
		// Token: 0x060029D3 RID: 10707 RVA: 0x000B50FF File Offset: 0x000B32FF
		public ArenaCompactorVolumeManager()
		{
			base.FriendlyName = "Arena Mode Compactor";
			base.SetDebugColor(new Color32(20, 20, 20, byte.MaxValue));
		}
	}
}
