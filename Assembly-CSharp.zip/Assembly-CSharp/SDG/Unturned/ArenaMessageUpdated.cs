﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005CD RID: 1485
	// (Invoke) Token: 0x060031FE RID: 12798
	public delegate void ArenaMessageUpdated(EArenaMessage newArenaMessage);
}
