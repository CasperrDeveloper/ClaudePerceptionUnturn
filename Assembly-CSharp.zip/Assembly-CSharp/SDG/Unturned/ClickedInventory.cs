﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007B4 RID: 1972
	// (Invoke) Token: 0x060043DF RID: 17375
	public delegate void ClickedInventory(SleekInventory inventory);
}
