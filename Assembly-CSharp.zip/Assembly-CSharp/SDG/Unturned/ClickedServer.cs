﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007CE RID: 1998
	// (Invoke) Token: 0x06004494 RID: 17556
	public delegate void ClickedServer(SleekServer server, SteamServerAdvertisement info);
}
