﻿using System;
using System.Collections.Generic;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005B0 RID: 1456
	public class ClaimManager : MonoBehaviour
	{
		// Token: 0x060030A9 RID: 12457 RVA: 0x000E0610 File Offset: 0x000DE810
		public static bool checkCanBuild(Vector3 point, CSteamID owner, CSteamID group, bool isClaim)
		{
			for (int i = 0; i < ClaimManager.bubbles.Count; i++)
			{
				ClaimBubble claimBubble = ClaimManager.bubbles[i];
				if ((isClaim ? ((claimBubble.origin - point).sqrMagnitude < 4f * claimBubble.sqrRadius) : ((claimBubble.origin - point).sqrMagnitude < claimBubble.sqrRadius)) && (Dedicator.IsDedicatedServer ? (!OwnershipTool.checkToggle(owner, claimBubble.owner, group, claimBubble.group)) : (!claimBubble.hasOwnership)))
				{
					return false;
				}
			}
			return true;
		}

		/// <param name="isClaim">True if it's a new claim flag.</param>
		// Token: 0x060030AA RID: 12458 RVA: 0x000E06B8 File Offset: 0x000DE8B8
		public static bool canBuildOnVehicle(Transform vehicle, CSteamID owner, CSteamID group)
		{
			foreach (ClaimPlant claimPlant in ClaimManager.plants)
			{
				if (!(claimPlant.parent != vehicle))
				{
					if (Dedicator.IsDedicatedServer)
					{
						if (!OwnershipTool.checkToggle(owner, claimPlant.owner, group, claimPlant.group))
						{
							return false;
						}
					}
					else if (!claimPlant.hasOwnership)
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x060030AB RID: 12459 RVA: 0x000E0740 File Offset: 0x000DE940
		public static ClaimBubble registerBubble(Vector3 origin, float radius, ulong owner, ulong group)
		{
			ClaimBubble claimBubble = new ClaimBubble(origin, radius * radius, owner, group);
			ClaimManager.bubbles.Add(claimBubble);
			return claimBubble;
		}

		// Token: 0x060030AC RID: 12460 RVA: 0x000E0765 File Offset: 0x000DE965
		public static void deregisterBubble(ClaimBubble bubble)
		{
			ClaimManager.bubbles.Remove(bubble);
		}

		// Token: 0x060030AD RID: 12461 RVA: 0x000E0774 File Offset: 0x000DE974
		public static ClaimPlant registerPlant(Transform parent, ulong owner, ulong group)
		{
			ClaimPlant claimPlant = new ClaimPlant(parent, owner, group);
			ClaimManager.plants.Add(claimPlant);
			return claimPlant;
		}

		// Token: 0x060030AE RID: 12462 RVA: 0x000E0796 File Offset: 0x000DE996
		public static void deregisterPlant(ClaimPlant plant)
		{
			ClaimManager.plants.Remove(plant);
		}

		// Token: 0x060030AF RID: 12463 RVA: 0x000E07A4 File Offset: 0x000DE9A4
		private void onLevelLoaded(int level)
		{
			ClaimManager.bubbles = new List<ClaimBubble>();
			ClaimManager.plants = new List<ClaimPlant>();
		}

		// Token: 0x060030B0 RID: 12464 RVA: 0x000E07BA File Offset: 0x000DE9BA
		private void Start()
		{
			Level.onPrePreLevelLoaded = (PrePreLevelLoaded)Delegate.Combine(Level.onPrePreLevelLoaded, new PrePreLevelLoaded(this.onLevelLoaded));
		}

		// Token: 0x040019BA RID: 6586
		private static List<ClaimBubble> bubbles;

		// Token: 0x040019BB RID: 6587
		private static List<ClaimPlant> plants;
	}
}
