﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000472 RID: 1138
	public class ArenaGameMode : GameMode
	{
		// Token: 0x060024B2 RID: 9394 RVA: 0x000988DB File Offset: 0x00096ADB
		public override string ToString()
		{
			return "Arena";
		}
	}
}
