﻿using System;

namespace SDG.Unturned
{
	/// <summary>
	/// Backwards-Compatible Asset Reference with Caching
	/// • Supports both GUID and legacy ID.
	/// • Caches resolved asset and updates if asset has been reloaded.
	/// • Parsing legacy ID without context requires "LegacyType:LegacyID" format. E.g., "Item:4" for the Eaglefire.
	/// • See CachingAssetRef if legacy ID support is unnecessary.
	/// </summary>
	// Token: 0x020002AD RID: 685
	public struct CachingBcAssetRef : IEquatable<CachingBcAssetRef>, IDatParseable
	{
		/// <summary>
		/// If true, doesn't reference anything.
		/// Could also be called "IsZero" or "IsNull".
		/// </summary>
		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x060014FB RID: 5371 RVA: 0x00051C1C File Offset: 0x0004FE1C
		public bool IsEmpty
		{
			get
			{
				return this.guid == Guid.Empty && this.legacyId == 0;
			}
		}

		/// <summary>
		/// Opposite of IsEmpty.
		/// </summary>
		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x060014FC RID: 5372 RVA: 0x00051C3B File Offset: 0x0004FE3B
		public bool IsAssigned
		{
			get
			{
				return this.guid != Guid.Empty || this.legacyId > 0;
			}
		}

		/// <summary>
		/// Assigned GUID, not the referenced asset's GUID.
		/// </summary>
		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x060014FD RID: 5373 RVA: 0x00051C5A File Offset: 0x0004FE5A
		public Guid Guid
		{
			get
			{
				return this.guid;
			}
		}

		/// <summary>
		/// Assigned legacy ID, not the referenced asset's legacy ID.
		/// </summary>
		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x060014FE RID: 5374 RVA: 0x00051C62 File Offset: 0x0004FE62
		public ushort LegacyId
		{
			get
			{
				return this.legacyId;
			}
		}

		/// <summary>
		/// Assigned legacy type, not the referenced asset's legacy type.
		/// </summary>
		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x060014FF RID: 5375 RVA: 0x00051C6A File Offset: 0x0004FE6A
		public EAssetType LegacyType
		{
			get
			{
				return this.legacyType;
			}
		}

		// Token: 0x06001500 RID: 5376 RVA: 0x00051C74 File Offset: 0x0004FE74
		public Asset Get()
		{
			if (this.cachedAsset == null || this.cachedAsset.hasBeenReplaced)
			{
				if (this.legacyId == 0)
				{
					this.cachedAsset = Assets.find(this.guid);
				}
				else
				{
					this.cachedAsset = Assets.find(this.legacyType, this.legacyId);
				}
			}
			return this.cachedAsset;
		}

		// Token: 0x06001501 RID: 5377 RVA: 0x00051CCE File Offset: 0x0004FECE
		public T Get<T>() where T : class
		{
			return this.Get() as T;
		}

		/// <summary>
		/// Doesn't only check (Get() == asset) because a new asset may have loaded.
		/// Rather, checks whether GUID or legacy ID (whichever is set) points at asset.
		/// If asset is null, returns true if GUID and legacy ID are zero.
		/// </summary>
		// Token: 0x06001502 RID: 5378 RVA: 0x00051CE0 File Offset: 0x0004FEE0
		public bool IsReferenceTo(Asset asset)
		{
			if (asset == null)
			{
				return this.guid == Guid.Empty && this.legacyId == 0;
			}
			if (!asset.hasBeenReplaced && this.cachedAsset != null)
			{
				return this.cachedAsset == asset;
			}
			if (this.guid != Guid.Empty)
			{
				return this.guid == asset.GUID;
			}
			return this.legacyId != 0 && this.legacyType == asset.assetCategory && this.legacyId == asset.id;
		}

		// Token: 0x06001503 RID: 5379 RVA: 0x00051D74 File Offset: 0x0004FF74
		public void Clear()
		{
			this.guid = Guid.Empty;
			this.legacyId = 0;
			this.legacyType = EAssetType.NONE;
			this.cachedAsset = null;
		}

		// Token: 0x06001504 RID: 5380 RVA: 0x00051D96 File Offset: 0x0004FF96
		public static bool operator ==(CachingBcAssetRef lhs, CachingBcAssetRef rhs)
		{
			return lhs.guid == rhs.guid && lhs.legacyId == rhs.legacyId && lhs.legacyType == rhs.legacyType;
		}

		// Token: 0x06001505 RID: 5381 RVA: 0x00051DC9 File Offset: 0x0004FFC9
		public static bool operator !=(CachingBcAssetRef lhs, CachingBcAssetRef rhs)
		{
			return !(lhs == rhs);
		}

		// Token: 0x06001506 RID: 5382 RVA: 0x00051DD8 File Offset: 0x0004FFD8
		public override bool Equals(object obj)
		{
			if (obj is CachingBcAssetRef)
			{
				CachingBcAssetRef rhs = (CachingBcAssetRef)obj;
				return this == rhs;
			}
			return false;
		}

		// Token: 0x06001507 RID: 5383 RVA: 0x00051E02 File Offset: 0x00050002
		public bool Equals(CachingBcAssetRef other)
		{
			return this == other;
		}

		// Token: 0x06001508 RID: 5384 RVA: 0x00051E10 File Offset: 0x00050010
		public override int GetHashCode()
		{
			return HashCode.Combine<Guid, ushort, EAssetType>(this.guid, this.legacyId, this.legacyType);
		}

		// Token: 0x06001509 RID: 5385 RVA: 0x00051E2C File Offset: 0x0005002C
		public override string ToString()
		{
			Asset asset = this.Get();
			string text = ((asset != null) ? asset.FriendlyName : null) ?? "null";
			if (this.legacyId == 0)
			{
				return string.Format("(GUID: {0:N}, Asset: {1})", this.guid, text);
			}
			return string.Format("(Legacy Type: {0}, Legacy ID: {1}, Asset: {2})", this.legacyType, this.legacyId, text);
		}

		// Token: 0x0600150A RID: 5386 RVA: 0x00051E98 File Offset: 0x00050098
		public bool TryParse(IDatNode node)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				return CachingBcAssetRef.TryParse(datValue.Value, out this);
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			if (datDictionary != null)
			{
				if (datDictionary.TryParseGuid("GUID", out this.guid))
				{
					return true;
				}
				if (datDictionary.TryParseEnum("Type", out this.legacyType) && datDictionary.TryParseUInt16("ID", out this.legacyId))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600150B RID: 5387 RVA: 0x00051F04 File Offset: 0x00050104
		public static bool TryParse(IDatNode node, EAssetType defaultLegacyType, out CachingBcAssetRef result)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				return CachingBcAssetRef.TryParse(datValue.Value, defaultLegacyType, out result);
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			if (datDictionary != null)
			{
				Guid guid;
				if (datDictionary.TryParseGuid("GUID", out guid))
				{
					result = new CachingBcAssetRef(guid);
					return true;
				}
				EAssetType eassetType;
				ushort num;
				if (datDictionary.TryParseEnum("Type", out eassetType) && datDictionary.TryParseUInt16("ID", out num))
				{
					result = new CachingBcAssetRef(eassetType, num);
					return true;
				}
			}
			result = CachingBcAssetRef.Empty;
			return false;
		}

		// Token: 0x0600150C RID: 5388 RVA: 0x00051F8C File Offset: 0x0005018C
		public static bool TryParse(IDatNode node, out CachingBcAssetRef result)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				return CachingBcAssetRef.TryParse(datValue.Value, out result);
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			if (datDictionary != null)
			{
				Guid guid;
				if (datDictionary.TryParseGuid("GUID", out guid))
				{
					result = new CachingBcAssetRef(guid);
					return true;
				}
				EAssetType eassetType;
				ushort num;
				if (datDictionary.TryParseEnum("Type", out eassetType) && datDictionary.TryParseUInt16("ID", out num))
				{
					result = new CachingBcAssetRef(eassetType, num);
					return true;
				}
			}
			result = CachingBcAssetRef.Empty;
			return false;
		}

		/// <summary>
		/// Supports both GUID and legacy ID formats.
		/// - If input string contains ':' the first part is EAssetType and the second part is legacy ID.
		/// - If defaultLegacyType is not None the input string can be parsed as a legacy ID.
		/// - Otherwise, parsed as GUID.
		/// </summary>
		// Token: 0x0600150D RID: 5389 RVA: 0x00052014 File Offset: 0x00050214
		public static bool TryParse(string input, EAssetType defaultLegacyType, out CachingBcAssetRef result)
		{
			if (!string.IsNullOrEmpty(input) && !string.Equals(input, "0"))
			{
				int num = input.IndexOf(':');
				if (num > 0)
				{
					EAssetType eassetType;
					if (!Enum.TryParse<EAssetType>(input.Substring(0, num), true, out eassetType))
					{
						result = CachingBcAssetRef.Empty;
						return false;
					}
					if (eassetType == EAssetType.NONE)
					{
						result = CachingBcAssetRef.Empty;
						return true;
					}
					ushort num2;
					if (ushort.TryParse(input.Substring(num + 1), out num2))
					{
						result = new CachingBcAssetRef(eassetType, num2);
						return true;
					}
				}
				else
				{
					ushort num3;
					if (defaultLegacyType != EAssetType.NONE && ushort.TryParse(input, out num3))
					{
						result = new CachingBcAssetRef(defaultLegacyType, num3);
						return true;
					}
					Guid guid;
					if (Guid.TryParse(input, out guid))
					{
						result = new CachingBcAssetRef(guid);
						return true;
					}
				}
			}
			result = CachingBcAssetRef.Empty;
			return false;
		}

		/// <summary>
		/// Supports both GUID and legacy ID formats.
		/// - If input string contains ':' the first part is EAssetType and the second part is legacy ID.
		/// - Otherwise, parsed as GUID.
		/// </summary>
		// Token: 0x0600150E RID: 5390 RVA: 0x000520DA File Offset: 0x000502DA
		public static bool TryParse(string input, out CachingBcAssetRef result)
		{
			return CachingBcAssetRef.TryParse(input, EAssetType.NONE, out result);
		}

		/// <summary>
		/// Returns Empty if TryParse returns false.
		/// </summary>
		// Token: 0x0600150F RID: 5391 RVA: 0x000520E4 File Offset: 0x000502E4
		public static CachingBcAssetRef Parse(string input, EAssetType defaultLegacyAssetType)
		{
			CachingBcAssetRef result;
			CachingBcAssetRef.TryParse(input, defaultLegacyAssetType, out result);
			return result;
		}

		/// <summary>
		/// Returns Empty if TryParse returns false.
		/// </summary>
		// Token: 0x06001510 RID: 5392 RVA: 0x000520FC File Offset: 0x000502FC
		public static CachingBcAssetRef Parse(string input)
		{
			CachingBcAssetRef result;
			CachingBcAssetRef.TryParse(input, out result);
			return result;
		}

		// Token: 0x06001511 RID: 5393 RVA: 0x00052113 File Offset: 0x00050313
		public CachingBcAssetRef(Asset asset)
		{
			this.guid = ((asset != null) ? asset.GUID : Guid.Empty);
			this.legacyType = EAssetType.NONE;
			this.legacyId = 0;
			this.cachedAsset = asset;
		}

		// Token: 0x06001512 RID: 5394 RVA: 0x00052140 File Offset: 0x00050340
		public CachingBcAssetRef(Guid guid)
		{
			this.guid = guid;
			this.legacyId = 0;
			this.legacyType = EAssetType.NONE;
			this.cachedAsset = null;
		}

		// Token: 0x06001513 RID: 5395 RVA: 0x0005215E File Offset: 0x0005035E
		public CachingBcAssetRef(EAssetType legacyType, ushort legacyId)
		{
			this.guid = Guid.Empty;
			this.legacyType = ((legacyId > 0) ? legacyType : EAssetType.NONE);
			this.legacyId = legacyId;
			this.cachedAsset = null;
		}

		// Token: 0x06001514 RID: 5396 RVA: 0x00052187 File Offset: 0x00050387
		public CachingBcAssetRef(Guid guid, EAssetType legacyType, ushort legacyId)
		{
			this.guid = ((legacyId > 0) ? Guid.Empty : guid);
			this.legacyType = ((legacyId > 0) ? legacyType : EAssetType.NONE);
			this.legacyId = legacyId;
			this.cachedAsset = null;
		}

		// Token: 0x06001515 RID: 5397 RVA: 0x000521B7 File Offset: 0x000503B7
		public CachingBcAssetRef(CachingAssetRef assetRef)
		{
			this.guid = assetRef.Guid;
			this.legacyType = EAssetType.NONE;
			this.legacyId = 0;
			this.cachedAsset = assetRef.cachedAsset;
		}

		/// <summary>
		/// Enables assigning assetRef from an existing asset without manually calling constructor.
		/// </summary>
		// Token: 0x06001516 RID: 5398 RVA: 0x000521E0 File Offset: 0x000503E0
		public static implicit operator CachingBcAssetRef(Asset asset)
		{
			return new CachingBcAssetRef(asset);
		}

		/// <summary>
		/// Enables assigning assetRef from an asset GUID without manually calling constructor.
		/// </summary>
		// Token: 0x06001517 RID: 5399 RVA: 0x000521E8 File Offset: 0x000503E8
		public static implicit operator CachingBcAssetRef(Guid guid)
		{
			return new CachingBcAssetRef(guid);
		}

		/// <summary>
		/// Enables assigning assetRef from a non-backwards-compatible asset ref without manually calling constructor.
		/// </summary>
		// Token: 0x06001518 RID: 5400 RVA: 0x000521F0 File Offset: 0x000503F0
		public static implicit operator CachingBcAssetRef(CachingAssetRef assetRef)
		{
			return new CachingBcAssetRef(assetRef);
		}

		// Token: 0x04000773 RID: 1907
		public static readonly CachingBcAssetRef Empty;

		// Token: 0x04000774 RID: 1908
		private Guid guid;

		// Token: 0x04000775 RID: 1909
		private ushort legacyId;

		// Token: 0x04000776 RID: 1910
		private EAssetType legacyType;

		// Token: 0x04000777 RID: 1911
		private Asset cachedAsset;
	}
}
