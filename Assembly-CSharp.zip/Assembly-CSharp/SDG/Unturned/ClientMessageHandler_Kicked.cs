﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x0200027A RID: 634
	internal static class ClientMessageHandler_Kicked
	{
		// Token: 0x060012FF RID: 4863 RVA: 0x00045184 File Offset: 0x00043384
		internal static void ReadMessage(NetPakReader reader)
		{
			string text;
			reader.ReadString(out text, 11);
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
			Provider._connectionFailureReason = text;
			Provider.RequestDisconnect("Kicked from server. Reason: \"" + text + "\"");
		}
	}
}
