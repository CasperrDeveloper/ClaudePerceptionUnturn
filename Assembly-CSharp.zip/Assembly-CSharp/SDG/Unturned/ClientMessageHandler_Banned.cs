﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000276 RID: 630
	internal static class ClientMessageHandler_Banned
	{
		// Token: 0x060012F9 RID: 4857 RVA: 0x00044C84 File Offset: 0x00042E84
		internal static void ReadMessage(NetPakReader reader)
		{
			string text;
			reader.ReadString(out text, 11);
			uint num;
			reader.ReadUInt32(out num);
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.BANNED;
			Provider._connectionFailureReason = text;
			Provider._connectionFailureDuration = num;
			Provider.RequestDisconnect(string.Format("Banned from server. Reason: \"{0}\" Duration: {1}", text, TimeSpan.FromSeconds(num)));
		}
	}
}
