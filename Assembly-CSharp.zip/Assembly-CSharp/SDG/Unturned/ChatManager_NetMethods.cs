﻿using System;
using SDG.NetPak;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020001E1 RID: 481
	[NetInvokableGeneratedClass(typeof(ChatManager))]
	public static class ChatManager_NetMethods
	{
		// Token: 0x06000E9A RID: 3738 RVA: 0x000365E4 File Offset: 0x000347E4
		[NetInvokableGeneratedMethod("ReceiveVoteStart", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveVoteStart_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			CSteamID origin;
			reader.ReadSteamID(out origin);
			CSteamID target;
			reader.ReadSteamID(out target);
			byte votesNeeded;
			reader.ReadUInt8(out votesNeeded);
			ChatManager.ReceiveVoteStart(origin, target, votesNeeded);
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x00036619 File Offset: 0x00034819
		[NetInvokableGeneratedMethod("ReceiveVoteStart", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveVoteStart_Write(NetPakWriter writer, CSteamID origin, CSteamID target, byte votesNeeded)
		{
			writer.WriteSteamID(origin);
			writer.WriteSteamID(target);
			writer.WriteUInt8(votesNeeded);
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x00036634 File Offset: 0x00034834
		[NetInvokableGeneratedMethod("ReceiveVoteUpdate", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveVoteUpdate_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			byte voteYes;
			reader.ReadUInt8(out voteYes);
			byte voteNo;
			reader.ReadUInt8(out voteNo);
			ChatManager.ReceiveVoteUpdate(voteYes, voteNo);
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x0003665F File Offset: 0x0003485F
		[NetInvokableGeneratedMethod("ReceiveVoteUpdate", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveVoteUpdate_Write(NetPakWriter writer, byte voteYes, byte voteNo)
		{
			writer.WriteUInt8(voteYes);
			writer.WriteUInt8(voteNo);
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x00036674 File Offset: 0x00034874
		[NetInvokableGeneratedMethod("ReceiveVoteStop", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveVoteStop_Read(in ClientInvocationContext context)
		{
			EVotingMessage message;
			context.reader.ReadEnum(out message);
			ChatManager.ReceiveVoteStop(message);
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x00036695 File Offset: 0x00034895
		[NetInvokableGeneratedMethod("ReceiveVoteStop", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveVoteStop_Write(NetPakWriter writer, EVotingMessage message)
		{
			writer.WriteEnum(message);
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x000366A0 File Offset: 0x000348A0
		[NetInvokableGeneratedMethod("ReceiveVoteMessage", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveVoteMessage_Read(in ClientInvocationContext context)
		{
			EVotingMessage message;
			context.reader.ReadEnum(out message);
			ChatManager.ReceiveVoteMessage(message);
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x000366C1 File Offset: 0x000348C1
		[NetInvokableGeneratedMethod("ReceiveVoteMessage", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveVoteMessage_Write(NetPakWriter writer, EVotingMessage message)
		{
			writer.WriteEnum(message);
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x000366CC File Offset: 0x000348CC
		[NetInvokableGeneratedMethod("ReceiveSubmitVoteRequest", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveSubmitVoteRequest_Read(in ServerInvocationContext context)
		{
			bool vote;
			context.reader.ReadBit(out vote);
			ChatManager.ReceiveSubmitVoteRequest(context, vote);
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x000366EE File Offset: 0x000348EE
		[NetInvokableGeneratedMethod("ReceiveSubmitVoteRequest", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveSubmitVoteRequest_Write(NetPakWriter writer, bool vote)
		{
			writer.WriteBit(vote);
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x000366F8 File Offset: 0x000348F8
		[NetInvokableGeneratedMethod("ReceiveCallVoteRequest", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveCallVoteRequest_Read(in ServerInvocationContext context)
		{
			CSteamID target;
			context.reader.ReadSteamID(out target);
			ChatManager.ReceiveCallVoteRequest(context, target);
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0003671A File Offset: 0x0003491A
		[NetInvokableGeneratedMethod("ReceiveCallVoteRequest", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveCallVoteRequest_Write(NetPakWriter writer, CSteamID target)
		{
			writer.WriteSteamID(target);
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x00036724 File Offset: 0x00034924
		[NetInvokableGeneratedMethod("ReceiveChatEntry", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveChatEntry_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			CSteamID owner;
			reader.ReadSteamID(out owner);
			string iconURL;
			reader.ReadString(out iconURL, 11);
			EChatMode mode;
			reader.ReadEnum(out mode);
			Color color;
			reader.ReadColor32RGB(out color);
			bool rich;
			reader.ReadBit(out rich);
			string text;
			reader.ReadString(out text, 11);
			ChatManager.ReceiveChatEntry(owner, iconURL, mode, color, rich, text);
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0003677D File Offset: 0x0003497D
		[NetInvokableGeneratedMethod("ReceiveChatEntry", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveChatEntry_Write(NetPakWriter writer, CSteamID owner, string iconURL, EChatMode mode, Color color, bool rich, string text)
		{
			writer.WriteSteamID(owner);
			writer.WriteString(iconURL, 11);
			writer.WriteEnum(mode);
			writer.WriteColor32RGB(color);
			writer.WriteBit(rich);
			writer.WriteString(text, 11);
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x000367BC File Offset: 0x000349BC
		[NetInvokableGeneratedMethod("ReceiveChatRequest", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveChatRequest_Read(in ServerInvocationContext context)
		{
			NetPakReader reader = context.reader;
			byte flags;
			reader.ReadUInt8(out flags);
			string text;
			reader.ReadString(out text, 11);
			ChatManager.ReceiveChatRequest(context, flags, text);
		}

		// Token: 0x06000EA9 RID: 3753 RVA: 0x000367EA File Offset: 0x000349EA
		[NetInvokableGeneratedMethod("ReceiveChatRequest", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveChatRequest_Write(NetPakWriter writer, byte flags, string text)
		{
			writer.WriteUInt8(flags);
			writer.WriteString(text, 11);
		}
	}
}
