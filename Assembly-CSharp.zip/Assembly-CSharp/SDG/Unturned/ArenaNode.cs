﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004FE RID: 1278
	public class ArenaNode : Node
	{
		/// <summary>
		/// This value is confusing because in the level editor it is the normalized radius, but in-game it is the radius.
		/// </summary>
		// Token: 0x17000872 RID: 2162
		// (get) Token: 0x060029D4 RID: 10708 RVA: 0x000B512D File Offset: 0x000B332D
		// (set) Token: 0x060029D5 RID: 10709 RVA: 0x000B5148 File Offset: 0x000B3348
		public float radius
		{
			get
			{
				if (Level.isEditor)
				{
					return this._normalizedRadius;
				}
				return ArenaNode.CalculateRadiusFromNormalizedRadius(this._normalizedRadius);
			}
			set
			{
				this._normalizedRadius = value;
			}
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x000B5151 File Offset: 0x000B3351
		public static float CalculateRadiusFromNormalizedRadius(float normalizedRadius)
		{
			return Mathf.Lerp(ArenaNode.MIN_SIZE, ArenaNode.MAX_SIZE, normalizedRadius) * 0.5f;
		}

		// Token: 0x060029D7 RID: 10711 RVA: 0x000B5169 File Offset: 0x000B3369
		public static float CalculateNormalizedRadiusFromRadius(float radius)
		{
			return Mathf.InverseLerp(ArenaNode.MIN_SIZE, ArenaNode.MAX_SIZE, radius * 2f);
		}

		// Token: 0x060029D8 RID: 10712 RVA: 0x000B5181 File Offset: 0x000B3381
		public ArenaNode(Vector3 newPoint) : this(newPoint, 0f)
		{
		}

		// Token: 0x060029D9 RID: 10713 RVA: 0x000B518F File Offset: 0x000B338F
		public ArenaNode(Vector3 newPoint, float newRadius)
		{
			this._point = newPoint;
			this._normalizedRadius = newRadius;
			this._type = ENodeType.ARENA;
		}

		// Token: 0x0400151A RID: 5402
		public static readonly float MIN_SIZE = 128f;

		// Token: 0x0400151B RID: 5403
		public static readonly float MAX_SIZE = 8192f;

		// Token: 0x0400151C RID: 5404
		internal float _normalizedRadius;
	}
}
