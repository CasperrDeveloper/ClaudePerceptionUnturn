﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005A6 RID: 1446
	// (Invoke) Token: 0x06003068 RID: 12392
	public delegate void CheckPermissions(SteamPlayer player, string text, ref bool shouldExecuteCommand, ref bool shouldList);
}
