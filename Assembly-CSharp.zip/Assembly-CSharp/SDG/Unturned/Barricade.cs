﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004D4 RID: 1236
	public class Barricade
	{
		// Token: 0x17000831 RID: 2097
		// (get) Token: 0x060028D6 RID: 10454 RVA: 0x000B1D2D File Offset: 0x000AFF2D
		public bool isDead
		{
			get
			{
				return this.health == 0;
			}
		}

		// Token: 0x17000832 RID: 2098
		// (get) Token: 0x060028D7 RID: 10455 RVA: 0x000B1D38 File Offset: 0x000AFF38
		public bool isRepaired
		{
			get
			{
				return this.health == this.asset.health;
			}
		}

		// Token: 0x17000833 RID: 2099
		// (get) Token: 0x060028D8 RID: 10456 RVA: 0x000B1D4D File Offset: 0x000AFF4D
		[Obsolete]
		public ushort id
		{
			get
			{
				return this.asset.id;
			}
		}

		// Token: 0x17000834 RID: 2100
		// (get) Token: 0x060028D9 RID: 10457 RVA: 0x000B1D5A File Offset: 0x000AFF5A
		// (set) Token: 0x060028DA RID: 10458 RVA: 0x000B1D62 File Offset: 0x000AFF62
		public ItemBarricadeAsset asset { get; private set; }

		// Token: 0x060028DB RID: 10459 RVA: 0x000B1D6B File Offset: 0x000AFF6B
		public void askDamage(ushort amount)
		{
			if (amount == 0 || this.isDead)
			{
				return;
			}
			if (amount >= this.health)
			{
				this.health = 0;
				return;
			}
			this.health -= amount;
		}

		// Token: 0x060028DC RID: 10460 RVA: 0x000B1D9C File Offset: 0x000AFF9C
		public void askRepair(ushort amount)
		{
			if (amount == 0 || this.isDead)
			{
				return;
			}
			if (amount >= this.asset.health - this.health)
			{
				this.health = this.asset.health;
				return;
			}
			this.health += amount;
		}

		// Token: 0x060028DD RID: 10461 RVA: 0x000B1DEC File Offset: 0x000AFFEC
		[Obsolete]
		public Barricade(ushort newID)
		{
			this.asset = (Assets.find(EAssetType.ITEM, newID) as ItemBarricadeAsset);
			if (this.asset == null)
			{
				this.health = 0;
				this.state = new byte[0];
				return;
			}
			this.health = this.asset.health;
			this.state = this.asset.getState();
		}

		// Token: 0x060028DE RID: 10462 RVA: 0x000B1E4F File Offset: 0x000B004F
		[Obsolete]
		public Barricade(ushort newID, ushort newHealth, byte[] newState, ItemBarricadeAsset newAsset)
		{
			this.health = newHealth;
			this.state = newState;
			this.asset = newAsset;
		}

		// Token: 0x060028DF RID: 10463 RVA: 0x000B1E70 File Offset: 0x000B0070
		public Barricade(ItemBarricadeAsset newAsset)
		{
			this.asset = newAsset;
			if (this.asset != null)
			{
				this.health = this.asset.health;
				this.state = this.asset.getState();
				return;
			}
			this.health = 0;
			this.state = new byte[0];
		}

		// Token: 0x060028E0 RID: 10464 RVA: 0x000B1EC8 File Offset: 0x000B00C8
		public Barricade(ItemBarricadeAsset newAsset, ushort newHealth, byte[] newState)
		{
			this.asset = newAsset;
			this.health = newHealth;
			this.state = newState;
		}

		// Token: 0x060028E1 RID: 10465 RVA: 0x000B1EE8 File Offset: 0x000B00E8
		public override string ToString()
		{
			string[] array = new string[5];
			int num = 0;
			ItemBarricadeAsset asset = this.asset;
			array[num] = ((asset != null) ? asset.ToString() : null);
			array[1] = " ";
			array[2] = this.health.ToString();
			array[3] = " ";
			array[4] = this.state.Length.ToString();
			return string.Concat(array);
		}

		// Token: 0x04001478 RID: 5240
		public ushort health;

		// Token: 0x04001479 RID: 5241
		public byte[] state;
	}
}
