﻿using System;
using System.Collections.Generic;
using SDG.Provider;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200060F RID: 1551
	public class Characters : MonoBehaviour
	{
		// Token: 0x170009E4 RID: 2532
		// (get) Token: 0x06003535 RID: 13621 RVA: 0x000FBACC File Offset: 0x000F9CCC
		// (set) Token: 0x06003536 RID: 13622 RVA: 0x000FBAD3 File Offset: 0x000F9CD3
		public static byte selected
		{
			get
			{
				return Characters._selected;
			}
			set
			{
				Characters._selected = value;
				CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
				if (characterUpdated != null)
				{
					characterUpdated(Characters.selected, Characters.active);
				}
				Characters.RefreshPreviewCharacterModel();
			}
		}

		// Token: 0x170009E5 RID: 2533
		// (get) Token: 0x06003537 RID: 13623 RVA: 0x000FBAFA File Offset: 0x000F9CFA
		public static Character active
		{
			get
			{
				return Characters.list[(int)Characters.selected];
			}
		}

		// Token: 0x170009E6 RID: 2534
		// (get) Token: 0x06003538 RID: 13624 RVA: 0x000FBB07 File Offset: 0x000F9D07
		// (set) Token: 0x06003539 RID: 13625 RVA: 0x000FBB0E File Offset: 0x000F9D0E
		public static Character[] list { get; private set; }

		// Token: 0x170009E7 RID: 2535
		// (get) Token: 0x0600353A RID: 13626 RVA: 0x000FBB16 File Offset: 0x000F9D16
		public static List<ulong> packageSkins
		{
			get
			{
				return Characters._packageSkins;
			}
		}

		// Token: 0x0600353B RID: 13627 RVA: 0x000FBB1D File Offset: 0x000F9D1D
		public static void rename(string name)
		{
			Characters.active.name = name;
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x0600353C RID: 13628 RVA: 0x000FBB43 File Offset: 0x000F9D43
		public static void skillify(EPlayerSkillset skillset)
		{
			Characters.active.skillset = skillset;
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated != null)
			{
				characterUpdated(Characters.selected, Characters.active);
			}
			Characters.active.applyHero();
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x0600353D RID: 13629 RVA: 0x000FBB79 File Offset: 0x000F9D79
		public static void growFace(byte face)
		{
			Characters.active.face = face;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x0600353E RID: 13630 RVA: 0x000FBB8B File Offset: 0x000F9D8B
		public static void growHair(byte hair)
		{
			Characters.active.hair = hair;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x0600353F RID: 13631 RVA: 0x000FBB9D File Offset: 0x000F9D9D
		public static void growBeard(byte beard)
		{
			Characters.active.beard = beard;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x06003540 RID: 13632 RVA: 0x000FBBAF File Offset: 0x000F9DAF
		public static void paintSkin(Color color)
		{
			Characters.active.skin = color;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x06003541 RID: 13633 RVA: 0x000FBBC1 File Offset: 0x000F9DC1
		public static void paintColor(Color color)
		{
			Characters.active.color = color;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x06003542 RID: 13634 RVA: 0x000FBBD3 File Offset: 0x000F9DD3
		public static void renick(string nick)
		{
			Characters.active.nick = nick;
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x06003543 RID: 13635 RVA: 0x000FBBF9 File Offset: 0x000F9DF9
		public static void paintMarkerColor(Color color)
		{
			Characters.active.markerColor = color;
		}

		// Token: 0x06003544 RID: 13636 RVA: 0x000FBC06 File Offset: 0x000F9E06
		public static void ChangeBeardColor(Color color)
		{
			Characters.active.BeardColor = color;
			Characters.RefreshPreviewCharacterModel();
		}

		// Token: 0x06003545 RID: 13637 RVA: 0x000FBC18 File Offset: 0x000F9E18
		public static void group(CSteamID group)
		{
			if (Characters.active.group == group)
			{
				Characters.active.group = CSteamID.Nil;
			}
			else
			{
				Characters.active.group = group;
			}
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x06003546 RID: 13638 RVA: 0x000FBC6C File Offset: 0x000F9E6C
		public static void ungroup()
		{
			Characters.active.group = CSteamID.Nil;
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x06003547 RID: 13639 RVA: 0x000FBC96 File Offset: 0x000F9E96
		public static void hand(bool state)
		{
			Characters.active.hand = state;
			Characters.RefreshPreviewCharacterModel();
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x06003548 RID: 13640 RVA: 0x000FBCC1 File Offset: 0x000F9EC1
		public static bool isSkinEquipped(ulong instance)
		{
			return instance != 0UL && Characters.packageSkins.IndexOf(instance) != -1;
		}

		// Token: 0x06003549 RID: 13641 RVA: 0x000FBCDC File Offset: 0x000F9EDC
		public static bool isCosmeticEquipped(ulong instance)
		{
			return instance != 0UL && (Characters.active.packageBackpack == instance || Characters.active.packageGlasses == instance || Characters.active.packageHat == instance || Characters.active.packageMask == instance || Characters.active.packagePants == instance || Characters.active.packageShirt == instance || Characters.active.packageVest == instance);
		}

		/// <summary>
		/// Is cosmetic or skin equipped?
		/// </summary>
		// Token: 0x0600354A RID: 13642 RVA: 0x000FBD4B File Offset: 0x000F9F4B
		public static bool isEquipped(ulong instanceID)
		{
			return Characters.isSkinEquipped(instanceID) || Characters.isCosmeticEquipped(instanceID);
		}

		// Token: 0x0600354B RID: 13643 RVA: 0x000FBD60 File Offset: 0x000F9F60
		public static void ToggleEquipItemByInstanceId(ulong itemInstanceId)
		{
			int inventoryItem = Provider.provider.economyService.getInventoryItem(itemInstanceId);
			if (inventoryItem == 0)
			{
				return;
			}
			Guid guid;
			Guid a;
			Provider.provider.economyService.getInventoryTargetID(inventoryItem, out guid, out a);
			if (guid == default(Guid) && a == default(Guid))
			{
				return;
			}
			ItemAsset itemAsset = Assets.find<ItemAsset>(guid);
			if (itemAsset == null || itemAsset.proPath == null || itemAsset.proPath.Length == 0)
			{
				if (Provider.provider.economyService.getInventorySkinID(inventoryItem) == 0)
				{
					return;
				}
				if (!Characters.packageSkins.Remove(itemInstanceId))
				{
					for (int i = 0; i < Characters.packageSkins.Count; i++)
					{
						ulong num = Characters.packageSkins[i];
						if (num != 0UL)
						{
							int inventoryItem2 = Provider.provider.economyService.getInventoryItem(num);
							if (inventoryItem2 != 0)
							{
								Guid b;
								Guid b2;
								Provider.provider.economyService.getInventoryTargetID(inventoryItem2, out b, out b2);
								if ((guid != default(Guid) && guid == b) || (a != default(Guid) && a == b2))
								{
									Characters.packageSkins.RemoveAt(i);
									break;
								}
							}
						}
					}
					Characters.packageSkins.Add(itemInstanceId);
				}
			}
			if (itemAsset != null)
			{
				if (itemAsset.type == EItemType.SHIRT)
				{
					if (Characters.active.packageShirt == itemInstanceId)
					{
						Characters.active.packageShirt = 0UL;
					}
					else
					{
						Characters.active.packageShirt = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.PANTS)
				{
					if (Characters.active.packagePants == itemInstanceId)
					{
						Characters.active.packagePants = 0UL;
					}
					else
					{
						Characters.active.packagePants = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.HAT)
				{
					if (Characters.active.packageHat == itemInstanceId)
					{
						Characters.active.packageHat = 0UL;
					}
					else
					{
						Characters.active.packageHat = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.BACKPACK)
				{
					if (Characters.active.packageBackpack == itemInstanceId)
					{
						Characters.active.packageBackpack = 0UL;
					}
					else
					{
						Characters.active.packageBackpack = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.VEST)
				{
					if (Characters.active.packageVest == itemInstanceId)
					{
						Characters.active.packageVest = 0UL;
					}
					else
					{
						Characters.active.packageVest = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.MASK)
				{
					if (Characters.active.packageMask == itemInstanceId)
					{
						Characters.active.packageMask = 0UL;
					}
					else
					{
						Characters.active.packageMask = itemInstanceId;
					}
				}
				else if (itemAsset.type == EItemType.GLASSES)
				{
					if (Characters.active.packageGlasses == itemInstanceId)
					{
						Characters.active.packageGlasses = 0UL;
					}
					else
					{
						Characters.active.packageGlasses = itemInstanceId;
					}
				}
			}
			Characters.RefreshPreviewCharacterModel();
			CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
			if (characterUpdated == null)
			{
				return;
			}
			characterUpdated(Characters.selected, Characters.active);
		}

		// Token: 0x0600354C RID: 13644 RVA: 0x000FC040 File Offset: 0x000FA240
		public static bool getPackageForItemID(ushort itemID, out ulong itemInstanceId)
		{
			itemInstanceId = 0UL;
			ItemAsset itemAsset = Assets.find(EAssetType.ITEM, itemID) as ItemAsset;
			if (itemAsset == null)
			{
				return false;
			}
			for (int i = 0; i < Characters.packageSkins.Count; i++)
			{
				itemInstanceId = Characters.packageSkins[i];
				if (itemInstanceId != 0UL)
				{
					int inventoryItem = Provider.provider.economyService.getInventoryItem(itemInstanceId);
					if (inventoryItem != 0)
					{
						Guid inventoryItemGuid = Provider.provider.economyService.getInventoryItemGuid(inventoryItem);
						if (!(inventoryItemGuid == default(Guid)) && itemAsset.GUID == inventoryItemGuid)
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		// Token: 0x0600354D RID: 13645 RVA: 0x000FC0D4 File Offset: 0x000FA2D4
		private static bool getSlot0StatTrackerValue(out EStatTrackerType type, out int kills)
		{
			type = EStatTrackerType.NONE;
			kills = -1;
			ulong instance;
			return Characters.getPackageForItemID(Characters.active.primaryItem, out instance) && Provider.provider.economyService.getInventoryStatTrackerValue(instance, out type, out kills);
		}

		// Token: 0x0600354E RID: 13646 RVA: 0x000FC110 File Offset: 0x000FA310
		private static bool getSlot1StatTrackerValue(out EStatTrackerType type, out int kills)
		{
			type = EStatTrackerType.NONE;
			kills = -1;
			ulong instance;
			return Characters.getPackageForItemID(Characters.active.secondaryItem, out instance) && Provider.provider.economyService.getInventoryStatTrackerValue(instance, out type, out kills);
		}

		// Token: 0x0600354F RID: 13647 RVA: 0x000FC14C File Offset: 0x000FA34C
		private static void apply(byte slot, bool showItems)
		{
			if (Characters.slots[(int)slot] != null)
			{
				UnityEngine.Object.Destroy(Characters.slots[(int)slot].gameObject);
			}
			if (!showItems)
			{
				return;
			}
			ushort num = 0;
			byte[] state = null;
			if (slot == 0)
			{
				num = Characters.active.primaryItem;
				state = Characters.active.primaryState;
			}
			else if (slot == 1)
			{
				num = Characters.active.secondaryItem;
				state = Characters.active.secondaryState;
			}
			if (num == 0)
			{
				return;
			}
			ItemAsset itemAsset = Assets.find(EAssetType.ITEM, num) as ItemAsset;
			if (itemAsset != null)
			{
				ushort skin = 0;
				ushort num2 = 0;
				bool flag = itemAsset.sharedSkinLookupID != num;
				Guid guid = itemAsset.GUID;
				if (flag)
				{
					Asset asset = Assets.find(EAssetType.ITEM, itemAsset.sharedSkinLookupID);
					if (asset != null)
					{
						guid = asset.GUID;
					}
				}
				for (int i = 0; i < Characters.packageSkins.Count; i++)
				{
					ulong num3 = Characters.packageSkins[i];
					if (num3 != 0UL)
					{
						int inventoryItem = Provider.provider.economyService.getInventoryItem(num3);
						if (inventoryItem != 0)
						{
							Guid inventoryItemGuid = Provider.provider.economyService.getInventoryItemGuid(inventoryItem);
							if (!(inventoryItemGuid == default(Guid)) && guid == inventoryItemGuid)
							{
								skin = Provider.provider.economyService.getInventorySkinID(inventoryItem);
								num2 = Provider.provider.economyService.getInventoryMythicID(inventoryItem);
								if (num2 == 0)
								{
									num2 = Provider.provider.economyService.getInventoryParticleEffect(num3);
									break;
								}
								break;
							}
						}
					}
				}
				GetStatTrackerValueHandler statTrackerCallback = null;
				if (slot == 0)
				{
					statTrackerCallback = new GetStatTrackerValueHandler(Characters.getSlot0StatTrackerValue);
				}
				else if (slot == 1)
				{
					statTrackerCallback = new GetStatTrackerValueHandler(Characters.getSlot1StatTrackerValue);
				}
				Transform item = ItemTool.getItem(num, skin, 100, state, false, itemAsset, statTrackerCallback);
				if (slot == 0)
				{
					if (itemAsset.type == EItemType.MELEE)
					{
						item.transform.parent = Characters.primaryMeleeSlot;
					}
					else if (itemAsset.slot == ESlotType.PRIMARY)
					{
						item.transform.parent = Characters.primaryLargeGunSlot;
					}
					else
					{
						item.transform.parent = Characters.primarySmallGunSlot;
					}
				}
				else if (slot == 1)
				{
					if (itemAsset.type == EItemType.MELEE)
					{
						item.transform.parent = Characters.secondaryMeleeSlot;
					}
					else
					{
						item.transform.parent = Characters.secondaryGunSlot;
					}
				}
				item.localPosition = Vector3.zero;
				item.localRotation = Quaternion.Euler(0f, 0f, 90f);
				item.localScale = Vector3.one;
				UnityEngine.Object.Destroy(item.GetComponent<Collider>());
				if (num2 != 0)
				{
					ItemTool.ApplyMythicalEffect(item, num2, EEffectType.THIRD);
				}
				Characters.slots[(int)slot] = item;
			}
		}

		// Token: 0x06003550 RID: 13648 RVA: 0x000FC3CD File Offset: 0x000FA5CD
		public static void RefreshPreviewCharacterModel()
		{
			if (Characters.active == null)
			{
				UnturnedLog.error("Failed to find an active character.");
				return;
			}
			if (Characters.clothes == null)
			{
				UnturnedLog.error("Failed to find character clothes.");
				return;
			}
			Characters.wasRefreshCharacterRequested = true;
		}

		// Token: 0x06003551 RID: 13649 RVA: 0x000FC400 File Offset: 0x000FA600
		private static void applyInternal()
		{
			bool active = MenuSurvivorsAppearanceUI.active;
			bool flag = MenuSurvivorsClothingUI.active || MenuSurvivorsClothingBoxUI.active || MenuSurvivorsClothingDeleteUI.active || MenuSurvivorsClothingInspectUI.active || MenuSurvivorsClothingItemUI.active;
			ItemStoreMenu instance = ItemStoreMenu.instance;
			if (instance != null && instance.IsOpen)
			{
				flag = true;
			}
			ItemStoreCartMenu instance2 = ItemStoreCartMenu.instance;
			if (instance2 != null && instance2.IsOpen)
			{
				flag = true;
			}
			ItemStoreDetailsMenu instance3 = ItemStoreDetailsMenu.instance;
			if (instance3 != null && instance3.IsOpen)
			{
				flag = true;
			}
			ItemStoreBundleContentsMenu instance4 = ItemStoreBundleContentsMenu.instance;
			if (instance4 != null && instance4.IsOpen)
			{
				flag = true;
			}
			bool flag2 = !active && !flag && !Characters.previewItemSolo;
			bool flag3 = !active && !Characters.previewItemSolo;
			Characters.character.localScale = new Vector3((float)(Characters.active.hand ? -1 : 1), 1f, 1f);
			if (flag2)
			{
				Characters.clothes.shirt = Characters.active.shirt;
				Characters.clothes.pants = Characters.active.pants;
				Characters.clothes.hat = Characters.active.hat;
				Characters.clothes.backpack = Characters.active.backpack;
				Characters.clothes.vest = Characters.active.vest;
				Characters.clothes.mask = Characters.active.mask;
				Characters.clothes.glasses = Characters.active.glasses;
			}
			else
			{
				Characters.clothes.shirt = 0;
				Characters.clothes.pants = 0;
				Characters.clothes.hat = 0;
				Characters.clothes.backpack = 0;
				Characters.clothes.vest = 0;
				Characters.clothes.mask = 0;
				Characters.clothes.glasses = 0;
			}
			if (flag3)
			{
				if (Characters.active.packageShirt != 0UL)
				{
					Characters.clothes.visualShirt = Provider.provider.economyService.getInventoryItem(Characters.active.packageShirt);
				}
				else
				{
					Characters.clothes.visualShirt = 0;
				}
				if (Characters.active.packagePants != 0UL)
				{
					Characters.clothes.visualPants = Provider.provider.economyService.getInventoryItem(Characters.active.packagePants);
				}
				else
				{
					Characters.clothes.visualPants = 0;
				}
				if (Characters.active.packageHat != 0UL)
				{
					Characters.clothes.visualHat = Provider.provider.economyService.getInventoryItem(Characters.active.packageHat);
				}
				else
				{
					Characters.clothes.visualHat = 0;
				}
				if (Characters.active.packageBackpack != 0UL)
				{
					Characters.clothes.visualBackpack = Provider.provider.economyService.getInventoryItem(Characters.active.packageBackpack);
				}
				else
				{
					Characters.clothes.visualBackpack = 0;
				}
				if (Characters.active.packageVest != 0UL)
				{
					Characters.clothes.visualVest = Provider.provider.economyService.getInventoryItem(Characters.active.packageVest);
				}
				else
				{
					Characters.clothes.visualVest = 0;
				}
				if (Characters.active.packageMask != 0UL)
				{
					Characters.clothes.visualMask = Provider.provider.economyService.getInventoryItem(Characters.active.packageMask);
				}
				else
				{
					Characters.clothes.visualMask = 0;
				}
				if (Characters.active.packageGlasses != 0UL)
				{
					Characters.clothes.visualGlasses = Provider.provider.economyService.getInventoryItem(Characters.active.packageGlasses);
				}
				else
				{
					Characters.clothes.visualGlasses = 0;
				}
			}
			else
			{
				Characters.clothes.visualShirt = 0;
				Characters.clothes.visualPants = 0;
				Characters.clothes.visualHat = 0;
				Characters.clothes.visualBackpack = 0;
				Characters.clothes.visualVest = 0;
				Characters.clothes.visualMask = 0;
				Characters.clothes.visualGlasses = 0;
			}
			if (Characters.previewItemDefId > 0)
			{
				ItemAsset itemAsset = Assets.find<ItemAsset>(Provider.provider.economyService.getInventoryItemGuid(Characters.previewItemDefId));
				if (itemAsset != null)
				{
					switch (itemAsset.type)
					{
					case EItemType.HAT:
						Characters.clothes.visualHat = Characters.previewItemDefId;
						break;
					case EItemType.PANTS:
						Characters.clothes.visualPants = Characters.previewItemDefId;
						break;
					case EItemType.SHIRT:
						Characters.clothes.visualShirt = Characters.previewItemDefId;
						break;
					case EItemType.MASK:
						Characters.clothes.visualMask = Characters.previewItemDefId;
						break;
					case EItemType.BACKPACK:
						Characters.clothes.visualBackpack = Characters.previewItemDefId;
						break;
					case EItemType.VEST:
						Characters.clothes.visualVest = Characters.previewItemDefId;
						break;
					case EItemType.GLASSES:
						Characters.clothes.visualGlasses = Characters.previewItemDefId;
						break;
					}
				}
			}
			Characters.clothes.face = Characters.active.face;
			Characters.clothes.hair = Characters.active.hair;
			Characters.clothes.beard = Characters.active.beard;
			Characters.clothes.skin = Characters.active.skin;
			Characters.clothes.color = Characters.active.color;
			Characters.clothes.BeardColor = Characters.active.BeardColor;
			Characters.clothes.hand = Characters.active.hand;
			Characters.clothes.apply();
			byte b = 0;
			while ((int)b < Characters.slots.Length)
			{
				Characters.apply(b, flag2);
				b += 1;
			}
		}

		// Token: 0x06003552 RID: 13650 RVA: 0x000FC930 File Offset: 0x000FAB30
		private static void onInventoryRefreshed()
		{
			if (Characters.clothes != null && Characters.list != null && Characters.packageSkins != null)
			{
				for (int i = Characters.packageSkins.Count - 1; i >= 0; i--)
				{
					ulong num = Characters.packageSkins[i];
					if (num != 0UL && Provider.provider.economyService.getInventoryItem(num) == 0)
					{
						Characters.packageSkins.RemoveAt(i);
					}
				}
				for (int j = 0; j < Characters.list.Length; j++)
				{
					Character character = Characters.list[j];
					if (character != null)
					{
						if (character.packageShirt != 0UL && Provider.provider.economyService.getInventoryItem(character.packageShirt) == 0)
						{
							character.packageShirt = 0UL;
						}
						if (character.packagePants != 0UL && Provider.provider.economyService.getInventoryItem(character.packagePants) == 0)
						{
							character.packagePants = 0UL;
						}
						if (character.packageHat != 0UL && Provider.provider.economyService.getInventoryItem(character.packageHat) == 0)
						{
							character.packageHat = 0UL;
						}
						if (character.packageBackpack != 0UL && Provider.provider.economyService.getInventoryItem(character.packageBackpack) == 0)
						{
							character.packageBackpack = 0UL;
						}
						if (character.packageVest != 0UL && Provider.provider.economyService.getInventoryItem(character.packageVest) == 0)
						{
							character.packageVest = 0UL;
						}
						if (character.packageMask != 0UL && Provider.provider.economyService.getInventoryItem(character.packageMask) == 0)
						{
							character.packageMask = 0UL;
						}
						if (character.packageGlasses != 0UL && Provider.provider.economyService.getInventoryItem(character.packageGlasses) == 0)
						{
							character.packageGlasses = 0UL;
						}
					}
				}
				if (!Characters.initialApply)
				{
					Characters.initialApply = true;
					Characters.RefreshPreviewCharacterModel();
				}
			}
			if (Characters.hasDropped)
			{
				return;
			}
			Characters.hasDropped = true;
			if (Characters.hasPlayed)
			{
				Provider.provider.economyService.dropInventory();
				LiveConfig.Refresh();
			}
		}

		// Token: 0x06003553 RID: 13651 RVA: 0x000FCB18 File Offset: 0x000FAD18
		private void Update()
		{
			if (Dedicator.IsDedicatedServer)
			{
				return;
			}
			if (Characters.character == null)
			{
				return;
			}
			Characters._characterYaw = Mathf.Lerp(Characters._characterYaw, Characters.characterOffset + Characters.characterYaw, 4f * Time.deltaTime);
			Characters.character.transform.rotation = Quaternion.Euler(90f, Characters._characterYaw, 0f);
			if (Characters.wasRefreshCharacterRequested)
			{
				Characters.wasRefreshCharacterRequested = false;
				try
				{
					Characters.applyInternal();
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e);
				}
			}
		}

		// Token: 0x06003554 RID: 13652 RVA: 0x000FCBB0 File Offset: 0x000FADB0
		private void ResetCharacterYaw(MenuOverridableObjects source)
		{
			Characters.characterOffset = Characters.character.transform.eulerAngles.y;
			Characters._characterYaw = Characters.characterOffset;
			Characters.characterYaw = 0f;
		}

		// Token: 0x06003555 RID: 13653 RVA: 0x000FCBDF File Offset: 0x000FADDF
		private void OnDestroy()
		{
			MenuOverridableObjects.OnMenuOverridesApplied -= this.ResetCharacterYaw;
		}

		// Token: 0x06003556 RID: 13654 RVA: 0x000FCBF4 File Offset: 0x000FADF4
		internal void customStart()
		{
			Characters.character = GameObject.Find("Hero").transform;
			Characters.clothes = Characters.character.GetComponent<HumanClothes>();
			Characters.clothes.isView = true;
			Characters.slots = new Transform[(int)PlayerInventory.SLOTS];
			Characters.primaryMeleeSlot = Characters.character.Find("Skeleton").Find("Spine").Find("Primary_Melee");
			Characters.primaryLargeGunSlot = Characters.character.Find("Skeleton").Find("Spine").Find("Primary_Large_Gun");
			Characters.primarySmallGunSlot = Characters.character.Find("Skeleton").Find("Spine").Find("Primary_Small_Gun");
			Characters.secondaryMeleeSlot = Characters.character.Find("Skeleton").Find("Right_Hip").Find("Right_Leg").Find("Secondary_Melee");
			Characters.secondaryGunSlot = Characters.character.Find("Skeleton").Find("Right_Hip").Find("Right_Leg").Find("Secondary_Gun");
			MenuOverridableObjects.OnMenuOverridesApplied += this.ResetCharacterYaw;
			this.ResetCharacterYaw(null);
			Characters.previewItemDefId = 0;
			Characters.previewItemSolo = false;
			Characters.hasDropped = false;
			if (!Characters.hasLoaded)
			{
				TempSteamworksEconomy economyService = Provider.provider.economyService;
				economyService.onInventoryRefreshed = (TempSteamworksEconomy.InventoryRefreshed)Delegate.Combine(economyService.onInventoryRefreshed, new TempSteamworksEconomy.InventoryRefreshed(Characters.onInventoryRefreshed));
			}
			Characters.load();
		}

		// Token: 0x06003557 RID: 13655 RVA: 0x000FCD7C File Offset: 0x000FAF7C
		public static void load()
		{
			Characters.initialApply = false;
			Provider.provider.economyService.refreshInventory();
			if (Characters.list != null)
			{
				byte b = 0;
				while ((int)b < Characters.list.Length)
				{
					if (Characters.list[(int)b] != null)
					{
						CharacterUpdated characterUpdated = Characters.onCharacterUpdated;
						if (characterUpdated != null)
						{
							characterUpdated(b, Characters.list[(int)b]);
						}
					}
					b += 1;
				}
				return;
			}
			Characters.list = new Character[(int)(Customization.FREE_CHARACTERS + Customization.PRO_CHARACTERS)];
			Characters._packageSkins = new List<ulong>();
			if (ReadWrite.fileExists("/Characters.dat", true))
			{
				Block block = ReadWrite.readBlock("/Characters.dat", true, 0);
				if (block != null)
				{
					byte b2 = block.readByte();
					if (b2 >= 12)
					{
						if (b2 >= 14)
						{
							ushort num = block.readUInt16();
							for (ushort num2 = 0; num2 < num; num2 += 1)
							{
								ulong num3 = block.readUInt64();
								if (num3 != 0UL)
								{
									Characters.packageSkins.Add(num3);
								}
							}
						}
						Characters._selected = block.readByte();
						if ((int)Characters._selected >= Characters.list.Length || (!Provider.isPro && Characters.selected >= Customization.FREE_CHARACTERS))
						{
							Characters._selected = 0;
						}
						byte b3 = 0;
						while ((int)b3 < Characters.list.Length)
						{
							ushort newShirt = block.readUInt16();
							ushort newPants = block.readUInt16();
							ushort newHat = block.readUInt16();
							ushort newBackpack = block.readUInt16();
							ushort newVest = block.readUInt16();
							ushort newMask = block.readUInt16();
							ushort newGlasses = block.readUInt16();
							ulong newPackageShirt = block.readUInt64();
							ulong newPackagePants = block.readUInt64();
							ulong newPackageHat = block.readUInt64();
							ulong newPackageBackpack = block.readUInt64();
							ulong newPackageVest = block.readUInt64();
							ulong newPackageMask = block.readUInt64();
							ulong newPackageGlasses = block.readUInt64();
							ushort newPrimaryItem = block.readUInt16();
							byte[] newPrimaryState = block.readByteArray();
							ushort newSecondaryItem = block.readUInt16();
							byte[] newSecondaryState = block.readByteArray();
							byte b4 = block.readByte();
							byte b5 = block.readByte();
							byte b6 = block.readByte();
							Color color = block.readColor();
							Color color2 = block.readColor();
							Color newMarkerColor;
							if (b2 > 20)
							{
								newMarkerColor = block.readColor();
							}
							else
							{
								newMarkerColor = Customization.MARKER_COLORS[UnityEngine.Random.Range(0, Customization.MARKER_COLORS.Length)];
							}
							Color color3;
							if (b2 >= 22)
							{
								color3 = block.readColor();
							}
							else
							{
								color3 = color2;
							}
							bool newHand = block.readBoolean();
							string newName = block.readString();
							if (b2 < 19)
							{
								newName = Provider.clientName;
							}
							string newNick = block.readString();
							CSteamID csteamID = block.readSteamID();
							byte b7 = block.readByte();
							if (!Provider.provider.communityService.checkGroup(csteamID))
							{
								csteamID = CSteamID.Nil;
							}
							if (b7 >= Customization.SKILLSETS)
							{
								b7 = 0;
							}
							if (b2 < 16)
							{
								b7 = (byte)UnityEngine.Random.Range(1, (int)Customization.SKILLSETS);
							}
							if (b2 > 16 && b2 < 20)
							{
								block.readBoolean();
							}
							if (!Provider.isPro)
							{
								if (b3 >= Customization.FREE_CHARACTERS)
								{
									newName = Provider.clientName;
									newNick = Provider.clientName;
								}
								if (b4 >= Customization.FACES_FREE)
								{
									b4 = (byte)UnityEngine.Random.Range(0, (int)Customization.FACES_FREE);
								}
								if (b5 >= Customization.HAIRS_FREE)
								{
									b5 = (byte)UnityEngine.Random.Range(0, (int)Customization.HAIRS_FREE);
								}
								if (b6 >= Customization.BEARDS_FREE)
								{
									b6 = 0;
								}
								if (!Customization.checkSkin(color))
								{
									color = Customization.SKINS[UnityEngine.Random.Range(0, Customization.SKINS.Length)];
								}
								if (!Customization.checkColor(color2))
								{
									color2 = Customization.COLORS[UnityEngine.Random.Range(0, Customization.COLORS.Length)];
								}
								if (!Customization.checkColor(color3))
								{
									color3 = color2;
								}
							}
							Characters.list[(int)b3] = new Character(newShirt, newPants, newHat, newBackpack, newVest, newMask, newGlasses, newPackageShirt, newPackagePants, newPackageHat, newPackageBackpack, newPackageVest, newPackageMask, newPackageGlasses, newPrimaryItem, newPrimaryState, newSecondaryItem, newSecondaryState, b4, b5, b6, color, color2, newMarkerColor, color3, newHand, newName, newNick, csteamID, (EPlayerSkillset)b7);
							CharacterUpdated characterUpdated2 = Characters.onCharacterUpdated;
							if (characterUpdated2 != null)
							{
								characterUpdated2(b3, Characters.list[(int)b3]);
							}
							b3 += 1;
						}
					}
					else
					{
						byte b8 = 0;
						while ((int)b8 < Characters.list.Length)
						{
							Characters.list[(int)b8] = new Character();
							CharacterUpdated characterUpdated3 = Characters.onCharacterUpdated;
							if (characterUpdated3 != null)
							{
								characterUpdated3(b8, Characters.list[(int)b8]);
							}
							b8 += 1;
						}
					}
				}
			}
			else
			{
				Characters._selected = 0;
			}
			byte b9 = 0;
			while ((int)b9 < Characters.list.Length)
			{
				if (Characters.list[(int)b9] == null)
				{
					Characters.list[(int)b9] = new Character();
					CharacterUpdated characterUpdated4 = Characters.onCharacterUpdated;
					if (characterUpdated4 != null)
					{
						characterUpdated4(b9, Characters.list[(int)b9]);
					}
				}
				b9 += 1;
			}
			Characters.RefreshPreviewCharacterModel();
			Characters.hasLoaded = true;
			UnturnedLog.info("Loaded characters");
		}

		// Token: 0x06003558 RID: 13656 RVA: 0x000FD1D4 File Offset: 0x000FB3D4
		public static void save()
		{
			if (!Characters.hasLoaded)
			{
				return;
			}
			Block block = new Block();
			block.writeByte(22);
			block.writeUInt16((ushort)Characters.packageSkins.Count);
			ushort num = 0;
			while ((int)num < Characters.packageSkins.Count)
			{
				ulong value = Characters.packageSkins[(int)num];
				block.writeUInt64(value);
				num += 1;
			}
			block.writeByte(Characters.selected);
			byte b = 0;
			while ((int)b < Characters.list.Length)
			{
				Character character = Characters.list[(int)b];
				if (character == null)
				{
					character = new Character();
				}
				block.writeUInt16(character.shirt);
				block.writeUInt16(character.pants);
				block.writeUInt16(character.hat);
				block.writeUInt16(character.backpack);
				block.writeUInt16(character.vest);
				block.writeUInt16(character.mask);
				block.writeUInt16(character.glasses);
				block.writeUInt64(character.packageShirt);
				block.writeUInt64(character.packagePants);
				block.writeUInt64(character.packageHat);
				block.writeUInt64(character.packageBackpack);
				block.writeUInt64(character.packageVest);
				block.writeUInt64(character.packageMask);
				block.writeUInt64(character.packageGlasses);
				block.writeUInt16(character.primaryItem);
				block.writeByteArray(character.primaryState);
				block.writeUInt16(character.secondaryItem);
				block.writeByteArray(character.secondaryState);
				block.writeByte(character.face);
				block.writeByte(character.hair);
				block.writeByte(character.beard);
				block.writeColor(character.skin);
				block.writeColor(character.color);
				block.writeColor(character.markerColor);
				block.writeColor(character.BeardColor);
				block.writeBoolean(character.hand);
				block.writeString(character.name);
				block.writeString(character.nick);
				block.writeSteamID(character.group);
				block.writeByte((byte)character.skillset);
				b += 1;
			}
			ReadWrite.writeBlock("/Characters.dat", true, block);
		}

		// Token: 0x04001C5F RID: 7263
		public const byte SAVEDATA_VERSION_INITIAL = 21;

		// Token: 0x04001C60 RID: 7264
		public const byte SAVEDATA_VERSION_ADDED_BEARD_COLOR = 22;

		// Token: 0x04001C61 RID: 7265
		private const byte SAVEDATA_VERSION_NEWEST = 22;

		// Token: 0x04001C62 RID: 7266
		public static readonly byte SAVEDATA_VERSION = 22;

		// Token: 0x04001C63 RID: 7267
		private static bool hasLoaded;

		// Token: 0x04001C64 RID: 7268
		private static bool initialApply;

		// Token: 0x04001C65 RID: 7269
		public static bool hasPlayed;

		// Token: 0x04001C66 RID: 7270
		private static bool hasDropped;

		// Token: 0x04001C67 RID: 7271
		public static CharacterUpdated onCharacterUpdated;

		// Token: 0x04001C68 RID: 7272
		private static byte _selected;

		// Token: 0x04001C6A RID: 7274
		private static Transform character;

		// Token: 0x04001C6B RID: 7275
		public static HumanClothes clothes;

		// Token: 0x04001C6C RID: 7276
		private static Transform[] slots;

		// Token: 0x04001C6D RID: 7277
		private static Transform primaryMeleeSlot;

		// Token: 0x04001C6E RID: 7278
		private static Transform primaryLargeGunSlot;

		// Token: 0x04001C6F RID: 7279
		private static Transform primarySmallGunSlot;

		// Token: 0x04001C70 RID: 7280
		private static Transform secondaryMeleeSlot;

		// Token: 0x04001C71 RID: 7281
		private static Transform secondaryGunSlot;

		// Token: 0x04001C72 RID: 7282
		private static List<ulong> _packageSkins;

		/// <summary>
		/// If set, this item is prioritized over equipped cosmetics. Used by item inspect menu.
		/// Admittedly, this is very hacked-together. Hopefully rewriting this file someday?
		/// </summary>
		// Token: 0x04001C73 RID: 7283
		internal static int previewItemDefId;

		// Token: 0x04001C74 RID: 7284
		internal static bool previewItemSolo;

		// Token: 0x04001C75 RID: 7285
		private static bool wasRefreshCharacterRequested;

		// Token: 0x04001C76 RID: 7286
		private static float characterOffset;

		// Token: 0x04001C77 RID: 7287
		private static float _characterYaw;

		// Token: 0x04001C78 RID: 7288
		public static float characterYaw;
	}
}
