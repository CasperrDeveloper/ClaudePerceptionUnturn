﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004F7 RID: 1271
	public class AirdropNode : Node
	{
		// Token: 0x060029B7 RID: 10679 RVA: 0x000B48BE File Offset: 0x000B2ABE
		public AirdropNode(Vector3 newPoint) : this(newPoint, 0)
		{
		}

		// Token: 0x060029B8 RID: 10680 RVA: 0x000B48C8 File Offset: 0x000B2AC8
		public AirdropNode(Vector3 newPoint, ushort newID)
		{
			this._point = newPoint;
			this.id = newID;
			this._type = ENodeType.AIRDROP;
		}

		// Token: 0x0400150E RID: 5390
		public ushort id;
	}
}
