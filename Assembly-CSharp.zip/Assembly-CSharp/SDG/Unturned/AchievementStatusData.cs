﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000786 RID: 1926
	public class AchievementStatusData
	{
		// Token: 0x060042BA RID: 17082 RVA: 0x0014C050 File Offset: 0x0014A250
		public bool canBeGrantedByNPC(string id)
		{
			string[] npc_Achievement_IDs = this.NPC_Achievement_IDs;
			for (int i = 0; i < npc_Achievement_IDs.Length; i++)
			{
				if (string.Equals(npc_Achievement_IDs[i], id))
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Names of achievements that can be granted by NPC rewards.
		/// </summary>
		// Token: 0x0400292E RID: 10542
		public string[] NPC_Achievement_IDs;
	}
}
