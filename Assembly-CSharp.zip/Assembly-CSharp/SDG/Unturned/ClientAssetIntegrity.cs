﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002B1 RID: 689
	internal static class ClientAssetIntegrity
	{
		/// <summary>
		/// Reset prior to joining a new server.
		/// </summary>
		// Token: 0x0600152F RID: 5423 RVA: 0x0005279C File Offset: 0x0005099C
		public static void Clear()
		{
			ClientAssetIntegrity.timer = 0f;
			ClientAssetIntegrity.validatedGuids.Clear();
			ClientAssetIntegrity.serverKnownMissingGuids.Clear();
			ClientAssetIntegrity.pendingValidation.Clear();
		}

		/// <summary>
		/// By default if the client submits an asset guid which the server cannot find an asset for the client will
		/// be kicked. This is necessary to prevent cheaters from spamming huge numbers of random guids. In certain cases
		/// like a terrain material missing the server knows the client will be missing it as well, and can register
		/// it here to prevent the client from being kicked unnecessarily.
		/// </summary>
		// Token: 0x06001530 RID: 5424 RVA: 0x000527C6 File Offset: 0x000509C6
		public static void ServerAddKnownMissingAsset(Guid guid, string context)
		{
			if (guid != Guid.Empty && ClientAssetIntegrity.serverKnownMissingGuids.Add(guid))
			{
				UnturnedLog.info(string.Format("Context \"{0}\" known missing asset {1:N}, server will not kick clients for this", context, guid));
			}
		}

		/// <summary>
		/// Send asset hash (or lack thereof) to server.
		///
		/// IMPORTANT: should only be called in cases where the server has verified the asset exists by loading it,
		/// otherwise only if the asset exists on the client. This is because the server kicks if the asset does not
		/// exist in order to prevent hacked clients from spamming requests. Context parameter is intended to help
		/// narrow down cases where this rule is being broken.
		/// </summary>
		// Token: 0x06001531 RID: 5425 RVA: 0x000527F8 File Offset: 0x000509F8
		public static void QueueRequest(Guid guid, Asset asset, string context)
		{
			if (guid == Guid.Empty)
			{
				return;
			}
			if (!ClientAssetIntegrity.validatedGuids.Add(guid))
			{
				return;
			}
			if (asset == null)
			{
				UnturnedLog.warn(string.Format("Context \"{0}\" missing asset {1:N}", context, guid));
			}
			ClientAssetIntegrity.pendingValidation.Add(new KeyValuePair<Guid, Asset>(guid, asset));
		}

		/// <summary>
		/// Send asset hash to server.
		/// Used in cases where server does not verify asset exists. (see other method's comment)
		/// </summary>
		// Token: 0x06001532 RID: 5426 RVA: 0x0005284B File Offset: 0x00050A4B
		public static void QueueRequest(Asset asset)
		{
			if (asset != null)
			{
				ClientAssetIntegrity.QueueRequest(asset.GUID, asset, null);
			}
		}

		/// <summary>
		/// Called each Update on the client.
		/// </summary>
		// Token: 0x06001533 RID: 5427 RVA: 0x00052860 File Offset: 0x00050A60
		public static void SendRequests()
		{
			if (ClientAssetIntegrity.pendingValidation.Count < 1)
			{
				return;
			}
			ClientAssetIntegrity.timer += Time.unscaledDeltaTime;
			if (ClientAssetIntegrity.timer > 0.1f)
			{
				ClientAssetIntegrity.timer = 0f;
				NetMessages.SendMessageToServer(EServerMessage.ValidateAssets, ENetReliability.Reliable, delegate(NetPakWriter writer)
				{
					int count = ClientAssetIntegrity.pendingValidation.Count;
					int b = (int)(ServerMessageHandler_ValidateAssets.MAX_ASSETS.value + 1U);
					int num = Mathf.Min(count, b);
					int num2 = count - num;
					uint value = (uint)(num - 1);
					writer.WriteBits(value, ServerMessageHandler_ValidateAssets.MAX_ASSETS.bitCount);
					uint num3 = 0U;
					int num4 = 0;
					int i = count - 1;
					while (i >= num2)
					{
						KeyValuePair<Guid, Asset> keyValuePair = ClientAssetIntegrity.pendingValidation[i];
						if (keyValuePair.Value != null && keyValuePair.Value.hash != null && keyValuePair.Value.hash.Length == 20)
						{
							num3 |= 1U << num4;
						}
						i--;
						num4++;
					}
					writer.WriteBits(num3, num);
					num4 = 0;
					int j = count - 1;
					while (j >= num2)
					{
						KeyValuePair<Guid, Asset> keyValuePair2 = ClientAssetIntegrity.pendingValidation[j];
						Guid key = keyValuePair2.Key;
						writer.WriteGuid(key);
						if ((num3 & 1U << num4) > 0U)
						{
							Asset value2 = keyValuePair2.Value;
							if (value2.originMasterBundle != null && value2.originMasterBundle.doesHashFileExist && value2.originMasterBundle.hash != null && value2.originMasterBundle.hash.Length == 20)
							{
								byte[] bytes = Hash.combine(new byte[][]
								{
									value2.hash,
									value2.originMasterBundle.hash
								});
								writer.WriteBytes(bytes);
							}
							else
							{
								writer.WriteBytes(value2.hash);
							}
						}
						j--;
						num4++;
					}
					ClientAssetIntegrity.pendingValidation.RemoveRange(num2, num);
				});
				return;
			}
		}

		// Token: 0x0400077A RID: 1914
		private static float timer;

		// Token: 0x0400077B RID: 1915
		private static HashSet<Guid> validatedGuids = new HashSet<Guid>();

		// Token: 0x0400077C RID: 1916
		internal static HashSet<Guid> serverKnownMissingGuids = new HashSet<Guid>();

		// Token: 0x0400077D RID: 1917
		private static List<KeyValuePair<Guid, Asset>> pendingValidation = new List<KeyValuePair<Guid, Asset>>();
	}
}
