﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005CE RID: 1486
	// (Invoke) Token: 0x06003202 RID: 12802
	public delegate void ArenaPlayerUpdated(ulong[] playerIDs, EArenaMessage newArenaMessage);
}
