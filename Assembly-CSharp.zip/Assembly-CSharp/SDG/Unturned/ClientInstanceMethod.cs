﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;

namespace SDG.Unturned
{
	// Token: 0x0200022C RID: 556
	public sealed class ClientInstanceMethod : ClientInstanceMethodBase
	{
		// Token: 0x06001147 RID: 4423 RVA: 0x0003F468 File Offset: 0x0003D668
		public static ClientInstanceMethod Get(Type declaringType, string methodName)
		{
			ClientMethodInfo clientMethodInfo = NetReflection.GetClientMethodInfo(declaringType, methodName);
			if (clientMethodInfo != null)
			{
				return new ClientInstanceMethod(clientMethodInfo);
			}
			return null;
		}

		// Token: 0x06001148 RID: 4424 RVA: 0x0003F488 File Offset: 0x0003D688
		public void Invoke(NetId netId, ENetReliability reliability, ITransportConnection transportConnection)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x06001149 RID: 4425 RVA: 0x0003F4A8 File Offset: 0x0003D6A8
		public void Invoke(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, Action<NetPakWriter> callback)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x0600114A RID: 4426 RVA: 0x0003F4D0 File Offset: 0x0003D6D0
		public void Invoke<T>(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, Action<NetPakWriter, T> callback, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x0600114B RID: 4427 RVA: 0x0003F4F8 File Offset: 0x0003D6F8
		public void Invoke<T1, T2>(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, Action<NetPakWriter, T1, T2> callback, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x0600114C RID: 4428 RVA: 0x0003F524 File Offset: 0x0003D724
		public void Invoke<T1, T2, T3>(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, Action<NetPakWriter, T1, T2, T3> callback, T1 arg1, T2 arg2, T3 arg3)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2, arg3);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x0600114D RID: 4429 RVA: 0x0003F550 File Offset: 0x0003D750
		public void Invoke(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x0600114E RID: 4430 RVA: 0x0003F570 File Offset: 0x0003D770
		[Obsolete("Replaced by List overload")]
		public void Invoke(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.Invoke(netId, reliability, list);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x0600114F RID: 4431 RVA: 0x0003F5A0 File Offset: 0x0003D7A0
		public void Invoke(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter> callback)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001150 RID: 4432 RVA: 0x0003F5C8 File Offset: 0x0003D7C8
		public void Invoke<T>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T> callback, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001151 RID: 4433 RVA: 0x0003F5F0 File Offset: 0x0003D7F0
		public void Invoke<T1, T2>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T1, T2> callback, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001152 RID: 4434 RVA: 0x0003F61C File Offset: 0x0003D81C
		public void Invoke<T1, T2, T3>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T1, T2, T3> callback, T1 arg1, T2 arg2, T3 arg3)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2, arg3);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001153 RID: 4435 RVA: 0x0003F648 File Offset: 0x0003D848
		[Obsolete("Replaced by List overload")]
		public void Invoke(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, Action<NetPakWriter> callback)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.Invoke(netId, reliability, list, callback);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001154 RID: 4436 RVA: 0x0003F67C File Offset: 0x0003D87C
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001155 RID: 4437 RVA: 0x0003F69C File Offset: 0x0003D89C
		[Obsolete("Replaced by List overload")]
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.InvokeAndLoopback(netId, reliability, list);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001156 RID: 4438 RVA: 0x0003F6CC File Offset: 0x0003D8CC
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter> callback)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001157 RID: 4439 RVA: 0x0003F6F4 File Offset: 0x0003D8F4
		public void InvokeAndLoopback<T>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T> callback, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001158 RID: 4440 RVA: 0x0003F71C File Offset: 0x0003D91C
		public void InvokeAndLoopback<T1, T2>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T1, T2> callback, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001159 RID: 4441 RVA: 0x0003F748 File Offset: 0x0003D948
		public void InvokeAndLoopback<T1, T2, T3>(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, Action<NetPakWriter, T1, T2, T3> callback, T1 arg1, T2 arg2, T3 arg3)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			callback(writerWithInstanceHeader, arg1, arg2, arg3);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x0600115A RID: 4442 RVA: 0x0003F774 File Offset: 0x0003D974
		[Obsolete("Replaced by List overload")]
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, Action<NetPakWriter> callback)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.InvokeAndLoopback(netId, reliability, list, callback);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x0600115B RID: 4443 RVA: 0x0003F7A6 File Offset: 0x0003D9A6
		private ClientInstanceMethod(ClientMethodInfo clientMethodInfo) : base(clientMethodInfo)
		{
		}
	}
}
