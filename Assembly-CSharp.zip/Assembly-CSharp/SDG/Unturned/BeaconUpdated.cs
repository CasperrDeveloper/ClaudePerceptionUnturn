﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200059F RID: 1439
	// (Invoke) Token: 0x06003046 RID: 12358
	public delegate void BeaconUpdated(byte nav, bool hasBeacon);
}
