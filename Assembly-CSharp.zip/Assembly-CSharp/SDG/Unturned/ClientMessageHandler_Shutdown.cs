﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000281 RID: 641
	internal static class ClientMessageHandler_Shutdown
	{
		// Token: 0x06001307 RID: 4871 RVA: 0x00045A14 File Offset: 0x00043C14
		internal static void ReadMessage(NetPakReader reader)
		{
			string text;
			reader.ReadString(out text, 11);
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.SHUTDOWN;
			Provider._connectionFailureReason = text;
			Provider.RequestDisconnect("Server was shutdown --- Reason: \"" + text + "\"");
		}
	}
}
