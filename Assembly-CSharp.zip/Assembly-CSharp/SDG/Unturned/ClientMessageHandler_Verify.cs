﻿using System;
using SDG.NetPak;
using SDG.NetTransport;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000283 RID: 643
	internal static class ClientMessageHandler_Verify
	{
		// Token: 0x06001309 RID: 4873 RVA: 0x00045A94 File Offset: 0x00043C94
		internal static void ReadMessage(NetPakReader reader)
		{
			Provider.isWaitingForConnectResponse = false;
			SteamNetworkingIdentity serverIdentity = default(SteamNetworkingIdentity);
			serverIdentity.SetSteamID(Provider.server);
			byte[] ticket = Provider.openTicket(serverIdentity);
			if (ticket == null)
			{
				Provider._connectionFailureInfo = ESteamConnectionFailureInfo.AUTH_EMPTY;
				Provider.RequestDisconnect("opening Steam auth ticket failed");
				return;
			}
			UnturnedLog.info("Authenticating with server");
			Provider.isWaitingForAuthenticationResponse = true;
			Provider.sentAuthenticationRequestTime = Time.realtimeSinceStartupAsDouble;
			NetMessages.SendMessageToServer(EServerMessage.Authenticate, ENetReliability.Reliable, delegate(NetPakWriter writer)
			{
				writer.WriteUInt16((ushort)ticket.Length);
				writer.WriteBytes(ticket);
				ClientMessageHandler_Verify.WriteEconomyDetails(writer);
			});
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x00045B14 File Offset: 0x00043D14
		private static void WriteEconomyDetails(NetPakWriter writer)
		{
			if (Provider.provider.economyService.wearingResult == SteamInventoryResult_t.Invalid)
			{
				writer.WriteUInt16(0);
				return;
			}
			uint num;
			bool flag = SteamInventory.SerializeResult(Provider.provider.economyService.wearingResult, null, out num);
			if (flag && num <= 65535U)
			{
				byte[] array = new byte[num];
				if (!SteamInventory.SerializeResult(Provider.provider.economyService.wearingResult, array, out num))
				{
					UnturnedLog.warn("SteamInventory.SerializeResult returned false the second time");
				}
				writer.WriteUInt16((ushort)num);
				writer.WriteBytes(array);
				SteamInventory.DestroyResult(Provider.provider.economyService.wearingResult);
				Provider.provider.economyService.wearingResult = SteamInventoryResult_t.Invalid;
				return;
			}
			SteamInventory.DestroyResult(Provider.provider.economyService.wearingResult);
			Provider.provider.economyService.wearingResult = SteamInventoryResult_t.Invalid;
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.AUTH_ECON_SERIALIZE;
			Provider.RequestDisconnect(flag ? "SteamInventory.SerializeResult length too large!" : "SteamInventory.SerializeResult failed");
		}
	}
}
