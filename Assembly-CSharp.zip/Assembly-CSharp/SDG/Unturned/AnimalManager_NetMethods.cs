﻿using System;
using SDG.NetPak;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020001DD RID: 477
	[NetInvokableGeneratedClass(typeof(AnimalManager))]
	public static class AnimalManager_NetMethods
	{
		// Token: 0x06000E77 RID: 3703 RVA: 0x00035E58 File Offset: 0x00034058
		[NetInvokableGeneratedMethod("ReceiveAnimalAlive", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveAnimalAlive_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			ushort index;
			reader.ReadUInt16(out index);
			Vector3 newPosition;
			reader.ReadClampedVector3(out newPosition, 13, 7);
			byte newAngle;
			reader.ReadUInt8(out newAngle);
			AnimalManager.ReceiveAnimalAlive(index, newPosition, newAngle);
		}

		// Token: 0x06000E78 RID: 3704 RVA: 0x00035E90 File Offset: 0x00034090
		[NetInvokableGeneratedMethod("ReceiveAnimalAlive", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveAnimalAlive_Write(NetPakWriter writer, ushort index, Vector3 newPosition, byte newAngle)
		{
			writer.WriteUInt16(index);
			writer.WriteClampedVector3(newPosition, 13, 7);
			writer.WriteUInt8(newAngle);
		}

		// Token: 0x06000E79 RID: 3705 RVA: 0x00035EB0 File Offset: 0x000340B0
		[NetInvokableGeneratedMethod("ReceiveAnimalDead", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveAnimalDead_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			ushort index;
			reader.ReadUInt16(out index);
			Vector3 newRagdoll;
			reader.ReadClampedVector3(out newRagdoll, 13, 7);
			ERagdollEffect newRagdollEffect;
			reader.ReadEnum(out newRagdollEffect);
			AnimalManager.ReceiveAnimalDead(index, newRagdoll, newRagdollEffect);
		}

		// Token: 0x06000E7A RID: 3706 RVA: 0x00035EE8 File Offset: 0x000340E8
		[NetInvokableGeneratedMethod("ReceiveAnimalDead", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveAnimalDead_Write(NetPakWriter writer, ushort index, Vector3 newRagdoll, ERagdollEffect newRagdollEffect)
		{
			writer.WriteUInt16(index);
			writer.WriteClampedVector3(newRagdoll, 13, 7);
			writer.WriteEnum(newRagdollEffect);
		}

		// Token: 0x06000E7B RID: 3707 RVA: 0x00035F08 File Offset: 0x00034108
		[NetInvokableGeneratedMethod("ReceiveAnimalStartle", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveAnimalStartle_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			ushort index;
			reader.ReadUInt16(out index);
			byte animationIndex;
			reader.ReadUInt8(out animationIndex);
			AnimalManager.ReceiveAnimalStartle(index, animationIndex);
		}

		// Token: 0x06000E7C RID: 3708 RVA: 0x00035F33 File Offset: 0x00034133
		[NetInvokableGeneratedMethod("ReceiveAnimalStartle", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveAnimalStartle_Write(NetPakWriter writer, ushort index, byte animationIndex)
		{
			writer.WriteUInt16(index);
			writer.WriteUInt8(animationIndex);
		}

		// Token: 0x06000E7D RID: 3709 RVA: 0x00035F48 File Offset: 0x00034148
		[NetInvokableGeneratedMethod("ReceiveAnimalAttack", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveAnimalAttack_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			ushort index;
			reader.ReadUInt16(out index);
			byte animationIndex;
			reader.ReadUInt8(out animationIndex);
			AnimalManager.ReceiveAnimalAttack(index, animationIndex);
		}

		// Token: 0x06000E7E RID: 3710 RVA: 0x00035F73 File Offset: 0x00034173
		[NetInvokableGeneratedMethod("ReceiveAnimalAttack", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveAnimalAttack_Write(NetPakWriter writer, ushort index, byte animationIndex)
		{
			writer.WriteUInt16(index);
			writer.WriteUInt8(animationIndex);
		}

		// Token: 0x06000E7F RID: 3711 RVA: 0x00035F88 File Offset: 0x00034188
		[NetInvokableGeneratedMethod("ReceiveAnimalPanic", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveAnimalPanic_Read(in ClientInvocationContext context)
		{
			ushort index;
			context.reader.ReadUInt16(out index);
			AnimalManager.ReceiveAnimalPanic(index);
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x00035FA9 File Offset: 0x000341A9
		[NetInvokableGeneratedMethod("ReceiveAnimalPanic", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveAnimalPanic_Write(NetPakWriter writer, ushort index)
		{
			writer.WriteUInt16(index);
		}
	}
}
