﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020007E1 RID: 2017
	public class Acid : MonoBehaviour
	{
		// Token: 0x06004508 RID: 17672 RVA: 0x0015F250 File Offset: 0x0015D450
		private void OnTriggerEnter(Collider other)
		{
			if (this.isExploded)
			{
				return;
			}
			if (other.isTrigger)
			{
				return;
			}
			if (other.transform.CompareTag("Agent"))
			{
				return;
			}
			this.isExploded = true;
			if (Provider.isServer)
			{
				EffectAsset effectAsset = Assets.FindEffectAssetByGuidOrLegacyId(this.effectGuid, this.effectID);
				if (effectAsset != null)
				{
					EffectManager.triggerEffect(new TriggerEffectParameters(effectAsset)
					{
						position = this.lastPos,
						relevantDistance = EffectManager.LARGE,
						reliable = true
					});
				}
			}
			UnityEngine.Object.Destroy(base.transform.parent.gameObject);
		}

		// Token: 0x06004509 RID: 17673 RVA: 0x0015F2E9 File Offset: 0x0015D4E9
		private void FixedUpdate()
		{
			this.lastPos = base.transform.position;
		}

		// Token: 0x0600450A RID: 17674 RVA: 0x0015F2FC File Offset: 0x0015D4FC
		private void Awake()
		{
			this.lastPos = base.transform.position;
		}

		// Token: 0x04002AD9 RID: 10969
		private bool isExploded;

		// Token: 0x04002ADA RID: 10970
		private Vector3 lastPos;

		// Token: 0x04002ADB RID: 10971
		public Guid effectGuid;

		/// <summary>
		/// Kept because lots of modders have been using this script in Unity,
		/// so removing legacy effect id would break their content.
		/// </summary>
		// Token: 0x04002ADC RID: 10972
		public ushort effectID;
	}
}
