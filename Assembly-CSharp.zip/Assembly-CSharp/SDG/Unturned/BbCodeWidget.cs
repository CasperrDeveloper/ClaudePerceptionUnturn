﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200045F RID: 1119
	public struct BbCodeWidget
	{
		// Token: 0x0600232C RID: 9004 RVA: 0x0009296E File Offset: 0x00090B6E
		public BbCodeWidget(EBbCodeWidgetType widgetType, string widgetData)
		{
			this.widgetType = widgetType;
			this.widgetData = widgetData;
		}

		// Token: 0x04001192 RID: 4498
		public EBbCodeWidgetType widgetType;

		// Token: 0x04001193 RID: 4499
		public string widgetData;
	}
}
