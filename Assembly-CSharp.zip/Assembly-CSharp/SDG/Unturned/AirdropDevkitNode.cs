﻿using System;
using SDG.Framework.Devkit;
using SDG.Framework.IO.FormattedFiles;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x0200015F RID: 351
	public class AirdropDevkitNode : TempNodeBase
	{
		// Token: 0x1700011D RID: 285
		// (get) Token: 0x060008D8 RID: 2264 RVA: 0x00021BC7 File Offset: 0x0001FDC7
		// (set) Token: 0x060008D9 RID: 2265 RVA: 0x00021BDC File Offset: 0x0001FDDC
		public CachingBcAssetRef CargoSpawnTableRef
		{
			get
			{
				return new CachingBcAssetRef(this._cargoSpawnTableGuid, EAssetType.SPAWN, this.id);
			}
			set
			{
				this.id = value.LegacyId;
				this._cargoSpawnTableGuid = value.Guid;
			}
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x00021BF8 File Offset: 0x0001FDF8
		public SpawnAsset GetCargoSpawnTableOrLogWarning()
		{
			CachingBcAssetRef cargoSpawnTableRef = this.CargoSpawnTableRef;
			SpawnAsset spawnAsset = cargoSpawnTableRef.Get<SpawnAsset>();
			if (spawnAsset == null)
			{
				UnturnedLog.warn(string.Format("Unable to find cargo spawn table ({0}) for airdrop marker at {1}", cargoSpawnTableRef, base.transform.position));
			}
			return spawnAsset;
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x00021C3B File Offset: 0x0001FE3B
		internal override ISleekElement CreateMenu()
		{
			return new AirdropDevkitNode.Menu(this);
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x00021C43 File Offset: 0x0001FE43
		internal void UpdateEditorVisibility()
		{
			this.boxCollider.enabled = SpawnpointSystemV2.Get().IsVisible;
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x00021C5C File Offset: 0x0001FE5C
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			string text = reader.readValue("SpawnTable_ID");
			if (ushort.TryParse(text, out this.id))
			{
				this._cargoSpawnTableGuid = Guid.Empty;
				return;
			}
			if (Guid.TryParse(text, out this._cargoSpawnTableGuid))
			{
				this.id = 0;
			}
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00021CAB File Offset: 0x0001FEAB
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			if (!this._cargoSpawnTableGuid.IsEmpty())
			{
				writer.writeValue<Guid>("SpawnTable_ID", this._cargoSpawnTableGuid);
				return;
			}
			writer.writeValue<ushort>("SpawnTable_ID", this.id);
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x00021CE4 File Offset: 0x0001FEE4
		private void OnEnable()
		{
			LevelHierarchy.addItem(this);
			AirdropDevkitNodeSystem.Get().AddNode(this);
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x00021CF7 File Offset: 0x0001FEF7
		private void OnDisable()
		{
			AirdropDevkitNodeSystem.Get().RemoveNode(this);
			LevelHierarchy.removeItem(this);
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x00021D0C File Offset: 0x0001FF0C
		private void Awake()
		{
			base.name = "Airdrop";
			base.gameObject.layer = 30;
			if (Level.isEditor)
			{
				this.boxCollider = base.gameObject.GetOrAddComponent<BoxCollider>();
				this.boxCollider.center = new Vector3(0f, 16f, 0f);
				this.boxCollider.size = new Vector3(1f, 32f, 1f);
				this.UpdateEditorVisibility();
			}
		}

		// Token: 0x040003A0 RID: 928
		[Obsolete("Replaced by CargoSpawnTableRef")]
		public ushort id;

		// Token: 0x040003A1 RID: 929
		[SerializeField]
		internal Guid _cargoSpawnTableGuid;

		// Token: 0x040003A2 RID: 930
		[SerializeField]
		private BoxCollider boxCollider;

		// Token: 0x0200091B RID: 2331
		private class Menu : SleekWrapper
		{
			// Token: 0x0600510D RID: 20749 RVA: 0x001F5AC4 File Offset: 0x001F3CC4
			public Menu(AirdropDevkitNode node)
			{
				this.node = node;
				base.SizeOffset_X = 400f;
				float num = 0f;
				SleekBcAssetField sleekBcAssetField = new SleekBcAssetField(EAssetType.SPAWN);
				sleekBcAssetField.PositionOffset_Y = num;
				sleekBcAssetField.SizeOffset_X = 200f;
				sleekBcAssetField.SizeOffset_Y = 60f;
				sleekBcAssetField.Value = node.CargoSpawnTableRef;
				sleekBcAssetField.AddLabel("ID", ESleekSide.RIGHT);
				sleekBcAssetField.OnValueChanged += this.OnIdTyped;
				base.AddChild(sleekBcAssetField);
				num += sleekBcAssetField.SizeOffset_Y + 10f;
				base.SizeOffset_Y = num - 10f;
			}

			// Token: 0x0600510E RID: 20750 RVA: 0x001F5B61 File Offset: 0x001F3D61
			private void OnIdTyped(SleekBcAssetField field)
			{
				this.node.CargoSpawnTableRef = field.Value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036F8 RID: 14072
			private AirdropDevkitNode node;
		}
	}
}
