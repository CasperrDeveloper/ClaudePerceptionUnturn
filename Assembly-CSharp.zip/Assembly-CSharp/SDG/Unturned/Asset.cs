﻿using System;
using System.Text;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000299 RID: 665
	public abstract class Asset : IAssetErrorContext
	{
		// Token: 0x060013E9 RID: 5097 RVA: 0x0004C6AC File Offset: 0x0004A8AC
		public virtual string getFilePath()
		{
			return this.absoluteOriginFilePath;
		}

		// Token: 0x060013EA RID: 5098 RVA: 0x0004C6B4 File Offset: 0x0004A8B4
		public AssetReference<T> getReferenceTo<T>() where T : Asset
		{
			return new AssetReference<T>(this.GUID);
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x060013EB RID: 5099 RVA: 0x0004C6C1 File Offset: 0x0004A8C1
		// (set) Token: 0x060013EC RID: 5100 RVA: 0x0004C6F9 File Offset: 0x0004A8F9
		[Obsolete("Replaced by AssetOrigin class")]
		public EAssetOrigin assetOrigin
		{
			get
			{
				if (this.origin == null)
				{
					return EAssetOrigin.MISC;
				}
				if (this.origin == Assets.coreOrigin || this.origin == Assets.legacyOfficialOrigin)
				{
					return EAssetOrigin.OFFICIAL;
				}
				if (this.origin.workshopFileId != 0UL)
				{
					return EAssetOrigin.WORKSHOP;
				}
				return EAssetOrigin.MISC;
			}
			set
			{
			}
		}

		/// <summary>
		/// If true, errors related to this asset were reported during loading.
		/// </summary>
		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x060013ED RID: 5101 RVA: 0x0004C6FB File Offset: 0x0004A8FB
		// (set) Token: 0x060013EE RID: 5102 RVA: 0x0004C703 File Offset: 0x0004A903
		public bool HasErrors { get; internal set; }

		// Token: 0x060013EF RID: 5103 RVA: 0x0004C70C File Offset: 0x0004A90C
		public string GetOriginName()
		{
			AssetOrigin assetOrigin = this.origin;
			return ((assetOrigin != null) ? assetOrigin.name : null) ?? "Unknown";
		}

		/// <summary>
		/// Contents of file this asset was loaded from. Only kept if data re-saving is enabled. (So that this memory
		/// is collected after populating the asset.)
		/// </summary>
		// Token: 0x170002BA RID: 698
		// (get) Token: 0x060013F0 RID: 5104 RVA: 0x0004C729 File Offset: 0x0004A929
		// (set) Token: 0x060013F1 RID: 5105 RVA: 0x0004C731 File Offset: 0x0004A931
		public IDatDictionary OriginParsedData { get; set; }

		/// <summary>
		/// Translation data associated with this asset. Only kept if per-asset property
		/// "Keep_Localization_Loaded" is true.
		/// (Otherwise, memory is collected after populating the asset.)
		/// Nelson 2025-11-07: hacking this in so that NPC hints replicated from the server don't
		/// use the server's language.
		/// </summary>
		// Token: 0x170002BB RID: 699
		// (get) Token: 0x060013F2 RID: 5106 RVA: 0x0004C73A File Offset: 0x0004A93A
		// (set) Token: 0x060013F3 RID: 5107 RVA: 0x0004C742 File Offset: 0x0004A942
		public Local Localization { get; set; }

		/// <summary>
		/// Master bundle this asset loaded from.
		/// </summary>
		// Token: 0x170002BC RID: 700
		// (get) Token: 0x060013F4 RID: 5108 RVA: 0x0004C74B File Offset: 0x0004A94B
		// (set) Token: 0x060013F5 RID: 5109 RVA: 0x0004C753 File Offset: 0x0004A953
		public MasterBundleConfig originMasterBundle { get; protected set; }

		/// <summary>
		/// Should read/write texture warnings be ignored?
		/// </summary>
		// Token: 0x170002BD RID: 701
		// (get) Token: 0x060013F6 RID: 5110 RVA: 0x0004C75C File Offset: 0x0004A95C
		// (set) Token: 0x060013F7 RID: 5111 RVA: 0x0004C764 File Offset: 0x0004A964
		public bool ignoreTextureReadable { get; protected set; }

		/// <summary>
		/// Hash of the original input file.
		/// </summary>
		// Token: 0x170002BE RID: 702
		// (get) Token: 0x060013F8 RID: 5112 RVA: 0x0004C76D File Offset: 0x0004A96D
		// (set) Token: 0x060013F9 RID: 5113 RVA: 0x0004C775 File Offset: 0x0004A975
		public byte[] hash { get; internal set; }

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x060013FA RID: 5114 RVA: 0x0004C77E File Offset: 0x0004A97E
		internal virtual bool ShouldVerifyHash
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x060013FB RID: 5115 RVA: 0x0004C781 File Offset: 0x0004A981
		public virtual string FriendlyName
		{
			get
			{
				return this.name;
			}
		}

		/// <summary>
		/// Maybe temporary? Used when something in-game changes the asset so that it shouldn't be useable on the server anymore.
		/// </summary>
		// Token: 0x060013FC RID: 5116 RVA: 0x0004C789 File Offset: 0x0004A989
		public virtual void clearHash()
		{
			this.hash = new byte[20];
		}

		// Token: 0x060013FD RID: 5117 RVA: 0x0004C798 File Offset: 0x0004A998
		public void appendHash(byte[] otherHash)
		{
			this.hash = Hash.combineSHA1Hashes(this.hash, otherHash);
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x060013FE RID: 5118 RVA: 0x0004C7AC File Offset: 0x0004A9AC
		public virtual EAssetType assetCategory
		{
			get
			{
				return EAssetType.NONE;
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x060013FF RID: 5119 RVA: 0x0004C7AF File Offset: 0x0004A9AF
		public string AssetErrorPrefix
		{
			get
			{
				return string.Format("{0} {1} ({2}) [{3:N}]", new object[]
				{
					this.GetOriginName(),
					this.FriendlyName,
					this.GetTypeFriendlyName(),
					this.GUID
				});
			}
		}

		// Token: 0x06001400 RID: 5120 RVA: 0x0004C7EA File Offset: 0x0004A9EA
		public void ReportAssetError(string message)
		{
			Assets.ReportError(this, message);
		}

		/// <summary>
		/// Most asset classes end in "Asset", so in debug strings if asset is clear from context we can remove the unnecessary suffix.
		/// </summary>
		// Token: 0x06001401 RID: 5121 RVA: 0x0004C7F4 File Offset: 0x0004A9F4
		public string GetTypeNameWithoutSuffix()
		{
			string text = base.GetType().Name;
			if (text.EndsWith("Asset"))
			{
				return text.Substring(0, text.Length - 5);
			}
			return text;
		}

		/// <summary>
		/// Remove "Asset" suffix and convert to title case.
		/// </summary>
		// Token: 0x06001402 RID: 5122 RVA: 0x0004C82C File Offset: 0x0004AA2C
		public virtual string GetTypeFriendlyName()
		{
			string typeNameWithoutSuffix = this.GetTypeNameWithoutSuffix();
			StringBuilder stringBuilder = new StringBuilder(32);
			for (int i = 0; i < typeNameWithoutSuffix.Length; i++)
			{
				char c = typeNameWithoutSuffix[i];
				if (i > 0 && char.IsUpper(c) && !char.IsUpper(typeNameWithoutSuffix[i - 1]))
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(c);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06001403 RID: 5123 RVA: 0x0004C894 File Offset: 0x0004AA94
		public string getTypeNameAndIdDisplayString()
		{
			return string.Format("({0}) {1} [{2}]", this.GetTypeFriendlyName(), this.name, this.id);
		}

		/// <summary>
		/// e.g. Canned Beans (Consumeable Item)
		/// </summary>
		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06001404 RID: 5124 RVA: 0x0004C8B7 File Offset: 0x0004AAB7
		public string FriendlyNameWithFriendlyType
		{
			get
			{
				return this.FriendlyName + " (" + this.GetTypeFriendlyName() + ")";
			}
		}

		// Token: 0x06001405 RID: 5125 RVA: 0x0004C8D4 File Offset: 0x0004AAD4
		public Asset()
		{
			this.name = base.GetType().Name;
		}

		// Token: 0x06001406 RID: 5126 RVA: 0x0004C8F0 File Offset: 0x0004AAF0
		public virtual void PopulateAsset(in PopulateAssetParameters p)
		{
			if (p.bundle != null)
			{
				this.name = p.bundle.name;
			}
			else
			{
				this.name = "Asset_" + this.id.ToString();
			}
			MasterBundle masterBundle = p.bundle as MasterBundle;
			if (masterBundle != null)
			{
				this.originMasterBundle = masterBundle.cfg;
			}
			if (p.data != null)
			{
				this.ignoreNPOT = p.data.ContainsKey("Ignore_NPOT");
				this.ignoreTextureReadable = p.data.ContainsKey("Ignore_TexRW");
			}
		}

		// Token: 0x06001407 RID: 5127 RVA: 0x0004C982 File Offset: 0x0004AB82
		internal virtual void PreResaveAsset(IDatDictionary data)
		{
		}

		// Token: 0x06001408 RID: 5128 RVA: 0x0004C984 File Offset: 0x0004AB84
		internal virtual void BuildCargoData(CargoBuilder builder)
		{
			CargoDeclaration orAddDeclaration = builder.GetOrAddDeclaration("Asset");
			orAddDeclaration.Append("GUID", this.GUID);
			if (this.id > 0)
			{
				orAddDeclaration.Append("ID", this.id);
			}
			orAddDeclaration.Append("Filename", this.name);
			if (this.originMasterBundle != null)
			{
				orAddDeclaration.Append("MasterBundle", this.originMasterBundle.assetBundleNameWithoutExtension);
			}
			orAddDeclaration.Append("Origin", this.GetOriginName());
			orAddDeclaration.Append("Type", this.GetTypeFriendlyName());
		}

		/// <summary>
		/// Perform any initialization required when PopulateAsset won't be called.
		/// </summary>
		// Token: 0x06001409 RID: 5129 RVA: 0x0004CA19 File Offset: 0x0004AC19
		internal virtual void OnCreatedAtRuntime()
		{
		}

		// Token: 0x0600140A RID: 5130 RVA: 0x0004CA1B File Offset: 0x0004AC1B
		public override string ToString()
		{
			return this.id.ToString() + " - " + this.name;
		}

		/// <summary>
		/// Planning ahead to potentially convert the game to use Unity's newer Addressables feature.
		/// </summary>
		// Token: 0x0600140B RID: 5131 RVA: 0x0004CA38 File Offset: 0x0004AC38
		protected T LoadRedirectableAsset<T>(Bundle fromBundle, string defaultName, IDatDictionary data, string key) where T : UnityEngine.Object
		{
			string text;
			if (data.TryGetString(key, out text))
			{
				int num = text.IndexOf(':');
				MasterBundleConfig masterBundleConfig;
				string text2;
				if (num < 0)
				{
					MasterBundle masterBundle = fromBundle as MasterBundle;
					masterBundleConfig = ((masterBundle != null) ? masterBundle.cfg : Assets.currentMasterBundle);
					text2 = text;
					if (masterBundleConfig == null || masterBundleConfig.assetBundle == null)
					{
						Assets.ReportError(this, "unable to load \"{0}\" without masterbundle", text);
						return default(T);
					}
				}
				else
				{
					string text3 = text.Substring(0, num);
					masterBundleConfig = Assets.findMasterBundleByName(text3, true);
					text2 = text.Substring(num + 1);
					if (masterBundleConfig == null || masterBundleConfig.assetBundle == null)
					{
						Assets.ReportError(this, string.Concat(new string[]
						{
							"unable to find masterbundle \"",
							text3,
							"\" when loading asset \"",
							text2,
							"\""
						}));
						return default(T);
					}
				}
				string text4 = masterBundleConfig.formatAssetPath(text2);
				T t = masterBundleConfig.assetBundle.LoadAsset<T>(text4);
				if (t == null)
				{
					Assets.ReportError(this, string.Concat(new string[]
					{
						"failed to load asset \"",
						text4,
						"\" from \"",
						masterBundleConfig.assetBundleName,
						"\" as ",
						typeof(T).Name
					}));
				}
				return t;
			}
			return fromBundle.load<T>(defaultName);
		}

		// Token: 0x0600140C RID: 5132 RVA: 0x0004CB90 File Offset: 0x0004AD90
		internal T loadRequiredAsset<T>(Bundle fromBundle, string name) where T : UnityEngine.Object
		{
			T t = fromBundle.load<T>(name);
			if (t == null)
			{
				Assets.ReportError(this, string.Concat(new string[]
				{
					"missing \"",
					name,
					"\" ",
					typeof(T).Name,
					" (expected at ",
					fromBundle.WhereLoadLookedToString(name),
					")"
				}));
			}
			else if (typeof(T) == typeof(GameObject))
			{
				AssetValidation.searchGameObjectForErrors(this, t as GameObject);
			}
			return t;
		}

		// Token: 0x0600140D RID: 5133 RVA: 0x0004CC33 File Offset: 0x0004AE33
		protected void validateAnimation(Animation animComponent, string name)
		{
			if (animComponent.GetClip(name) == null)
			{
				Assets.ReportError(this, "{0} missing animation clip '{1}'", animComponent.gameObject, name);
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x0600140E RID: 5134 RVA: 0x0004CC56 File Offset: 0x0004AE56
		protected bool OriginAllowsVanillaLegacyId
		{
			get
			{
				return this.origin == Assets.coreOrigin || this.origin == Assets.reloadOrigin;
			}
		}

		// Token: 0x040006F9 RID: 1785
		public string name;

		// Token: 0x040006FA RID: 1786
		public ushort id;

		// Token: 0x040006FB RID: 1787
		public Guid GUID;

		// Token: 0x040006FC RID: 1788
		internal AssetOrigin origin;

		/// <summary>
		/// If true, an asset with the same ID or GUID has been added to the current asset mapping, replacing this one.
		/// </summary>
		// Token: 0x040006FD RID: 1789
		internal bool hasBeenReplaced;

		/// <summary>
		/// Null or empty if created at runtime, otherwise set by <see cref="T:SDG.Unturned.Assets" /> when loading.
		/// </summary>
		// Token: 0x040006FF RID: 1791
		public string absoluteOriginFilePath;

		/// <summary>
		/// Were this asset's shaders set to Standard and/or consolidated?
		/// Needed for vehicle rotors special case.
		/// </summary>
		// Token: 0x04000703 RID: 1795
		public bool requiredShaderUpgrade;

		/// <summary>
		/// Should texture non-power-of-two warnings be ignored?
		/// Unfortunately some already-included third-party assets have NPOT textures.
		/// </summary>
		// Token: 0x04000704 RID: 1796
		public bool ignoreNPOT;
	}
}
