﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200077D RID: 1917
	public class AudioPreferenceData
	{
		// Token: 0x0600429E RID: 17054 RVA: 0x0014B753 File Offset: 0x00149953
		public AudioPreferenceData()
		{
			this.Vehicle_Engine_Volume_Multiplier = 1f;
		}

		// Token: 0x04002906 RID: 10502
		public float Vehicle_Engine_Volume_Multiplier;
	}
}
