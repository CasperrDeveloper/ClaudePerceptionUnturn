﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000501 RID: 1281
	public class CartographyVolume : LevelVolume<CartographyVolume, CartographyVolumeManager>
	{
		// Token: 0x060029DF RID: 10719 RVA: 0x000B52E4 File Offset: 0x000B34E4
		public void GetSatelliteCaptureTransform(out Vector3 position, out Quaternion rotation)
		{
			position = base.transform.TransformPoint(new Vector3(0f, 0.5f, 0f));
			rotation = base.transform.rotation * Quaternion.Euler(90f, 0f, 0f);
		}

		// Token: 0x060029E0 RID: 10720 RVA: 0x000B5340 File Offset: 0x000B3540
		protected override void Awake()
		{
			this.supportsSphereShape = false;
			base.Awake();
		}
	}
}
