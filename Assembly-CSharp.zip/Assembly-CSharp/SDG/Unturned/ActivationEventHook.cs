﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace SDG.Unturned
{
	// Token: 0x0200061E RID: 1566
	[AddComponentMenu("Unturned/Activation Event Hook")]
	public class ActivationEventHook : MonoBehaviour
	{
		// Token: 0x060035B3 RID: 13747 RVA: 0x000FF6E4 File Offset: 0x000FD8E4
		private void OnEnable()
		{
			this.OnEnabled.Invoke();
		}

		// Token: 0x060035B4 RID: 13748 RVA: 0x000FF6F1 File Offset: 0x000FD8F1
		private void OnDisable()
		{
			this.OnDisabled.Invoke();
		}

		/// <summary>
		/// Invoked when component is enabled and when the game object is activated.
		/// </summary>
		// Token: 0x04001CAE RID: 7342
		public UnityEvent OnEnabled;

		/// <summary>
		/// Invoked when component is disabled and when the game object is deactivated.
		/// Note that if the component or game object spawn deactivated this will not be immediately invoked.
		/// </summary>
		// Token: 0x04001CAF RID: 7343
		public UnityEvent OnDisabled;
	}
}
