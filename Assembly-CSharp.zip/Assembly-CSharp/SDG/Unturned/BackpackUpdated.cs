﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000682 RID: 1666
	// (Invoke) Token: 0x060037AA RID: 14250
	public delegate void BackpackUpdated(ushort newBackpack, byte newBackpackQuality, byte[] newBackpackState);
}
