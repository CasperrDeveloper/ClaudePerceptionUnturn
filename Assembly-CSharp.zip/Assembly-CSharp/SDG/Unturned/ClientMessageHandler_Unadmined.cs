﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000282 RID: 642
	internal static class ClientMessageHandler_Unadmined
	{
		// Token: 0x06001308 RID: 4872 RVA: 0x00045A50 File Offset: 0x00043C50
		internal static void ReadMessage(NetPakReader reader)
		{
			byte b;
			reader.ReadUInt8(out b);
			SteamPlayer steamPlayer = PlayerTool.findSteamPlayerByChannel((int)b);
			if (steamPlayer != null)
			{
				steamPlayer.isAdmin = false;
				return;
			}
			UnturnedLog.error("Unadmined unable to find channel {0}", new object[]
			{
				b
			});
		}
	}
}
