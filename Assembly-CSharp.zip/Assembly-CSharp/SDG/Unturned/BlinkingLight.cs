﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000500 RID: 1280
	public class BlinkingLight : MonoBehaviour
	{
		// Token: 0x060029DD RID: 10717 RVA: 0x000B52A2 File Offset: 0x000B34A2
		private void Update()
		{
			if (Time.time - this.blinkTime < 1f)
			{
				return;
			}
			this.blinkTime = Time.time;
			this.target.SetActive(!this.target.activeSelf);
		}

		// Token: 0x0400151D RID: 5405
		public GameObject target;

		// Token: 0x0400151E RID: 5406
		private float blinkTime;
	}
}
