﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SDG.Unturned
{
	// Token: 0x0200076A RID: 1898
	public class BrowserConfigData
	{
		// Token: 0x06004260 RID: 16992 RVA: 0x00148E94 File Offset: 0x00147094
		public BrowserConfigData()
		{
			this.Icon = string.Empty;
			this.Thumbnail = string.Empty;
			this.Desc_Hint = string.Empty;
			this.Desc_Full = string.Empty;
			this.Desc_Server_List = string.Empty;
			this.Login_Token = string.Empty;
			this.BookmarkHost = string.Empty;
			this.Monetization = EServerMonetizationTag.Unspecified;
			this.Links = null;
		}

		/// <summary>
		/// URL of a 64x64 image shown in the upper-left of the server lobby menu.
		/// </summary>
		// Token: 0x040027C7 RID: 10183
		public string Icon;

		/// <summary>
		/// URL of a 32x32 image shown in the server list.
		/// </summary>
		// Token: 0x040027C8 RID: 10184
		public string Thumbnail;

		/// <summary>
		/// Short description underneath the server name in the server lobby menu.
		/// </summary>
		// Token: 0x040027C9 RID: 10185
		public string Desc_Hint;

		/// <summary>
		/// Long description in the lower-right of the server lobby menu.
		/// </summary>
		// Token: 0x040027CA RID: 10186
		public string Desc_Full;

		/// <summary>
		/// Short description underneath the server name in the server list.
		/// </summary>
		// Token: 0x040027CB RID: 10187
		public string Desc_Server_List;

		/// <summary>
		/// Documentation: https://docs.smartlydressedgames.com/en/stable/servers/game-server-login-tokens.html
		/// To generate a new token visit: https://steamcommunity.com/dev/managegameservers
		/// </summary>
		// Token: 0x040027CC RID: 10188
		public string Login_Token;

		/// <summary>
		/// IP address, DNS name, or a web address (to perform GET request) to advertise.
		///
		/// Servers not using Fake IP can specify just a DNS entry. This way if server's IP changes clients can rejoin.
		/// For example, if you own the "example.com" domain you could add an A record "myunturnedserver" pointing at
		/// your game server IP and set that record here "myunturnedserver.example.com".
		///
		/// Servers using Fake IP are assigned random ports at startup, but can implement a web API endpoint to return
		/// the IP and port. Clients perform a GET request if this string starts with http:// or https://. The returned
		/// text can be an IP address or DNS name with optional query port override. (e.g., "127.0.0.1:27015")
		///
		/// Documentation: https://docs.smartlydressedgames.com/en/stable/servers/bookmark-host.html
		/// </summary>
		// Token: 0x040027CD RID: 10189
		public string BookmarkHost;

		/// <summary>
		/// If true, the server lobby warns that in-game ping may be higher than shown.
		/// </summary>
		// Token: 0x040027CE RID: 10190
		public bool Is_Using_Anycast_Proxy;

		/// <summary>
		/// How the server is monetized (if at all).
		/// </summary>
		// Token: 0x040027CF RID: 10191
		[JsonConverter(typeof(StringEnumConverter))]
		public EServerMonetizationTag Monetization;

		/// <summary>
		/// Buttons shown in the server lobby menu. For example:
		/// ` Links
		/// ` [
		/// `     {
		/// `         Message Visit our website!
		/// `         URL https://smartlydressedgames.com/
		/// `     }
		/// ` ]
		/// </summary>
		// Token: 0x040027D0 RID: 10192
		public BrowserConfigData.Link[] Links;

		// Token: 0x02000A9C RID: 2716
		public struct Link : IDatParseable, IDatSerializable
		{
			/// <summary>
			/// Used to find overrides in json file.
			/// </summary>
			// Token: 0x060055C8 RID: 21960 RVA: 0x001FED2C File Offset: 0x001FCF2C
			public override bool Equals(object other)
			{
				if (other != null && other is BrowserConfigData.Link)
				{
					BrowserConfigData.Link link = (BrowserConfigData.Link)other;
					return string.Equals(this.Message, link.Message) && string.Equals(this.Url, link.Url);
				}
				return false;
			}

			// Token: 0x060055C9 RID: 21961 RVA: 0x001FED75 File Offset: 0x001FCF75
			public override int GetHashCode()
			{
				return HashCode.Combine<string, string>(this.Message, this.Url);
			}

			// Token: 0x060055CA RID: 21962 RVA: 0x001FED88 File Offset: 0x001FCF88
			public bool TryParse(IDatNode node)
			{
				IDatDictionary datDictionary = node as IDatDictionary;
				if (datDictionary != null)
				{
					this.Message = datDictionary.GetString("Message", null);
					this.Url = datDictionary.GetString("URL", null);
					return true;
				}
				return false;
			}

			// Token: 0x060055CB RID: 21963 RVA: 0x001FEDC6 File Offset: 0x001FCFC6
			public void SerializeIntoDictionary(IEditableDatDictionary dictionary)
			{
				dictionary.AddValue("Message").SetString(this.Message);
				dictionary.AddValue("URL").SetString(this.Url);
			}

			// Token: 0x04003A8B RID: 14987
			public string Message;

			// Token: 0x04003A8C RID: 14988
			public string Url;
		}
	}
}
