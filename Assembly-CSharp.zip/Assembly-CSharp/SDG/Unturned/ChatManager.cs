﻿using System;
using System.Collections.Generic;
using SDG.NetTransport;
using Steamworks;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x020005AC RID: 1452
	public class ChatManager : SteamCaller
	{
		// Token: 0x140000A1 RID: 161
		// (add) Token: 0x0600307B RID: 12411 RVA: 0x000DF4FC File Offset: 0x000DD6FC
		// (remove) Token: 0x0600307C RID: 12412 RVA: 0x000DF530 File Offset: 0x000DD730
		public static event ChatManager.ClientUnityEventPermissionsHandler onCheckUnityEventPermissions;

		/// <summary>
		/// Exposed for Rocket transition to modules backwards compatibility.
		/// </summary>
		// Token: 0x1700098D RID: 2445
		// (get) Token: 0x0600307D RID: 12413 RVA: 0x000DF563 File Offset: 0x000DD763
		public static ChatManager instance
		{
			get
			{
				return ChatManager.manager;
			}
		}

		// Token: 0x1700098E RID: 2446
		// (get) Token: 0x0600307E RID: 12414 RVA: 0x000DF56A File Offset: 0x000DD76A
		public static List<ReceivedChatMessage> receivedChatHistory
		{
			get
			{
				return ChatManager._receivedChatHistory;
			}
		}

		/// <summary>
		/// Add a newly received chat message to the front of the list,
		/// and remove an old message if necessary.
		/// </summary>
		// Token: 0x0600307F RID: 12415 RVA: 0x000DF574 File Offset: 0x000DD774
		public static void receiveChatMessage(CSteamID speakerSteamID, string iconURL, EChatMode mode, Color color, bool isRich, string text)
		{
			text = text.Trim();
			ControlsSettings.formatPluginHotkeysIntoText(ref text);
			ProfanityFilter.ApplyFilter(OptionsSettings.filter, ref text);
			if (OptionsSettings.ShouldAnonymizeMultiplayerDetails)
			{
				color = Color.white;
			}
			SteamPlayer steamPlayer;
			if (speakerSteamID == CSteamID.Nil)
			{
				steamPlayer = null;
			}
			else
			{
				if (!OptionsSettings.chatText && speakerSteamID != Provider.client)
				{
					return;
				}
				steamPlayer = PlayerTool.getSteamPlayer(speakerSteamID);
				if (steamPlayer.isTextChatLocallyMuted)
				{
					return;
				}
			}
			ReceivedChatMessage item = new ReceivedChatMessage(steamPlayer, iconURL, mode, color, isRich, text);
			ChatManager.receivedChatHistory.Insert(0, item);
			if (ChatManager.receivedChatHistory.Count > Provider.preferenceData.Chat.History_Length)
			{
				ChatManager.receivedChatHistory.RemoveAt(ChatManager.receivedChatHistory.Count - 1);
			}
			ChatMessageReceivedHandler chatMessageReceivedHandler = ChatManager.onChatMessageReceived;
			if (chatMessageReceivedHandler == null)
			{
				return;
			}
			chatMessageReceivedHandler();
		}

		// Token: 0x06003080 RID: 12416 RVA: 0x000DF63C File Offset: 0x000DD83C
		public static bool process(SteamPlayer player, string cmd)
		{
			return ChatManager.process(player, cmd, false);
		}

		// Token: 0x06003081 RID: 12417 RVA: 0x000DF648 File Offset: 0x000DD848
		public static bool process(SteamPlayer player, string cmd, bool fromUnityEvent)
		{
			bool flag = false;
			bool result = true;
			string a = cmd.Substring(0, 1);
			if (a == "@" || a == "/")
			{
				if (!Dedicator.IsDedicatedServer || player.isAdmin)
				{
					flag = true;
					result = false;
				}
				if (Dedicator.IsDedicatedServer && fromUnityEvent && !Provider.configData.UnityEvents.Allow_Client_Commands)
				{
					flag = false;
					result = false;
				}
			}
			CheckPermissions checkPermissions = ChatManager.onCheckPermissions;
			if (checkPermissions != null)
			{
				checkPermissions(player, cmd, ref flag, ref result);
			}
			if (fromUnityEvent)
			{
				ChatManager.ClientUnityEventPermissionsHandler clientUnityEventPermissionsHandler = ChatManager.onCheckUnityEventPermissions;
				if (clientUnityEventPermissionsHandler != null)
				{
					clientUnityEventPermissionsHandler(player, cmd, ref flag, ref result);
				}
			}
			if (flag)
			{
				Commander.execute(player.playerID.steamID, cmd.Substring(1));
			}
			return result;
		}

		// Token: 0x06003082 RID: 12418 RVA: 0x000DF6F8 File Offset: 0x000DD8F8
		[Obsolete]
		public void tellVoteStart(CSteamID steamID, CSteamID origin, CSteamID target, byte votesNeeded)
		{
			ChatManager.ReceiveVoteStart(origin, target, votesNeeded);
		}

		// Token: 0x06003083 RID: 12419 RVA: 0x000DF704 File Offset: 0x000DD904
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellVoteStart")]
		public static void ReceiveVoteStart(CSteamID origin, CSteamID target, byte votesNeeded)
		{
			SteamPlayer steamPlayer = PlayerTool.getSteamPlayer(origin);
			if (steamPlayer == null)
			{
				return;
			}
			SteamPlayer steamPlayer2 = PlayerTool.getSteamPlayer(target);
			if (steamPlayer2 == null)
			{
				return;
			}
			ChatManager.needsVote = true;
			ChatManager.hasVote = false;
			VotingStart votingStart = ChatManager.onVotingStart;
			if (votingStart == null)
			{
				return;
			}
			votingStart(steamPlayer, steamPlayer2, votesNeeded);
		}

		// Token: 0x06003084 RID: 12420 RVA: 0x000DF745 File Offset: 0x000DD945
		[Obsolete]
		public void tellVoteUpdate(CSteamID steamID, byte voteYes, byte voteNo)
		{
			ChatManager.ReceiveVoteUpdate(voteYes, voteNo);
		}

		// Token: 0x06003085 RID: 12421 RVA: 0x000DF74E File Offset: 0x000DD94E
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellVoteMessage")]
		public static void ReceiveVoteUpdate(byte voteYes, byte voteNo)
		{
			VotingUpdate votingUpdate = ChatManager.onVotingUpdate;
			if (votingUpdate == null)
			{
				return;
			}
			votingUpdate(voteYes, voteNo);
		}

		// Token: 0x06003086 RID: 12422 RVA: 0x000DF761 File Offset: 0x000DD961
		[Obsolete]
		public void tellVoteStop(CSteamID steamID, byte message)
		{
			ChatManager.ReceiveVoteStop((EVotingMessage)message);
		}

		// Token: 0x06003087 RID: 12423 RVA: 0x000DF769 File Offset: 0x000DD969
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellVoteStop")]
		public static void ReceiveVoteStop(EVotingMessage message)
		{
			ChatManager.needsVote = false;
			VotingStop votingStop = ChatManager.onVotingStop;
			if (votingStop == null)
			{
				return;
			}
			votingStop(message);
		}

		// Token: 0x06003088 RID: 12424 RVA: 0x000DF781 File Offset: 0x000DD981
		[Obsolete]
		public void tellVoteMessage(CSteamID steamID, byte message)
		{
			ChatManager.ReceiveVoteMessage((EVotingMessage)message);
		}

		// Token: 0x06003089 RID: 12425 RVA: 0x000DF789 File Offset: 0x000DD989
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellVoteMessage")]
		public static void ReceiveVoteMessage(EVotingMessage message)
		{
			VotingMessage votingMessage = ChatManager.onVotingMessage;
			if (votingMessage == null)
			{
				return;
			}
			votingMessage(message);
		}

		// Token: 0x0600308A RID: 12426 RVA: 0x000DF79C File Offset: 0x000DD99C
		[Obsolete]
		public void askVote(CSteamID steamID, bool vote)
		{
			ServerInvocationContext serverInvocationContext = ServerInvocationContext.FromSteamIDForBackwardsCompatibility(steamID);
			ChatManager.ReceiveSubmitVoteRequest(serverInvocationContext, vote);
		}

		// Token: 0x0600308B RID: 12427 RVA: 0x000DF7B8 File Offset: 0x000DD9B8
		[SteamCall(ESteamCallValidation.SERVERSIDE, ratelimitHz = 2, legacyName = "askVote")]
		public static void ReceiveSubmitVoteRequest(in ServerInvocationContext context, bool vote)
		{
			SteamPlayer callingPlayer = context.GetCallingPlayer();
			if (callingPlayer == null)
			{
				return;
			}
			if (!ChatManager.isVoting)
			{
				return;
			}
			if (ChatManager.votes.Contains(callingPlayer.playerID.steamID))
			{
				return;
			}
			ChatManager.votes.Add(callingPlayer.playerID.steamID);
			if (vote)
			{
				ChatManager.voteYes += 1;
			}
			else
			{
				ChatManager.voteNo += 1;
			}
			ChatManager.SendVoteUpdate.Invoke(ENetReliability.Reliable, Provider.GatherClientConnections(), ChatManager.voteYes, ChatManager.voteNo);
		}

		// Token: 0x0600308C RID: 12428 RVA: 0x000DF840 File Offset: 0x000DDA40
		[Obsolete]
		public void askCallVote(CSteamID steamID, CSteamID target)
		{
			ServerInvocationContext serverInvocationContext = ServerInvocationContext.FromSteamIDForBackwardsCompatibility(steamID);
			ChatManager.ReceiveCallVoteRequest(serverInvocationContext, target);
		}

		// Token: 0x0600308D RID: 12429 RVA: 0x000DF85C File Offset: 0x000DDA5C
		[SteamCall(ESteamCallValidation.SERVERSIDE, ratelimitHz = 2, legacyName = "askCallVote")]
		public static void ReceiveCallVoteRequest(in ServerInvocationContext context, CSteamID target)
		{
			if (ChatManager.isVoting)
			{
				return;
			}
			SteamPlayer callingPlayer = context.GetCallingPlayer();
			if (callingPlayer == null || Time.realtimeSinceStartup < callingPlayer.nextVote)
			{
				ChatManager.SendVoteMessage.Invoke(ENetReliability.Reliable, context.GetTransportConnection(), EVotingMessage.DELAY);
				return;
			}
			if (!ChatManager.voteAllowed)
			{
				ChatManager.SendVoteMessage.Invoke(ENetReliability.Reliable, context.GetTransportConnection(), EVotingMessage.OFF);
				return;
			}
			SteamPlayer steamPlayer = PlayerTool.getSteamPlayer(target);
			if (steamPlayer == null || steamPlayer.isAdmin)
			{
				return;
			}
			if (Provider.clients.Count < (int)ChatManager.votePlayers)
			{
				ChatManager.SendVoteMessage.Invoke(ENetReliability.Reliable, context.GetTransportConnection(), EVotingMessage.PLAYERS);
				return;
			}
			CommandWindow.Log(Provider.localization.format("Vote_Kick", new object[]
			{
				callingPlayer.playerID.characterName,
				callingPlayer.playerID.playerName,
				steamPlayer.playerID.characterName,
				steamPlayer.playerID.playerName
			}));
			ChatManager.lastVote = Time.realtimeSinceStartup;
			ChatManager.isVoting = true;
			ChatManager.voteYes = 0;
			ChatManager.voteNo = 0;
			ChatManager.votesPossible = (byte)Provider.clients.Count;
			ChatManager.votesNeeded = (byte)Mathf.Ceil((float)ChatManager.votesPossible * ChatManager.votePercentage);
			ChatManager.voteOrigin = callingPlayer;
			ChatManager.voteTarget = target;
			ChatManager.votes = new List<CSteamID>();
			ChatManager.voteIP = steamPlayer.getIPv4AddressOrZero();
			ChatManager.SendVoteStart.Invoke(ENetReliability.Reliable, Provider.GatherClientConnections(), callingPlayer.playerID.steamID, target, ChatManager.votesNeeded);
		}

		// Token: 0x0600308E RID: 12430 RVA: 0x000DF9C3 File Offset: 0x000DDBC3
		public static void sendVote(bool vote)
		{
			ChatManager.SendSubmitVoteRequest.Invoke(ENetReliability.Reliable, vote);
		}

		// Token: 0x0600308F RID: 12431 RVA: 0x000DF9D1 File Offset: 0x000DDBD1
		public static void sendCallVote(CSteamID target)
		{
			ChatManager.SendCallVoteRequest.Invoke(ENetReliability.Unreliable, target);
		}

		// Token: 0x06003090 RID: 12432 RVA: 0x000DF9DF File Offset: 0x000DDBDF
		[Obsolete]
		public void tellChat(CSteamID steamID, CSteamID owner, string iconURL, byte mode, Color color, bool rich, string text)
		{
			ChatManager.ReceiveChatEntry(owner, iconURL, (EChatMode)mode, color, rich, text);
		}

		// Token: 0x06003091 RID: 12433 RVA: 0x000DF9F0 File Offset: 0x000DDBF0
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellChat")]
		public static void ReceiveChatEntry(CSteamID owner, string iconURL, EChatMode mode, Color color, bool rich, string text)
		{
			ChatManager.receiveChatMessage(owner, iconURL, mode, color, rich, text);
		}

		// Token: 0x06003092 RID: 12434 RVA: 0x000DFA00 File Offset: 0x000DDC00
		[Obsolete]
		public void askChat(CSteamID steamID, byte flags, string text)
		{
			ServerInvocationContext serverInvocationContext = ServerInvocationContext.FromSteamIDForBackwardsCompatibility(steamID);
			ChatManager.ReceiveChatRequest(serverInvocationContext, flags, text);
		}

		// Token: 0x06003093 RID: 12435 RVA: 0x000DFA20 File Offset: 0x000DDC20
		[SteamCall(ESteamCallValidation.SERVERSIDE, ratelimitHz = 15, legacyName = "askChat")]
		public static void ReceiveChatRequest(in ServerInvocationContext context, byte flags, string text)
		{
			SteamPlayer callingPlayer = context.GetCallingPlayer();
			if (callingPlayer == null || callingPlayer.player == null)
			{
				return;
			}
			if (Time.realtimeSinceStartup - callingPlayer.lastChat < ChatManager.chatrate)
			{
				return;
			}
			callingPlayer.lastChat = Time.realtimeSinceStartup;
			EChatMode echatMode = (EChatMode)(flags & 127);
			bool flag = (flags & 128) > 0;
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			if (Dedicator.IsDedicatedServer && flag && !Provider.configData.UnityEvents.Allow_Client_Messages)
			{
				return;
			}
			text = text.Trim();
			if (text.Length < 1)
			{
				return;
			}
			if (text.ContainsNewLine())
			{
				return;
			}
			if (text.Length > ChatManager.MAX_MESSAGE_LENGTH)
			{
				text = text.Substring(0, ChatManager.MAX_MESSAGE_LENGTH);
			}
			if (echatMode == EChatMode.GLOBAL)
			{
				if (CommandWindow.shouldLogChat)
				{
					CommandWindow.Log(Provider.localization.format("Global", callingPlayer.playerID.characterName, callingPlayer.playerID.playerName, text));
				}
			}
			else if (echatMode == EChatMode.LOCAL)
			{
				if (CommandWindow.shouldLogChat)
				{
					CommandWindow.Log(Provider.localization.format("Local", callingPlayer.playerID.characterName, callingPlayer.playerID.playerName, text));
				}
			}
			else
			{
				if (echatMode != EChatMode.GROUP)
				{
					return;
				}
				if (CommandWindow.shouldLogChat)
				{
					CommandWindow.Log(Provider.localization.format("Group", callingPlayer.playerID.characterName, callingPlayer.playerID.playerName, text));
				}
			}
			if (flag)
			{
				UnturnedLog.info("UnityEventMsg {0}: '{1}'", new object[]
				{
					callingPlayer.playerID.steamID,
					text
				});
			}
			Color color = Color.white;
			if (callingPlayer.isAdmin && !Provider.hideAdmins)
			{
				color = Palette.ADMIN;
			}
			else if (callingPlayer.isPro)
			{
				color = Palette.PRO;
			}
			bool useRichTextFormatting = false;
			bool flag2 = true;
			Chatted chatted = ChatManager.onChatted;
			if (chatted != null)
			{
				chatted(callingPlayer, echatMode, ref color, ref useRichTextFormatting, text, ref flag2);
			}
			if (ProfanityFilter.NaiveContainsHardcodedBannedWord(text))
			{
				return;
			}
			if (ChatManager.process(callingPlayer, text, flag) && flag2)
			{
				if (ChatManager.onServerFormattingMessage != null)
				{
					ChatManager.onServerFormattingMessage(callingPlayer, echatMode, ref text);
				}
				else
				{
					text = "%SPEAKER%: " + text;
					if (echatMode != EChatMode.LOCAL)
					{
						if (echatMode == EChatMode.GROUP)
						{
							text = "[G] " + text;
						}
					}
					else
					{
						text = "[A] " + text;
					}
				}
				if (echatMode == EChatMode.GLOBAL)
				{
					ChatManager.serverSendMessage(text, color, callingPlayer, null, EChatMode.GLOBAL, null, useRichTextFormatting);
					return;
				}
				if (echatMode == EChatMode.LOCAL)
				{
					float num = 16384f;
					using (List<SteamPlayer>.Enumerator enumerator = Provider.clients.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							SteamPlayer steamPlayer = enumerator.Current;
							if (!(steamPlayer.player == null) && (steamPlayer.player.transform.position - callingPlayer.player.transform.position).sqrMagnitude < num)
							{
								ChatManager.serverSendMessage(text, color, callingPlayer, steamPlayer, EChatMode.LOCAL, null, useRichTextFormatting);
							}
						}
						return;
					}
				}
				if (echatMode == EChatMode.GROUP && callingPlayer.player.quests.groupID != CSteamID.Nil)
				{
					foreach (SteamPlayer steamPlayer2 in Provider.clients)
					{
						if (!(steamPlayer2.player == null) && steamPlayer2.player.quests.isMemberOfSameGroupAs(callingPlayer.player))
						{
							ChatManager.serverSendMessage(text, color, callingPlayer, steamPlayer2, EChatMode.GROUP, null, useRichTextFormatting);
						}
					}
				}
			}
		}

		// Token: 0x06003094 RID: 12436 RVA: 0x000DFD98 File Offset: 0x000DDF98
		public static string getRecentlySentMessage(int index)
		{
			if (index >= 0 && index < ChatManager.recentlySentMessages.Length)
			{
				return ChatManager.recentlySentMessages[index];
			}
			return string.Empty;
		}

		/// <summary>
		/// Send a request to chat from the client to the server.
		/// </summary>
		// Token: 0x06003095 RID: 12437 RVA: 0x000DFDB8 File Offset: 0x000DDFB8
		public static void sendChat(EChatMode mode, string text)
		{
			for (int i = ChatManager.recentlySentMessages.Length - 1; i > 0; i--)
			{
				ChatManager.recentlySentMessages[i] = ChatManager.recentlySentMessages[i - 1];
			}
			ChatManager.recentlySentMessages[0] = text;
			if (string.Equals(text, "/copycameratransform", StringComparison.InvariantCultureIgnoreCase))
			{
				ChatManager.CopyCameraTransform();
				return;
			}
			if (string.Equals(text, "/freezecameratransform", StringComparison.InvariantCultureIgnoreCase))
			{
				ChatManager.ToggleFreezeCameraTransform();
				return;
			}
			if (string.Equals(text, "/logmemoryusage"))
			{
				CommandLogMemoryUsage.ExecuteAndCopyToClipboard();
			}
			else if (string.Equals(text, "/drawaudioreverbzones", StringComparison.InvariantCultureIgnoreCase))
			{
				ChatManager.DrawAudioReverbZones();
				return;
			}
			ChatManager.SendChatRequest.Invoke(ENetReliability.Reliable, (byte)mode, text);
		}

		/// <summary>
		/// Allows Unity events to send text chat messages from the client, for example to execute commands.
		/// Messenger context is logged to help track down assets using it in inappropriate ways.
		/// </summary>
		// Token: 0x06003096 RID: 12438 RVA: 0x000DFE50 File Offset: 0x000DE050
		public static void clientSendMessage_UnityEvent(EChatMode mode, string text, ClientTextChatMessenger messenger)
		{
			if (messenger == null)
			{
				throw new ArgumentNullException("messenger");
			}
			UnturnedLog.info("UnityEventMsg {0}: '{1}'", new object[]
			{
				messenger.gameObject.GetSceneHierarchyPath(),
				text
			});
			ChatManager.SendChatRequest.Invoke(ENetReliability.Reliable, (byte)(mode | (EChatMode)128), text);
		}

		/// <summary>
		/// Allows Unity events to broadcast text chat messages from the server.
		/// Messenger context is logged to help track down assets using it in inappropriate ways.
		/// </summary>
		// Token: 0x06003097 RID: 12439 RVA: 0x000DFEA8 File Offset: 0x000DE0A8
		public static void serverSendMessage_UnityEvent(string text, Color color, string iconURL, bool useRichTextFormatting, ServerTextChatMessenger messenger)
		{
			if (messenger == null)
			{
				throw new ArgumentNullException("messenger");
			}
			if (Dedicator.IsDedicatedServer && !Provider.configData.UnityEvents.Allow_Server_Messages)
			{
				UnturnedLog.info(string.Concat(new string[]
				{
					"Blocking ServerTextChatMessenger component at ",
					messenger.gameObject.GetSceneHierarchyPath(),
					" from sending message \"",
					text,
					"\" because UnityEvents.Allow_Server_Messages is off"
				}));
				return;
			}
			UnturnedLog.info("UnityEventMsg {0}: '{1}'", new object[]
			{
				messenger.gameObject.GetSceneHierarchyPath(),
				text
			});
			ChatManager.serverSendMessage(text, color, null, null, EChatMode.SAY, iconURL, useRichTextFormatting);
		}

		/// <summary>
		/// Server send message to specific player.
		/// Used in vanilla for the welcome message.
		/// Should not be removed because plugins may depend on it.
		/// </summary>
		// Token: 0x06003098 RID: 12440 RVA: 0x000DFF4D File Offset: 0x000DE14D
		public static void say(CSteamID target, string text, Color color, bool isRich = false)
		{
			ChatManager.say(target, text, color, EChatMode.WELCOME, isRich);
		}

		/// <summary>
		/// Server send message to specific player.
		/// Used in vanilla by help command to tell player about command options.
		/// Should not be removed because plugins may depend on it.
		/// </summary>
		// Token: 0x06003099 RID: 12441 RVA: 0x000DFF5C File Offset: 0x000DE15C
		public static void say(CSteamID target, string text, Color color, EChatMode mode, bool isRich = false)
		{
			SteamPlayer steamPlayer = PlayerTool.getSteamPlayer(target);
			if (steamPlayer == null)
			{
				return;
			}
			ChatManager.serverSendMessage(text, color, null, steamPlayer, EChatMode.SAY, null, isRich);
		}

		/// <summary>
		/// Server send message to all players.
		/// Used in vanilla by some alerts and broadcast command.
		/// Should not be removed because plugins may depend on it.
		/// </summary>
		// Token: 0x0600309A RID: 12442 RVA: 0x000DFF81 File Offset: 0x000DE181
		public static void say(string text, Color color, bool isRich = false)
		{
			ChatManager.serverSendMessage(text, color, null, null, EChatMode.SAY, null, isRich);
		}

		/// <summary>
		/// Serverside send a chat message to all players, or a specific player.
		/// </summary>
		/// <param name="text">Contents to display.</param>
		/// <param name="color">Default text color unless rich formatting overrides it.</param>
		/// <param name="fromPlayer">Player who sent the message (used for avatar), or null if send by a plugin.</param>
		/// <param name="toPlayer">Send message to only this player, or all players if null.</param>
		/// <param name="mode">Mostly deprecated, but global/local/group may be displayed.</param>
		/// <param name="iconURL">URL to a 32x32 .png to show rather than a player avatar, or null/empty.</param>
		/// <param name="useRichTextFormatting">Enable rich tags e.g., bold, italics in the message contents.</param>
		// Token: 0x0600309B RID: 12443 RVA: 0x000DFF90 File Offset: 0x000DE190
		public static void serverSendMessage(string text, Color color, SteamPlayer fromPlayer = null, SteamPlayer toPlayer = null, EChatMode mode = EChatMode.SAY, string iconURL = null, bool useRichTextFormatting = false)
		{
			if (!Provider.isServer)
			{
				throw new Exception("Tried to send server message, but currently a client! Text: " + text);
			}
			ServerSendingChatMessageHandler serverSendingChatMessageHandler = ChatManager.onServerSendingMessage;
			if (serverSendingChatMessageHandler != null)
			{
				serverSendingChatMessageHandler(ref text, ref color, fromPlayer, toPlayer, mode, ref iconURL, ref useRichTextFormatting);
			}
			if (fromPlayer != null && toPlayer != null)
			{
				string newValue;
				if (!string.IsNullOrEmpty(fromPlayer.playerID.nickName) && fromPlayer != toPlayer && toPlayer.player != null && fromPlayer.player != null && fromPlayer.player.quests.isMemberOfSameGroupAs(toPlayer.player))
				{
					newValue = fromPlayer.playerID.nickName;
				}
				else
				{
					newValue = fromPlayer.playerID.characterName;
				}
				text = text.Replace("%SPEAKER%", newValue);
			}
			if (iconURL == null)
			{
				iconURL = string.Empty;
			}
			CSteamID arg = (fromPlayer == null) ? CSteamID.Nil : fromPlayer.playerID.steamID;
			if (toPlayer == null)
			{
				using (List<SteamPlayer>.Enumerator enumerator = Provider.clients.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						SteamPlayer steamPlayer = enumerator.Current;
						if (steamPlayer != null)
						{
							ChatManager.serverSendMessage(text, color, fromPlayer, steamPlayer, mode, iconURL, useRichTextFormatting);
						}
					}
					return;
				}
			}
			ChatManager.SendChatEntry.Invoke(ENetReliability.Reliable, toPlayer.transportConnection, arg, iconURL, mode, color, useRichTextFormatting, text);
		}

		// Token: 0x0600309C RID: 12444 RVA: 0x000E00D8 File Offset: 0x000DE2D8
		private void onLevelLoaded(int level)
		{
			if (level > Level.BUILD_INDEX_SETUP)
			{
				ChatManager.receivedChatHistory.Clear();
			}
		}

		// Token: 0x0600309D RID: 12445 RVA: 0x000E00EC File Offset: 0x000DE2EC
		private void onServerConnected(CSteamID steamID)
		{
			if (Provider.isServer && ChatManager.welcomeText != "")
			{
				SteamPlayer steamPlayer = PlayerTool.getSteamPlayer(steamID);
				ChatManager.say(steamPlayer.playerID.steamID, string.Format(ChatManager.welcomeText, steamPlayer.playerID.characterName), ChatManager.welcomeColor, false);
			}
		}

		// Token: 0x0600309E RID: 12446 RVA: 0x000E0144 File Offset: 0x000DE344
		private void Update()
		{
			if (ChatManager.isVoting && (Time.realtimeSinceStartup - ChatManager.lastVote > ChatManager.voteDuration || ChatManager.voteYes >= ChatManager.votesNeeded || ChatManager.voteNo > ChatManager.votesPossible - ChatManager.votesNeeded))
			{
				ChatManager.isVoting = false;
				if (ChatManager.voteYes >= ChatManager.votesNeeded)
				{
					if (ChatManager.voteOrigin != null)
					{
						ChatManager.voteOrigin.nextVote = Time.realtimeSinceStartup + ChatManager.votePassCooldown;
					}
					CommandWindow.Log(Provider.localization.format("Vote_Pass"));
					ChatManager.SendVoteStop.Invoke(ENetReliability.Reliable, Provider.GatherClientConnections(), EVotingMessage.PASS);
					SteamBlacklist.ban(ChatManager.voteTarget, ChatManager.voteIP, null, CSteamID.Nil, "you were vote kicked", SteamBlacklist.TEMPORARY);
				}
				else
				{
					if (ChatManager.voteOrigin != null)
					{
						ChatManager.voteOrigin.nextVote = Time.realtimeSinceStartup + ChatManager.voteFailCooldown;
					}
					CommandWindow.Log(Provider.localization.format("Vote_Fail"));
					ChatManager.SendVoteStop.Invoke(ENetReliability.Reliable, Provider.GatherClientConnections(), EVotingMessage.FAIL);
				}
			}
			if (ChatManager.needsVote && !ChatManager.hasVote)
			{
				if (InputEx.GetKeyDown(KeyCode.F1))
				{
					ChatManager.needsVote = false;
					ChatManager.hasVote = true;
					ChatManager.sendVote(true);
					return;
				}
				if (InputEx.GetKeyDown(KeyCode.F2))
				{
					ChatManager.needsVote = false;
					ChatManager.hasVote = true;
					ChatManager.sendVote(false);
				}
			}
		}

		/// <summary>
		/// Nelson 2024-10-14: We might want to elaborate on this with "client-side chat commands" in the future, but
		/// for the meantime I've hacked in this one command.
		/// </summary>
		// Token: 0x0600309F RID: 12447 RVA: 0x000E0290 File Offset: 0x000DE490
		internal static void CopyCameraTransform()
		{
			Camera instance = MainCamera.instance;
			if (instance == null)
			{
				UnturnedLog.warn("Unable to copy camera transform because there is no active main camera");
				return;
			}
			Vector3 eulerAngles = instance.transform.rotation.eulerAngles;
			float x = eulerAngles.x;
			float y = eulerAngles.y;
			GUIUtility.systemCopyBuffer = string.Format("{0}:{1}, {2}", instance.transform.position, x, y);
		}

		// Token: 0x060030A0 RID: 12448 RVA: 0x000E0304 File Offset: 0x000DE504
		internal static void ToggleFreezeCameraTransform()
		{
			if (MainCamera.instance == null)
			{
				UnturnedLog.warn("Unable to freeze camera transform because there is no active main camera");
				return;
			}
			if (!Player.LocalPlayer.channel.owner.isAdmin)
			{
				UnturnedLog.warn("Unable to freeze camera transform without admin permissions");
				return;
			}
			MainCamera.IsPositionFrozen = !MainCamera.IsPositionFrozen;
		}

		// Token: 0x060030A1 RID: 12449 RVA: 0x000E0358 File Offset: 0x000DE558
		internal static void DrawAudioReverbZones()
		{
			if (!Player.LocalPlayer.channel.owner.isAdmin)
			{
				UnturnedLog.warn("Unable to draw audio reverb zones without admin permissions");
				return;
			}
			bool flag = false;
			List<ReverbGizmoComponent> list = new List<ReverbGizmoComponent>();
			AudioReverbZone[] array = UnityEngine.Object.FindObjectsByType<AudioReverbZone>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
			if (!array.IsNullOrEmpty())
			{
				foreach (AudioReverbZone audioReverbZone in array)
				{
					ReverbGizmoComponent reverbGizmoComponent = audioReverbZone.GetComponent<ReverbGizmoComponent>();
					if (reverbGizmoComponent == null)
					{
						reverbGizmoComponent = audioReverbZone.gameObject.AddComponent<ReverbGizmoComponent>();
						reverbGizmoComponent.zone = audioReverbZone;
						flag = true;
					}
					list.Add(reverbGizmoComponent);
				}
			}
			if (!flag)
			{
				foreach (ReverbGizmoComponent obj in list)
				{
					UnityEngine.Object.Destroy(obj);
				}
			}
		}

		// Token: 0x060030A2 RID: 12450 RVA: 0x000E0430 File Offset: 0x000DE630
		private void Start()
		{
			ChatManager.manager = this;
			Level.onLevelLoaded = (LevelLoaded)Delegate.Combine(Level.onLevelLoaded, new LevelLoaded(this.onLevelLoaded));
			Provider.onServerConnected = (Provider.ServerConnected)Delegate.Combine(Provider.onServerConnected, new Provider.ServerConnected(this.onServerConnected));
		}

		// Token: 0x0400198A RID: 6538
		public static readonly int MAX_MESSAGE_LENGTH = 512;

		/// <summary>
		/// Called on the client after a new message is inserted to the front of the list.
		/// </summary>
		// Token: 0x0400198B RID: 6539
		public static ChatMessageReceivedHandler onChatMessageReceived;

		/// <summary>
		/// Called on the server when preparing a message to be sent to a player.
		/// Allows controlling how %SPEAKER% is formatted for the receiving player.
		/// </summary>
		// Token: 0x0400198C RID: 6540
		public static ServerSendingChatMessageHandler onServerSendingMessage;

		/// <summary>
		/// Called on the server when formatting a player's message before sending to anyone.
		/// Allows structuring the message and where the player's name is, for example: '[CustomPluginRoleThing] %SPEAKER% - OriginalMessageText'
		/// </summary>
		// Token: 0x0400198D RID: 6541
		public static ServerFormattingChatMessageHandler onServerFormattingMessage;

		// Token: 0x0400198E RID: 6542
		public static Chatted onChatted;

		// Token: 0x0400198F RID: 6543
		public static CheckPermissions onCheckPermissions;

		// Token: 0x04001990 RID: 6544
		public static VotingStart onVotingStart;

		// Token: 0x04001991 RID: 6545
		public static VotingUpdate onVotingUpdate;

		// Token: 0x04001992 RID: 6546
		public static VotingStop onVotingStop;

		// Token: 0x04001993 RID: 6547
		public static VotingMessage onVotingMessage;

		// Token: 0x04001995 RID: 6549
		public static string welcomeText = "";

		// Token: 0x04001996 RID: 6550
		public static Color welcomeColor = Palette.SERVER;

		// Token: 0x04001997 RID: 6551
		public static float chatrate = 0.25f;

		// Token: 0x04001998 RID: 6552
		public static bool voteAllowed = false;

		// Token: 0x04001999 RID: 6553
		public static float votePassCooldown = 5f;

		// Token: 0x0400199A RID: 6554
		public static float voteFailCooldown = 60f;

		// Token: 0x0400199B RID: 6555
		public static float voteDuration = 15f;

		// Token: 0x0400199C RID: 6556
		public static float votePercentage = 0.75f;

		// Token: 0x0400199D RID: 6557
		public static byte votePlayers = 3;

		// Token: 0x0400199E RID: 6558
		private static float lastVote;

		// Token: 0x0400199F RID: 6559
		private static bool isVoting;

		// Token: 0x040019A0 RID: 6560
		private static bool needsVote;

		// Token: 0x040019A1 RID: 6561
		private static bool hasVote;

		// Token: 0x040019A2 RID: 6562
		private static byte voteYes;

		// Token: 0x040019A3 RID: 6563
		private static byte voteNo;

		// Token: 0x040019A4 RID: 6564
		private static byte votesPossible;

		// Token: 0x040019A5 RID: 6565
		private static byte votesNeeded;

		// Token: 0x040019A6 RID: 6566
		private static SteamPlayer voteOrigin;

		// Token: 0x040019A7 RID: 6567
		private static CSteamID voteTarget;

		// Token: 0x040019A8 RID: 6568
		private static uint voteIP;

		// Token: 0x040019A9 RID: 6569
		private static List<CSteamID> votes;

		// Token: 0x040019AA RID: 6570
		private static ChatManager manager;

		// Token: 0x040019AB RID: 6571
		private static List<ReceivedChatMessage> _receivedChatHistory = new List<ReceivedChatMessage>();

		// Token: 0x040019AC RID: 6572
		private static readonly ClientStaticMethod<CSteamID, CSteamID, byte> SendVoteStart = ClientStaticMethod<CSteamID, CSteamID, byte>.Get(new ClientStaticMethod<CSteamID, CSteamID, byte>.ReceiveDelegate(ChatManager.ReceiveVoteStart));

		// Token: 0x040019AD RID: 6573
		private static readonly ClientStaticMethod<byte, byte> SendVoteUpdate = ClientStaticMethod<byte, byte>.Get(new ClientStaticMethod<byte, byte>.ReceiveDelegate(ChatManager.ReceiveVoteUpdate));

		// Token: 0x040019AE RID: 6574
		private static readonly ClientStaticMethod<EVotingMessage> SendVoteStop = ClientStaticMethod<EVotingMessage>.Get(new ClientStaticMethod<EVotingMessage>.ReceiveDelegate(ChatManager.ReceiveVoteStop));

		// Token: 0x040019AF RID: 6575
		private static readonly ClientStaticMethod<EVotingMessage> SendVoteMessage = ClientStaticMethod<EVotingMessage>.Get(new ClientStaticMethod<EVotingMessage>.ReceiveDelegate(ChatManager.ReceiveVoteMessage));

		// Token: 0x040019B0 RID: 6576
		private static readonly ServerStaticMethod<bool> SendSubmitVoteRequest = ServerStaticMethod<bool>.Get(new ServerStaticMethod<bool>.ReceiveDelegateWithContext(ChatManager.ReceiveSubmitVoteRequest));

		// Token: 0x040019B1 RID: 6577
		private static readonly ServerStaticMethod<CSteamID> SendCallVoteRequest = ServerStaticMethod<CSteamID>.Get(new ServerStaticMethod<CSteamID>.ReceiveDelegateWithContext(ChatManager.ReceiveCallVoteRequest));

		// Token: 0x040019B2 RID: 6578
		private static readonly ClientStaticMethod<CSteamID, string, EChatMode, Color, bool, string> SendChatEntry = ClientStaticMethod<CSteamID, string, EChatMode, Color, bool, string>.Get(new ClientStaticMethod<CSteamID, string, EChatMode, Color, bool, string>.ReceiveDelegate(ChatManager.ReceiveChatEntry));

		// Token: 0x040019B3 RID: 6579
		private static readonly ServerStaticMethod<byte, string> SendChatRequest = ServerStaticMethod<byte, string>.Get(new ServerStaticMethod<byte, string>.ReceiveDelegateWithContext(ChatManager.ReceiveChatRequest));

		/// <summary>
		/// Previous messages sent to server from this client.
		/// Newest at the front, oldest at the back. Used to repeat chat commands.
		/// </summary>
		// Token: 0x040019B4 RID: 6580
		private static string[] recentlySentMessages = new string[10];

		// Token: 0x02000A25 RID: 2597
		// (Invoke) Token: 0x0600545A RID: 21594
		public delegate void ClientUnityEventPermissionsHandler(SteamPlayer player, string command, ref bool shouldExecuteCommand, ref bool shouldList);
	}
}
