﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002A2 RID: 674
	internal class AssetLoadingStats
	{
		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06001437 RID: 5175 RVA: 0x0004D625 File Offset: 0x0004B825
		public int RegisteredSearchLocations
		{
			get
			{
				return this.totalRegisteredSearchLocations - this.baselineRegisteredSearchLocations;
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06001438 RID: 5176 RVA: 0x0004D634 File Offset: 0x0004B834
		public int SearchLocationsFinishedSearching
		{
			get
			{
				return this.totalSearchLocationsFinishedSearching - this.baselineSearchLocationsFinishedSearching;
			}
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06001439 RID: 5177 RVA: 0x0004D643 File Offset: 0x0004B843
		public int AssetBundlesFound
		{
			get
			{
				return this.totalMasterBundlesFound - this.baselineMasterBundlesFound;
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x0600143A RID: 5178 RVA: 0x0004D652 File Offset: 0x0004B852
		public int AssetBundlesLoaded
		{
			get
			{
				return this.totalMasterBundlesLoaded - this.baselineMasterBundlesLoaded;
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x0600143B RID: 5179 RVA: 0x0004D661 File Offset: 0x0004B861
		public int FilesFound
		{
			get
			{
				return this.totalFilesFound - this.baselineFilesFound;
			}
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x0600143C RID: 5180 RVA: 0x0004D670 File Offset: 0x0004B870
		public int FilesRead
		{
			get
			{
				return this.totalFilesRead - this.baselineFilesRead;
			}
		}

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x0600143D RID: 5181 RVA: 0x0004D67F File Offset: 0x0004B87F
		public int FilesLoaded
		{
			get
			{
				return this.totalFilesLoaded - this.baselineFilesLoaded;
			}
		}

		// Token: 0x0600143E RID: 5182 RVA: 0x0004D690 File Offset: 0x0004B890
		public float EstimateAssetBundleProgressPercentage()
		{
			float num = (this.RegisteredSearchLocations > 1) ? (1f / (float)this.RegisteredSearchLocations) : 1f;
			float num2 = (this.SearchLocationsFinishedSearching > 0) ? ((float)this.SearchLocationsFinishedSearching * num) : num;
			return Mathf.Clamp01(((this.AssetBundlesFound > 1) ? ((float)this.AssetBundlesLoaded / (float)this.AssetBundlesFound) : 0f) * num2);
		}

		// Token: 0x0600143F RID: 5183 RVA: 0x0004D6F7 File Offset: 0x0004B8F7
		public float EstimateSearchProgressPercentage()
		{
			if (this.RegisteredSearchLocations <= 0)
			{
				return 0f;
			}
			return (float)this.SearchLocationsFinishedSearching / (float)this.RegisteredSearchLocations;
		}

		// Token: 0x06001440 RID: 5184 RVA: 0x0004D718 File Offset: 0x0004B918
		public float EstimateReadProgressPercentage()
		{
			float num = (this.RegisteredSearchLocations > 1) ? (1f / (float)this.RegisteredSearchLocations) : 1f;
			float num2 = (this.SearchLocationsFinishedSearching > 0) ? ((float)this.SearchLocationsFinishedSearching * num) : num;
			return Mathf.Clamp01(((this.FilesFound > 1) ? ((float)this.FilesRead / (float)this.FilesFound) : 0f) * num2);
		}

		// Token: 0x06001441 RID: 5185 RVA: 0x0004D780 File Offset: 0x0004B980
		public float EstimateFileProgressPercentage()
		{
			float num = (this.RegisteredSearchLocations > 1) ? (1f / (float)this.RegisteredSearchLocations) : 1f;
			float num2 = (this.SearchLocationsFinishedSearching > 0) ? ((float)this.SearchLocationsFinishedSearching * num) : num;
			return Mathf.Clamp01(((this.FilesFound > 1) ? ((float)this.FilesLoaded / (float)this.FilesFound) : 0f) * num2);
		}

		// Token: 0x06001442 RID: 5186 RVA: 0x0004D7E8 File Offset: 0x0004B9E8
		public void Reset()
		{
			this.baselineRegisteredSearchLocations = this.totalRegisteredSearchLocations;
			this.baselineSearchLocationsFinishedSearching = this.totalSearchLocationsFinishedSearching;
			this.baselineMasterBundlesFound = this.totalMasterBundlesFound;
			this.baselineMasterBundlesLoaded = this.totalMasterBundlesLoaded;
			this.baselineFilesFound = this.totalFilesFound;
			this.baselineFilesRead = this.totalFilesRead;
			this.baselineFilesLoaded = this.totalFilesLoaded;
		}

		// Token: 0x04000719 RID: 1817
		public bool isLoadingAssetBundles;

		// Token: 0x0400071A RID: 1818
		public int totalRegisteredSearchLocations;

		// Token: 0x0400071B RID: 1819
		public int totalSearchLocationsFinishedSearching;

		// Token: 0x0400071C RID: 1820
		public int totalMasterBundlesFound;

		// Token: 0x0400071D RID: 1821
		public int totalMasterBundlesLoaded;

		// Token: 0x0400071E RID: 1822
		public int totalFilesFound;

		// Token: 0x0400071F RID: 1823
		public int totalFilesRead;

		// Token: 0x04000720 RID: 1824
		public int totalFilesLoaded;

		// Token: 0x04000721 RID: 1825
		private int baselineRegisteredSearchLocations;

		// Token: 0x04000722 RID: 1826
		private int baselineSearchLocationsFinishedSearching;

		// Token: 0x04000723 RID: 1827
		private int baselineMasterBundlesFound;

		// Token: 0x04000724 RID: 1828
		private int baselineMasterBundlesLoaded;

		// Token: 0x04000725 RID: 1829
		private int baselineFilesFound;

		// Token: 0x04000726 RID: 1830
		private int baselineFilesRead;

		// Token: 0x04000727 RID: 1831
		private int baselineFilesLoaded;
	}
}
