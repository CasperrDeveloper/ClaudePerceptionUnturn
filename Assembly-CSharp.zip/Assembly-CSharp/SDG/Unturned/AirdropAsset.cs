﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000293 RID: 659
	public class AirdropAsset : Asset
	{
		// Token: 0x060013A9 RID: 5033 RVA: 0x0004BC1C File Offset: 0x00049E1C
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			this.barricadeRef = p.data.ParseStruct("Landed_Barricade", default(AssetReference<ItemBarricadeAsset>));
			this.model = p.data.ParseStruct("Carepackage_Prefab", default(MasterBundleReference<GameObject>));
		}

		// Token: 0x040006CF RID: 1743
		public static AssetReference<AirdropAsset> defaultAirdrop = new AssetReference<AirdropAsset>("229440c249dc490ba26ce71e8a59d5c6");

		/// <summary>
		/// Interactable storage barricade to spawn at the drop position.
		/// </summary>
		// Token: 0x040006D0 RID: 1744
		public AssetReference<ItemBarricadeAsset> barricadeRef;

		/// <summary>
		/// Prefab to spawn falling from the aircraft.
		/// </summary>
		// Token: 0x040006D1 RID: 1745
		public MasterBundleReference<GameObject> model;
	}
}
