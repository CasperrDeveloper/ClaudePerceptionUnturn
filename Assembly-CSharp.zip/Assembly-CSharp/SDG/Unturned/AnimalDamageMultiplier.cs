﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000426 RID: 1062
	public class AnimalDamageMultiplier : IDamageMultiplier
	{
		// Token: 0x06002197 RID: 8599 RVA: 0x000854EC File Offset: 0x000836EC
		public float multiply(ELimb limb)
		{
			switch (limb)
			{
			case ELimb.LEFT_BACK:
				return this.damage * this.leg;
			case ELimb.RIGHT_BACK:
				return this.damage * this.leg;
			case ELimb.LEFT_FRONT:
				return this.damage * this.leg;
			case ELimb.RIGHT_FRONT:
				return this.damage * this.leg;
			case ELimb.SPINE:
				return this.damage * this.spine;
			case ELimb.SKULL:
				return this.damage * this.skull;
			default:
				return this.damage;
			}
		}

		// Token: 0x06002198 RID: 8600 RVA: 0x00085575 File Offset: 0x00083775
		public AnimalDamageMultiplier(float newDamage, float newLeg, float newSpine, float newSkull)
		{
			this.damage = newDamage;
			this.leg = newLeg;
			this.spine = newSpine;
			this.skull = newSkull;
		}

		// Token: 0x04000FBE RID: 4030
		public static readonly float MULTIPLIER_EASY = 1.25f;

		// Token: 0x04000FBF RID: 4031
		public static readonly float MULTIPLIER_HARD = 0.75f;

		// Token: 0x04000FC0 RID: 4032
		public float damage;

		// Token: 0x04000FC1 RID: 4033
		public float leg;

		// Token: 0x04000FC2 RID: 4034
		public float spine;

		// Token: 0x04000FC3 RID: 4035
		public float skull;
	}
}
