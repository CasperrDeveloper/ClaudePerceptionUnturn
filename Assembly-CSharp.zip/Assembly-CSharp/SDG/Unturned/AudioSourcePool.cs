﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200058E RID: 1422
	internal class AudioSourcePool : MonoBehaviour
	{
		// Token: 0x06002F21 RID: 12065 RVA: 0x000D98A4 File Offset: 0x000D7AA4
		public static AudioSourcePool Get()
		{
			if (AudioSourcePool.instance == null)
			{
				AudioSourcePool.instance = new GameObject("AudioSourcePool").AddComponent<AudioSourcePool>();
			}
			return AudioSourcePool.instance;
		}

		// Token: 0x06002F22 RID: 12066 RVA: 0x000D98CC File Offset: 0x000D7ACC
		internal OneShotAudioHandle Play(ref OneShotAudioParameters parameters)
		{
			if (parameters.clip == null || Dedicator.IsDedicatedServer || MainCamera.instance == null)
			{
				return default(OneShotAudioHandle);
			}
			if (MathfEx.IsNearlyEqual(parameters.spatialBlend, 1f, 0.001f) && (MainCamera.instance.transform.position - parameters.position).sqrMagnitude > MathfEx.Square(parameters.maxDistance))
			{
				return default(OneShotAudioHandle);
			}
			int count = this.availableComponents.Count;
			PooledAudioSource pooledAudioSource;
			if (count > 0)
			{
				int index = count - 1;
				pooledAudioSource = this.availableComponents[index];
				this.availableComponents.RemoveAt(index);
				pooledAudioSource.component.enabled = true;
			}
			else
			{
				pooledAudioSource = new PooledAudioSource();
				pooledAudioSource.sourceId = this.nextSourceId;
				this.nextSourceId++;
				GameObject gameObject = new GameObject("PooledAudioSource");
				pooledAudioSource.component = gameObject.AddComponent<AudioSource>();
				pooledAudioSource.component.dopplerLevel = 0f;
				pooledAudioSource.component.playOnAwake = false;
			}
			Transform transform = pooledAudioSource.component.transform;
			transform.parent = parameters.parent;
			transform.localScale = Vector3.one;
			transform.position = parameters.position;
			pooledAudioSource.component.outputAudioMixerGroup = parameters.outputAudioMixerGroup;
			if (pooledAudioSource.component.outputAudioMixerGroup == null)
			{
				pooledAudioSource.component.outputAudioMixerGroup = UnturnedAudioMixer.GetDefaultGroup();
			}
			pooledAudioSource.component.clip = parameters.clip;
			pooledAudioSource.component.volume = parameters.volume;
			pooledAudioSource.component.pitch = parameters.pitch;
			pooledAudioSource.component.spatialBlend = parameters.spatialBlend;
			pooledAudioSource.component.rolloffMode = parameters.rolloffMode;
			pooledAudioSource.component.minDistance = parameters.minDistance;
			pooledAudioSource.component.maxDistance = parameters.maxDistance;
			pooledAudioSource.component.Play();
			pooledAudioSource.isInPool = false;
			pooledAudioSource.playId = this.nextPlayId;
			this.nextPlayId++;
			base.StartCoroutine(this.PlayCoroutine(pooledAudioSource, pooledAudioSource.playId, parameters.clip.length / parameters.pitch + 0.1f));
			return new OneShotAudioHandle(pooledAudioSource);
		}

		// Token: 0x06002F23 RID: 12067 RVA: 0x000D9B20 File Offset: 0x000D7D20
		internal void StopAndReleaseAudioSource(PooledAudioSource audioSource)
		{
			if (audioSource.component != null)
			{
				audioSource.component.enabled = false;
				if (audioSource.component.transform.parent != null)
				{
					audioSource.component.transform.parent = null;
				}
				this.availableComponents.Add(audioSource);
				audioSource.isInPool = true;
				audioSource.playId = 0;
			}
		}

		/// <summary>
		/// Timer needs playId as well in case source has been recycled by the time duration expires.
		/// </summary>
		// Token: 0x06002F24 RID: 12068 RVA: 0x000D9B8A File Offset: 0x000D7D8A
		private IEnumerator PlayCoroutine(PooledAudioSource audioSource, int playId, float duration)
		{
			if (duration < 1f)
			{
				yield return this.waitForOneSecond;
			}
			else
			{
				yield return new WaitForSeconds(duration);
			}
			if (!audioSource.isInPool && audioSource.playId == playId)
			{
				this.StopAndReleaseAudioSource(audioSource);
			}
			yield break;
		}

		// Token: 0x06002F25 RID: 12069 RVA: 0x000D9BAE File Offset: 0x000D7DAE
		private void OnEnable()
		{
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Combine(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
		}

		// Token: 0x06002F26 RID: 12070 RVA: 0x000D9BD0 File Offset: 0x000D7DD0
		private void OnDisable()
		{
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Remove(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
		}

		// Token: 0x06002F27 RID: 12071 RVA: 0x000D9BF4 File Offset: 0x000D7DF4
		private void OnLogMemoryUsage(List<string> results)
		{
			string format = "Audio source pool size: {0}";
			List<PooledAudioSource> list = this.availableComponents;
			results.Add(string.Format(format, (list != null) ? new int?(list.Count) : null));
		}

		// Token: 0x04001934 RID: 6452
		private WaitForSeconds waitForOneSecond = new WaitForSeconds(1f);

		// Token: 0x04001935 RID: 6453
		private static AudioSourcePool instance;

		// Token: 0x04001936 RID: 6454
		private List<PooledAudioSource> availableComponents = new List<PooledAudioSource>();

		// Token: 0x04001937 RID: 6455
		private int nextPlayId = 1;

		// Token: 0x04001938 RID: 6456
		private int nextSourceId = 1;
	}
}
