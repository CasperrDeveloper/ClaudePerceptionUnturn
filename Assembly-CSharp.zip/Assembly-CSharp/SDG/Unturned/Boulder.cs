﻿using System;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020007E2 RID: 2018
	public class Boulder : MonoBehaviour
	{
		// Token: 0x0600450C RID: 17676 RVA: 0x0015F318 File Offset: 0x0015D518
		private void OnTriggerEnter(Collider other)
		{
			if (this.isExploded)
			{
				return;
			}
			if (other.isTrigger)
			{
				return;
			}
			if (other.transform.CompareTag("Agent"))
			{
				return;
			}
			this.isExploded = true;
			Vector3 normalized = (base.transform.position - this.lastPos).normalized;
			if (Provider.isServer)
			{
				float num = Mathf.Clamp(base.transform.parent.GetComponent<Rigidbody>().velocity.magnitude, 0f, 20f);
				if (num < 3f)
				{
					return;
				}
				if (other.transform.CompareTag("Player"))
				{
					Player player = DamageTool.getPlayer(other.transform);
					if (player != null)
					{
						EPlayerKill eplayerKill;
						DamageTool.damage(player, EDeathCause.BOULDER, ELimb.SPINE, CSteamID.Nil, normalized, Boulder.DAMAGE_PLAYER, num, out eplayerKill, true, false, ERagdollEffect.NONE);
					}
				}
				else if (other.transform.CompareTag("Vehicle"))
				{
					if (Provider.modeConfigData.Zombies.Can_Target_Vehicles)
					{
						InteractableVehicle component = other.transform.GetComponent<InteractableVehicle>();
						if (component != null && component.asset != null && component.asset.isVulnerableToEnvironment)
						{
							VehicleManager.damage(component, Boulder.DAMAGE_VEHICLE, num, true, default(CSteamID), EDamageOrigin.Mega_Zombie_Boulder);
						}
					}
				}
				else if (other.transform.CompareTag("Barricade"))
				{
					if (Provider.modeConfigData.Zombies.Can_Target_Barricades)
					{
						Transform barricadeRootTransform = DamageTool.getBarricadeRootTransform(other.transform);
						if (barricadeRootTransform != null)
						{
							BarricadeManager.damage(barricadeRootTransform, Boulder.DAMAGE_BARRICADE, num, true, default(CSteamID), EDamageOrigin.Mega_Zombie_Boulder);
						}
					}
				}
				else if (other.transform.CompareTag("Structure"))
				{
					if (Provider.modeConfigData.Zombies.Can_Target_Structures)
					{
						Transform structureRootTransform = DamageTool.getStructureRootTransform(other.transform);
						if (structureRootTransform != null)
						{
							StructureManager.damage(structureRootTransform, normalized, Boulder.DAMAGE_STRUCTURE, num, true, default(CSteamID), EDamageOrigin.Mega_Zombie_Boulder);
						}
					}
				}
				else if (other.transform.CompareTag("Resource"))
				{
					Transform resourceRootTransform = DamageTool.getResourceRootTransform(other.transform);
					if (resourceRootTransform != null)
					{
						EPlayerKill eplayerKill2;
						uint num2;
						ResourceManager.damage(resourceRootTransform, normalized, Boulder.DAMAGE_RESOURCE, num, 1f, out eplayerKill2, out num2, default(CSteamID), EDamageOrigin.Mega_Zombie_Boulder, true);
					}
				}
				else
				{
					InteractableObjectRubble componentInParent = other.transform.GetComponentInParent<InteractableObjectRubble>();
					if (componentInParent != null)
					{
						EPlayerKill eplayerKill3;
						uint num3;
						DamageTool.damage(componentInParent.transform, normalized, componentInParent.getSection(other.transform), Boulder.DAMAGE_OBJECT, num, out eplayerKill3, out num3, default(CSteamID), EDamageOrigin.Mega_Zombie_Boulder);
					}
				}
			}
			if (!Dedicator.IsDedicatedServer)
			{
				EffectAsset effectAsset = Assets.find<EffectAsset>(Boulder.Metal_2_Ref);
				if (effectAsset != null)
				{
					EffectManager.effect(effectAsset, base.transform.position, -normalized);
				}
			}
		}

		// Token: 0x0600450D RID: 17677 RVA: 0x0015F5F6 File Offset: 0x0015D7F6
		private void FixedUpdate()
		{
			this.lastPos = base.transform.position;
		}

		// Token: 0x0600450E RID: 17678 RVA: 0x0015F609 File Offset: 0x0015D809
		private void Awake()
		{
			this.lastPos = base.transform.position;
		}

		// Token: 0x04002ADD RID: 10973
		private static readonly float DAMAGE_PLAYER = 3f;

		// Token: 0x04002ADE RID: 10974
		private static readonly float DAMAGE_BARRICADE = 15f;

		// Token: 0x04002ADF RID: 10975
		private static readonly float DAMAGE_STRUCTURE = 15f;

		// Token: 0x04002AE0 RID: 10976
		private static readonly float DAMAGE_OBJECT = 25f;

		// Token: 0x04002AE1 RID: 10977
		private static readonly float DAMAGE_VEHICLE = 10f;

		// Token: 0x04002AE2 RID: 10978
		private static readonly float DAMAGE_RESOURCE = 25f;

		// Token: 0x04002AE3 RID: 10979
		private bool isExploded;

		// Token: 0x04002AE4 RID: 10980
		private Vector3 lastPos;

		// Token: 0x04002AE5 RID: 10981
		internal static AssetReference<EffectAsset> Metal_2_Ref = new AssetReference<EffectAsset>("b7d53965bc6545c28e029175af35de30");
	}
}
