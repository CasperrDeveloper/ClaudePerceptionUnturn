﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000792 RID: 1938
	public class BlueprintItemIconsInfo
	{
		// Token: 0x060042E2 RID: 17122 RVA: 0x0014C4E8 File Offset: 0x0014A6E8
		public void onItemIconReady(Texture2D texture)
		{
			if (this.index >= this.textures.Length)
			{
				return;
			}
			this.textures[this.index] = texture;
			this.index++;
			if (this.index == this.textures.Length)
			{
				BlueprintItemIconsReady blueprintItemIconsReady = this.callback;
				if (blueprintItemIconsReady == null)
				{
					return;
				}
				blueprintItemIconsReady();
			}
		}

		// Token: 0x04002950 RID: 10576
		public Texture2D[] textures;

		// Token: 0x04002951 RID: 10577
		public BlueprintItemIconsReady callback;

		// Token: 0x04002952 RID: 10578
		private int index;
	}
}
