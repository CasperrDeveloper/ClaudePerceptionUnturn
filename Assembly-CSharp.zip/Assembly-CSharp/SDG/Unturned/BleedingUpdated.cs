﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020006B3 RID: 1715
	// (Invoke) Token: 0x06003A15 RID: 14869
	public delegate void BleedingUpdated(bool newBleeding);
}
