﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200045C RID: 1116
	public struct BbCodeToken
	{
		// Token: 0x0600231A RID: 8986 RVA: 0x0009207E File Offset: 0x0009027E
		public BbCodeToken(EBbCodeTokenType tokenType)
		{
			this.tokenType = tokenType;
			this.tokenValue = null;
		}

		// Token: 0x0600231B RID: 8987 RVA: 0x0009208E File Offset: 0x0009028E
		public BbCodeToken(EBbCodeTokenType tokenType, string tokenValue)
		{
			this.tokenType = tokenType;
			this.tokenValue = tokenValue;
		}

		// Token: 0x0600231C RID: 8988 RVA: 0x0009209E File Offset: 0x0009029E
		public bool TryParseValue(string key, out string value)
		{
			if (string.IsNullOrEmpty(this.tokenValue))
			{
				value = null;
				return false;
			}
			return CommandLine.TryParseValue(this.tokenValue, key, out value);
		}

		/// <summary>
		/// Steam's new visual editor quotes value in [url=x] tag. If value is not quoted, this method returns as-is.
		/// If it IS quoted, this methods returns without quotation marks.
		/// </summary>
		// Token: 0x0600231D RID: 8989 RVA: 0x000920C0 File Offset: 0x000902C0
		public string GetUnquotedValue()
		{
			if (string.IsNullOrEmpty(this.tokenValue))
			{
				return this.tokenValue;
			}
			if (this.tokenValue.Length >= 2 && this.tokenValue.StartsWith('"') && this.tokenValue.EndsWith('"'))
			{
				return this.tokenValue.Substring(1, this.tokenValue.Length - 2);
			}
			return this.tokenValue;
		}

		// Token: 0x0600231E RID: 8990 RVA: 0x0009212D File Offset: 0x0009032D
		public override string ToString()
		{
			if (string.IsNullOrEmpty(this.tokenValue))
			{
				return this.tokenType.ToString();
			}
			return string.Format("{0}: {1}", this.tokenType, this.tokenValue);
		}

		// Token: 0x04001181 RID: 4481
		public EBbCodeTokenType tokenType;

		// Token: 0x04001182 RID: 4482
		public string tokenValue;
	}
}
