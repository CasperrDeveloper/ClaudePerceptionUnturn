﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005AD RID: 1453
	public class ClaimBase
	{
		// Token: 0x1700098F RID: 2447
		// (get) Token: 0x060030A5 RID: 12453 RVA: 0x000E05BB File Offset: 0x000DE7BB
		public bool hasOwnership
		{
			get
			{
				return OwnershipTool.checkToggle(this.owner, this.group);
			}
		}

		// Token: 0x060030A6 RID: 12454 RVA: 0x000E05CE File Offset: 0x000DE7CE
		public ClaimBase(ulong newOwner, ulong newGroup)
		{
			this.owner = newOwner;
			this.group = newGroup;
		}

		// Token: 0x040019B5 RID: 6581
		public ulong owner;

		// Token: 0x040019B6 RID: 6582
		public ulong group;
	}
}
