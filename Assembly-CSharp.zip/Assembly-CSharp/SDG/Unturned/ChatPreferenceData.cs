﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000780 RID: 1920
	public class ChatPreferenceData
	{
		// Token: 0x060042A2 RID: 17058 RVA: 0x0014B955 File Offset: 0x00149B55
		public ChatPreferenceData()
		{
			this.Fade_Delay = 10f;
			this.History_Length = 16;
			this.Preview_Length = 5;
		}

		// Token: 0x04002919 RID: 10521
		public const int DEFAULT_HISTORY_LENGTH = 16;

		// Token: 0x0400291A RID: 10522
		public float Fade_Delay;

		// Token: 0x0400291B RID: 10523
		public int History_Length;

		// Token: 0x0400291C RID: 10524
		public int Preview_Length;
	}
}
