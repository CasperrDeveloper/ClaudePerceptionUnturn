﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004DC RID: 1244
	public class BlueprintSupply : IEquatable<BlueprintSupply>
	{
		/// <summary>
		/// Note: if calling ItemRef.Get() please use FindItemAsset instead to avoid redundant asset lookups.
		/// </summary>
		// Token: 0x17000856 RID: 2134
		// (get) Token: 0x06002931 RID: 10545 RVA: 0x000B2C6D File Offset: 0x000B0E6D
		// (set) Token: 0x06002932 RID: 10546 RVA: 0x000B2C75 File Offset: 0x000B0E75
		public CachingBcAssetRef ItemRef
		{
			get
			{
				return this._itemRef;
			}
			internal set
			{
				this._itemRef = value;
			}
		}

		// Token: 0x17000857 RID: 2135
		// (get) Token: 0x06002933 RID: 10547 RVA: 0x000B2C7E File Offset: 0x000B0E7E
		public bool isCritical
		{
			get
			{
				return this._isCritical;
			}
		}

		/// <summary>
		/// If true, items with an "amount" of zero are included in eligible supplies as amount 1.
		/// In practice (as of 2025-03-03), items with zero amount are empty containers such as magazines.
		/// </summary>
		// Token: 0x17000858 RID: 2136
		// (get) Token: 0x06002934 RID: 10548 RVA: 0x000B2C86 File Offset: 0x000B0E86
		// (set) Token: 0x06002935 RID: 10549 RVA: 0x000B2C8E File Offset: 0x000B0E8E
		public bool ShouldCountEmptyAsOne { get; private set; }

		/// <summary>
		/// Determines how totalAmount of each input is calculated.
		/// </summary>
		// Token: 0x17000859 RID: 2137
		// (get) Token: 0x06002936 RID: 10550 RVA: 0x000B2C97 File Offset: 0x000B0E97
		// (set) Token: 0x06002937 RID: 10551 RVA: 0x000B2C9F File Offset: 0x000B0E9F
		public ECraftingInputCountingMethod CountingMethod { get; internal set; }

		/// <summary>
		/// If true, items with an "amount" of zero are included in eligible supplies.
		/// Otherwise, they are ignored (default).
		/// </summary>
		// Token: 0x1700085A RID: 2138
		// (get) Token: 0x06002938 RID: 10552 RVA: 0x000B2CA8 File Offset: 0x000B0EA8
		// (set) Token: 0x06002939 RID: 10553 RVA: 0x000B2CB0 File Offset: 0x000B0EB0
		public bool ShouldIncludeEmptyAmount { get; internal set; }

		/// <summary>
		/// If true, items with an "amount" &gt;= their MaxAmount are ignored. Otherwise, they are eligible (default).
		/// </summary>
		// Token: 0x1700085B RID: 2139
		// (get) Token: 0x0600293A RID: 10554 RVA: 0x000B2CB9 File Offset: 0x000B0EB9
		// (set) Token: 0x0600293B RID: 10555 RVA: 0x000B2CC1 File Offset: 0x000B0EC1
		public bool ShouldExcludeFullAmount { get; internal set; }

		/// <summary>
		/// If true, items with quality of 100% are eligible (default). Otherwise, they are ignored.
		/// </summary>
		// Token: 0x1700085C RID: 2140
		// (get) Token: 0x0600293C RID: 10556 RVA: 0x000B2CCA File Offset: 0x000B0ECA
		// (set) Token: 0x0600293D RID: 10557 RVA: 0x000B2CD2 File Offset: 0x000B0ED2
		public bool ShouldIncludeMaxQuality { get; internal set; }

		/// <summary>
		/// Controls which items are used first. For example, whether to use the lowest quality items first.
		/// </summary>
		// Token: 0x1700085D RID: 2141
		// (get) Token: 0x0600293E RID: 10558 RVA: 0x000B2CDB File Offset: 0x000B0EDB
		// (set) Token: 0x0600293F RID: 10559 RVA: 0x000B2CE3 File Offset: 0x000B0EE3
		public ECraftingInputPrioritization Prioritization { get; private set; }

		/// <summary>
		/// If true, delete input item. Defaults to true.
		/// Replaces the "tool" blueprint option.
		/// </summary>
		// Token: 0x1700085E RID: 2142
		// (get) Token: 0x06002940 RID: 10560 RVA: 0x000B2CEC File Offset: 0x000B0EEC
		// (set) Token: 0x06002941 RID: 10561 RVA: 0x000B2CF4 File Offset: 0x000B0EF4
		public bool ShouldConsume { get; internal set; }

		// Token: 0x06002942 RID: 10562 RVA: 0x000B2CFD File Offset: 0x000B0EFD
		public ItemAsset FindItemAsset()
		{
			return this._itemRef.Get<ItemAsset>();
		}

		/// <summary>
		/// Does this blueprint input require the specified item?
		/// </summary>
		// Token: 0x06002943 RID: 10563 RVA: 0x000B2D0A File Offset: 0x000B0F0A
		public bool IsItem(ItemAsset asset)
		{
			return asset != null && this._itemRef.IsReferenceTo(asset);
		}

		// Token: 0x06002944 RID: 10564 RVA: 0x000B2D20 File Offset: 0x000B0F20
		public bool Equals(BlueprintSupply other)
		{
			return other != null && !(this.ItemRef != other.ItemRef) && this.isCritical == other.isCritical && this.ShouldCountEmptyAsOne == other.ShouldCountEmptyAsOne && this.CountingMethod == other.CountingMethod && this.ShouldIncludeEmptyAmount == other.ShouldIncludeEmptyAmount && this.ShouldExcludeFullAmount == other.ShouldExcludeFullAmount && this.ShouldIncludeMaxQuality == other.ShouldIncludeMaxQuality && this.Prioritization == other.Prioritization && this.ShouldConsume == other.ShouldConsume;
		}

		// Token: 0x06002945 RID: 10565 RVA: 0x000B2DC8 File Offset: 0x000B0FC8
		public override string ToString()
		{
			return string.Format("(Item: {0} Amount: {1} Critical: {2} CountEmptyAsOne: {3}\r\n CountingMethod: {4} IncludeEmpty: {5} ExcludeFull: {6}\r\n IncludeMaxQuality: {7} Prioritization: {8} Consume: {9})", new object[]
			{
				this._itemRef,
				this.amount,
				this.isCritical,
				this.ShouldCountEmptyAsOne,
				this.CountingMethod,
				this.ShouldIncludeEmptyAmount,
				this.ShouldExcludeFullAmount,
				this.ShouldIncludeMaxQuality,
				this.Prioritization,
				this.ShouldConsume
			});
		}

		// Token: 0x06002946 RID: 10566 RVA: 0x000B2E73 File Offset: 0x000B1073
		public BlueprintSupply(ushort newID, bool newCritical, int newAmount, bool newTreatEmptyAsOne, ECraftingInputPrioritization newPrioritization)
		{
			this._isCritical = newCritical;
			this.ShouldCountEmptyAsOne = newTreatEmptyAsOne;
			this.ShouldIncludeEmptyAmount = newTreatEmptyAsOne;
			this.Prioritization = newPrioritization;
			this.ShouldConsume = true;
			this.ShouldIncludeMaxQuality = true;
			this.amount = newAmount;
		}

		// Token: 0x1700085F RID: 2143
		// (get) Token: 0x06002947 RID: 10567 RVA: 0x000B2EAF File Offset: 0x000B10AF
		[Obsolete("Please use FindItemAsset instead for GUID support")]
		public ushort id
		{
			get
			{
				return this._itemRef.LegacyId;
			}
		}

		// Token: 0x040014B1 RID: 5297
		private CachingBcAssetRef _itemRef;

		// Token: 0x040014B2 RID: 5298
		internal bool _isCritical;

		// Token: 0x040014BA RID: 5306
		public int amount;
	}
}
