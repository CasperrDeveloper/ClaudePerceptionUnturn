﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000591 RID: 1425
	public class BarricadeDrop
	{
		// Token: 0x1400009E RID: 158
		// (add) Token: 0x06002F3A RID: 12090 RVA: 0x000D9F88 File Offset: 0x000D8188
		// (remove) Token: 0x06002F3B RID: 12091 RVA: 0x000D9FBC File Offset: 0x000D81BC
		public static event BarricadeDrop.SalvageRequestHandler OnSalvageRequested_Global;

		// Token: 0x1700097E RID: 2430
		// (get) Token: 0x06002F3C RID: 12092 RVA: 0x000D9FEF File Offset: 0x000D81EF
		public Transform model
		{
			get
			{
				return this._model;
			}
		}

		// Token: 0x1700097F RID: 2431
		// (get) Token: 0x06002F3D RID: 12093 RVA: 0x000D9FF7 File Offset: 0x000D81F7
		public Interactable interactable
		{
			get
			{
				return this._interactable;
			}
		}

		// Token: 0x17000980 RID: 2432
		// (get) Token: 0x06002F3E RID: 12094 RVA: 0x000D9FFF File Offset: 0x000D81FF
		public uint instanceID
		{
			get
			{
				if (this.serversideData == null)
				{
					return 0U;
				}
				return this.serversideData.instanceID;
			}
		}

		// Token: 0x17000981 RID: 2433
		// (get) Token: 0x06002F3F RID: 12095 RVA: 0x000DA016 File Offset: 0x000D8216
		// (set) Token: 0x06002F40 RID: 12096 RVA: 0x000DA01E File Offset: 0x000D821E
		public ItemBarricadeAsset asset { get; protected set; }

		// Token: 0x17000982 RID: 2434
		// (get) Token: 0x06002F41 RID: 12097 RVA: 0x000DA027 File Offset: 0x000D8227
		public bool IsChildOfVehicle
		{
			get
			{
				return this._model != null && this._model.parent != null && this._model.parent.CompareTag("Vehicle");
			}
		}

		// Token: 0x06002F42 RID: 12098 RVA: 0x000DA061 File Offset: 0x000D8261
		public BarricadeData GetServersideData()
		{
			return this.serversideData;
		}

		// Token: 0x06002F43 RID: 12099 RVA: 0x000DA069 File Offset: 0x000D8269
		public NetId GetNetId()
		{
			return this._netId;
		}

		// Token: 0x06002F44 RID: 12100 RVA: 0x000DA074 File Offset: 0x000D8274
		internal void AssignNetId(NetId netId)
		{
			this._netId = netId;
			NetIdRegistry.Assign(netId, this);
			NetIdRegistry.AssignTransform(netId + 1U, this._model);
			if (this._interactable != null)
			{
				this._interactable.AssignNetId(netId + 2U);
			}
		}

		// Token: 0x06002F45 RID: 12101 RVA: 0x000DA0C4 File Offset: 0x000D82C4
		internal void ReleaseNetId()
		{
			if (this._interactable != null)
			{
				this._interactable.ReleaseNetId();
			}
			NetIdRegistry.ReleaseTransform(this._netId + 1U, this._model);
			NetIdRegistry.Release(this._netId);
			this._netId.Clear();
		}

		// Token: 0x06002F46 RID: 12102 RVA: 0x000DA118 File Offset: 0x000D8318
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, deferMode = ENetInvocationDeferMode.Queue)]
		public void ReceiveHealth(byte hp)
		{
			Interactable2HP component = this.model.GetComponent<Interactable2HP>();
			if (component != null)
			{
				component.hp = hp;
			}
		}

		// Token: 0x06002F47 RID: 12103 RVA: 0x000DA144 File Offset: 0x000D8344
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, deferMode = ENetInvocationDeferMode.Queue)]
		public void ReceiveTransform(in ClientInvocationContext context, byte old_x, byte old_y, ushort oldPlant, Vector3 point, Quaternion rotation)
		{
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(old_x, old_y, oldPlant, out barricadeRegion))
			{
				return;
			}
			if (!Provider.isServer && !barricadeRegion.isNetworked)
			{
				return;
			}
			this.model.position = point;
			this.model.rotation = rotation;
			if (oldPlant == 65535)
			{
				byte b;
				byte b2;
				if (Regions.tryGetCoordinate(point, out b, out b2) && (old_x != b || old_y != b2))
				{
					BarricadeRegion barricadeRegion2 = BarricadeManager.regions[(int)b, (int)b2];
					barricadeRegion.drops.Remove(this);
					if (barricadeRegion2.isNetworked || Provider.isServer)
					{
						barricadeRegion2.drops.Add(this);
					}
					else if (!Provider.isServer)
					{
						this.CustomDestroy();
					}
					if (Provider.isServer)
					{
						barricadeRegion.barricades.Remove(this.serversideData);
						barricadeRegion2.barricades.Add(this.serversideData);
					}
				}
				if (Provider.isServer)
				{
					this.serversideData.point = point;
					this.serversideData.rotation = rotation;
					return;
				}
			}
			else if (Provider.isServer)
			{
				this.serversideData.point = this.model.localPosition;
				this.serversideData.rotation = this.model.localRotation;
			}
		}

		/// <summary>
		/// Not using rate limit attribute because this is potentially called for hundreds of barricades at once,
		/// and only admins will actually be allowed to apply the transform.
		/// </summary>
		// Token: 0x06002F48 RID: 12104 RVA: 0x000DA270 File Offset: 0x000D8470
		[SteamCall(ESteamCallValidation.SERVERSIDE)]
		public void ReceiveTransformRequest(in ServerInvocationContext context, Vector3 point, Quaternion rotation)
		{
			Player player = context.GetPlayer();
			if (player == null)
			{
				return;
			}
			if (player.life.isDead)
			{
				return;
			}
			if (!player.look.canUseWorkzone)
			{
				return;
			}
			if (this._model == null)
			{
				return;
			}
			byte x;
			byte y;
			ushort maxValue;
			if (this._model.parent != null && this._model.parent.CompareTag("Vehicle"))
			{
				BarricadeRegion barricadeRegion;
				if (!BarricadeManager.tryGetPlant(this._model.parent, out x, out y, out maxValue, out barricadeRegion))
				{
					return;
				}
			}
			else
			{
				if (!Regions.tryGetCoordinate(this._model.position, out x, out y))
				{
					return;
				}
				maxValue = ushort.MaxValue;
			}
			if (BarricadeManager.onTransformRequested != null)
			{
				Vector3 eulerAngles = rotation.eulerAngles;
				byte b = MeasurementTool.angleToByte(eulerAngles.x);
				byte b2 = MeasurementTool.angleToByte(eulerAngles.y);
				byte b3 = MeasurementTool.angleToByte(eulerAngles.z);
				byte b4 = b;
				byte b5 = b2;
				byte b6 = b3;
				bool flag = true;
				BarricadeManager.onTransformRequested(player.channel.owner.playerID.steamID, x, y, maxValue, this.instanceID, ref point, ref b4, ref b5, ref b6, ref flag);
				if (b4 != b || b5 != b2 || b6 != b3)
				{
					float x2 = MeasurementTool.byteToAngle(b4);
					float y2 = MeasurementTool.byteToAngle(b5);
					float z = MeasurementTool.byteToAngle(b6);
					rotation = Quaternion.Euler(x2, y2, z);
				}
				if (!flag)
				{
					point = this.model.position;
					rotation = this.model.rotation;
				}
			}
			BarricadeManager.InternalSetBarricadeTransform(x, y, maxValue, this, point, rotation);
		}

		// Token: 0x06002F49 RID: 12105 RVA: 0x000DA3F4 File Offset: 0x000D85F4
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, deferMode = ENetInvocationDeferMode.Queue)]
		public void ReceiveOwnerAndGroup(ulong newOwner, ulong newGroup)
		{
			BarricadeDrop.workingSalvageArray.Clear();
			this.model.GetComponentsInChildren<Interactable2SalvageBarricade>(BarricadeDrop.workingSalvageArray);
			foreach (Interactable2SalvageBarricade interactable2SalvageBarricade in BarricadeDrop.workingSalvageArray)
			{
				interactable2SalvageBarricade.owner = newOwner;
				interactable2SalvageBarricade.group = newGroup;
			}
		}

		/// <summary>
		/// Only used by plugins.
		/// </summary>
		// Token: 0x06002F4A RID: 12106 RVA: 0x000DA468 File Offset: 0x000D8668
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, deferMode = ENetInvocationDeferMode.Queue)]
		public void ReceiveUpdateState(byte[] newState)
		{
			if (this.asset == null || this.interactable == null)
			{
				UnturnedLog.warn("tellBarricadeUpdateState was missing asset/interactable");
				return;
			}
			this.interactable.updateState(this.asset, newState);
		}

		// Token: 0x06002F4B RID: 12107 RVA: 0x000DA4A0 File Offset: 0x000D86A0
		[SteamCall(ESteamCallValidation.SERVERSIDE, ratelimitHz = 10)]
		public void ReceiveSalvageRequest(in ServerInvocationContext context)
		{
			Player player = context.GetPlayer();
			if (player == null)
			{
				return;
			}
			if (player.life.isDead)
			{
				return;
			}
			if ((this._model.position - player.transform.position).sqrMagnitude > 400f)
			{
				return;
			}
			if (!this.asset.shouldBypassPickupOwnership && !OwnershipTool.checkToggle(player.channel.owner.playerID.steamID, this.serversideData.owner, player.quests.groupID, this.serversideData.group))
			{
				return;
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(this._model, out x, out y, out plant, out barricadeRegion))
			{
				return;
			}
			bool flag = true;
			if (BarricadeManager.onSalvageBarricadeRequested != null)
			{
				ushort index = (ushort)barricadeRegion.drops.IndexOf(this);
				BarricadeManager.onSalvageBarricadeRequested(player.channel.owner.playerID.steamID, x, y, plant, index, ref flag);
			}
			BarricadeDrop.SalvageRequestHandler onSalvageRequested_Global = BarricadeDrop.OnSalvageRequested_Global;
			if (onSalvageRequested_Global != null)
			{
				onSalvageRequested_Global(this, context.GetCallingPlayer(), ref flag);
			}
			if (!flag)
			{
				return;
			}
			if (this.asset.isUnpickupable)
			{
				return;
			}
			if (this.serversideData.barricade.health >= this.asset.health)
			{
				this.asset.GrantSalvageItems(player, true);
			}
			else if (this.asset.isSalvageable)
			{
				this.asset.GrantSalvageItems(player, false);
			}
			BarricadeManager.destroyBarricade(this, x, y, plant);
		}

		// Token: 0x06002F4C RID: 12108 RVA: 0x000DA614 File Offset: 0x000D8814
		internal void CustomDestroy()
		{
			try
			{
				BarricadeDrop.destroyEventComponents.Clear();
				this.model.GetComponents<IManualOnDestroy>(BarricadeDrop.destroyEventComponents);
				foreach (IManualOnDestroy manualOnDestroy in BarricadeDrop.destroyEventComponents)
				{
					manualOnDestroy.ManualOnDestroy();
				}
				this.ReleaseNetId();
				this.model.position = Vector3.zero;
				BarricadeManager.instance.DestroyOrReleaseBarricade(this.asset, this.model.gameObject);
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, "Exception destroying barricade {0}:", new object[]
				{
					this.asset
				});
			}
		}

		/// <summary>
		/// See BarricadeRegion.FindBarricadeByRootFast comment.
		/// </summary>
		// Token: 0x06002F4D RID: 12109 RVA: 0x000DA6D8 File Offset: 0x000D88D8
		internal static BarricadeDrop FindByRootFast(Transform rootTransform)
		{
			return rootTransform.GetComponent<BarricadeRefComponent>().tempNotSureIfBarricadeShouldBeAComponentYet;
		}

		/// <summary>
		/// For code which does not know whether transform exists and/or even is a barricade.
		/// See BarricadeRegion.FindBarricadeByRootFast comment.
		/// </summary>
		// Token: 0x06002F4E RID: 12110 RVA: 0x000DA6E5 File Offset: 0x000D88E5
		internal static BarricadeDrop FindByTransformFastMaybeNull(Transform transform)
		{
			if (transform == null)
			{
				return null;
			}
			BarricadeRefComponent component = transform.root.GetComponent<BarricadeRefComponent>();
			if (component == null)
			{
				return null;
			}
			return component.tempNotSureIfBarricadeShouldBeAComponentYet;
		}

		// Token: 0x06002F4F RID: 12111 RVA: 0x000DA702 File Offset: 0x000D8902
		internal BarricadeDrop(Transform newModel, Interactable newInteractable, ItemBarricadeAsset newAsset)
		{
			this._model = newModel;
			this._interactable = newInteractable;
			this.asset = newAsset;
		}

		// Token: 0x06002F50 RID: 12112 RVA: 0x000DA71F File Offset: 0x000D891F
		[Obsolete]
		public BarricadeDrop(Transform newModel, Interactable newInteractable, uint newInstanceID, ItemBarricadeAsset newAsset) : this(newModel, newInteractable, newAsset)
		{
		}

		// Token: 0x04001946 RID: 6470
		private Transform _model;

		// Token: 0x04001947 RID: 6471
		private Interactable _interactable;

		// Token: 0x04001949 RID: 6473
		internal static readonly ClientInstanceMethod<byte> SendHealth = ClientInstanceMethod<byte>.Get(typeof(BarricadeDrop), "ReceiveHealth");

		// Token: 0x0400194A RID: 6474
		internal static readonly ClientInstanceMethod<byte, byte, ushort, Vector3, Quaternion> SendTransform = ClientInstanceMethod<byte, byte, ushort, Vector3, Quaternion>.Get(typeof(BarricadeDrop), "ReceiveTransform");

		// Token: 0x0400194B RID: 6475
		internal static readonly ServerInstanceMethod<Vector3, Quaternion> SendTransformRequest = ServerInstanceMethod<Vector3, Quaternion>.Get(typeof(BarricadeDrop), "ReceiveTransformRequest");

		// Token: 0x0400194C RID: 6476
		private static List<Interactable2SalvageBarricade> workingSalvageArray = new List<Interactable2SalvageBarricade>();

		// Token: 0x0400194D RID: 6477
		internal static readonly ClientInstanceMethod<ulong, ulong> SendOwnerAndGroup = ClientInstanceMethod<ulong, ulong>.Get(typeof(BarricadeDrop), "ReceiveOwnerAndGroup");

		// Token: 0x0400194E RID: 6478
		internal static readonly ClientInstanceMethod<byte[]> SendUpdateState = ClientInstanceMethod<byte[]>.Get(typeof(BarricadeDrop), "ReceiveUpdateState");

		// Token: 0x0400194F RID: 6479
		internal static readonly ServerInstanceMethod SendSalvageRequest = ServerInstanceMethod.Get(typeof(BarricadeDrop), "ReceiveSalvageRequest");

		// Token: 0x04001950 RID: 6480
		private static List<IManualOnDestroy> destroyEventComponents = new List<IManualOnDestroy>();

		// Token: 0x04001951 RID: 6481
		private NetId _netId;

		// Token: 0x04001952 RID: 6482
		internal BarricadeData serversideData;

		// Token: 0x02000A21 RID: 2593
		// (Invoke) Token: 0x06005453 RID: 21587
		public delegate void SalvageRequestHandler(BarricadeDrop barricade, SteamPlayer instigatorClient, ref bool shouldAllow);
	}
}
