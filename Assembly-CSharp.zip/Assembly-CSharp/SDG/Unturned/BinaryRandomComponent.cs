﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace SDG.Unturned
{
	/// <summary>
	/// Single percentage randomness with two outcomes.
	/// </summary>
	// Token: 0x02000623 RID: 1571
	[AddComponentMenu("Unturned/Binary Random")]
	public class BinaryRandomComponent : MonoBehaviour
	{
		// Token: 0x060035C0 RID: 13760 RVA: 0x000FFA8E File Offset: 0x000FDC8E
		public void TriggerDefault()
		{
			this.TriggerWithProbability(this.DefaultProbability);
		}

		// Token: 0x060035C1 RID: 13761 RVA: 0x000FFA9C File Offset: 0x000FDC9C
		public void TriggerWithProbability(float Probability)
		{
			if (this.AuthorityOnly && !Provider.isServer)
			{
				return;
			}
			if (UnityEngine.Random.value < Probability)
			{
				this.OnTrue.Invoke();
				return;
			}
			this.OnFalse.Invoke();
		}

		/// <summary>
		/// If true the event will only be invoked in offline mode and on the server.
		/// </summary>
		// Token: 0x04001CBB RID: 7355
		public bool AuthorityOnly;

		/// <summary>
		/// Percentage chance of event occurring.
		/// </summary>
		// Token: 0x04001CBC RID: 7356
		[Range(0f, 1f)]
		public float DefaultProbability;

		/// <summary>
		/// Invoked when random event occurs.
		/// </summary>
		// Token: 0x04001CBD RID: 7357
		public UnityEvent OnTrue;

		/// <summary>
		/// Invoked when random event does NOT occur.
		/// </summary>
		// Token: 0x04001CBE RID: 7358
		public UnityEvent OnFalse;
	}
}
