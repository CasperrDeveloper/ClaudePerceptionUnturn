﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000655 RID: 1621
	internal class BoundsHistory
	{
		// Token: 0x170009EC RID: 2540
		// (get) Token: 0x06003659 RID: 13913 RVA: 0x00101E44 File Offset: 0x00100044
		// (set) Token: 0x0600365A RID: 13914 RVA: 0x00101E4C File Offset: 0x0010004C
		public float Expansion
		{
			get
			{
				return this.expansion;
			}
			set
			{
				this.expansion = value;
			}
		}

		// Token: 0x0600365B RID: 13915 RVA: 0x00101E55 File Offset: 0x00100055
		public BoundsHistory()
		{
			this.buffer = new Bounds[50];
			this.writeIndex = 0;
			this.writeCount = 0;
		}

		// Token: 0x0600365C RID: 13916 RVA: 0x00101E78 File Offset: 0x00100078
		public void Clear()
		{
			this.writeIndex = 0;
			this.writeCount = 0;
		}

		// Token: 0x0600365D RID: 13917 RVA: 0x00101E88 File Offset: 0x00100088
		public void AddBounds(Bounds bounds)
		{
			this.buffer[this.writeIndex] = bounds;
			this.writeIndex = (this.writeIndex + 1) % 50;
			this.writeCount = Mathf.Min(this.writeCount + 1, 50);
		}

		// Token: 0x0600365E RID: 13918 RVA: 0x00101EC2 File Offset: 0x001000C2
		public void AddCharacterControllerBounds(CharacterController characterController)
		{
			this.AddBounds(this.CalculateCharacterControllerBounds(characterController));
		}

		/// <summary>
		/// Tests whether current or recent history contains point.
		/// </summary>
		// Token: 0x0600365F RID: 13919 RVA: 0x00101ED4 File Offset: 0x001000D4
		public bool ContainsPoint(CharacterController characterController, Vector3 point)
		{
			Bounds bounds = this.CalculateCharacterControllerBounds(characterController);
			if (bounds.Contains(point))
			{
				return true;
			}
			if (this.writeCount < 1)
			{
				return false;
			}
			Bounds bounds2 = bounds;
			int num = this.writeIndex;
			int num2 = 0;
			for (;;)
			{
				Bounds bounds3 = this.buffer[num];
				bounds2.Encapsulate(bounds3);
				if (bounds2.Contains(point))
				{
					break;
				}
				bounds2 = bounds3;
				num--;
				if (num < 0)
				{
					num = 49;
				}
				num2++;
				if (num2 >= this.writeCount)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06003660 RID: 13920 RVA: 0x00101F4C File Offset: 0x0010014C
		public Bounds CalculateCharacterControllerBounds(CharacterController characterController)
		{
			Vector3 position;
			Quaternion rotation;
			characterController.transform.GetPositionAndRotation(out position, out rotation);
			return this.CalculateCharacterControllerBounds(position, rotation, characterController.center, characterController.radius, characterController.height);
		}

		// Token: 0x06003661 RID: 13921 RVA: 0x00101F84 File Offset: 0x00100184
		public Bounds CalculateCharacterControllerBounds(Vector3 position, Quaternion rotation, Vector3 center, float radius, float height)
		{
			float num = Mathf.Max(0f, height * 0.5f - radius);
			Vector3 vector = position + rotation * (center + new Vector3(0f, -num, 0f));
			Vector3 vector2 = position + rotation * (center + new Vector3(0f, num, 0f));
			float num2 = (this.expansion + radius) * 2f;
			Vector3 center2 = (vector + vector2) * 0.5f;
			Vector3 size = (vector2 - vector).GetAbs() + new Vector3(num2, num2, num2);
			return new Bounds(center2, size);
		}

		// Token: 0x06003662 RID: 13922 RVA: 0x00102034 File Offset: 0x00100234
		internal void DrawGizmos()
		{
			if (this.writeCount < 1)
			{
				return;
			}
			RuntimeGizmos runtimeGizmos = RuntimeGizmos.Get();
			Bounds bounds = default(Bounds);
			int num = this.writeIndex;
			int num2 = 0;
			do
			{
				Bounds bounds2 = this.buffer[num];
				runtimeGizmos.Box(bounds2.center, bounds2.size, Color.red, 0f, EGizmoLayer.World);
				if (num2 > 0)
				{
					bounds.Encapsulate(bounds2);
					runtimeGizmos.Box(bounds.center, bounds.size, Color.yellow, 0f, EGizmoLayer.World);
				}
				bounds = bounds2;
				num--;
				if (num < 0)
				{
					num = 49;
				}
				num2++;
			}
			while (num2 < this.writeCount);
		}

		// Token: 0x04001D99 RID: 7577
		private Bounds[] buffer;

		// Token: 0x04001D9A RID: 7578
		private int writeIndex;

		// Token: 0x04001D9B RID: 7579
		private int writeCount;

		// Token: 0x04001D9C RID: 7580
		private float expansion;

		/// <summary>
		/// One second history at 50 tickrate.
		/// </summary>
		// Token: 0x04001D9D RID: 7581
		private const int CAPACITY = 50;
	}
}
