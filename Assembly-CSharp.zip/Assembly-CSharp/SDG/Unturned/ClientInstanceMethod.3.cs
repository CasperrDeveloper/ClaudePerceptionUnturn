﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;

namespace SDG.Unturned
{
	// Token: 0x0200022E RID: 558
	public sealed class ClientInstanceMethod<T1, T2> : ClientInstanceMethodBase
	{
		// Token: 0x06001163 RID: 4451 RVA: 0x0003F8D2 File Offset: 0x0003DAD2
		public static ClientInstanceMethod<T1, T2> Get(Type declaringType, string methodName)
		{
			return ClientMethodHandle.GetInternal<ClientInstanceMethod<T1, T2>, ClientInstanceMethod<T1, T2>.WriteDelegate>(declaringType, methodName, (ClientMethodInfo clientMethodInfo, ClientInstanceMethod<T1, T2>.WriteDelegate generatedWrite) => new ClientInstanceMethod<T1, T2>(clientMethodInfo, generatedWrite));
		}

		// Token: 0x06001164 RID: 4452 RVA: 0x0003F8FC File Offset: 0x0003DAFC
		public void Invoke(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x06001165 RID: 4453 RVA: 0x0003F92C File Offset: 0x0003DB2C
		public void Invoke(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001166 RID: 4454 RVA: 0x0003F95C File Offset: 0x0003DB5C
		[Obsolete("Replaced by List overload")]
		public void Invoke(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, T1 arg1, T2 arg2)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.Invoke(netId, reliability, list, arg1, arg2);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001167 RID: 4455 RVA: 0x0003F990 File Offset: 0x0003DB90
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, T1 arg1, T2 arg2)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg1, arg2);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001168 RID: 4456 RVA: 0x0003F9C0 File Offset: 0x0003DBC0
		[Obsolete("Replaced by List overload")]
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, T1 arg1, T2 arg2)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.InvokeAndLoopback(netId, reliability, list, arg1, arg2);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x0003F9F4 File Offset: 0x0003DBF4
		private ClientInstanceMethod(ClientMethodInfo clientMethodInfo, ClientInstanceMethod<T1, T2>.WriteDelegate generatedWrite) : base(clientMethodInfo)
		{
			this.generatedWrite = generatedWrite;
		}

		// Token: 0x040005CA RID: 1482
		private ClientInstanceMethod<T1, T2>.WriteDelegate generatedWrite;

		// Token: 0x0200092E RID: 2350
		// (Invoke) Token: 0x0600513E RID: 20798
		private delegate void WriteDelegate(NetPakWriter writer, T1 arg1, T2 arg2);
	}
}
