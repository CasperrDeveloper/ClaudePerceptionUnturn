﻿using System;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200060D RID: 1549
	public class Character
	{
		// Token: 0x170009E3 RID: 2531
		// (get) Token: 0x0600352C RID: 13612 RVA: 0x000FB76E File Offset: 0x000F996E
		// (set) Token: 0x0600352D RID: 13613 RVA: 0x000FB776 File Offset: 0x000F9976
		public Color BeardColor { get; set; }

		// Token: 0x0600352E RID: 13614 RVA: 0x000FB780 File Offset: 0x000F9980
		public void applyHero()
		{
			this.shirt = 0;
			this.pants = 0;
			this.hat = 0;
			this.backpack = 0;
			this.vest = 0;
			this.mask = 0;
			this.glasses = 0;
			this.primaryItem = 0;
			this.primaryState = new byte[0];
			this.secondaryItem = 0;
			this.secondaryState = new byte[0];
			for (int i = 0; i < PlayerInventory.SKILLSETS_HERO[(int)((byte)this.skillset)].Length; i++)
			{
				ushort id = PlayerInventory.SKILLSETS_HERO[(int)((byte)this.skillset)][i];
				ItemAsset itemAsset = Assets.find(EAssetType.ITEM, id) as ItemAsset;
				if (itemAsset != null)
				{
					switch (itemAsset.type)
					{
					case EItemType.HAT:
						this.hat = id;
						break;
					case EItemType.PANTS:
						this.pants = id;
						break;
					case EItemType.SHIRT:
						this.shirt = id;
						break;
					case EItemType.MASK:
						this.mask = id;
						break;
					case EItemType.BACKPACK:
						this.backpack = id;
						break;
					case EItemType.VEST:
						this.vest = id;
						break;
					case EItemType.GLASSES:
						this.glasses = id;
						break;
					case EItemType.GUN:
					case EItemType.MELEE:
						if (itemAsset.slot == ESlotType.PRIMARY)
						{
							this.primaryItem = id;
							this.primaryState = itemAsset.getState(EItemOrigin.ADMIN);
						}
						else
						{
							this.secondaryItem = id;
							this.secondaryState = itemAsset.getState(EItemOrigin.ADMIN);
						}
						break;
					}
				}
			}
		}

		// Token: 0x0600352F RID: 13615 RVA: 0x000FB8EC File Offset: 0x000F9AEC
		public Character()
		{
			this.face = (byte)UnityEngine.Random.Range(0, (int)Customization.FACES_FREE);
			this.hair = (byte)UnityEngine.Random.Range(0, (int)Customization.HAIRS_FREE);
			this.beard = 0;
			this.skin = Customization.SKINS[UnityEngine.Random.Range(0, Customization.SKINS.Length)];
			this.color = Customization.COLORS[UnityEngine.Random.Range(0, Customization.COLORS.Length)];
			this.markerColor = Customization.MARKER_COLORS[UnityEngine.Random.Range(0, Customization.MARKER_COLORS.Length)];
			this.BeardColor = this.color;
			this.hand = false;
			this.name = Provider.clientName;
			this.nick = Provider.clientName;
			this.group = CSteamID.Nil;
			this.skillset = (EPlayerSkillset)UnityEngine.Random.Range(1, (int)Customization.SKILLSETS);
			this.applyHero();
		}

		// Token: 0x06003530 RID: 13616 RVA: 0x000FB9CC File Offset: 0x000F9BCC
		public Character(ushort newShirt, ushort newPants, ushort newHat, ushort newBackpack, ushort newVest, ushort newMask, ushort newGlasses, ulong newPackageShirt, ulong newPackagePants, ulong newPackageHat, ulong newPackageBackpack, ulong newPackageVest, ulong newPackageMask, ulong newPackageGlasses, ushort newPrimaryItem, byte[] newPrimaryState, ushort newSecondaryItem, byte[] newSecondaryState, byte newFace, byte newHair, byte newBeard, Color newSkin, Color newColor, Color newMarkerColor, Color newBeardColor, bool newHand, string newName, string newNick, CSteamID newGroup, EPlayerSkillset newSkillset)
		{
			this.shirt = newShirt;
			this.pants = newPants;
			this.hat = newHat;
			this.backpack = newBackpack;
			this.vest = newVest;
			this.mask = newMask;
			this.glasses = newGlasses;
			this.packageShirt = newPackageShirt;
			this.packagePants = newPackagePants;
			this.packageHat = newPackageHat;
			this.packageBackpack = newPackageBackpack;
			this.packageVest = newPackageVest;
			this.packageMask = newPackageMask;
			this.packageGlasses = newPackageGlasses;
			this.primaryItem = newPrimaryItem;
			this.secondaryItem = newSecondaryItem;
			this.primaryState = newPrimaryState;
			this.secondaryState = newSecondaryState;
			this.face = newFace;
			this.hair = newHair;
			this.beard = newBeard;
			this.skin = newSkin;
			this.color = newColor;
			this.markerColor = newMarkerColor;
			this.BeardColor = newBeardColor;
			this.hand = newHand;
			this.name = newName;
			this.nick = newNick;
			this.group = newGroup;
			this.skillset = newSkillset;
		}

		// Token: 0x04001C41 RID: 7233
		public ushort shirt;

		// Token: 0x04001C42 RID: 7234
		public ushort pants;

		// Token: 0x04001C43 RID: 7235
		public ushort hat;

		// Token: 0x04001C44 RID: 7236
		public ushort backpack;

		// Token: 0x04001C45 RID: 7237
		public ushort vest;

		// Token: 0x04001C46 RID: 7238
		public ushort mask;

		// Token: 0x04001C47 RID: 7239
		public ushort glasses;

		// Token: 0x04001C48 RID: 7240
		public ulong packageShirt;

		// Token: 0x04001C49 RID: 7241
		public ulong packagePants;

		// Token: 0x04001C4A RID: 7242
		public ulong packageHat;

		// Token: 0x04001C4B RID: 7243
		public ulong packageBackpack;

		// Token: 0x04001C4C RID: 7244
		public ulong packageVest;

		// Token: 0x04001C4D RID: 7245
		public ulong packageMask;

		// Token: 0x04001C4E RID: 7246
		public ulong packageGlasses;

		// Token: 0x04001C4F RID: 7247
		public ushort primaryItem;

		// Token: 0x04001C50 RID: 7248
		public byte[] primaryState;

		// Token: 0x04001C51 RID: 7249
		public ushort secondaryItem;

		// Token: 0x04001C52 RID: 7250
		public byte[] secondaryState;

		// Token: 0x04001C53 RID: 7251
		public byte face;

		// Token: 0x04001C54 RID: 7252
		public byte hair;

		// Token: 0x04001C55 RID: 7253
		public byte beard;

		// Token: 0x04001C56 RID: 7254
		public Color skin;

		// Token: 0x04001C57 RID: 7255
		public Color color;

		// Token: 0x04001C58 RID: 7256
		public Color markerColor;

		// Token: 0x04001C5A RID: 7258
		public bool hand;

		// Token: 0x04001C5B RID: 7259
		public string name;

		// Token: 0x04001C5C RID: 7260
		public string nick;

		// Token: 0x04001C5D RID: 7261
		public CSteamID group;

		// Token: 0x04001C5E RID: 7262
		public EPlayerSkillset skillset;
	}
}
