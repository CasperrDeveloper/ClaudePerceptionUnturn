﻿using System;
using SDG.NetPak;
using SDG.NetTransport;

namespace SDG.Unturned
{
	// Token: 0x0200027B RID: 635
	internal static class ClientMessageHandler_PingRequest
	{
		// Token: 0x06001300 RID: 4864 RVA: 0x000451BD File Offset: 0x000433BD
		internal static void ReadMessage(NetPakReader reader)
		{
			NetMessages.SendMessageToServer(EServerMessage.PingResponse, ENetReliability.Unreliable, delegate(NetPakWriter writer)
			{
			});
		}
	}
}
