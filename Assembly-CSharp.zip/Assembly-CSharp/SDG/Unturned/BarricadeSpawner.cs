﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	/// <summary>
	/// Allows Unity events to spawn barricades.
	/// </summary>
	// Token: 0x02000622 RID: 1570
	[AddComponentMenu("Unturned/Barricade Spawner")]
	public class BarricadeSpawner : MonoBehaviour
	{
		// Token: 0x060035BC RID: 13756 RVA: 0x000FF8DC File Offset: 0x000FDADC
		public void SpawnDefault()
		{
			this.Spawn(this.DefaultAsset);
		}

		// Token: 0x060035BD RID: 13757 RVA: 0x000FF8EC File Offset: 0x000FDAEC
		public void Spawn(string assetId)
		{
			if (!Provider.isServer)
			{
				return;
			}
			if (EffectManager.isInstantiatingEffectForPreload)
			{
				return;
			}
			CachingBcAssetRef cachingBcAssetRef;
			if (!CachingBcAssetRef.TryParse(assetId, EAssetType.ITEM, out cachingBcAssetRef))
			{
				UnturnedLog.warn("{0} unable to parse asset ID \"{1}\"", new object[]
				{
					base.transform.GetSceneHierarchyPath(),
					assetId
				});
				return;
			}
			Asset asset = cachingBcAssetRef.Get();
			if (asset == null)
			{
				UnturnedLog.warn("{0} unable to find asset \"{1}\"", new object[]
				{
					base.transform.GetSceneHierarchyPath(),
					assetId
				});
				return;
			}
			SpawnAsset spawnAsset = asset as SpawnAsset;
			if (spawnAsset != null)
			{
				asset = SpawnTableTool.Resolve(spawnAsset, EAssetType.ITEM, new Func<string>(this.OnGetSpawnErrorContext));
				if (asset == null)
				{
					return;
				}
			}
			ItemBarricadeAsset itemBarricadeAsset = asset as ItemBarricadeAsset;
			if (itemBarricadeAsset == null)
			{
				UnturnedLog.warn(string.Concat(new string[]
				{
					base.transform.GetSceneHierarchyPath(),
					" tried to spawn barricade but asset (",
					asset.FriendlyName,
					") is ",
					asset.GetTypeFriendlyName()
				}));
				return;
			}
			ulong owner = 0UL;
			ulong group = 0UL;
			if (this.InheritOwnership)
			{
				DamageTool.TryFindOwnership(base.transform, out owner, out group);
			}
			Vector3 vector;
			Quaternion quaternion;
			base.transform.GetPositionAndRotation(out vector, out quaternion);
			Barricade barricade = new Barricade(itemBarricadeAsset);
			if (this.ShouldAttachToVehicle)
			{
				VehicleBarricadeRegion vehicleBarricadeRegion = BarricadeManager.FindVehicleRegionByTransform(base.transform.root);
				if (vehicleBarricadeRegion != null)
				{
					vector = vehicleBarricadeRegion.parent.InverseTransformPoint(vector);
					quaternion = vehicleBarricadeRegion.parent.InverseTransformRotation(quaternion);
					BarricadeManager.dropPlantedBarricade(vehicleBarricadeRegion.parent, barricade, vector, quaternion, owner, group);
					return;
				}
			}
			BarricadeManager.dropNonPlantedBarricade(barricade, vector, quaternion, owner, group);
		}

		// Token: 0x060035BE RID: 13758 RVA: 0x000FFA6F File Offset: 0x000FDC6F
		private string OnGetSpawnErrorContext()
		{
			return "barricade spawner " + base.transform.GetSceneHierarchyPath();
		}

		// Token: 0x04001CB8 RID: 7352
		[Tooltip("ID or GUID of barricade asset (or spawn table) to spawn when SpawnDefault is invoked.")]
		public string DefaultAsset;

		// Token: 0x04001CB9 RID: 7353
		[Tooltip("Finds ownership of BarricadeSpawner (e.g., parent barricade) and assigns to spawned barricade.")]
		public bool InheritOwnership;

		// Token: 0x04001CBA RID: 7354
		[Tooltip("If true and a vehicle exists in parent hierarchy, the spawned barricade will be attached to the vehicle.")]
		public bool ShouldAttachToVehicle;
	}
}
