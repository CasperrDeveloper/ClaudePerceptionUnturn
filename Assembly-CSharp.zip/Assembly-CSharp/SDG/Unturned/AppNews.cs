﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000842 RID: 2114
	public class AppNews
	{
		// Token: 0x17000CDB RID: 3291
		// (get) Token: 0x060048F6 RID: 18678 RVA: 0x0018CC0D File Offset: 0x0018AE0D
		// (set) Token: 0x060048F7 RID: 18679 RVA: 0x0018CC15 File Offset: 0x0018AE15
		public uint AppID { get; set; }

		// Token: 0x17000CDC RID: 3292
		// (get) Token: 0x060048F8 RID: 18680 RVA: 0x0018CC1E File Offset: 0x0018AE1E
		// (set) Token: 0x060048F9 RID: 18681 RVA: 0x0018CC26 File Offset: 0x0018AE26
		public NewsItem[] NewsItems { get; set; }
	}
}
