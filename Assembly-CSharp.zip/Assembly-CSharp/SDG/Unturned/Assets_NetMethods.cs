﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x020001DE RID: 478
	[NetInvokableGeneratedClass(typeof(Assets))]
	public static class Assets_NetMethods
	{
		// Token: 0x06000E81 RID: 3713 RVA: 0x00035FB4 File Offset: 0x000341B4
		[NetInvokableGeneratedMethod("ReceiveKickForInvalidGuid", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveKickForInvalidGuid_Read(in ClientInvocationContext context)
		{
			Guid guid;
			context.reader.ReadGuid(out guid);
			Assets.ReceiveKickForInvalidGuid(guid);
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x00035FD5 File Offset: 0x000341D5
		[NetInvokableGeneratedMethod("ReceiveKickForInvalidGuid", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveKickForInvalidGuid_Write(NetPakWriter writer, Guid guid)
		{
			writer.WriteGuid(guid);
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x00035FE0 File Offset: 0x000341E0
		[NetInvokableGeneratedMethod("ReceiveKickForHashMismatch", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveKickForHashMismatch_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			Guid guid;
			reader.ReadGuid(out guid);
			string serverName;
			reader.ReadString(out serverName, 11);
			string serverFriendlyName;
			reader.ReadString(out serverFriendlyName, 11);
			byte b;
			reader.ReadUInt8(out b);
			byte[] array = new byte[(int)b];
			reader.ReadBytes(array);
			string serverAssetBundleNameWithoutExtension;
			reader.ReadString(out serverAssetBundleNameWithoutExtension, 11);
			string serverAssetOrigin;
			reader.ReadString(out serverAssetOrigin, 11);
			Assets.ReceiveKickForHashMismatch(guid, serverName, serverFriendlyName, array, serverAssetBundleNameWithoutExtension, serverAssetOrigin);
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x00036050 File Offset: 0x00034250
		[NetInvokableGeneratedMethod("ReceiveKickForHashMismatch", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveKickForHashMismatch_Write(NetPakWriter writer, Guid guid, string serverName, string serverFriendlyName, byte[] serverHash, string serverAssetBundleNameWithoutExtension, string serverAssetOrigin)
		{
			writer.WriteGuid(guid);
			writer.WriteString(serverName, 11);
			writer.WriteString(serverFriendlyName, 11);
			byte b = (byte)serverHash.Length;
			writer.WriteUInt8(b);
			writer.WriteBytes(serverHash, (int)b);
			writer.WriteString(serverAssetBundleNameWithoutExtension, 11);
			writer.WriteString(serverAssetOrigin, 11);
		}
	}
}
