﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004D6 RID: 1238
	public class BlueprintOutput
	{
		/// <summary>
		/// Note: if calling ItemRef.Get() please use FindItemAsset instead to avoid redundant asset lookups.
		/// </summary>
		// Token: 0x17000851 RID: 2129
		// (get) Token: 0x0600291B RID: 10523 RVA: 0x000B2733 File Offset: 0x000B0933
		// (set) Token: 0x0600291C RID: 10524 RVA: 0x000B273B File Offset: 0x000B093B
		public CachingBcAssetRef ItemRef
		{
			get
			{
				return this._itemRef;
			}
			internal set
			{
				this._itemRef = value;
			}
		}

		// Token: 0x17000852 RID: 2130
		// (get) Token: 0x0600291D RID: 10525 RVA: 0x000B2744 File Offset: 0x000B0944
		[Obsolete("Please use FindItemAsset instead for GUID support")]
		public ushort id
		{
			get
			{
				return this._itemRef.LegacyId;
			}
		}

		// Token: 0x0600291E RID: 10526 RVA: 0x000B2751 File Offset: 0x000B0951
		public ItemAsset FindItemAsset()
		{
			return this._itemRef.Get<ItemAsset>();
		}

		// Token: 0x0600291F RID: 10527 RVA: 0x000B275E File Offset: 0x000B095E
		public T FindItemAsset<T>() where T : ItemAsset
		{
			return this._itemRef.Get<T>();
		}

		/// <summary>
		/// Does this blueprint output create the specified item?
		/// </summary>
		// Token: 0x06002920 RID: 10528 RVA: 0x000B276B File Offset: 0x000B096B
		public bool IsItem(ItemAsset asset)
		{
			return asset != null && this._itemRef.IsReferenceTo(asset);
		}

		// Token: 0x06002921 RID: 10529 RVA: 0x000B277E File Offset: 0x000B097E
		public BlueprintOutput(ushort newID, int newAmount, EItemOrigin newOrigin)
		{
			this.amount = newAmount;
			this.origin = newOrigin;
		}

		// Token: 0x04001493 RID: 5267
		private CachingBcAssetRef _itemRef;

		// Token: 0x04001494 RID: 5268
		public int amount;

		// Token: 0x04001495 RID: 5269
		public EItemOrigin origin;
	}
}
