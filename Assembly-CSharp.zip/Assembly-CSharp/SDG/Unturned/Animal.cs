﻿using System;
using System.Collections.Generic;
using SDG.Framework.Water;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000290 RID: 656
	public class Animal : MonoBehaviour, IExplosionDamageable, IEquatable<IExplosionDamageable>
	{
		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06001344 RID: 4932 RVA: 0x00048427 File Offset: 0x00046627
		// (set) Token: 0x06001345 RID: 4933 RVA: 0x0004842F File Offset: 0x0004662F
		public Vector3 target { get; private set; }

		// Token: 0x06001346 RID: 4934 RVA: 0x00048438 File Offset: 0x00046638
		public bool Equals(IExplosionDamageable obj)
		{
			return this == obj;
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06001347 RID: 4935 RVA: 0x0004843E File Offset: 0x0004663E
		public bool IsEligibleForExplosionDamage
		{
			get
			{
				return this.IsAlive;
			}
		}

		// Token: 0x06001348 RID: 4936 RVA: 0x00048446 File Offset: 0x00046646
		public Vector3 GetClosestPointToExplosion(Vector3 explosionCenter)
		{
			return CollisionUtil.ClosestPoint(base.gameObject, explosionCenter, false, -4194305);
		}

		// Token: 0x06001349 RID: 4937 RVA: 0x0004845C File Offset: 0x0004665C
		public void ApplyExplosionDamage(in ExplosionParameters explosionParameters, ref ExplosionDamageParameters damageParameters)
		{
			if (!damageParameters.shouldAffectAnimals)
			{
				return;
			}
			Vector3 a = damageParameters.closestPoint - explosionParameters.point;
			float magnitude = a.magnitude;
			if (magnitude > explosionParameters.damageRadius)
			{
				return;
			}
			Vector3 vector = a / magnitude;
			RaycastHit raycastHit;
			if (damageParameters.LineOfSightTest(explosionParameters.point, vector, magnitude, out raycastHit) && raycastHit.transform != null && !raycastHit.transform.IsChildOf(base.transform))
			{
				return;
			}
			if (explosionParameters.playImpactEffect)
			{
				EffectAsset effectAsset = DamageTool.FleshDynamicRef.Find();
				if (effectAsset != null)
				{
					TriggerEffectParameters parameters = new TriggerEffectParameters(effectAsset)
					{
						relevantDistance = EffectManager.SMALL,
						position = base.transform.position + Vector3.up + Vector3.up,
						reliable = true
					};
					EffectManager.triggerEffect(parameters);
					parameters.SetDirection(-vector);
					EffectManager.triggerEffect(parameters);
				}
			}
			EPlayerKill eplayerKill;
			uint num;
			DamageTool.damage(this, vector, explosionParameters.animalDamage, 1f - magnitude / explosionParameters.damageRadius, out eplayerKill, out num, explosionParameters.ragdollEffect);
			if (eplayerKill != EPlayerKill.NONE)
			{
				damageParameters.kills.Add(eplayerKill);
			}
			damageParameters.xp += num;
		}

		// Token: 0x0600134A RID: 4938 RVA: 0x00048590 File Offset: 0x00046790
		private void updateTicking()
		{
			if (this.isFleeing || this.isWandering || this.isHunting)
			{
				if (this.isTicking)
				{
					return;
				}
				this.isTicking = true;
				AnimalManager.tickingAnimals.Add(this);
				this.lastTick = Time.timeAsDouble;
				return;
			}
			else
			{
				if (!this.isTicking)
				{
					return;
				}
				this.isTicking = false;
				AnimalManager.tickingAnimals.RemoveFast(this);
				return;
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x0600134B RID: 4939 RVA: 0x000485F8 File Offset: 0x000467F8
		public bool isFleeing
		{
			get
			{
				return this._isFleeing;
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x0600134C RID: 4940 RVA: 0x00048600 File Offset: 0x00046800
		// (set) Token: 0x0600134D RID: 4941 RVA: 0x00048608 File Offset: 0x00046808
		public bool isHunting { get; private set; }

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x0600134E RID: 4942 RVA: 0x00048611 File Offset: 0x00046811
		public float lastDead
		{
			get
			{
				return this._lastDead;
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x0600134F RID: 4943 RVA: 0x00048619 File Offset: 0x00046819
		public bool IsAlive
		{
			get
			{
				return !this.isDead;
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06001350 RID: 4944 RVA: 0x00048624 File Offset: 0x00046824
		public AnimalAsset asset
		{
			get
			{
				return this._asset;
			}
		}

		// Token: 0x06001351 RID: 4945 RVA: 0x0004862C File Offset: 0x0004682C
		public float GetHealth()
		{
			return (float)this.health;
		}

		// Token: 0x06001352 RID: 4946 RVA: 0x00048635 File Offset: 0x00046835
		public Player GetTargetPlayer()
		{
			return this.currentTargetPlayer;
		}

		// Token: 0x06001353 RID: 4947 RVA: 0x00048640 File Offset: 0x00046840
		public void askEat()
		{
			if (this.isDead)
			{
				return;
			}
			this.lastEat = Time.timeAsDouble;
			this.eatDelay = UnityEngine.Random.Range(4f, 8f);
			this.isPlayingEat = true;
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				string text;
				if (this.asset.eatAnimVariantsCount == 1)
				{
					text = "Eat";
				}
				else
				{
					text = "Eat_" + UnityEngine.Random.Range(0, this.asset.eatAnimVariantsCount).ToString();
				}
				Animation animation = this.animator;
				AnimationClip animationClip = (animation != null) ? animation.GetClip(text) : null;
				if (animationClip != null)
				{
					this.eatTime = animationClip.length;
					this.animator.Play(text);
					return;
				}
				if (Assets.shouldValidateAssets)
				{
					Assets.ReportError(this.asset, "missing AnimationClip \"" + text + "\"");
				}
			}
		}

		// Token: 0x06001354 RID: 4948 RVA: 0x0004872C File Offset: 0x0004692C
		public void askGlance()
		{
			if (this.isDead)
			{
				return;
			}
			this.lastGlance = Time.timeAsDouble;
			this.glanceDelay = UnityEngine.Random.Range(4f, 8f);
			this.isPlayingGlance = true;
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				string text = "Glance_" + UnityEngine.Random.Range(0, this.asset.glanceAnimVariantsCount).ToString();
				Animation animation = this.animator;
				AnimationClip animationClip = (animation != null) ? animation.GetClip(text) : null;
				if (animationClip != null)
				{
					this.glanceTime = animationClip.length;
					this.animator.Play(text);
					return;
				}
				if (Assets.shouldValidateAssets)
				{
					Assets.ReportError(this.asset, "missing AnimationClip \"" + text + "\"");
				}
			}
		}

		// Token: 0x06001355 RID: 4949 RVA: 0x00048804 File Offset: 0x00046A04
		public void PlayStartleAnimation(byte animationIndex)
		{
			if (this.isDead)
			{
				return;
			}
			this.startleAnimationCompletionTime = Time.timeAsDouble + 0.5;
			this.isPlayingStartleAnimation = true;
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				string text;
				if (this.asset.startleAnimVariantsCount == 1)
				{
					text = "Startle";
				}
				else
				{
					text = "Startle_" + animationIndex.ToString();
				}
				Animation animation = this.animator;
				AnimationClip animationClip = (animation != null) ? animation.GetClip(text) : null;
				if (animationClip != null)
				{
					this.startleAnimationCompletionTime = Time.timeAsDouble + (double)animationClip.length;
					this.animator.Play(text);
					return;
				}
				if (Assets.shouldValidateAssets)
				{
					Assets.ReportError(this.asset, "missing AnimationClip \"" + text + "\"");
				}
			}
		}

		// Token: 0x06001356 RID: 4950 RVA: 0x000488DC File Offset: 0x00046ADC
		public void askAttack(byte animationIndex)
		{
			if (this.isDead)
			{
				return;
			}
			this.lastAttack = Time.timeAsDouble;
			this.isPlayingAttack = true;
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				string text;
				if (this.asset.attackAnimVariantsCount == 1)
				{
					text = "Attack";
				}
				else
				{
					text = "Attack_" + animationIndex.ToString();
				}
				Animation animation = this.animator;
				AnimationClip animationClip = (animation != null) ? animation.GetClip(text) : null;
				if (animationClip != null)
				{
					this.attackDuration = animationClip.length;
					this.attackInterval = Mathf.Max(this.attackDuration, this.asset.attackInterval);
					this.animator.Play(text);
				}
				else if (Assets.shouldValidateAssets)
				{
					Assets.ReportError(this.asset, "missing AnimationClip \"" + text + "\"");
				}
				if (this.asset != null && this.asset.roars != null && this.asset.roars.Length != 0 && Time.timeAsDouble - this.startedRoar > 1.0)
				{
					this.startedRoar = Time.timeAsDouble;
					AudioClip clip = this.asset.roars[UnityEngine.Random.Range(0, this.asset.roars.Length)];
					OneShotAudioParameters oneShotAudioParameters = new OneShotAudioParameters(base.transform, clip);
					oneShotAudioParameters.volume = 0.5f;
					oneShotAudioParameters.RandomizePitch(0.9f, 1.1f);
					oneShotAudioParameters.SetLinearRolloff(1f, 32f);
					oneShotAudioParameters.Play();
				}
			}
		}

		// Token: 0x06001357 RID: 4951 RVA: 0x00048A70 File Offset: 0x00046C70
		public void askPanic()
		{
			if (this.isDead)
			{
				return;
			}
			if ((!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer) && this.asset != null && this.asset.panics != null && this.asset.panics.Length != 0 && Time.timeAsDouble - this.startedPanic > 1.0)
			{
				this.startedPanic = Time.timeAsDouble;
				AudioClip clip = this.asset.panics[UnityEngine.Random.Range(0, this.asset.panics.Length)];
				OneShotAudioParameters oneShotAudioParameters = new OneShotAudioParameters(base.transform, clip);
				oneShotAudioParameters.volume = 0.5f;
				oneShotAudioParameters.RandomizePitch(0.9f, 1.1f);
				oneShotAudioParameters.SetLinearRolloff(1f, 32f);
				oneShotAudioParameters.Play();
			}
		}

		// Token: 0x06001358 RID: 4952 RVA: 0x00048B50 File Offset: 0x00046D50
		public void askDamage(ushort amount, Vector3 newRagdoll, out EPlayerKill kill, out uint xp, bool trackKill = true, bool dropLoot = true, ERagdollEffect ragdollEffect = ERagdollEffect.NONE)
		{
			kill = EPlayerKill.NONE;
			xp = 0U;
			if (amount == 0 || this.isDead)
			{
				return;
			}
			if (this.IsAlive)
			{
				if (amount >= this.health)
				{
					this.health = 0;
				}
				else
				{
					this.health -= amount;
				}
				this.ragdoll = newRagdoll;
				if (this.health == 0)
				{
					kill = EPlayerKill.ANIMAL;
					if (this.asset != null)
					{
						xp = this.asset.rewardXP;
					}
					if (dropLoot)
					{
						AnimalManager.dropLoot(this);
					}
					AnimalManager.sendAnimalDead(this, this.ragdoll, ragdollEffect);
					if (trackKill)
					{
						for (int i = 0; i < Provider.clients.Count; i++)
						{
							SteamPlayer steamPlayer = Provider.clients[i];
							if (!(steamPlayer.player == null) && !(steamPlayer.player.movement == null) && !(steamPlayer.player.life == null) && !steamPlayer.player.life.isDead && (steamPlayer.player.transform.position - base.transform.position).sqrMagnitude < 262144f)
							{
								steamPlayer.player.quests.trackAnimalKill(this);
							}
						}
					}
				}
				else if (this.asset != null && this.asset.panics != null && this.asset.panics.Length != 0)
				{
					AnimalManager.sendAnimalPanic(this);
				}
				this.lastRegen = Time.timeAsDouble;
			}
		}

		// Token: 0x06001359 RID: 4953 RVA: 0x00048CC9 File Offset: 0x00046EC9
		public void sendRevive(Vector3 position, float angle)
		{
			AnimalManager.sendAnimalAlive(this, position, MeasurementTool.angleToByte(angle));
		}

		// Token: 0x0600135A RID: 4954 RVA: 0x00048CD8 File Offset: 0x00046ED8
		private bool checkTargetValid(Vector3 point)
		{
			if (!Level.checkSafeIncludingClipVolumes(point))
			{
				return false;
			}
			float height = LevelGround.getHeight(point);
			return !WaterUtility.isPointUnderwater(new Vector3(point.x, height - 1f, point.z));
		}

		// Token: 0x0600135B RID: 4955 RVA: 0x00048D18 File Offset: 0x00046F18
		private Vector3 getFleeTarget(Vector3 normal)
		{
			Vector3 vector = base.transform.position + normal * 64f + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
			if (this.checkTargetValid(vector))
			{
				return vector;
			}
			Vector3 vector2 = base.transform.position + normal * 32f + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
			if (this.checkTargetValid(vector2))
			{
				return vector2;
			}
			vector2 = base.transform.position + normal * -32f + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
			if (this.checkTargetValid(vector2))
			{
				return vector2;
			}
			vector2 = base.transform.position + normal * -16f + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
			if (this.checkTargetValid(vector2))
			{
				return vector2;
			}
			return vector;
		}

		// Token: 0x0600135C RID: 4956 RVA: 0x00048E78 File Offset: 0x00047078
		private void getWanderTarget()
		{
			Vector3 vector;
			if (this.isStuck)
			{
				vector = base.transform.position + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
				if (!this.checkTargetValid(vector))
				{
					return;
				}
			}
			else if (this.pack != null)
			{
				if ((base.transform.position - this.pack.getAverageAnimalPoint()).sqrMagnitude > 256f)
				{
					vector = this.pack.getAverageAnimalPoint() + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
				}
				else
				{
					Vector3 wanderDirection = this.pack.getWanderDirection();
					vector = base.transform.position + wanderDirection * UnityEngine.Random.Range(6f, 8f) + new Vector3(UnityEngine.Random.Range(-4f, 4f), 0f, UnityEngine.Random.Range(-4f, 4f));
					if (!this.checkTargetValid(vector))
					{
						vector = base.transform.position - wanderDirection * UnityEngine.Random.Range(6f, 8f) + new Vector3(UnityEngine.Random.Range(-4f, 4f), 0f, UnityEngine.Random.Range(-4f, 4f));
						if (!this.checkTargetValid(vector))
						{
							return;
						}
						this.pack.wanderAngle += UnityEngine.Random.Range(160f, 200f);
					}
					else
					{
						this.pack.wanderAngle += UnityEngine.Random.Range(-20f, 20f);
					}
				}
			}
			else
			{
				vector = base.transform.position + new Vector3(UnityEngine.Random.Range(-8f, 8f), 0f, UnityEngine.Random.Range(-8f, 8f));
			}
			this.target = vector;
			this.isWandering = true;
			this.updateTicking();
		}

		// Token: 0x0600135D RID: 4957 RVA: 0x000490A1 File Offset: 0x000472A1
		public bool checkAlert(Player potentialTargetPlayer)
		{
			return this.currentTargetPlayer != potentialTargetPlayer;
		}

		// Token: 0x0600135E RID: 4958 RVA: 0x000490B0 File Offset: 0x000472B0
		public void alertPlayer(Player potentialTargetPlayer, bool sendToPack)
		{
			if (sendToPack && this.pack != null)
			{
				for (int i = 0; i < this.pack.animals.Count; i++)
				{
					Animal animal = this.pack.animals[i];
					if (!(animal == null) && !(animal == this))
					{
						animal.alertPlayer(potentialTargetPlayer, false);
					}
				}
			}
			if (this.isDead)
			{
				return;
			}
			if (this.currentTargetPlayer == potentialTargetPlayer)
			{
				return;
			}
			if (!this.isHunting && this.asset.startleAnimVariantsCount > 0)
			{
				int value = UnityEngine.Random.Range(0, this.asset.startleAnimVariantsCount);
				AnimalManager.sendAnimalStartle(this, MathfEx.ClampToByte(value));
			}
			if (this.currentTargetPlayer == null)
			{
				this._isFleeing = false;
				this.isWandering = false;
				this.isHunting = true;
				this.updateTicking();
				this.lastStuck = Time.timeAsDouble;
				this.currentTargetPlayer = potentialTargetPlayer;
				return;
			}
			if ((potentialTargetPlayer.transform.position - base.transform.position).sqrMagnitude < (this.currentTargetPlayer.transform.position - base.transform.position).sqrMagnitude)
			{
				this._isFleeing = false;
				this.isWandering = false;
				this.isHunting = true;
				this.updateTicking();
				this.currentTargetPlayer = potentialTargetPlayer;
			}
		}

		/// <summary>
		/// Alert this animal that it was damaged from a given position.
		/// Offensive animals investigate the position, whereas other animals run away.
		/// </summary>
		// Token: 0x0600135F RID: 4959 RVA: 0x00049206 File Offset: 0x00047406
		public void alertDamagedFromPoint(Vector3 point)
		{
			if (this.asset != null && this.asset.behaviour == EAnimalBehaviour.OFFENSE)
			{
				this.alertGoToPoint(point, true);
				return;
			}
			this.alertRunAwayFromPoint(point, true);
		}

		/// <summary>
		/// Alerts this animal that it needs to run away.
		/// </summary>
		/// <param name="newPosition">The position to run away from.</param>
		// Token: 0x06001360 RID: 4960 RVA: 0x00049230 File Offset: 0x00047430
		public void alertRunAwayFromPoint(Vector3 newPosition, bool sendToPack)
		{
			this.alertDirection((base.transform.position - newPosition).normalized, sendToPack);
		}

		/// <summary>
		/// Keep for plugin backwards compatibility.
		/// </summary>
		// Token: 0x06001361 RID: 4961 RVA: 0x0004925D File Offset: 0x0004745D
		[Obsolete("Clarified with alertRunAwayFromPoint, alertGoToPoint and alertDamagedFromPoint.")]
		public void alertPoint(Vector3 newPosition, bool sendToPack)
		{
			this.alertRunAwayFromPoint(newPosition, sendToPack);
		}

		// Token: 0x06001362 RID: 4962 RVA: 0x00049268 File Offset: 0x00047468
		public void alertDirection(Vector3 newDirection, bool sendToPack)
		{
			if (sendToPack && this.pack != null)
			{
				for (int i = 0; i < this.pack.animals.Count; i++)
				{
					Animal animal = this.pack.animals[i];
					if (!(animal == null) && !(animal == this))
					{
						animal.alertDirection(newDirection, false);
					}
				}
			}
			if (this.isDead)
			{
				return;
			}
			if (this.isStuck)
			{
				return;
			}
			if (this.isHunting)
			{
				return;
			}
			if (!this.isFleeing && this.asset.startleAnimVariantsCount > 0)
			{
				int value = UnityEngine.Random.Range(0, this.asset.startleAnimVariantsCount);
				AnimalManager.sendAnimalStartle(this, MathfEx.ClampToByte(value));
			}
			this._isFleeing = true;
			this.isWandering = false;
			this.isHunting = false;
			this.updateTicking();
			this.target = this.getFleeTarget(newDirection);
		}

		// Token: 0x06001363 RID: 4963 RVA: 0x00049340 File Offset: 0x00047540
		public void alertGoToPoint(Vector3 point, bool sendToPack)
		{
			if (sendToPack && this.pack != null)
			{
				for (int i = 0; i < this.pack.animals.Count; i++)
				{
					Animal animal = this.pack.animals[i];
					if (!(animal == null) && !(animal == this))
					{
						animal.alertGoToPoint(point, false);
					}
				}
			}
			if (this.isDead)
			{
				return;
			}
			if (this.isFleeing || this.isHunting)
			{
				return;
			}
			this.lastWander = Time.timeAsDouble;
			this._isFleeing = false;
			this.isWandering = true;
			this.isHunting = false;
			this.target = point;
			this.updateTicking();
		}

		// Token: 0x06001364 RID: 4964 RVA: 0x000493E8 File Offset: 0x000475E8
		private void stop()
		{
			this.isMoving = false;
			this.isRunning = false;
			this._isFleeing = false;
			this.isWandering = false;
			this.isHunting = false;
			this.updateTicking();
			this.isStuck = false;
			this.currentTargetPlayer = null;
			this.target = base.transform.position;
		}

		// Token: 0x06001365 RID: 4965 RVA: 0x00049440 File Offset: 0x00047640
		public void tellAlive(Vector3 newPosition, byte newAngle)
		{
			this.isDead = false;
			base.transform.position = newPosition;
			base.transform.rotation = Quaternion.Euler(0f, (float)(newAngle * 2), 0f);
			this.updateLife();
			this.updateStates();
			this.reset();
		}

		// Token: 0x06001366 RID: 4966 RVA: 0x00049490 File Offset: 0x00047690
		public void tellDead(Vector3 newRagdoll, ERagdollEffect ragdollEffect)
		{
			this.isDead = true;
			this._lastDead = Time.realtimeSinceStartup;
			this.updateLife();
			if (!Dedicator.IsDedicatedServer)
			{
				this.ragdoll = newRagdoll;
				RagdollTool.ragdollAnimal(base.transform.position, base.transform.rotation, this.skeleton, this.ragdoll, this.id, ragdollEffect);
			}
			if (Provider.isServer)
			{
				this.stop();
			}
		}

		// Token: 0x06001367 RID: 4967 RVA: 0x000494FE File Offset: 0x000476FE
		[Obsolete]
		public void tellState(Vector3 newPosition, byte newAngle)
		{
			this.tellState(newPosition, (float)newAngle * 2f);
		}

		// Token: 0x06001368 RID: 4968 RVA: 0x00049510 File Offset: 0x00047710
		public void tellState(Vector3 newPosition, float newAngle)
		{
			this.lastUpdatePos = newPosition;
			this.lastUpdateAngle = newAngle;
			if (this.nsb != null)
			{
				this.nsb.addNewSnapshot(new YawSnapshotInfo(newPosition, newAngle));
			}
			if (this.isPlayingEat || this.isPlayingGlance)
			{
				this.isPlayingEat = false;
				this.isPlayingGlance = false;
				Animation animation = this.animator;
				if (animation == null)
				{
					return;
				}
				animation.Stop();
			}
		}

		// Token: 0x06001369 RID: 4969 RVA: 0x00049574 File Offset: 0x00047774
		private void updateLife()
		{
			if (this.controller != null)
			{
				this.controller.SetDetectCollisionsDeferred(this.IsAlive);
			}
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				if (this.renderer_0 != null)
				{
					this.renderer_0.enabled = this.IsAlive;
				}
				if (this.renderer_1 != null)
				{
					this.renderer_1.enabled = this.IsAlive;
				}
				if (this.skeleton != null)
				{
					this.skeleton.gameObject.SetActive(this.IsAlive);
				}
			}
			Collider component = base.GetComponent<Collider>();
			if (component != null)
			{
				component.enabled = this.IsAlive;
			}
		}

		// Token: 0x0600136A RID: 4970 RVA: 0x00049634 File Offset: 0x00047834
		public void updateStates()
		{
			this.lastUpdatePos = base.transform.position;
			this.lastUpdateAngle = base.transform.rotation.eulerAngles.y;
			if (this.nsb != null)
			{
				this.nsb.updateLastSnapshot(new YawSnapshotInfo(base.transform.position, base.transform.rotation.eulerAngles.y));
			}
		}

		// Token: 0x0600136B RID: 4971 RVA: 0x000496AC File Offset: 0x000478AC
		private void reset()
		{
			this.target = base.transform.position;
			this.lastWander = Time.timeAsDouble;
			this.lastStuck = Time.timeAsDouble;
			this.isPlayingEat = false;
			this.isPlayingGlance = false;
			this.isPlayingStartleAnimation = false;
			this.isMoving = false;
			this.isRunning = false;
			this._isFleeing = false;
			this.isWandering = false;
			this.isHunting = false;
			this.updateTicking();
			this.isStuck = false;
			this.health = this.asset.health;
		}

		// Token: 0x0600136C RID: 4972 RVA: 0x00049738 File Offset: 0x00047938
		private void move(float delta)
		{
			Vector3 horizontal = (this.target - base.transform.position).GetHorizontal();
			float magnitude = horizontal.magnitude;
			bool flag = this.isPlayingStartleAnimation && this.asset.ShouldPreventMoveDuringStartle;
			bool flag2 = magnitude > 0.75f && !flag;
			if ((!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer) && flag2 && !this.isMoving)
			{
				if (this.isPlayingEat)
				{
					Animation animation = this.animator;
					if (animation != null)
					{
						animation.Stop();
					}
					this.isPlayingEat = false;
				}
				if (this.isPlayingGlance)
				{
					Animation animation2 = this.animator;
					if (animation2 != null)
					{
						animation2.Stop();
					}
					this.isPlayingGlance = false;
				}
			}
			this.isMoving = flag2;
			this.isRunning = (this.isMoving && (this.isFleeing || this.isHunting));
			float num = Mathf.Clamp01(magnitude / 0.6f);
			Vector3 forward = base.transform.forward;
			float a = Vector3.Dot(horizontal.normalized, forward);
			float num2 = (this.isRunning ? this.asset.speedRun : this.asset.speedWalk) * Mathf.Max(a, 0.05f) * num;
			if (Time.deltaTime > 0f)
			{
				num2 = Mathf.Clamp(num2, 0f, magnitude / (Time.deltaTime * 2f));
			}
			Vector3 a2 = forward * num2;
			a2.y = Physics.gravity.y * 2f;
			if (!this.isMoving && !flag)
			{
				a2.x = 0f;
				a2.z = 0f;
				if (!this.isStuck)
				{
					this._isFleeing = false;
					this.isWandering = false;
					this.updateTicking();
				}
			}
			else
			{
				Quaternion quaternion = base.transform.rotation;
				Quaternion b = Quaternion.LookRotation(horizontal);
				Vector3 eulerAngles = Quaternion.Slerp(quaternion, b, 8f * delta).eulerAngles;
				eulerAngles.z = 0f;
				eulerAngles.x = 0f;
				quaternion = Quaternion.Euler(eulerAngles);
				base.transform.rotation = quaternion;
			}
			if (!flag && a2.sqrMagnitude > 1E-45f)
			{
				CharacterController characterController = this.controller;
				if (characterController == null)
				{
					return;
				}
				characterController.Move(a2 * delta);
			}
		}

		// Token: 0x0600136D RID: 4973 RVA: 0x0004998C File Offset: 0x00047B8C
		private void Update()
		{
			if (this.isDead)
			{
				return;
			}
			if (Provider.isServer)
			{
				if (!this.isUpdated)
				{
					if (Mathf.Abs(this.lastUpdatePos.x - base.transform.position.x) > Provider.UPDATE_DISTANCE || Mathf.Abs(this.lastUpdatePos.y - base.transform.position.y) > Provider.UPDATE_DISTANCE || Mathf.Abs(this.lastUpdatePos.z - base.transform.position.z) > Provider.UPDATE_DISTANCE || Mathf.Abs(this.lastUpdateAngle - base.transform.rotation.eulerAngles.y) > 1f)
					{
						this.lastUpdatePos = base.transform.position;
						this.lastUpdateAngle = base.transform.rotation.eulerAngles.y;
						this.isUpdated = true;
						AnimalManager.updates += 1;
						if (this.isStuck && Time.timeAsDouble - this.lastStuck > 0.5)
						{
							this.isStuck = false;
							this.lastStuck = Time.timeAsDouble;
						}
					}
					else if (this.isMoving)
					{
						if (Time.timeAsDouble - this.lastStuck > 0.125)
						{
							this.isStuck = true;
						}
					}
					else
					{
						this.isStuck = false;
						this.lastStuck = Time.timeAsDouble;
					}
				}
			}
			else
			{
				if (Mathf.Abs(this.lastUpdatePos.x - base.transform.position.x) > 0.01f || Mathf.Abs(this.lastUpdatePos.y - base.transform.position.y) > 0.01f || Mathf.Abs(this.lastUpdatePos.z - base.transform.position.z) > 0.01f)
				{
					if (!this.isMoving)
					{
						if (this.isPlayingEat)
						{
							Animation animation = this.animator;
							if (animation != null)
							{
								animation.Stop();
							}
							this.isPlayingEat = false;
						}
						if (this.isPlayingGlance)
						{
							Animation animation2 = this.animator;
							if (animation2 != null)
							{
								animation2.Stop();
							}
							this.isPlayingGlance = false;
						}
					}
					this.isMoving = true;
					this.isRunning = ((this.lastUpdatePos - base.transform.position).sqrMagnitude > 1f);
				}
				else
				{
					this.isMoving = false;
					this.isRunning = false;
				}
				if (this.nsb != null)
				{
					YawSnapshotInfo currentSnapshot = this.nsb.getCurrentSnapshot();
					base.transform.position = currentSnapshot.pos;
					base.transform.rotation = Quaternion.Euler(0f, currentSnapshot.yaw, 0f);
				}
			}
			if ((!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer) && !this.isMoving && !this.isPlayingEat && !this.isPlayingGlance && !this.isPlayingAttack && !this.isPlayingStartleAnimation && Time.timeAsDouble - this.lastAttack > (double)this.attackInterval + 0.5)
			{
				if (this.asset.eatAnimVariantsCount > 0 && Time.timeAsDouble - this.lastEat > (double)this.eatDelay)
				{
					this.askEat();
				}
				else if (this.asset.glanceAnimVariantsCount > 0 && Time.timeAsDouble - this.lastGlance > (double)this.glanceDelay)
				{
					this.askGlance();
				}
			}
			if (Provider.isServer)
			{
				if (this.isStuck)
				{
					if (Time.timeAsDouble - this.lastStuck > 0.75)
					{
						this.lastStuck = Time.timeAsDouble;
						this.getWanderTarget();
					}
				}
				else if (!this.isFleeing && !this.isHunting)
				{
					if (Time.timeAsDouble - this.lastWander > (double)this.wanderDelay)
					{
						this.lastWander = Time.timeAsDouble;
						this.wanderDelay = UnityEngine.Random.Range(8f, 16f);
						this.getWanderTarget();
					}
				}
				else
				{
					this.lastWander = Time.timeAsDouble;
				}
			}
			if (this.isPlayingEat)
			{
				if (Time.timeAsDouble - this.lastEat > (double)this.eatTime)
				{
					this.isPlayingEat = false;
				}
			}
			else if (this.isPlayingGlance)
			{
				if (Time.timeAsDouble - this.lastGlance > (double)this.glanceTime)
				{
					this.isPlayingGlance = false;
				}
			}
			else if (this.isPlayingStartleAnimation)
			{
				if (Time.timeAsDouble > this.startleAnimationCompletionTime)
				{
					this.isPlayingStartleAnimation = false;
				}
			}
			else if (this.isPlayingAttack)
			{
				if (Time.timeAsDouble - this.lastAttack > (double)this.attackDuration)
				{
					this.isPlayingAttack = false;
				}
			}
			else if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				if (this.isRunning && this.hasRunAnimation)
				{
					Animation animation3 = this.animator;
					if (animation3 != null)
					{
						animation3.Play("Run");
					}
				}
				else if (this.isMoving && this.hasWalkAnimation)
				{
					Animation animation4 = this.animator;
					if (animation4 != null)
					{
						animation4.Play("Walk");
					}
				}
				else if (this.hasIdleAnimation)
				{
					Animation animation5 = this.animator;
					if (animation5 != null)
					{
						animation5.Play("Idle");
					}
				}
			}
			if (Provider.isServer && this.health < this.asset.health && Time.timeAsDouble - this.lastRegen > (double)this.asset.regen)
			{
				this.lastRegen = Time.timeAsDouble;
				this.health += 1;
			}
		}

		// Token: 0x0600136E RID: 4974 RVA: 0x00049F30 File Offset: 0x00048130
		public void tick()
		{
			float num = (float)(Time.timeAsDouble - this.lastTick);
			this.lastTick = Time.timeAsDouble;
			this.undergroundTestTimer -= num;
			if (this.undergroundTestTimer < 0f)
			{
				this.undergroundTestTimer = UnityEngine.Random.Range(30f, 60f);
				if (!UndergroundAllowlist.IsPositionWithinValidHeight(base.transform.position, 0.1f))
				{
					AnimalManager.TeleportAnimalBackIntoMap(this);
					return;
				}
			}
			if (this.isHunting)
			{
				if (this.currentTargetPlayer != null && this.currentTargetPlayer.life.IsAlive && this.currentTargetPlayer.stance.stance != EPlayerStance.SWIM)
				{
					this.target = this.currentTargetPlayer.transform.position;
					float num2 = MathfEx.HorizontalDistanceSquared(this.target, base.transform.position);
					float num3 = Mathf.Abs(this.target.y - base.transform.position.y);
					if (num2 < ((this.currentTargetPlayer.movement.getVehicle() != null) ? this.asset.horizontalVehicleAttackRangeSquared : this.asset.horizontalAttackRangeSquared) && num3 < this.asset.verticalAttackRange)
					{
						if (Time.timeAsDouble - this.lastTarget > (double)(Dedicator.IsDedicatedServer ? 0.3f : 0.1f))
						{
							if (this.isAttacking)
							{
								if (Time.timeAsDouble - this.lastAttack > (double)(this.attackDuration * 0.5f))
								{
									this.isAttacking = false;
									byte b = this.asset.damage;
									b = (byte)((float)b * Provider.modeConfigData.Animals.Damage_Multiplier);
									if (this.currentTargetPlayer.movement.getVehicle() != null)
									{
										if (this.currentTargetPlayer.movement.getVehicle().asset != null && this.currentTargetPlayer.movement.getVehicle().asset.isVulnerableToEnvironment)
										{
											VehicleManager.damage(this.currentTargetPlayer.movement.getVehicle(), (float)b, 1f, true, default(CSteamID), EDamageOrigin.Animal_Attack);
										}
									}
									else
									{
										EPlayerKill eplayerKill;
										DamageTool.damagePlayer(new DamagePlayerParameters(this.currentTargetPlayer)
										{
											cause = EDeathCause.ANIMAL,
											killer = Provider.server,
											direction = (this.target - base.transform.position).normalized,
											damage = (float)b,
											respectArmor = true
										}, out eplayerKill);
									}
								}
							}
							else if (this.asset.attackAnimVariantsCount > 0 && Time.timeAsDouble - this.lastAttack > (double)this.attackInterval)
							{
								this.isAttacking = true;
								int value = UnityEngine.Random.Range(0, this.asset.attackAnimVariantsCount);
								AnimalManager.sendAnimalAttack(this, MathfEx.ClampToByte(value));
							}
						}
					}
					else if (num2 > 4096f)
					{
						this.currentTargetPlayer = null;
						this.isHunting = false;
						this.updateTicking();
					}
					else
					{
						this.lastTarget = Time.timeAsDouble;
						this.isAttacking = false;
					}
				}
				else
				{
					this.currentTargetPlayer = null;
					this.isHunting = false;
					this.updateTicking();
				}
				this.lastWander = Time.timeAsDouble;
			}
			this.move(num);
		}

		// Token: 0x0600136F RID: 4975 RVA: 0x0004A284 File Offset: 0x00048484
		public void init()
		{
			this._asset = (Assets.find(EAssetType.ANIMAL, this.id) as AnimalAsset);
			this.attackDuration = 0.5f;
			this.attackInterval = this.asset.attackInterval;
			this.eatTime = 0.5f;
			this.glanceTime = 0.5f;
			if (!Dedicator.IsDedicatedServer || this.asset.shouldPlayAnimsOnDedicatedServer)
			{
				Transform transform = base.transform.Find("Character");
				if (transform != null)
				{
					this.animator = transform.GetComponent<Animation>();
					if (this.animator != null)
					{
						this.hasIdleAnimation = (this.animator.GetClip("Idle") != null);
						this.hasRunAnimation = (this.animator.GetClip("Run") != null);
						this.hasWalkAnimation = (this.animator.GetClip("Walk") != null);
						if (Dedicator.IsDedicatedServer)
						{
							this.animator.cullingType = AnimationCullingType.AlwaysAnimate;
						}
					}
					else
					{
						this._asset.ReportAssetError("missing Animation component on child Character transform");
					}
					this.skeleton = transform.Find("Skeleton");
					if (this.skeleton == null)
					{
						this._asset.ReportAssetError("missing Skeleton transform child of Character transform");
					}
					Transform transform2 = transform.Find("Model_0");
					this.renderer_0 = ((transform2 != null) ? transform2.GetComponent<Renderer>() : null);
					Transform transform3 = transform.Find("Model_1");
					this.renderer_1 = ((transform3 != null) ? transform3.GetComponent<Renderer>() : null);
				}
				else
				{
					this._asset.ReportAssetError("missing child Character transform with Animation component");
				}
			}
			if (Provider.isServer)
			{
				this.controller = base.GetComponent<CharacterController>();
				if (this.controller != null)
				{
					this.controller.enableOverlapRecovery = false;
				}
				else
				{
					Assets.ReportError(this.asset, "missing CharacterController component");
				}
			}
			else
			{
				this.nsb = new NetworkSnapshotBuffer<YawSnapshotInfo>(Provider.UPDATE_TIME, Provider.UPDATE_DELAY);
			}
			this.reset();
			this.lastEat = Time.timeAsDouble + (double)UnityEngine.Random.Range(4f, 16f);
			this.lastGlance = Time.timeAsDouble + (double)UnityEngine.Random.Range(4f, 16f);
			this.lastWander = Time.timeAsDouble + (double)UnityEngine.Random.Range(8f, 32f);
			this.eatDelay = UnityEngine.Random.Range(4f, 8f);
			this.glanceDelay = UnityEngine.Random.Range(4f, 8f);
			this.wanderDelay = UnityEngine.Random.Range(8f, 16f);
			this.updateLife();
			this.updateStates();
		}

		// Token: 0x06001370 RID: 4976 RVA: 0x0004A517 File Offset: 0x00048717
		[Obsolete("Renamed to PlayStartleAnimation")]
		public void askStartle()
		{
			this.PlayStartleAnimation(0);
		}

		// Token: 0x06001372 RID: 4978 RVA: 0x0004A533 File Offset: 0x00048733
		void IExplosionDamageable.ApplyExplosionDamage(in ExplosionParameters explosionParameters, ref ExplosionDamageParameters damageParameters)
		{
			this.ApplyExplosionDamage(explosionParameters, ref damageParameters);
		}

		// Token: 0x04000663 RID: 1635
		private Animation animator;

		// Token: 0x04000664 RID: 1636
		private Transform skeleton;

		// Token: 0x04000665 RID: 1637
		private Renderer renderer_0;

		// Token: 0x04000666 RID: 1638
		private Renderer renderer_1;

		// Token: 0x04000667 RID: 1639
		private double lastEat;

		// Token: 0x04000668 RID: 1640
		private double lastGlance;

		// Token: 0x04000669 RID: 1641
		private double startleAnimationCompletionTime;

		// Token: 0x0400066A RID: 1642
		private double lastWander;

		// Token: 0x0400066B RID: 1643
		private double lastStuck;

		// Token: 0x0400066C RID: 1644
		private double lastTarget;

		// Token: 0x0400066D RID: 1645
		private double lastAttack;

		// Token: 0x0400066E RID: 1646
		private double lastRegen;

		// Token: 0x0400066F RID: 1647
		private float eatTime;

		// Token: 0x04000670 RID: 1648
		private float glanceTime;

		// Token: 0x04000671 RID: 1649
		private float attackDuration;

		// Token: 0x04000672 RID: 1650
		private float attackInterval;

		// Token: 0x04000673 RID: 1651
		private double startedRoar;

		// Token: 0x04000674 RID: 1652
		private double startedPanic;

		// Token: 0x04000675 RID: 1653
		private float eatDelay;

		// Token: 0x04000676 RID: 1654
		private float glanceDelay;

		// Token: 0x04000677 RID: 1655
		private float wanderDelay;

		// Token: 0x04000678 RID: 1656
		private bool isPlayingEat;

		// Token: 0x04000679 RID: 1657
		private bool isPlayingGlance;

		// Token: 0x0400067A RID: 1658
		private bool isPlayingStartleAnimation;

		// Token: 0x0400067B RID: 1659
		private bool isPlayingAttack;

		// Token: 0x0400067C RID: 1660
		private Player currentTargetPlayer;

		// Token: 0x0400067E RID: 1662
		private Vector3 lastUpdatePos;

		// Token: 0x0400067F RID: 1663
		private float lastUpdateAngle;

		// Token: 0x04000680 RID: 1664
		private NetworkSnapshotBuffer<YawSnapshotInfo> nsb;

		// Token: 0x04000681 RID: 1665
		private bool isMoving;

		// Token: 0x04000682 RID: 1666
		private bool isRunning;

		// Token: 0x04000683 RID: 1667
		private bool isTicking;

		// Token: 0x04000684 RID: 1668
		private bool _isFleeing;

		// Token: 0x04000685 RID: 1669
		private bool isWandering;

		// Token: 0x04000687 RID: 1671
		private bool isStuck;

		// Token: 0x04000688 RID: 1672
		private bool isAttacking;

		// Token: 0x04000689 RID: 1673
		private float _lastDead;

		// Token: 0x0400068A RID: 1674
		public bool isDead;

		// Token: 0x0400068B RID: 1675
		public ushort index;

		// Token: 0x0400068C RID: 1676
		public ushort id;

		// Token: 0x0400068D RID: 1677
		public PackInfo pack;

		// Token: 0x0400068E RID: 1678
		private ushort health;

		// Token: 0x0400068F RID: 1679
		private Vector3 ragdoll;

		// Token: 0x04000690 RID: 1680
		private AnimalAsset _asset;

		// Token: 0x04000691 RID: 1681
		private CharacterController controller;

		/// <summary>
		/// Whether this animal was updated in this network tick and needs to be resent.
		/// </summary>
		// Token: 0x04000692 RID: 1682
		public bool isUpdated;

		/// <summary>
		/// Reduces frequency of UndergroundAllowlist checks because it can be expensive with lots of entities and volumes. 
		/// </summary>
		// Token: 0x04000693 RID: 1683
		private float undergroundTestTimer = 10f;

		// Token: 0x04000694 RID: 1684
		private double lastTick;

		// Token: 0x04000695 RID: 1685
		private bool hasIdleAnimation;

		// Token: 0x04000696 RID: 1686
		private bool hasRunAnimation;

		// Token: 0x04000697 RID: 1687
		private bool hasWalkAnimation;
	}
}
