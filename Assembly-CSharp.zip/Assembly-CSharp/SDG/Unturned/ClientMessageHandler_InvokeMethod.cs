﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000279 RID: 633
	internal static class ClientMessageHandler_InvokeMethod
	{
		// Token: 0x060012FE RID: 4862 RVA: 0x000450E0 File Offset: 0x000432E0
		internal static void ReadMessage(NetPakReader reader)
		{
			uint num;
			if (!reader.ReadBits(NetReflection.clientMethodsBitCount, out num))
			{
				UnturnedLog.warn("unable to read method index");
				return;
			}
			if (num >= NetReflection.clientMethodsLength)
			{
				UnturnedLog.warn("out of bounds method index ({0}/{1})", new object[]
				{
					num,
					NetReflection.clientMethodsLength
				});
				return;
			}
			ClientMethodInfo clientMethodInfo = NetReflection.clientMethods[(int)num];
			ClientInvocationContext clientInvocationContext = new ClientInvocationContext(ClientInvocationContext.EOrigin.Remote, reader, clientMethodInfo);
			try
			{
				clientMethodInfo.readMethod(clientInvocationContext);
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, "Exception invoking {0} from server:", new object[]
				{
					clientMethodInfo
				});
			}
		}
	}
}
