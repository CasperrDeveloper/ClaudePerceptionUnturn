﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SDG.Framework.Devkit;
using SDG.Framework.Modules;
using Steamworks;
using UnityEngine;
using UnityEngine.SceneManagement;
using Unturned.SystemEx;
using Unturned.UnityEx;

namespace SDG.Unturned
{
	// Token: 0x020002A3 RID: 675
	public class Assets : MonoBehaviour
	{
		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06001444 RID: 5188 RVA: 0x0004D851 File Offset: 0x0004BA51
		public static TypeRegistryDictionary assetTypes
		{
			get
			{
				return Assets._assetTypes;
			}
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06001445 RID: 5189 RVA: 0x0004D858 File Offset: 0x0004BA58
		public static TypeRegistryDictionary useableTypes
		{
			get
			{
				return Assets._useableTypes;
			}
		}

		/// <summary>
		/// Has initial client UGC loading step run yet?
		/// Used to defer asset loading for workshop installs that occured during startup.
		/// </summary>
		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06001446 RID: 5190 RVA: 0x0004D85F File Offset: 0x0004BA5F
		// (set) Token: 0x06001447 RID: 5191 RVA: 0x0004D866 File Offset: 0x0004BA66
		public static bool hasLoadedUgc { get; protected set; }

		/// <summary>
		/// Has initial map loading step run yet?
		/// Used to defer map loading for workshop installs that occured during startup.
		/// </summary>
		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x06001448 RID: 5192 RVA: 0x0004D86E File Offset: 0x0004BA6E
		// (set) Token: 0x06001449 RID: 5193 RVA: 0x0004D875 File Offset: 0x0004BA75
		public static bool hasLoadedMaps { get; protected set; }

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x0600144A RID: 5194 RVA: 0x0004D87D File Offset: 0x0004BA7D
		public static bool isLoading
		{
			get
			{
				return Assets.isLoadingAllAssets || Assets.isLoadingFromUpdate;
			}
		}

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x0600144B RID: 5195 RVA: 0x0004D88D File Offset: 0x0004BA8D
		internal static bool ShouldWaitForNewAssetsToFinishLoading
		{
			get
			{
				return Assets.isLoading || Assets.instance.worker.IsWorking;
			}
		}

		/// <summary>
		/// Should some specific asset types which opt-in be allowed to defer loading from asset bundles until used?
		/// Disabled by asset validation because all assets need to be loaded.
		/// </summary>
		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x0600144C RID: 5196 RVA: 0x0004D8A7 File Offset: 0x0004BAA7
		public static bool shouldDeferLoadingAssets
		{
			get
			{
				return Assets.wantsDeferLoadingAssets && !Assets.shouldValidateAssets;
			}
		}

		/// <summary>
		/// While an asset is being loaded, this is the master bundle for that asset.
		/// Used by master bundle pointer as a default.
		/// </summary>
		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x0600144D RID: 5197 RVA: 0x0004D8C4 File Offset: 0x0004BAC4
		// (set) Token: 0x0600144E RID: 5198 RVA: 0x0004D8CB File Offset: 0x0004BACB
		public static MasterBundleConfig currentMasterBundle { get; private set; }

		// Token: 0x0600144F RID: 5199 RVA: 0x0004D8D3 File Offset: 0x0004BAD3
		private static string getExceptionMessage(Exception e)
		{
			if (e == null)
			{
				return "Exception = Null";
			}
			if (e.InnerException != null)
			{
				return e.InnerException.Message;
			}
			return e.Message;
		}

		// Token: 0x06001450 RID: 5200 RVA: 0x0004D8F8 File Offset: 0x0004BAF8
		public static void reportError(string error)
		{
			Assets.errors.Add(error);
			UnturnedLog.warn(error);
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x0004D90C File Offset: 0x0004BB0C
		public static void ReportError(IAssetErrorContext context, string error)
		{
			Asset asset = context as Asset;
			if (asset != null)
			{
				asset.HasErrors = true;
			}
			Assets.reportError(context.AssetErrorPrefix + ": " + error);
		}

		// Token: 0x06001452 RID: 5202 RVA: 0x0004D940 File Offset: 0x0004BB40
		public static void ReportError(IAssetErrorContext context, string format, params object[] args)
		{
			string error = string.Format(format, args);
			Assets.ReportError(context, error);
		}

		// Token: 0x06001453 RID: 5203 RVA: 0x0004D95C File Offset: 0x0004BB5C
		public static void ReportError(IAssetErrorContext context, string format, object arg0)
		{
			string error = string.Format(format, arg0);
			Assets.ReportError(context, error);
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x0004D978 File Offset: 0x0004BB78
		public static void ReportError(IAssetErrorContext context, string format, object arg0, object arg1)
		{
			string error = string.Format(format, arg0, arg1);
			Assets.ReportError(context, error);
		}

		// Token: 0x06001455 RID: 5205 RVA: 0x0004D998 File Offset: 0x0004BB98
		public static void ReportError(IAssetErrorContext context, string format, object arg0, object arg1, object arg2)
		{
			string error = string.Format(format, arg0, arg1, arg2);
			Assets.ReportError(context, error);
		}

		// Token: 0x06001456 RID: 5206 RVA: 0x0004D9B7 File Offset: 0x0004BBB7
		public static List<string> getReportedErrorsList()
		{
			return Assets.errors;
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x0004D9C0 File Offset: 0x0004BBC0
		internal static AssetOrigin FindWorkshopFileOrigin(ulong workshopFileId)
		{
			foreach (AssetOrigin assetOrigin in Assets.assetOrigins)
			{
				if (assetOrigin.workshopFileId == workshopFileId)
				{
					return assetOrigin;
				}
			}
			return null;
		}

		// Token: 0x06001458 RID: 5208 RVA: 0x0004DA1C File Offset: 0x0004BC1C
		private static AssetOrigin FindLevelOrigin(LevelInfo level)
		{
			if (level.publishedFileId != 0UL)
			{
				return Assets.FindWorkshopFileOrigin(level.publishedFileId);
			}
			string b = "Map \"" + level.name + "\"";
			foreach (AssetOrigin assetOrigin in Assets.assetOrigins)
			{
				if (string.Equals(assetOrigin.name, b))
				{
					return assetOrigin;
				}
			}
			return null;
		}

		// Token: 0x06001459 RID: 5209 RVA: 0x0004DAA8 File Offset: 0x0004BCA8
		internal static AssetOrigin FindOrAddWorkshopFileOrigin(ulong workshopFileId, bool shouldOverrideIds)
		{
			AssetOrigin assetOrigin = Assets.FindWorkshopFileOrigin(workshopFileId);
			if (assetOrigin != null)
			{
				return assetOrigin;
			}
			AssetOrigin assetOrigin2 = new AssetOrigin();
			assetOrigin2.name = string.Format("Workshop File ({0})", workshopFileId);
			assetOrigin2.workshopFileId = workshopFileId;
			assetOrigin2.shouldAssetsOverrideExistingIds = shouldOverrideIds;
			Assets.assetOrigins.Add(assetOrigin2);
			return assetOrigin2;
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x0004DAF8 File Offset: 0x0004BCF8
		internal static AssetOrigin FindOrAddLevelOrigin(LevelInfo level)
		{
			if (level.publishedFileId != 0UL)
			{
				return Assets.FindOrAddWorkshopFileOrigin(level.publishedFileId, false);
			}
			string text = "Map \"" + level.name + "\"";
			foreach (AssetOrigin assetOrigin in Assets.assetOrigins)
			{
				if (string.Equals(assetOrigin.name, text))
				{
					return assetOrigin;
				}
			}
			AssetOrigin assetOrigin2 = new AssetOrigin();
			assetOrigin2.name = text;
			assetOrigin2.canResave = true;
			Assets.assetOrigins.Add(assetOrigin2);
			return assetOrigin2;
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x0600145B RID: 5211 RVA: 0x0004DBA4 File Offset: 0x0004BDA4
		public static Asset find(EAssetType type, ushort id)
		{
			if (type == EAssetType.NONE || id == 0)
			{
				return null;
			}
			Asset asset;
			Assets.currentAssetMapping.legacyAssetsTable[type].TryGetValue(id, out asset);
			int num = 0;
			do
			{
				RedirectorAsset redirectorAsset = asset as RedirectorAsset;
				if (redirectorAsset == null)
				{
					return asset;
				}
				Assets.currentAssetMapping.assetDictionary.TryGetValue(redirectorAsset.TargetGuid, out asset);
				num++;
			}
			while (num <= 32);
			asset = null;
			UnturnedLog.warn(string.Format("Infinite asset director loop encountered when resolving Type: {0} Legacy ID: {1}", type, id));
			return asset;
		}

		/// <summary>
		/// Find an asset by GUID reference.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		/// <returns>Asset with matching GUID if it exists, null otherwise.</returns>
		// Token: 0x0600145C RID: 5212 RVA: 0x0004DC20 File Offset: 0x0004BE20
		public static T find<T>(AssetReference<T> reference) where T : Asset
		{
			if (!reference.isValid)
			{
				return default(T);
			}
			return Assets.find(reference.GUID) as T;
		}

		/// <summary>
		/// Find an asset by GUID reference.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// Maybe considered a hack? Ignores the current per-server asset mapping.
		/// </summary>
		/// <returns>Asset with matching GUID if it exists, null otherwise.</returns>
		// Token: 0x0600145D RID: 5213 RVA: 0x0004DC56 File Offset: 0x0004BE56
		public static T Find_UseDefaultAssetMapping<T>(AssetReference<T> reference) where T : Asset
		{
			return Assets.Find_UseDefaultAssetMapping(reference.GUID) as T;
		}

		/// <summary>
		/// Find an asset by GUID reference.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// Maybe considered a hack? Ignores the current per-server asset mapping.
		/// </summary>
		/// <returns>Asset with matching GUID if it exists, null otherwise.</returns>
		// Token: 0x0600145E RID: 5214 RVA: 0x0004DC70 File Offset: 0x0004BE70
		public static Asset Find_UseDefaultAssetMapping(Guid assetGuid)
		{
			Asset asset;
			Assets.defaultAssetMapping.assetDictionary.TryGetValue(assetGuid, out asset);
			int num = 0;
			do
			{
				RedirectorAsset redirectorAsset = asset as RedirectorAsset;
				if (redirectorAsset == null)
				{
					return asset;
				}
				Assets.currentAssetMapping.assetDictionary.TryGetValue(redirectorAsset.TargetGuid, out asset);
				num++;
			}
			while (num <= 32);
			asset = null;
			UnturnedLog.warn(string.Format("Infinite asset director loop encountered when resolving: {0:N}", assetGuid));
			return asset;
		}

		/// <summary>
		/// Load content from an assetbundle.
		/// </summary>
		// Token: 0x0600145F RID: 5215 RVA: 0x0004DCD8 File Offset: 0x0004BED8
		public static T load<T>(ContentReference<T> reference) where T : UnityEngine.Object
		{
			if (!reference.isValid)
			{
				return default(T);
			}
			MasterBundleConfig masterBundleConfig = Assets.findMasterBundleByName(reference.name, true);
			if (masterBundleConfig != null && masterBundleConfig.assetBundle != null)
			{
				string text = masterBundleConfig.FormatAssetPathAndCache(reference.path);
				T t = masterBundleConfig.assetBundle.LoadAsset<T>(text);
				if (t == null)
				{
					UnturnedLog.warn("Failed to load content reference '{0}' from master bundle '{1}' as {2}", new object[]
					{
						text,
						reference.name,
						typeof(T).Name
					});
				}
				return t;
			}
			return default(T);
		}

		/// <summary>
		/// Find an asset by GUID reference.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		/// <returns>Asset with matching GUID if it exists, null otherwise.</returns>
		// Token: 0x06001460 RID: 5216 RVA: 0x0004DD7C File Offset: 0x0004BF7C
		public static Asset find(Guid GUID)
		{
			Asset asset;
			Assets.currentAssetMapping.assetDictionary.TryGetValue(GUID, out asset);
			int num = 0;
			do
			{
				RedirectorAsset redirectorAsset = asset as RedirectorAsset;
				if (redirectorAsset == null)
				{
					return asset;
				}
				Assets.currentAssetMapping.assetDictionary.TryGetValue(redirectorAsset.TargetGuid, out asset);
				num++;
			}
			while (num <= 32);
			asset = null;
			UnturnedLog.warn(string.Format("Infinite asset director loop encountered when resolving: {0}", GUID));
			return asset;
		}

		/// <summary>
		/// Find an asset by GUID reference.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		/// <returns>Asset with matching GUID if it exists, null otherwise.</returns>
		// Token: 0x06001461 RID: 5217 RVA: 0x0004DDE1 File Offset: 0x0004BFE1
		public static T find<T>(Guid guid) where T : Asset
		{
			return Assets.find(guid) as T;
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x06001462 RID: 5218 RVA: 0x0004DDF3 File Offset: 0x0004BFF3
		public static EffectAsset FindEffectAssetByGuidOrLegacyId(Guid guid, ushort legacyId)
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.EFFECT, legacyId) as EffectAsset;
			}
			return Assets.find<EffectAsset>(guid);
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x06001463 RID: 5219 RVA: 0x0004DE10 File Offset: 0x0004C010
		public static T FindNpcAssetByGuidOrLegacyId<T>(Guid guid, ushort legacyId) where T : Asset
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.NPC, legacyId) as T;
			}
			return Assets.find<T>(guid);
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// Note: this method doesn't handle redirects by VehicleRedirectorAsset.
		/// </summary>
		// Token: 0x06001464 RID: 5220 RVA: 0x0004DE33 File Offset: 0x0004C033
		public static VehicleAsset FindVehicleAssetByGuidOrLegacyId(Guid guid, ushort legacyId)
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.VEHICLE, legacyId) as VehicleAsset;
			}
			return Assets.find<VehicleAsset>(guid);
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// Note: this method doesn't handle redirects by VehicleRedirectorAsset.
		/// </summary>
		// Token: 0x06001465 RID: 5221 RVA: 0x0004DE50 File Offset: 0x0004C050
		public static Asset FindBaseVehicleAssetByGuidOrLegacyId(Guid guid, ushort legacyId)
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.VEHICLE, legacyId);
			}
			return Assets.find(guid);
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x06001466 RID: 5222 RVA: 0x0004DE68 File Offset: 0x0004C068
		public static SpawnAsset FindSpawnAssetByGuidOrLegacyId(Guid guid, ushort legacyId)
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.SPAWN, legacyId) as SpawnAsset;
			}
			return Assets.find<SpawnAsset>(guid);
		}

		/// <summary>
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x06001467 RID: 5223 RVA: 0x0004DE86 File Offset: 0x0004C086
		internal static T FindItemByGuidOrLegacyId<T>(Guid guid, ushort legacyId) where T : ItemAsset
		{
			if (guid.IsEmpty())
			{
				return Assets.find(EAssetType.ITEM, legacyId) as T;
			}
			return Assets.find<T>(guid);
		}

		/// <summary>
		/// Useful if GUID can reference a different asset type than legacy ID. For example, gun magazine GUID can
		/// reference a SpawnAsset while its legacy ID cannot.
		/// This method supports <see cref="T:SDG.Unturned.RedirectorAsset" />.
		/// </summary>
		// Token: 0x06001468 RID: 5224 RVA: 0x0004DEA8 File Offset: 0x0004C0A8
		internal static Asset FindByGuidOrLegacyId(Guid guid, EAssetType legacyAssetType, ushort legacyId)
		{
			if (guid.IsEmpty())
			{
				return Assets.find(legacyAssetType, legacyId);
			}
			return Assets.find(guid);
		}

		/// <summary>
		/// Append assets that extend from result type.
		/// </summary>
		// Token: 0x06001469 RID: 5225 RVA: 0x0004DEC0 File Offset: 0x0004C0C0
		public static void find<T>(List<T> results) where T : class
		{
			Assets.FindAssetsInListByType<T>(Assets.currentAssetMapping.assetList, results);
		}

		// Token: 0x0600146A RID: 5226 RVA: 0x0004DED2 File Offset: 0x0004C0D2
		internal static bool HasCurrentAssetMappingChanged(ref int counter)
		{
			bool result = Assets.currentAssetMapping.modificationCounter != counter;
			counter = Assets.currentAssetMapping.modificationCounter;
			return result;
		}

		// Token: 0x0600146B RID: 5227 RVA: 0x0004DEF1 File Offset: 0x0004C0F1
		internal static bool HasDefaultAssetMappingChanged(ref int counter)
		{
			bool result = Assets.defaultAssetMapping.modificationCounter != counter;
			counter = Assets.defaultAssetMapping.modificationCounter;
			return result;
		}

		/// <summary>
		/// Maybe considered a hack? Ignores the current per-server asset mapping.
		/// Append assets that extend from result type.
		/// </summary>
		// Token: 0x0600146C RID: 5228 RVA: 0x0004DF10 File Offset: 0x0004C110
		internal static void FindAssetsByType_UseDefaultAssetMapping<T>(List<T> results) where T : class
		{
			Assets.FindAssetsInListByType<T>(Assets.defaultAssetMapping.assetList, results);
		}

		// Token: 0x0600146D RID: 5229 RVA: 0x0004DF24 File Offset: 0x0004C124
		private static void FindAssetsInListByType<T>(List<Asset> assetList, List<T> results) where T : class
		{
			foreach (Asset asset in assetList)
			{
				T t = asset as T;
				if (t != null)
				{
					results.Add(t);
				}
			}
		}

		// Token: 0x0600146E RID: 5230 RVA: 0x0004DF84 File Offset: 0x0004C184
		public static Asset findByAbsolutePath(string path)
		{
			if (string.IsNullOrEmpty(path))
			{
				return null;
			}
			path = Path.GetFullPath(path);
			foreach (Asset asset in Assets.currentAssetMapping.assetList)
			{
				if (path.Equals(asset.absoluteOriginFilePath))
				{
					return asset;
				}
			}
			return null;
		}

		// Token: 0x0600146F RID: 5231 RVA: 0x0004DFFC File Offset: 0x0004C1FC
		internal static Asset CreateAtRuntime(Type type, ushort legacyId)
		{
			try
			{
				Asset asset = Activator.CreateInstance(type) as Asset;
				if (asset != null)
				{
					asset.GUID = Guid.NewGuid();
					asset.id = legacyId;
					Assets.AddToMapping(asset, false, Assets.defaultAssetMapping);
					if (asset is IDirtyable)
					{
						(asset as IDirtyable).isDirty = true;
					}
					asset.OnCreatedAtRuntime();
					return asset;
				}
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e);
			}
			return null;
		}

		// Token: 0x06001470 RID: 5232 RVA: 0x0004E070 File Offset: 0x0004C270
		internal static T CreateAtRuntime<T>(ushort legacyId) where T : Asset
		{
			return Assets.CreateAtRuntime(typeof(T), legacyId) as T;
		}

		// Token: 0x06001471 RID: 5233 RVA: 0x0004E08C File Offset: 0x0004C28C
		internal static void AddToMapping(Asset asset, bool overrideExistingID, Assets.AssetMapping assetMapping)
		{
			if (asset == null)
			{
				return;
			}
			EAssetType assetCategory = asset.assetCategory;
			if (assetCategory == EAssetType.SPAWN)
			{
				Assets.hasUnlinkedSpawns = true;
			}
			bool flag = false;
			if (assetCategory == EAssetType.OBJECT)
			{
				if (overrideExistingID)
				{
					Asset asset2;
					if (assetMapping.legacyAssetsTable[assetCategory].TryGetValue(asset.id, out asset2))
					{
						assetMapping.legacyAssetsTable[assetCategory].Remove(asset.id);
						asset2.hasBeenReplaced = true;
						flag = true;
					}
					assetMapping.legacyAssetsTable[assetCategory].Add(asset.id, asset);
				}
				else if (!assetMapping.legacyAssetsTable[assetCategory].ContainsKey(asset.id))
				{
					assetMapping.legacyAssetsTable[assetCategory].Add(asset.id, asset);
				}
			}
			else if (assetCategory != EAssetType.NONE)
			{
				if (asset.id != 0)
				{
					if (overrideExistingID)
					{
						Asset asset3;
						if (assetMapping.legacyAssetsTable[assetCategory].TryGetValue(asset.id, out asset3))
						{
							assetMapping.legacyAssetsTable[assetCategory].Remove(asset.id);
							asset3.hasBeenReplaced = true;
							flag = true;
						}
					}
					else if (assetMapping.legacyAssetsTable[assetCategory].ContainsKey(asset.id))
					{
						Asset asset4;
						assetMapping.legacyAssetsTable[assetCategory].TryGetValue(asset.id, out asset4);
						Assets.ReportError(asset, string.Format("legacy ID {0} already taken by {1} in {2}!", asset.id, asset4.FriendlyNameWithFriendlyType, asset4.GetOriginName()));
						return;
					}
					assetMapping.legacyAssetsTable[assetCategory].Add(asset.id, asset);
				}
				else
				{
					bool flag2;
					switch (assetCategory)
					{
					case EAssetType.ITEM:
					{
						ItemAsset itemAsset = asset as ItemAsset;
						flag2 = (itemAsset == null || !itemAsset.isPro);
						goto IL_1CA;
					}
					case EAssetType.EFFECT:
					case EAssetType.VEHICLE:
						break;
					case EAssetType.OBJECT:
					case EAssetType.RESOURCE:
						goto IL_1C7;
					default:
						if (assetCategory - EAssetType.SPAWN > 1)
						{
							goto IL_1C7;
						}
						break;
					}
					flag2 = false;
					goto IL_1CA;
					IL_1C7:
					flag2 = true;
					IL_1CA:
					if (flag2)
					{
						Assets.ReportError(asset, "needs a non-zero ID");
					}
				}
			}
			if (asset.GUID != Guid.Empty)
			{
				if (overrideExistingID)
				{
					Asset asset5;
					if (assetMapping.assetDictionary.TryGetValue(asset.GUID, out asset5))
					{
						assetMapping.assetDictionary.Remove(asset5.GUID);
						assetMapping.assetList.Remove(asset5);
						asset5.hasBeenReplaced = true;
						flag = true;
					}
				}
				else if (assetMapping.assetDictionary.ContainsKey(asset.GUID))
				{
					Asset asset6;
					assetMapping.assetDictionary.TryGetValue(asset.GUID, out asset6);
					Assets.ReportError(asset, string.Concat(new string[]
					{
						"GUID already taken by ",
						asset6.FriendlyNameWithFriendlyType,
						" in ",
						asset6.GetOriginName(),
						"!"
					}));
					return;
				}
				assetMapping.assetDictionary.Add(asset.GUID, asset);
				assetMapping.assetList.Add(asset);
			}
			assetMapping.modificationCounter++;
			if (flag && assetCategory == EAssetType.VEHICLE && Level.isLoaded && Provider.isServer && VehicleManager.vehicles != null && VehicleManager.vehicles.Count > 0)
			{
				VehicleManager.shouldRespawnReloadedVehicles = true;
			}
			if (asset.origin != null && asset.origin.workshopFileId != 0UL && Assets.shouldLogWorkshopAssets)
			{
				UnturnedLog.info(asset.getTypeNameAndIdDisplayString());
			}
		}

		// Token: 0x06001472 RID: 5234 RVA: 0x0004E3BC File Offset: 0x0004C5BC
		private static void AddAssetsFromOriginToCurrentMapping(AssetOrigin origin)
		{
			UnturnedLog.info(string.Format("Adding {0} asset(s) from origin {1} to server mapping", origin.assets.Count, origin.name));
			foreach (Asset asset in origin.assets)
			{
				Assets.AddToMapping(asset, true, Assets.currentAssetMapping);
			}
		}

		/// <summary>
		/// While playing on server the client will use the same dictionary/list of assets the server uses in order
		/// to reduce issues with ID conflicts.
		///
		/// 2023-05-27: server now ALSO uses the same logic to ensure IDs are applied in consistent order regardless
		/// of multi-threaded loading order.
		/// </summary>
		// Token: 0x06001473 RID: 5235 RVA: 0x0004E438 File Offset: 0x0004C638
		internal static void ApplyServerAssetMapping(LevelInfo pendingLevel, List<PublishedFileId_t> serverWorkshopFileIds)
		{
			Assets.currentAssetMapping = new Assets.AssetMapping();
			List<AssetOrigin> list = new List<AssetOrigin>();
			list.Add(Assets.coreOrigin);
			AssetOrigin assetOrigin = null;
			if (pendingLevel != null)
			{
				assetOrigin = Assets.FindLevelOrigin(pendingLevel);
				if (assetOrigin != null)
				{
					list.Add(assetOrigin);
				}
			}
			if (serverWorkshopFileIds != null)
			{
				foreach (PublishedFileId_t publishedFileId_t in serverWorkshopFileIds)
				{
					AssetOrigin assetOrigin2 = Assets.FindWorkshopFileOrigin(publishedFileId_t.m_PublishedFileId);
					if (assetOrigin2 != null)
					{
						if (assetOrigin2 != assetOrigin)
						{
							list.Add(assetOrigin2);
						}
					}
					else
					{
						UnturnedLog.info(string.Format("Unable to find assets for server mapping (file ID {0})", publishedFileId_t));
					}
				}
			}
			if (Dedicator.IsDedicatedServer)
			{
				foreach (AssetOrigin assetOrigin3 in Assets.assetOrigins)
				{
					if (assetOrigin3 != Assets.reloadOrigin && assetOrigin3.assets.Count >= 1 && !list.Contains(assetOrigin3))
					{
						UnturnedLog.info("Inserting asset origin " + assetOrigin3.name + " before other assets to reduce chances of ID conflicts because otherwise it was not included");
						list.Insert(0, assetOrigin3);
					}
				}
			}
			foreach (AssetOrigin origin in list)
			{
				Assets.AddAssetsFromOriginToCurrentMapping(origin);
			}
		}

		// Token: 0x06001474 RID: 5236 RVA: 0x0004E5AC File Offset: 0x0004C7AC
		internal static void ClearServerAssetMapping()
		{
			Assets.currentAssetMapping = Assets.defaultAssetMapping;
		}

		// Token: 0x06001475 RID: 5237 RVA: 0x0004E5B8 File Offset: 0x0004C7B8
		public static void RequestReloadAllAssets()
		{
			if (Assets.hasFinishedInitialStartupLoading && !Assets.isLoading)
			{
				Assets.instance.StartCoroutine(Assets.instance.LoadAllAssets());
			}
		}

		/// <summary>
		/// Search all loaded master bundles for one in path's hierarchy.
		/// </summary>
		// Token: 0x06001476 RID: 5238 RVA: 0x0004E5E0 File Offset: 0x0004C7E0
		public static MasterBundleConfig findMasterBundleByPath(string path)
		{
			int num = 0;
			MasterBundleConfig result = null;
			foreach (MasterBundleConfig masterBundleConfig in Assets.allMasterBundles)
			{
				if (masterBundleConfig.directoryPath.Length >= num && path.StartsWith(masterBundleConfig.directoryPath))
				{
					if (path.Length > masterBundleConfig.directoryPath.Length)
					{
						char c = path[masterBundleConfig.directoryPath.Length];
						if (c != '/' && c != '\\')
						{
							continue;
						}
					}
					num = masterBundleConfig.directoryPath.Length;
					result = masterBundleConfig;
				}
			}
			return result;
		}

		// Token: 0x06001477 RID: 5239 RVA: 0x0004E68C File Offset: 0x0004C88C
		public static MasterBundleConfig findMasterBundleInListByName(List<MasterBundleConfig> list, string name, bool matchExtension = true)
		{
			foreach (MasterBundleConfig masterBundleConfig in list)
			{
				if ((matchExtension ? masterBundleConfig.assetBundleName : masterBundleConfig.assetBundleNameWithoutExtension).Equals(name, StringComparison.InvariantCultureIgnoreCase))
				{
					return masterBundleConfig;
				}
			}
			return null;
		}

		/// <summary>
		/// Find loaded master bundle by name.
		/// </summary>
		// Token: 0x06001478 RID: 5240 RVA: 0x0004E6F4 File Offset: 0x0004C8F4
		public static MasterBundleConfig findMasterBundleByName(string name, bool matchExtension = true)
		{
			return Assets.findMasterBundleInListByName(Assets.allMasterBundles, name, matchExtension);
		}

		/// <summary>
		/// Unload all asset bundles from memory, and empty known list.
		/// Called when reloading assets.
		/// </summary>
		// Token: 0x06001479 RID: 5241 RVA: 0x0004E704 File Offset: 0x0004C904
		private static void UnloadAllMasterBundles()
		{
			foreach (MasterBundleConfig masterBundleConfig in Assets.allMasterBundles)
			{
				masterBundleConfig.unload();
			}
			Assets.allMasterBundles.Clear();
		}

		/// <summary>
		/// Catches exceptions thrown by LoadFile to avoid breaking loading.
		/// </summary>
		// Token: 0x0600147A RID: 5242 RVA: 0x0004E760 File Offset: 0x0004C960
		private static void TryLoadFile(AssetsWorker.AssetDefinition file)
		{
			try
			{
				Assets.loadingStats.totalFilesLoaded++;
				Assets.LoadFile(file);
			}
			catch (Exception e)
			{
				UnturnedLog.error("Exception loading file {0}:", new object[]
				{
					file.path
				});
				UnturnedLog.exception(e);
			}
		}

		// Token: 0x0600147B RID: 5243 RVA: 0x0004E7BC File Offset: 0x0004C9BC
		private static void LoadFile(AssetsWorker.AssetDefinition file)
		{
			string path = file.path;
			IDatDictionary assetData = file.assetData;
			byte[] array = file.hash;
			if (path.Length > 260)
			{
				Assets.reportError("Asset path exceeds 260 characters and might not load properly on Windows: \"" + path + "\"");
			}
			if (file.assetErrors != null)
			{
				foreach (string text in file.assetErrors)
				{
					Assets.reportError(string.Concat(new string[]
					{
						"Error parsing \"",
						path,
						"\": \"",
						text,
						"\""
					}));
				}
			}
			string directoryName = Path.GetDirectoryName(path);
			string text2 = path.EndsWith("Asset.dat", StringComparison.OrdinalIgnoreCase) ? Path.GetFileName(directoryName) : Path.GetFileNameWithoutExtension(path);
			Guid guid = default(Guid);
			Type type = null;
			IDatDictionary dictionary;
			if (assetData.TryGetDictionary("Metadata", out dictionary))
			{
				if (!dictionary.TryParseGuid("GUID", out guid))
				{
					Assets.reportError("Unable to parse Metadata.GUID in \"" + path + "\"");
					return;
				}
				type = dictionary.ParseType("Type", null);
				if (type == null)
				{
					Assets.reportError("Unable to parse Metadata.Type in \"" + path + "\"");
					return;
				}
			}
			else
			{
				if (!assetData.ContainsKey("GUID"))
				{
					guid = Guid.NewGuid();
					try
					{
						string text3 = File.ReadAllText(path);
						text3 = "GUID " + guid.ToString("N") + Environment.NewLine + text3;
						File.WriteAllText(path, text3);
						UnturnedLog.info(string.Format("Assigned GUID {0:N} to asset \"{1}\"", guid, path));
						goto IL_1D0;
					}
					catch (Exception e)
					{
						UnturnedLog.exception(e, "Caught IO exception adding GUID to \"" + path + "\":");
						goto IL_1D0;
					}
				}
				if (!assetData.TryParseGuid("GUID", out guid))
				{
					Assets.reportError("Unable to parse GUID in \"" + path + "\"");
					return;
				}
			}
			IL_1D0:
			if (guid.IsEmpty())
			{
				Assets.reportError("Cannot use empty GUID in \"" + path + "\"");
				return;
			}
			IDatDictionary datDictionary = assetData;
			IDatDictionary datDictionary2;
			if (assetData.TryGetDictionary("Asset", out datDictionary2))
			{
				datDictionary = datDictionary2;
			}
			if (type == null)
			{
				string @string = datDictionary.GetString("Type", null);
				if (string.IsNullOrEmpty(@string))
				{
					Assets.reportError("Missing asset Type in \"" + path + "\"");
					return;
				}
				type = Assets.assetTypes.getType(@string);
				if (type == null)
				{
					type = datDictionary.ParseType("Type", null);
					if (type == null)
					{
						Assets.reportError(string.Concat(new string[]
						{
							"Unhandled asset type \"",
							@string,
							"\" in \"",
							path,
							"\""
						}));
						return;
					}
				}
			}
			if (!typeof(Asset).IsAssignableFrom(type))
			{
				Assets.reportError(string.Format("Type \"{0}\" is not a valid asset type in \"{1}\"", type, path));
				return;
			}
			MasterBundleConfig masterBundleConfig = Assets.findMasterBundleByPath(path);
			string string2 = datDictionary.GetString("Master_Bundle_Override", null);
			if (string2 != null)
			{
				masterBundleConfig = Assets.findMasterBundleByName(string2, true);
				if (masterBundleConfig == null)
				{
					UnturnedLog.warn("Unable to find master bundle override '{0}' for '{1}'", new object[]
					{
						string2,
						path
					});
				}
			}
			else if (datDictionary.ContainsKey("Exclude_From_Master_Bundle"))
			{
				masterBundleConfig = null;
			}
			if (masterBundleConfig != null && masterBundleConfig.assetBundle == null)
			{
				UnturnedLog.warn("Skipping master bundle '{0}' for '{1}' because asset bundle is null", new object[]
				{
					masterBundleConfig.assetBundleName,
					path
				});
				masterBundleConfig = null;
			}
			Assets.currentMasterBundle = masterBundleConfig;
			int a = -1;
			Bundle bundle;
			if (masterBundleConfig != null)
			{
				string text4;
				if (!datDictionary.TryGetString("Bundle_Override_Path", out text4))
				{
					if (!datDictionary.ParseBool("Bundle_Path_Include_Filename", false))
					{
						text4 = directoryName.Substring(masterBundleConfig.directoryPath.Length);
					}
					else
					{
						text4 = Path.ChangeExtension(path, null).Substring(masterBundleConfig.directoryPath.Length);
					}
					text4 = text4.Replace('\\', '/');
				}
				bundle = new MasterBundle(masterBundleConfig, text4, text2);
				string text5 = text4.ToLowerInvariant() + "/" + text2.ToLowerInvariant();
				array = Hash.combine(new byte[][]
				{
					array,
					Hash.SHA1(text5)
				});
				a = masterBundleConfig.version;
			}
			else if (datDictionary.ContainsKey("Bundle_Override_Path"))
			{
				string text6 = datDictionary.GetString("Bundle_Override_Path", null);
				int num = text6.LastIndexOf('/');
				string str;
				if (num == -1)
				{
					str = text6;
				}
				else
				{
					str = text6.Substring(num + 1);
				}
				text6 = text6 + "/" + str + ".unity3d";
				bundle = new Bundle(text6, false, text2);
			}
			else
			{
				bundle = new Bundle(directoryName + "/" + text2 + ".unity3d", false, null);
			}
			int num2 = datDictionary.ParseInt32("Asset_Bundle_Version", 1);
			if (num2 < 1)
			{
				Assets.reportError(text2 + " Lowest individual asset bundle version is 1 (default), associated with 5.5.");
				num2 = 1;
			}
			else if (num2 > 6)
			{
				Assets.reportError(text2 + " Highest individual asset bundle version is 6, associated with 2022 LTS.");
				num2 = 6;
			}
			int num3 = Mathf.Max(a, num2);
			bundle.convertShadersToStandard = (num3 < 2);
			bundle.consolidateShaders = (num3 < 3 || (datDictionary.ContainsKey("Enable_Shader_Consolidation") && !datDictionary.ContainsKey("Disable_Shader_Consolidation")));
			Local localization = new Local(file.translationData, file.fallbackTranslationData);
			ushort id = datDictionary.ParseUInt16("ID", 0);
			Asset asset;
			try
			{
				asset = (Activator.CreateInstance(type) as Asset);
			}
			catch (Exception e2)
			{
				Assets.reportError(string.Format("Caught exception while constructing {0} in \"{1}\": {2}", type, path, Assets.getExceptionMessage(e2)));
				UnturnedLog.exception(e2);
				bundle.unload();
				Assets.currentMasterBundle = null;
				Assets.currentAsset = null;
				return;
			}
			if (asset == null)
			{
				Assets.reportError(string.Format("Failed to construct {0} in \"{1}\"", type, path));
				bundle.unload();
				Assets.currentMasterBundle = null;
				Assets.currentAsset = null;
				return;
			}
			Assets.currentAsset = asset;
			try
			{
				asset.id = id;
				asset.GUID = guid;
				asset.hash = array;
				asset.requiredShaderUpgrade = (bundle.convertShadersToStandard || bundle.consolidateShaders);
				asset.HasErrors = (file.assetErrors != null && file.assetErrors.Count > 0);
				asset.absoluteOriginFilePath = path;
				asset.origin = file.origin;
				bool flag;
				if (Assets.shouldResaveAssets)
				{
					AssetOrigin origin = asset.origin;
					if (origin != null && origin.canResave)
					{
						flag = Assets.shouldParseMetadata;
						goto IL_646;
					}
				}
				flag = false;
				IL_646:
				bool flag2 = flag;
				if (flag2)
				{
					asset.OriginParsedData = assetData;
				}
				if (datDictionary.ParseBool("Keep_Localization_Loaded", false))
				{
					asset.Localization = localization;
				}
				PopulateAssetParameters populateAssetParameters = new PopulateAssetParameters
				{
					bundle = bundle,
					data = datDictionary,
					localization = localization,
					CanPerformDataConversions = flag2
				};
				asset.PopulateAsset(populateAssetParameters);
				asset.origin.assets.Add(asset);
				Assets.AddToMapping(asset, file.origin.shouldAssetsOverrideExistingIds, Assets.defaultAssetMapping);
				bundle.unload();
			}
			catch (Exception e3)
			{
				Assets.reportError("Caught exception while populating \"" + path + "\": " + Assets.getExceptionMessage(e3));
				UnturnedLog.exception(e3);
				bundle.unload();
			}
			Assets.currentMasterBundle = null;
			Assets.currentAsset = null;
		}

		/// <summary>
		/// Called when a new workshop item is installed either on client or server.
		/// </summary>
		// Token: 0x0600147C RID: 5244 RVA: 0x0004EF40 File Offset: 0x0004D140
		public static void RequestAddSearchLocation(string absoluteDirectoryPath, AssetOrigin origin)
		{
			Assets.instance.AddSearchLocation(absoluteDirectoryPath, origin);
		}

		/// <summary>
		/// Reload assets in given folder.
		/// </summary>
		// Token: 0x0600147D RID: 5245 RVA: 0x0004EF4E File Offset: 0x0004D14E
		public static void reload(string absolutePath)
		{
			if (Assets.hasFinishedInitialStartupLoading && !Assets.isLoading)
			{
				Assets.loadingStats.Reset();
				Assets.RequestAddSearchLocation(absolutePath, Assets.reloadOrigin);
			}
		}

		// Token: 0x0600147E RID: 5246 RVA: 0x0004EF73 File Offset: 0x0004D173
		public static void ReloadAsset(Asset asset)
		{
			Assets.reload(Path.GetDirectoryName(asset.absoluteOriginFilePath));
		}

		// Token: 0x0600147F RID: 5247 RVA: 0x0004EF85 File Offset: 0x0004D185
		public static void linkSpawnsIfDirty()
		{
			if (Assets.hasUnlinkedSpawns)
			{
				UnturnedLog.info("Linking spawns because changes were detected");
				Assets.linkSpawns();
				return;
			}
			UnturnedLog.info("Skipping link spawns because no changes were detected");
		}

		/// <summary>
		/// Can now be safely called multiple times on client in order to handle spawns for downloaded maps.
		/// Spawn tables have "roots" which allow mods to insert custom spawns into the vanilla spawn tables.
		/// This method is used after workshop assets are loaded on client, or after the dedicated server is done downloading workshop content.
		/// </summary>
		// Token: 0x06001480 RID: 5248 RVA: 0x0004EFA8 File Offset: 0x0004D1A8
		public static void linkSpawns()
		{
			if (Assets.hasUnlinkedSpawns)
			{
				Assets.hasUnlinkedSpawns = false;
				List<SpawnAsset> list = new List<SpawnAsset>();
				Assets.FindAssetsByType_UseDefaultAssetMapping<SpawnAsset>(list);
				int num = 0;
				int num2 = 0;
				int num3 = 0;
				foreach (SpawnAsset spawnAsset in list)
				{
					if (spawnAsset.insertRoots.Count >= 1)
					{
						foreach (SpawnTable spawnTable in spawnAsset.insertRoots)
						{
							SpawnAsset spawnAsset2;
							if (spawnTable.legacySpawnId != 0)
							{
								spawnAsset2 = (Assets.find(EAssetType.SPAWN, spawnTable.legacySpawnId) as SpawnAsset);
								if (spawnAsset2 == null)
								{
									Assets.ReportError(spawnAsset, "unable to find root {0} during link", spawnTable.legacySpawnId);
									continue;
								}
							}
							else
							{
								if (spawnTable.targetGuid.IsEmpty())
								{
									continue;
								}
								Asset asset = Assets.find(spawnTable.targetGuid);
								if (asset == null)
								{
									Assets.ReportError(spawnAsset, "unable to find root {0} during link", spawnTable.targetGuid);
									continue;
								}
								spawnAsset2 = (asset as SpawnAsset);
								if (spawnAsset2 == null)
								{
									Assets.ReportError(spawnAsset, string.Format("root {0} found as {1} {2} (not a spawn table)", spawnTable.targetGuid, asset.GetTypeFriendlyName(), asset.FriendlyName));
									continue;
								}
							}
							spawnTable.legacySpawnId = 0;
							spawnTable.targetGuid = spawnAsset.GUID;
							spawnTable.isLink = true;
							spawnAsset2.tables.Add(spawnTable);
							if (spawnTable.isOverride)
							{
								spawnAsset2.markOverridden();
							}
							spawnAsset2.markTablesDirty();
							num++;
							if (Assets.shouldLogSpawnInsertions)
							{
								if (spawnTable.isOverride)
								{
									UnturnedLog.info("Spawn {0} overriding {1}", new object[]
									{
										spawnAsset.name,
										spawnAsset2.name
									});
								}
								else
								{
									UnturnedLog.info("Spawn {0} inserted into {1}", new object[]
									{
										spawnAsset.name,
										spawnAsset2.name
									});
								}
							}
						}
						spawnAsset.insertRoots.Clear();
					}
				}
				foreach (SpawnAsset spawnAsset3 in list)
				{
					if (spawnAsset3.areTablesDirty)
					{
						spawnAsset3.sortAndNormalizeWeights();
						num2++;
					}
				}
				foreach (SpawnAsset spawnAsset4 in list)
				{
					foreach (SpawnTable spawnTable2 in spawnAsset4.tables)
					{
						if (!spawnTable2.hasNotifiedChild)
						{
							spawnTable2.hasNotifiedChild = true;
							SpawnAsset spawnAsset5;
							if (spawnTable2.legacySpawnId != 0)
							{
								spawnAsset5 = (Assets.find(EAssetType.SPAWN, spawnTable2.legacySpawnId) as SpawnAsset);
								if (spawnAsset5 == null)
								{
									Assets.ReportError(spawnAsset4, "unable to find child table {0} during link", spawnTable2.legacySpawnId);
									continue;
								}
							}
							else
							{
								if (spawnTable2.targetGuid.IsEmpty())
								{
									continue;
								}
								Asset asset2 = Assets.find(spawnTable2.targetGuid);
								if (asset2 == null)
								{
									Assets.ReportError(spawnAsset4, "unable to find child {0} during link", spawnTable2.targetGuid);
									continue;
								}
								spawnAsset5 = (asset2 as SpawnAsset);
								if (spawnAsset5 == null)
								{
									continue;
								}
							}
							SpawnTable spawnTable3 = new SpawnTable();
							spawnTable3.targetGuid = spawnAsset4.GUID;
							spawnTable3.weight = spawnTable2.weight;
							spawnTable3.normalizedWeight = spawnTable2.normalizedWeight;
							spawnTable3.isLink = spawnTable2.isLink;
							spawnTable3.isOverride = spawnTable2.isOverride;
							spawnAsset5.roots.Add(spawnTable3);
							num3++;
						}
					}
				}
				UnturnedLog.info("Link spawns: {0} children, {1} sorted/normalized and {2} parents", new object[]
				{
					num,
					num2,
					num3
				});
				return;
			}
		}

		// Token: 0x06001481 RID: 5249 RVA: 0x0004F414 File Offset: 0x0004D614
		public static void initializeMasterBundleValidation()
		{
			MasterBundleValidation.initialize(Assets.allMasterBundles);
		}

		/// <summary>
		/// Look through all item blueprints and log errors if there are duplicates.
		/// </summary>
		// Token: 0x06001482 RID: 5250 RVA: 0x0004F420 File Offset: 0x0004D620
		private void CheckForBlueprintErrors()
		{
			Func<Blueprint, Blueprint, bool> func = delegate(Blueprint myBlueprint, Blueprint yourBlueprint)
			{
				if (myBlueprint.Operation != yourBlueprint.Operation)
				{
					return false;
				}
				if (myBlueprint.SkillSpecialityIndex != yourBlueprint.SkillSpecialityIndex)
				{
					return false;
				}
				if (myBlueprint.SkillIndex != yourBlueprint.SkillIndex)
				{
					return false;
				}
				if (myBlueprint.CategoryTagRef != yourBlueprint.CategoryTagRef)
				{
					return false;
				}
				if (myBlueprint.outputs.Length != yourBlueprint.outputs.Length)
				{
					return false;
				}
				if (myBlueprint.supplies.Length != yourBlueprint.supplies.Length)
				{
					return false;
				}
				if (myBlueprint.questConditions != null != (yourBlueprint.questConditions != null))
				{
					return false;
				}
				if (myBlueprint.questConditions != null && myBlueprint.questConditions.Length != yourBlueprint.questConditions.Length)
				{
					return false;
				}
				if (myBlueprint.questRewards != null != (yourBlueprint.questRewards != null))
				{
					return false;
				}
				if (myBlueprint.questRewards != null && myBlueprint.questRewards.Length != yourBlueprint.questRewards.Length)
				{
					return false;
				}
				if (myBlueprint.RequiresNearbyCraftingTags != null != (yourBlueprint.RequiresNearbyCraftingTags != null))
				{
					return false;
				}
				if (myBlueprint.RequiresNearbyCraftingTags != null && myBlueprint.RequiresNearbyCraftingTags.Length != yourBlueprint.RequiresNearbyCraftingTags.Length)
				{
					return false;
				}
				if (myBlueprint.TargetItem != null != (yourBlueprint.TargetItem != null))
				{
					return false;
				}
				if (myBlueprint.TargetItem != null && !myBlueprint.TargetItem.Equals(yourBlueprint.TargetItem))
				{
					return false;
				}
				byte b5 = 0;
				while ((int)b5 < myBlueprint.outputs.Length)
				{
					if (myBlueprint.outputs[(int)b5].ItemRef != yourBlueprint.outputs[(int)b5].ItemRef)
					{
						return false;
					}
					b5 += 1;
				}
				byte b6 = 0;
				while ((int)b6 < myBlueprint.supplies.Length)
				{
					if (!myBlueprint.supplies[(int)b6].Equals(yourBlueprint.supplies[(int)b6]))
					{
						return false;
					}
					b6 += 1;
				}
				if (myBlueprint.questConditions != null)
				{
					for (int m = 0; m < myBlueprint.questConditions.Length; m++)
					{
						if (!myBlueprint.questConditions[m].Equals(yourBlueprint.questConditions[m]))
						{
							return false;
						}
					}
				}
				if (myBlueprint.questRewards != null)
				{
					for (int n = 0; n < myBlueprint.questRewards.Length; n++)
					{
						if (!myBlueprint.questRewards[n].Equals(yourBlueprint.questRewards[n]))
						{
							return false;
						}
					}
				}
				if (myBlueprint.RequiresNearbyCraftingTags != null)
				{
					for (int num = 0; num < myBlueprint.RequiresNearbyCraftingTags.Length; num++)
					{
						if (!myBlueprint.RequiresNearbyCraftingTags[num].Equals(yourBlueprint.RequiresNearbyCraftingTags[num]))
						{
							return false;
						}
					}
				}
				return true;
			};
			List<ItemAsset> list = new List<ItemAsset>();
			Assets.find<ItemAsset>(list);
			if (list.Count > 0)
			{
				for (int i = 0; i < list.Count; i++)
				{
					ItemAsset itemAsset = list[i];
					byte b = 0;
					while ((int)b < itemAsset.blueprints.Count)
					{
						Blueprint blueprint = itemAsset.blueprints[(int)b];
						byte b2 = 0;
						while ((int)b2 < itemAsset.blueprints.Count)
						{
							if (b2 != b)
							{
								Blueprint arg = itemAsset.blueprints[(int)b2];
								if (func(blueprint, arg))
								{
									Assets.ReportError(itemAsset, string.Format("blueprint [{0}] is identical to blueprint [{1}]", b, b2));
								}
							}
							b2 += 1;
						}
						if (blueprint.supplies != null && blueprint.supplies.Length > 1)
						{
							for (int j = 0; j < blueprint.supplies.Length - 1; j++)
							{
								for (int k = j + 1; k < blueprint.supplies.Length; k++)
								{
									BlueprintSupply blueprintSupply = blueprint.supplies[j];
									BlueprintSupply other = blueprint.supplies[k];
									if (blueprintSupply.Equals(other))
									{
										Assets.ReportError(itemAsset, string.Format("blueprint [{0}] input items [{1}] and [{2}] are identical", b, j, k));
									}
								}
							}
						}
						b += 1;
					}
					for (int l = 0; l < list.Count; l++)
					{
						if (l != i)
						{
							ItemAsset itemAsset2 = list[l];
							byte b3 = 0;
							while ((int)b3 < itemAsset.blueprints.Count)
							{
								Blueprint arg2 = itemAsset.blueprints[(int)b3];
								byte b4 = 0;
								while ((int)b4 < itemAsset2.blueprints.Count)
								{
									Blueprint arg3 = itemAsset2.blueprints[(int)b4];
									if (func(arg2, arg3))
									{
										Assets.ReportError(itemAsset, string.Format("blueprint [{0}] is identical to {1} blueprint [{2}]", b3, itemAsset2.itemName, b4));
									}
									b4 += 1;
								}
								b3 += 1;
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Look through all dialogue and check that their referenced
		/// dialogueID or vendorID is an actual loaded asset.
		/// </summary>
		// Token: 0x06001483 RID: 5251 RVA: 0x0004F658 File Offset: 0x0004D858
		private void CheckForNpcErrors()
		{
			List<DialogueAsset> list = new List<DialogueAsset>();
			Assets.find<DialogueAsset>(list);
			foreach (DialogueAsset dialogueAsset in list)
			{
				int num = dialogueAsset.responses.Length;
				for (int i = 0; i < num; i++)
				{
					DialogueResponse dialogueResponse = dialogueAsset.responses[i];
					if (!dialogueResponse.IsDialogueRefNull() && dialogueResponse.FindDialogueAsset() == null)
					{
						Assets.ReportError(dialogueAsset, "unable to find dialogue asset for response " + i.ToString());
					}
					if (!dialogueResponse.IsVendorRefNull() && dialogueResponse.FindVendorAsset() == null)
					{
						Assets.ReportError(dialogueAsset, "unable to find vendor asset for response " + i.ToString());
					}
				}
			}
		}

		/// <summary>
		/// Manually run asset unload and garbage collection in the hope
		/// that it will minimize RAM allocated during loading.
		/// </summary>
		// Token: 0x06001484 RID: 5252 RVA: 0x0004F720 File Offset: 0x0004D920
		private void CleanupMemory()
		{
			Resources.UnloadUnusedAssets();
			GC.Collect();
		}

		/// <summary>
		/// Helper for Assets.init.
		/// Load all non-map assets from:
		/// 	/Bundles/Workshop/Content
		/// 	/Servers/ServerID/Workshop/Content
		/// 	/Servers/ServerID/Bundles
		/// </summary>
		// Token: 0x06001485 RID: 5253 RVA: 0x0004F730 File Offset: 0x0004D930
		private void AddDedicatedServerUgcSearchLocations()
		{
			string path = Path.Combine(ReadWrite.PATH, "Bundles", "Workshop", "Content");
			if (ReadWrite.folderExists(path, false))
			{
				this.AddSearchLocation(path, Assets.legacyServerSharedOrigin);
			}
			string path2 = Path.Combine(new string[]
			{
				ReadWrite.PATH,
				ServerSavedata.directoryName,
				Provider.serverID,
				"Workshop",
				"Content"
			});
			if (ReadWrite.folderExists(path2, false))
			{
				this.AddSearchLocation(path2, Assets.legacyPerServerOrigin);
			}
			string path3 = Path.Combine(ReadWrite.PATH, ServerSavedata.directoryName, Provider.serverID, "Bundles");
			if (ReadWrite.folderExists(path3, false))
			{
				this.AddSearchLocation(path3, Assets.legacyPerServerOrigin);
			}
		}

		/// <summary>
		/// Helper for Assets.init.
		/// Load all non-map assets from subscribed UGC.
		/// </summary>
		// Token: 0x06001486 RID: 5254 RVA: 0x0004F7E4 File Offset: 0x0004D9E4
		private void AddClientUgcSearchLocations()
		{
			if (Provider.provider.workshopService.ugc != null)
			{
				SteamContent[] array = Provider.provider.workshopService.ugc.ToArray();
				Assets.hasLoadedUgc = true;
				foreach (SteamContent steamContent in array)
				{
					if (LocalWorkshopSettings.get().getEnabled(steamContent.publishedFileID) && (steamContent.type == ESteamUGCType.OBJECT || steamContent.type == ESteamUGCType.ITEM || steamContent.type == ESteamUGCType.VEHICLE))
					{
						AssetOrigin origin = Assets.FindOrAddWorkshopFileOrigin(steamContent.publishedFileID.m_PublishedFileId, false);
						this.AddSearchLocation(steamContent.path, origin);
					}
				}
			}
		}

		/// <summary>
		/// Helper for modders creating workshop content.
		/// Loads folders in the "Sandbox" directory the same way workshop files are loaded.
		/// </summary>
		// Token: 0x06001487 RID: 5255 RVA: 0x0004F87C File Offset: 0x0004DA7C
		private void AddSandboxSearchLocations()
		{
			string path = Path.Combine(ReadWrite.PATH, "Sandbox");
			if (Directory.Exists(path))
			{
				foreach (string path2 in ReadWrite.getFolders(path, false))
				{
					string fileName = Path.GetFileName(path2);
					UnturnedLog.info("Sandbox: {0}", new object[]
					{
						fileName
					});
					AssetOrigin assetOrigin = new AssetOrigin();
					assetOrigin.name = "Sandbox Folder \"" + fileName + "\"";
					assetOrigin.shouldAssetsOverrideExistingIds = true;
					assetOrigin.canResave = true;
					Assets.assetOrigins.Add(assetOrigin);
					this.AddSearchLocation(path2, assetOrigin);
				}
				return;
			}
			Directory.CreateDirectory(path);
		}

		/// <summary>
		/// Helper for Assets.init.
		/// Load all assets in each map's Bundles folder, and content in map's Content folder.
		/// </summary>
		// Token: 0x06001488 RID: 5256 RVA: 0x0004F924 File Offset: 0x0004DB24
		private void AddMapSearchLocations()
		{
			LevelInfo[] levels = Level.getLevels(ESingleplayerMapCategory.ALL);
			Assets.hasLoadedMaps = true;
			foreach (LevelInfo levelInfo in levels)
			{
				if (levelInfo != null)
				{
					string path = Path.Combine(levelInfo.path, "Bundles");
					if (ReadWrite.folderExists(path, false))
					{
						AssetOrigin origin = Assets.FindOrAddLevelOrigin(levelInfo);
						this.AddSearchLocation(path, origin);
					}
				}
			}
		}

		// Token: 0x06001489 RID: 5257 RVA: 0x0004F97E File Offset: 0x0004DB7E
		private void AddSearchLocation(string path, AssetOrigin origin)
		{
			path = Path.GetFullPath(path);
			UnturnedLog.info(origin.name + " added asset search location \"" + path + "\"");
			this.worker.RequestSearch(path, origin);
		}

		// Token: 0x0600148A RID: 5258 RVA: 0x0004F9B0 File Offset: 0x0004DBB0
		private MasterBundleConfig FindAndRemoveLoadedPendingMasterBundle()
		{
			for (int i = Assets.pendingMasterBundles.Count - 1; i >= 0; i--)
			{
				MasterBundleConfig masterBundleConfig = Assets.pendingMasterBundles[i];
				if (masterBundleConfig.assetBundleCreateRequest.isDone)
				{
					Assets.pendingMasterBundles.RemoveAtFast(i);
					return masterBundleConfig;
				}
			}
			return null;
		}

		// Token: 0x0600148B RID: 5259 RVA: 0x0004F9FB File Offset: 0x0004DBFB
		private IEnumerator LoadAssetsFromWorkerThread()
		{
			double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
			int gcFrameCount = 0;
			while (this.worker.IsWorking || Assets.pendingMasterBundles.Count > 0)
			{
				AssetsWorker.MasterBundle masterBundle;
				if (this.worker.TryDequeueMasterBundle(out masterBundle))
				{
					MasterBundleConfig config = masterBundle.config;
					Assets.pendingMasterBundles.Add(config);
					config.StartLoad(masterBundle.assetBundleData, masterBundle.hash);
					Assets.loadingStats.isLoadingAssetBundles = true;
				}
				else
				{
					AssetsWorker.AssetDefinition file;
					if (Assets.pendingMasterBundles.Count > 0)
					{
						MasterBundleConfig masterBundleConfig = this.FindAndRemoveLoadedPendingMasterBundle();
						if (masterBundleConfig != null)
						{
							masterBundleConfig.FinishLoad();
							Assets.loadingStats.totalMasterBundlesLoaded++;
							if (masterBundleConfig.assetBundle != null)
							{
								if (masterBundleConfig.origin == Assets.coreOrigin)
								{
									Assets.coreMasterBundle = masterBundleConfig;
								}
								Assets.allMasterBundles.Add(masterBundleConfig);
							}
							else
							{
								MasterBundleConfig masterBundleConfig2 = Assets.findMasterBundleByName(masterBundleConfig.assetBundleName, true);
								if (masterBundleConfig2 != null)
								{
									masterBundleConfig.CopyAssetBundleFromDuplicateConfig(masterBundleConfig2);
									if (masterBundleConfig.assetBundle != null)
									{
										UnturnedLog.info(string.Concat(new string[]
										{
											"Using \"",
											masterBundleConfig2.assetBundleName,
											"\" in \"",
											masterBundleConfig2.directoryPath,
											"\" as fallback asset bundle for \"",
											masterBundleConfig.directoryPath,
											"\""
										}));
										Assets.allMasterBundles.Add(masterBundleConfig);
									}
									else
									{
										UnturnedLog.info(string.Concat(new string[]
										{
											"Unable to use \"",
											masterBundleConfig2.assetBundleName,
											"\" in \"",
											masterBundleConfig2.directoryPath,
											"\" as fallback asset bundle for \"",
											masterBundleConfig.directoryPath,
											"\""
										}));
									}
								}
								else
								{
									UnturnedLog.info("Unable to find a fallback asset bundle for \"" + masterBundleConfig.assetBundleName + "\"");
								}
							}
						}
						if (Assets.pendingMasterBundles.Count < 1)
						{
							Assets.loadingStats.isLoadingAssetBundles = false;
						}
					}
					else if (Assets.coreMasterBundle != null && this.worker.TryDequeueAssetDefinition(out file))
					{
						Assets.TryLoadFile(file);
					}
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble > 0.05)
					{
						Assets.SyncAssetDefinitionLoadingProgress();
						int num = gcFrameCount + 1;
						gcFrameCount = num;
						if (gcFrameCount % 25 == 0 && Assets.shouldCollectGarbageAggressively)
						{
							this.CleanupMemory();
						}
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
			}
			yield break;
		}

		// Token: 0x0600148C RID: 5260 RVA: 0x0004FA0C File Offset: 0x0004DC0C
		internal static void SyncAssetDefinitionLoadingProgress()
		{
			Assets.loadingStats.totalRegisteredSearchLocations = Assets.instance.worker.totalSearchLocationRequests;
			Assets.loadingStats.totalSearchLocationsFinishedSearching = Assets.instance.worker.totalSearchLocationsFinishedSearching;
			Assets.loadingStats.totalMasterBundlesFound = Assets.instance.worker.totalMasterBundlesFound;
			Assets.loadingStats.totalFilesFound = Assets.instance.worker.totalAssetDefinitionsFound;
			Assets.loadingStats.totalFilesRead = Assets.instance.worker.totalAssetDefinitionsRead;
			LoadingUI.NotifyAssetDefinitionLoadingProgress();
		}

		// Token: 0x0600148D RID: 5261 RVA: 0x0004FA9B File Offset: 0x0004DC9B
		private IEnumerator LoadAllAssets()
		{
			Assets.isLoadingAllAssets = true;
			double startTime = Time.realtimeSinceStartupAsDouble;
			if (Assets.errors == null)
			{
				Assets.errors = new List<string>();
			}
			else
			{
				Assets.errors.Clear();
			}
			Assets.defaultAssetMapping = new Assets.AssetMapping();
			Assets.currentAssetMapping = Assets.defaultAssetMapping;
			Assets.coreMasterBundle = null;
			if (Assets.allMasterBundles == null)
			{
				Assets.allMasterBundles = new List<MasterBundleConfig>();
				Assets.pendingMasterBundles = new List<MasterBundleConfig>();
			}
			else
			{
				Assets.UnloadAllMasterBundles();
			}
			Assets.assetOrigins = new List<AssetOrigin>();
			Assets.loadingStats.Reset();
			Assets.coreOrigin = new AssetOrigin();
			Assets.coreOrigin.name = "Vanilla Built-in Assets";
			Assets.coreOrigin.canResave = Application.isEditor;
			Assets.assetOrigins.Add(Assets.coreOrigin);
			Assets.reloadOrigin = new AssetOrigin();
			Assets.reloadOrigin.name = "Reloaded Assets (Debug)";
			Assets.reloadOrigin.shouldAssetsOverrideExistingIds = true;
			Assets.assetOrigins.Add(Assets.reloadOrigin);
			Assets.legacyServerSharedOrigin = new AssetOrigin();
			Assets.legacyServerSharedOrigin.name = "Server Common (Legacy)";
			Assets.assetOrigins.Add(Assets.legacyServerSharedOrigin);
			Assets.legacyPerServerOrigin = new AssetOrigin();
			Assets.legacyPerServerOrigin.name = "Per-Server (Legacy)";
			Assets.assetOrigins.Add(Assets.legacyPerServerOrigin);
			yield return null;
			ResourceHash.Initialize();
			if (Assets.shouldLoadAnyAssets)
			{
				this.AddSearchLocation(Path.Combine(ReadWrite.PATH, "Bundles"), Assets.coreOrigin);
				if (Dedicator.IsDedicatedServer)
				{
					this.AddDedicatedServerUgcSearchLocations();
				}
				else
				{
					this.AddClientUgcSearchLocations();
				}
				this.AddSandboxSearchLocations();
				this.AddMapSearchLocations();
				yield return null;
				if (!Dedicator.IsDedicatedServer)
				{
					Provider.initAutoSubscribeMaps();
				}
				yield return this.LoadAssetsFromWorkerThread();
			}
			LoadingUI.SetLoadingText("Loading_Blueprints");
			yield return null;
			if (Assets.shouldValidateAssets)
			{
				this.CheckForBlueprintErrors();
			}
			LoadingUI.SetLoadingText("Loading_Spawns");
			yield return null;
			if (!Dedicator.IsDedicatedServer)
			{
				Assets.linkSpawns();
			}
			if (Assets.shouldValidateAssets)
			{
				this.CheckForNpcErrors();
			}
			this.CleanupMemory();
			if (Assets.shouldResaveAssets && Assets.shouldParseMetadata)
			{
				this.ResaveAssets();
			}
			LoadingUI.SetLoadingText("Loading_Misc");
			yield return null;
			AssetsRefreshed assetsRefreshed = Assets.onAssetsRefreshed;
			if (assetsRefreshed != null)
			{
				assetsRefreshed();
			}
			yield return null;
			UnturnedLog.info(string.Format("Loading all assets took {0}s", Time.realtimeSinceStartupAsDouble - startTime));
			Assets.isLoadingAllAssets = false;
			yield break;
		}

		// Token: 0x0600148E RID: 5262 RVA: 0x0004FAAA File Offset: 0x0004DCAA
		private IEnumerator StartupAssetLoading()
		{
			yield return this.LoadAllAssets();
			Assets.hasFinishedInitialStartupLoading = true;
			if (Dedicator.IsDedicatedServer)
			{
				Provider.host();
			}
			else
			{
				LoadingUI.SetLoadingText("Loading_MainMenu");
				yield return null;
				UnturnedLog.info("Launching main menu");
				SceneManager.LoadScene("Menu");
			}
			yield break;
		}

		// Token: 0x0600148F RID: 5263 RVA: 0x0004FABC File Offset: 0x0004DCBC
		private void ResaveAssets()
		{
			UnturnedLog.info("Re-saving assets!");
			DatWriter datWriter = new DatWriter();
			MetadataPreservingDatWriter metadataPreservingDatWriter = new MetadataPreservingDatWriter();
			foreach (Asset asset in Assets.defaultAssetMapping.assetList)
			{
				if (asset.OriginParsedData != null)
				{
					if (asset.HasErrors)
					{
						UnturnedLog.info(string.Format("Skipping re-saving asset {0} because it loaded with errors and may lose data", asset));
					}
					else
					{
						try
						{
							asset.PreResaveAsset(asset.OriginParsedData);
							using (StreamWriter streamWriter = new StreamWriter(asset.absoluteOriginFilePath, false, Encoding.UTF8))
							{
								datWriter.SetOutput(streamWriter);
								metadataPreservingDatWriter.WriteRootDictionary(asset.OriginParsedData, datWriter);
							}
						}
						catch (Exception e)
						{
							UnturnedLog.exception(e, string.Format("Caught exception re-saving asset {0}", asset));
						}
					}
				}
			}
		}

		// Token: 0x06001490 RID: 5264 RVA: 0x0004FBBC File Offset: 0x0004DDBC
		private IEnumerator LoadNewAssetsFromUpdate()
		{
			Assets.isLoadingFromUpdate = true;
			double startTime = Time.realtimeSinceStartupAsDouble;
			yield return this.LoadAssetsFromWorkerThread();
			Assets.linkSpawnsIfDirty();
			this.CleanupMemory();
			UnturnedLog.info(string.Format("Loading new assets took {0}s", Time.realtimeSinceStartupAsDouble - startTime));
			Assets.isLoadingFromUpdate = false;
			Action onNewAssetsFinishedLoading = Assets.OnNewAssetsFinishedLoading;
			if (onNewAssetsFinishedLoading != null)
			{
				onNewAssetsFinishedLoading();
			}
			yield break;
		}

		/// <summary>
		/// Not the tidiest place for this, but it allows startup to pause and show error message.
		/// Occasionally there have been reports of the steamclient redist files being out of date on the dedicated
		/// server causing problems. For example: https://github.com/SmartlyDressedGames/Unturned-3.x-Community/issues/2866#issuecomment-965945985
		/// </summary>
		// Token: 0x06001491 RID: 5265 RVA: 0x0004FBCC File Offset: 0x0004DDCC
		private bool TestDedicatedServerSteamRedist()
		{
			string text = PathEx.Join(UnityPaths.GameDirectory, "steamclient64.dll");
			if (!File.Exists(text))
			{
				CommandWindow.LogError("Missing steamclient redist file at: " + text);
				return false;
			}
			bool result;
			try
			{
				FileInfo fileInfo = new FileInfo(text);
				DateTime dateTime = new DateTime(2021, 9, 14, 21, 30, 0, DateTimeKind.Utc);
				if (fileInfo.LastWriteTimeUtc >= dateTime)
				{
					result = true;
				}
				else
				{
					CommandWindow.LogError(string.Format("Out-of-date steamclient redist file (expected: {0} actual: {1})", dateTime, fileInfo.LastWriteTimeUtc));
					result = false;
				}
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, "Unable to get steamclient redist file info");
				result = false;
			}
			return result;
		}

		// Token: 0x06001492 RID: 5266 RVA: 0x0004FC78 File Offset: 0x0004DE78
		private void Start()
		{
			if (Dedicator.IsDedicatedServer)
			{
				Module moduleByName = ModuleHook.getModuleByName("Rocket.Unturned");
				if (moduleByName != null)
				{
					uint uint32FromIP = Parser.getUInt32FromIP("4.9.3.1");
					if (moduleByName.config.Version_Internal < uint32FromIP)
					{
						CommandWindow.LogError("Upgrading to the officially maintained version of Rocket, or a custom fork of it, is required.");
						CommandWindow.LogErrorFormat("Installed version: {0} Maintained version: 4.9.3.3+", new object[]
						{
							moduleByName.config.Version
						});
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("--- Overview ---");
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("SDG maintains a fork of Rocket called the Legally Distinct Missile (or LDM) after the resignation of its original community team. Using this fork is important because it preserves compatibility, and has fixes for important legacy Rocket issues like multithreading exceptions and teleportation exploits.");
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("--- Installation ---");
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("The dedicated server includes the latest version, so an external download is not necessary:");
						CommandWindow.Log("1. Copy the Rocket.Unturned module from the game's Extras directory.");
						CommandWindow.Log("2. Paste it into the game's Modules directory.");
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("--- Resources ---");
						CommandWindow.Log(string.Empty);
						CommandWindow.Log("https://github.com/SmartlyDressedGames/Legally-Distinct-Missile");
						CommandWindow.Log("https://www.reddit.com/r/UnturnedLDM/");
						CommandWindow.Log("https://steamcommunity.com/app/304930/discussions/17/");
						return;
					}
				}
				CommandWindow.LogError("Hosting dedicated servers using client files has been deprecated since June 2019.");
				CommandWindow.Log("Please use the standalone dedicated server app ID 1110390 available through SteamCMD instead.");
				CommandWindow.Log("For more information and an installation guide read more at:");
				CommandWindow.Log("https://docs.smartlydressedgames.com/en/stable/servers/server-hosting.html");
				return;
			}
			this.worker = new AssetsWorker();
			this.worker.Initialize();
			base.StartCoroutine(this.StartupAssetLoading());
		}

		// Token: 0x06001493 RID: 5267 RVA: 0x0004FDD1 File Offset: 0x0004DFD1
		private void Awake()
		{
			Assets.instance = this;
		}

		// Token: 0x06001494 RID: 5268 RVA: 0x0004FDD9 File Offset: 0x0004DFD9
		private void Update()
		{
			this.worker.Update();
			if (!Assets.isLoading && this.worker.IsWorking)
			{
				base.StartCoroutine(this.LoadNewAssetsFromUpdate());
			}
		}

		// Token: 0x06001495 RID: 5269 RVA: 0x0004FE07 File Offset: 0x0004E007
		private void OnDestroy()
		{
			this.worker.Shutdown();
		}

		// Token: 0x06001496 RID: 5270 RVA: 0x0004FE14 File Offset: 0x0004E014
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveKickForInvalidGuid(Guid guid)
		{
			Provider._connectionFailureInfo = ESteamConnectionFailureInfo.CUSTOM;
			Asset asset = Assets.find(guid);
			if (asset != null)
			{
				Provider._connectionFailureReason = string.Format("Server missing asset: \"{0}\" File: \"{1}\" Id: {2:N}", asset.FriendlyName, asset.name, guid) + "\nFile path: \"" + asset.absoluteOriginFilePath + "\"" + "\nClient asset is from " + asset.GetOriginName() + ".";
			}
			else
			{
				Provider._connectionFailureReason = "Client and server are both missing unknown asset! ID: " + guid.ToString("N") + "\nThis probably means either an invalid ID was sent by the server," + "\nthe ID got corrupted for example by plugins modifying network traffic," + "\nor a required level asset like materials/foliage/trees/objects is missing.";
			}
			Provider.RequestDisconnect(string.Format("Kicked for sending invalid asset guid: {0:N}", guid));
		}

		// Token: 0x06001497 RID: 5271 RVA: 0x0004FED0 File Offset: 0x0004E0D0
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveKickForHashMismatch(Guid guid, string serverName, string serverFriendlyName, byte[] serverHash, string serverAssetBundleNameWithoutExtension, string serverAssetOrigin)
		{
			Asset asset = Assets.find(guid);
			bool flag;
			if (asset != null)
			{
				AssetOrigin origin = asset.origin;
				string text = (origin != null) ? origin.name : null;
				if (string.IsNullOrEmpty(text))
				{
					text = "Unknown";
				}
				string text2;
				if (string.Equals(asset.name, serverName) && string.Equals(asset.FriendlyName, serverFriendlyName))
				{
					if (!string.IsNullOrEmpty(serverAssetBundleNameWithoutExtension) && asset.originMasterBundle != null && !string.Equals(asset.originMasterBundle.assetBundleNameWithoutExtension, serverAssetBundleNameWithoutExtension))
					{
						text2 = string.Format("Client and server loaded \"{0}\" from different asset bundles! (File: \"{1}\" ID: {2:N})", serverFriendlyName, asset.name, guid);
						text2 = string.Concat(new string[]
						{
							text2,
							"\nClient asset bundle is \"",
							asset.originMasterBundle.assetBundleNameWithoutExtension,
							"\", whereas server asset bundle is \"",
							serverAssetBundleNameWithoutExtension,
							"\"."
						});
						flag = true;
					}
					else if (!string.IsNullOrEmpty(serverAssetBundleNameWithoutExtension) && asset.originMasterBundle == null)
					{
						text2 = string.Format("Client loaded \"{0}\" from legacy asset bundle but server did not! (File: \"{1}\" ID: {2:N})", serverFriendlyName, asset.name, guid);
						text2 = text2 + "\nServer asset bundle name: \"" + serverAssetBundleNameWithoutExtension + "\".";
						flag = true;
					}
					else if (string.IsNullOrEmpty(serverAssetBundleNameWithoutExtension) && asset.originMasterBundle != null)
					{
						text2 = string.Format("Server loaded \"{0}\" from legacy asset bundle but client did not! (File: \"{1}\" ID: {2:N})", serverFriendlyName, asset.name, guid);
						text2 = text2 + "\nClient asset bundle name: \"" + asset.originMasterBundle.assetBundleNameWithoutExtension + "\"";
						flag = true;
					}
					else if (Hash.verifyHash(asset.hash, serverHash))
					{
						text2 = string.Format("Server asset bundle hash out of date for \"{0}\"! (File: \"{1}\" ID: {2:N})", serverFriendlyName, asset.name, guid);
						text2 = text2 + "\nThis probably means the mod creator should re-export the \"" + serverAssetBundleNameWithoutExtension + "\" asset bundle.";
						flag = false;
					}
					else
					{
						text2 = string.Format("Client and server disagree on asset \"{0}\" configuration. (File: \"{1}\" ID: {2:N})", asset.FriendlyName, asset.name, guid);
						text2 += "\nUsually this means the files are different versions in which case updating the client and server might fix it.";
						text2 += "\nAlternatively the file may have been corrupted, locally modified, or modified on the server.";
						text2 = string.Concat(new string[]
						{
							text2,
							"\nClient hash is ",
							Hash.toString(asset.hash),
							", whereas server hash is ",
							Hash.toString(serverHash),
							"."
						});
						flag = true;
					}
				}
				else
				{
					text2 = string.Format("Client and server have different assets with the same ID! ({0:N})", guid);
					text2 += "\nThis probably means an existing file was copied, but the mod creator can fix it by changing the ID.";
					if (string.Equals(asset.FriendlyName, serverFriendlyName))
					{
						text2 = text2 + "\nDisplay name \"" + serverFriendlyName + "\" matches between client and server.";
					}
					else
					{
						text2 = string.Concat(new string[]
						{
							text2,
							"\nClient display name is \"",
							asset.FriendlyName,
							"\", whereas server display name is \"",
							serverFriendlyName,
							"\"."
						});
					}
					if (string.Equals(asset.name, serverName))
					{
						text2 = text2 + "\nFile name \"" + asset.name + "\" matches between client and server.";
					}
					else
					{
						text2 = string.Concat(new string[]
						{
							text2,
							"\nClient file name is \"",
							asset.name,
							"\", whereas server file name is \"",
							serverName,
							"\"."
						});
					}
					flag = true;
				}
				if (string.Equals(text, serverAssetOrigin))
				{
					text2 = text2 + "\nClient and server agree this asset is from " + text + ".";
				}
				else
				{
					text2 = string.Concat(new string[]
					{
						text2,
						"\nClient asset is from ",
						text,
						", whereas server asset is from ",
						serverAssetOrigin,
						"."
					});
				}
				Provider._connectionFailureReason = text2;
			}
			else
			{
				Provider._connectionFailureReason = string.Format("Unknown asset hash mismatch? (should never happen) Name: \"{0}\" File: \"{1}\" Id: {2:N}", serverFriendlyName, serverName, guid);
				flag = true;
			}
			Provider._connectionFailureInfo = (flag ? ESteamConnectionFailureInfo.CUSTOM_SHOULD_VERIFY_GAME_FILES : ESteamConnectionFailureInfo.CUSTOM);
			Provider.RequestDisconnect(string.Format("Kicked for asset hash mismatch guid: {0:N} serverName: \"{1}\" serverFriendlyName: \"{2}\" serverHash: {3} serverAssetBundleName: \"{4}\" serverAssetOrigin: \"{5}\"", new object[]
			{
				guid,
				serverName,
				serverFriendlyName,
				Hash.toString(serverHash),
				serverAssetBundleNameWithoutExtension,
				serverAssetOrigin
			}));
		}

		// Token: 0x06001498 RID: 5272 RVA: 0x0005027F File Offset: 0x0004E47F
		[Obsolete("Renamed to RequestAddSearchLocation")]
		public static void load(string absoluteDirectoryPath, AssetOrigin origin, bool overrideExistingIDs)
		{
			Assets.RequestAddSearchLocation(absoluteDirectoryPath, origin);
		}

		// Token: 0x06001499 RID: 5273 RVA: 0x00050288 File Offset: 0x0004E488
		[Obsolete("Renamed to RequestReloadAllAssets")]
		public static void refresh()
		{
			Assets.RequestReloadAllAssets();
		}

		// Token: 0x0600149A RID: 5274 RVA: 0x0005028F File Offset: 0x0004E48F
		[Obsolete]
		public static void rename(Asset asset, string newName)
		{
		}

		// Token: 0x0600149B RID: 5275 RVA: 0x00050294 File Offset: 0x0004E494
		[Obsolete]
		public static AssetOrigin ConvertLegacyOrigin(EAssetOrigin legacyOrigin)
		{
			if (legacyOrigin == EAssetOrigin.OFFICIAL)
			{
				if (Assets.legacyOfficialOrigin == null)
				{
					Assets.legacyOfficialOrigin = new AssetOrigin();
					Assets.legacyOfficialOrigin.name = "Official (Legacy)";
					Assets.assetOrigins.Add(Assets.legacyOfficialOrigin);
				}
				return Assets.legacyOfficialOrigin;
			}
			if (legacyOrigin == EAssetOrigin.MISC)
			{
				if (Assets.legacyMiscOrigin == null)
				{
					Assets.legacyMiscOrigin = new AssetOrigin();
					Assets.legacyMiscOrigin.name = "Misc (Legacy)";
					Assets.assetOrigins.Add(Assets.legacyMiscOrigin);
				}
				return Assets.legacyMiscOrigin;
			}
			if (Assets.legacyWorkshopOrigin == null)
			{
				Assets.legacyWorkshopOrigin = new AssetOrigin();
				Assets.legacyWorkshopOrigin.name = "Workshop File (Legacy)";
				Assets.assetOrigins.Add(Assets.legacyWorkshopOrigin);
			}
			return Assets.legacyWorkshopOrigin;
		}

		// Token: 0x0600149C RID: 5276 RVA: 0x00050346 File Offset: 0x0004E546
		[Obsolete]
		public static Asset find(EAssetType type, string name)
		{
			return null;
		}

		// Token: 0x0600149D RID: 5277 RVA: 0x00050349 File Offset: 0x0004E549
		[Obsolete]
		public static void add(Asset asset, bool overrideExistingID)
		{
			Assets.AddToMapping(asset, overrideExistingID, Assets.defaultAssetMapping);
		}

		// Token: 0x0600149E RID: 5278 RVA: 0x00050357 File Offset: 0x0004E557
		[Obsolete]
		public static void load(string path, bool usePath, bool loadFromResources, bool canUse, EAssetOrigin origin, bool overrideExistingIDs)
		{
			Assets.load(path, usePath, loadFromResources, canUse, origin, overrideExistingIDs, 0UL);
		}

		// Token: 0x0600149F RID: 5279 RVA: 0x00050368 File Offset: 0x0004E568
		[Obsolete("Remove unused loadFromResources which was used by vanilla assets before masterbundles, and canUse which was for timed curated maps.")]
		public static void load(string path, bool usePath, bool loadFromResources, bool canUse, EAssetOrigin origin, bool overrideExistingIDs, ulong workshopFileId)
		{
			Assets.load(path, usePath, origin, overrideExistingIDs, workshopFileId);
		}

		// Token: 0x060014A0 RID: 5280 RVA: 0x00050378 File Offset: 0x0004E578
		[Obsolete("Replaced origin enum with class")]
		public static void load(string path, bool usePath, EAssetOrigin legacyOrigin, bool overrideExistingIDs, ulong workshopFileId)
		{
			if (usePath)
			{
				path = ReadWrite.PATH + path;
			}
			AssetOrigin origin = Assets.ConvertLegacyOrigin(legacyOrigin);
			Assets.load(path, origin, overrideExistingIDs);
		}

		// Token: 0x060014A1 RID: 5281 RVA: 0x000503A4 File Offset: 0x0004E5A4
		[Obsolete("Please use the method which takes a List instead.")]
		public static Asset[] find(EAssetType type)
		{
			if (type == EAssetType.NONE)
			{
				return null;
			}
			if (type == EAssetType.OBJECT)
			{
				throw new NotSupportedException();
			}
			Asset[] array = new Asset[Assets.currentAssetMapping.legacyAssetsTable[type].Values.Count];
			int num = 0;
			foreach (KeyValuePair<ushort, Asset> keyValuePair in Assets.currentAssetMapping.legacyAssetsTable[type])
			{
				array[num] = keyValuePair.Value;
				num++;
			}
			return array;
		}

		// Token: 0x060014A2 RID: 5282 RVA: 0x0005043C File Offset: 0x0004E63C
		[Obsolete("Renamed to ReportError with an IAssetErrorContext parameter")]
		public static void reportError(Asset offendingAsset, string error)
		{
			Assets.reportError(offendingAsset, error);
		}

		// Token: 0x060014A3 RID: 5283 RVA: 0x00050448 File Offset: 0x0004E648
		[Obsolete("Renamed to ReportError with an IAssetErrorContext parameter")]
		public static void reportError(Asset offendingAsset, string format, params object[] args)
		{
			string error = string.Format(format, args);
			Assets.reportError(offendingAsset, error);
		}

		// Token: 0x060014A4 RID: 5284 RVA: 0x00050464 File Offset: 0x0004E664
		[Obsolete("Renamed to ReportError with an IAssetErrorContext parameter")]
		public static void reportError(Asset offendingAsset, string format, object arg0)
		{
			string error = string.Format(format, arg0);
			Assets.reportError(offendingAsset, error);
		}

		// Token: 0x060014A5 RID: 5285 RVA: 0x00050480 File Offset: 0x0004E680
		[Obsolete("Renamed to ReportError with an IAssetErrorContext parameter")]
		public static void reportError(Asset offendingAsset, string format, object arg0, object arg1)
		{
			string error = string.Format(format, arg0, arg1);
			Assets.reportError(offendingAsset, error);
		}

		// Token: 0x060014A6 RID: 5286 RVA: 0x000504A0 File Offset: 0x0004E6A0
		[Obsolete("Renamed to ReportError with an IAssetErrorContext parameter")]
		public static void reportError(Asset offendingAsset, string format, object arg0, object arg1, object arg2)
		{
			string error = string.Format(format, arg0, arg1, arg2);
			Assets.reportError(offendingAsset, error);
		}

		// Token: 0x04000728 RID: 1832
		private static TypeRegistryDictionary _assetTypes = new TypeRegistryDictionary(typeof(Asset));

		// Token: 0x04000729 RID: 1833
		private static TypeRegistryDictionary _useableTypes = new TypeRegistryDictionary(typeof(Useable));

		// Token: 0x0400072A RID: 1834
		private static Assets instance;

		/// <summary>
		/// The first time asset loading finishes it will load the main menu.
		/// </summary>
		// Token: 0x0400072B RID: 1835
		private static bool hasFinishedInitialStartupLoading;

		/// <summary>
		/// If true, either loading during initial startup or full refresh.
		/// </summary>
		// Token: 0x0400072C RID: 1836
		private static bool isLoadingAllAssets;

		/// <summary>
		/// If true, currently searching locations added after initial startup loading.
		/// </summary>
		// Token: 0x0400072D RID: 1837
		private static bool isLoadingFromUpdate;

		// Token: 0x04000730 RID: 1840
		public static AssetsRefreshed onAssetsRefreshed;

		// Token: 0x04000731 RID: 1841
		internal static Action OnNewAssetsFinishedLoading;

		// Token: 0x04000732 RID: 1842
		internal static Assets.AssetMapping defaultAssetMapping;

		/// <summary>
		/// In singleplayer and the level editor this is the same as defaultAssetMapping,
		/// but when playing on a server a subset of assets based on the server's workshop files is used.
		/// </summary>
		// Token: 0x04000733 RID: 1843
		private static Assets.AssetMapping currentAssetMapping;

		/// <summary>
		/// Should folders be scanned for and load .dat and asset bundle files?
		/// Plugin developers find it useful to quickly launch the server.
		/// </summary>
		// Token: 0x04000734 RID: 1844
		public static CommandLineFlag shouldLoadAnyAssets = new CommandLineFlag(true, "-SkipAssets");

		/// <summary>
		/// Do we want to enable shouldDeferLoadingAssets?
		/// </summary>
		// Token: 0x04000735 RID: 1845
		public static CommandLineFlag wantsDeferLoadingAssets = new CommandLineFlag(true, "-NoDeferAssets");

		/// <summary>
		/// Should extra validation be performed on assets as they load?
		/// Useful for developing, but it does slow down loading.
		/// </summary>
		// Token: 0x04000736 RID: 1846
		public static CommandLineFlag shouldValidateAssets = new CommandLineFlag(false, "-ValidateAssets");

		/// <summary>
		/// Should asset file metadata such as line numbers and comments be parsed?
		/// Useful for development (e.g., error messages), but may slow down loading and increases RAM usage.
		/// </summary>
		// Token: 0x04000737 RID: 1847
		public static CommandLineFlag shouldParseMetadata = new CommandLineFlag(false, "-ParseAssetMetadata");

		/// <summary>
		/// Should asset files be re-saved after all loading is finished?
		/// Requires asset metadata. Useful for automatically upgrading .dat/.asset files.
		/// </summary>
		// Token: 0x04000738 RID: 1848
		public static CommandLineFlag shouldResaveAssets = new CommandLineFlag(false, "-ResaveAssets");

		/// <summary>
		/// Should workshop asset names and IDs be logged while loading?
		/// Useful when debugging unknown workshop content.
		/// </summary>
		// Token: 0x04000739 RID: 1849
		public static CommandLineFlag shouldLogWorkshopAssets = new CommandLineFlag(false, "-LogWorkshopAssets");

		/// <summary>
		/// Should GC and clear unused assets be called after every loading frame?
		/// Potentially useful for players running out of RAM, refer to:
		/// https://github.com/SmartlyDressedGames/Unturned-3.x-Community/issues/1352#issuecomment-751138105
		/// </summary>
		// Token: 0x0400073A RID: 1850
		private static CommandLineFlag shouldCollectGarbageAggressively = new CommandLineFlag(false, "-AggressiveGC");

		/// <summary>
		/// Should modded spawn tables being inserted into parents be logged?
		/// Useful for debugging workshop spawn table problems.
		/// </summary>
		// Token: 0x0400073B RID: 1851
		private static CommandLineFlag shouldLogSpawnInsertions = new CommandLineFlag(false, "-LogSpawnInsertions");

		/// <summary>
		/// Loaded master bundles.
		/// </summary>
		// Token: 0x0400073C RID: 1852
		private static List<MasterBundleConfig> allMasterBundles;

		/// <summary>
		/// Loading master bundles.
		/// </summary>
		// Token: 0x0400073D RID: 1853
		private static List<MasterBundleConfig> pendingMasterBundles;

		/// <summary>
		/// Master bundle from root /Bundles directory containing vanilla assets.
		/// </summary>
		// Token: 0x0400073E RID: 1854
		private static MasterBundleConfig coreMasterBundle;

		/// <summary>
		/// While an asset is being loaded, this is the asset.
		/// Used by some error logging.
		/// Note: not ideal because any global state like this prevents parallelization.
		/// </summary>
		// Token: 0x04000740 RID: 1856
		internal static Asset currentAsset;

		// Token: 0x04000741 RID: 1857
		internal static List<AssetOrigin> assetOrigins;

		// Token: 0x04000742 RID: 1858
		internal static AssetOrigin coreOrigin;

		// Token: 0x04000743 RID: 1859
		internal static AssetOrigin reloadOrigin;

		// Token: 0x04000744 RID: 1860
		private static AssetOrigin legacyServerSharedOrigin;

		// Token: 0x04000745 RID: 1861
		private static AssetOrigin legacyPerServerOrigin;

		// Token: 0x04000746 RID: 1862
		private static List<string> errors;

		/// <summary>
		/// Do we have any new spawn assets that have not been linked yet?
		/// Used to skip linking spawns if not required when downloading assets.
		/// </summary>
		// Token: 0x04000747 RID: 1863
		private static bool hasUnlinkedSpawns;

		// Token: 0x04000748 RID: 1864
		internal static readonly ClientStaticMethod<Guid> SendKickForInvalidGuid = ClientStaticMethod<Guid>.Get(new ClientStaticMethod<Guid>.ReceiveDelegate(Assets.ReceiveKickForInvalidGuid));

		// Token: 0x04000749 RID: 1865
		internal static readonly ClientStaticMethod<Guid, string, string, byte[], string, string> SendKickForHashMismatch = ClientStaticMethod<Guid, string, string, byte[], string, string>.Get(new ClientStaticMethod<Guid, string, string, byte[], string, string>.ReceiveDelegate(Assets.ReceiveKickForHashMismatch));

		// Token: 0x0400074A RID: 1866
		internal static AssetLoadingStats loadingStats = new AssetLoadingStats();

		// Token: 0x0400074B RID: 1867
		private AssetsWorker worker;

		// Token: 0x0400074C RID: 1868
		internal static AssetOrigin legacyOfficialOrigin;

		// Token: 0x0400074D RID: 1869
		internal static AssetOrigin legacyMiscOrigin;

		// Token: 0x0400074E RID: 1870
		internal static AssetOrigin legacyWorkshopOrigin;

		// Token: 0x020009B5 RID: 2485
		internal class AssetMapping
		{
			// Token: 0x0600531C RID: 21276 RVA: 0x001F6860 File Offset: 0x001F4A60
			public AssetMapping()
			{
				this.legacyAssetsTable = new Dictionary<EAssetType, Dictionary<ushort, Asset>>();
				this.legacyAssetsTable.Add(EAssetType.ITEM, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.EFFECT, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.OBJECT, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.RESOURCE, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.VEHICLE, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.ANIMAL, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.MYTHIC, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.SKIN, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.SPAWN, new Dictionary<ushort, Asset>());
				this.legacyAssetsTable.Add(EAssetType.NPC, new Dictionary<ushort, Asset>());
				this.assetDictionary = new Dictionary<Guid, Asset>();
				this.assetList = new List<Asset>();
				this.modificationCounter = 0;
			}

			/// <summary>
			/// Calling this "legacy" is a bit of a stretch because even most of the vanilla assets are
			/// built around the 16-bit IDs. Ideally no new code should be relying on 16-bit IDs however.
			/// </summary>
			// Token: 0x04003792 RID: 14226
			public Dictionary<EAssetType, Dictionary<ushort, Asset>> legacyAssetsTable;

			// Token: 0x04003793 RID: 14227
			public Dictionary<Guid, Asset> assetDictionary;

			// Token: 0x04003794 RID: 14228
			public List<Asset> assetList;

			/// <summary>
			/// Incremented when assets are added or removed.
			/// Used by boombox UI to only refresh songs list if assets have changed.
			/// </summary>
			// Token: 0x04003795 RID: 14229
			public int modificationCounter;
		}
	}
}
