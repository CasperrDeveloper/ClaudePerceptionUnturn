﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	/// <summary>
	/// When placing structures that snap to grid multiple requests can come
	/// in to the server at the same time, and checking overlaps against structures
	/// can be problematic, so as a backup we track pending build requests
	/// and cancel ones which conflict.
	/// </summary>
	// Token: 0x020005A1 RID: 1441
	public class BuildRequestManager
	{
		/// <summary>
		/// Register a location as having something built there soon.
		/// </summary>
		/// <returns>Unique handle to later finish the request.</returns>
		// Token: 0x06003050 RID: 12368 RVA: 0x000DF3C4 File Offset: 0x000DD5C4
		public static int registerPendingBuild(Vector3 location)
		{
			BuildRequestManager.PendingBuild pendingBuild = default(BuildRequestManager.PendingBuild);
			pendingBuild.handle = BuildRequestManager.getUniqueHandle();
			pendingBuild.location = location;
			BuildRequestManager.pendingBuilds.Add(pendingBuild);
			return pendingBuild.handle;
		}

		/// <summary>
		/// Is a location available to build at (i.e. no pending builds)?
		/// </summary>
		/// <returns>False if there are any outstanding build requests for given location.</returns>
		// Token: 0x06003051 RID: 12369 RVA: 0x000DF400 File Offset: 0x000DD600
		public static bool canBuildAt(Vector3 location, int ignoreHandle)
		{
			foreach (BuildRequestManager.PendingBuild pendingBuild in BuildRequestManager.pendingBuilds)
			{
				if ((pendingBuild.location - location).sqrMagnitude < 0.01f && pendingBuild.handle != ignoreHandle)
				{
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// Notify that a previously registered build has been completed.
		/// </summary>
		/// <param name="handle">Unique handle.</param>
		// Token: 0x06003052 RID: 12370 RVA: 0x000DF478 File Offset: 0x000DD678
		public static void finishPendingBuild(ref int handle)
		{
			if (!BuildRequestManager.isValidHandle(handle))
			{
				return;
			}
			int count = BuildRequestManager.pendingBuilds.Count;
			for (int i = 0; i < count; i++)
			{
				if (BuildRequestManager.pendingBuilds[i].handle == handle)
				{
					BuildRequestManager.pendingBuilds.RemoveAtFast(i);
					handle = -1;
					return;
				}
			}
			handle = -1;
		}

		// Token: 0x06003053 RID: 12371 RVA: 0x000DF4CC File Offset: 0x000DD6CC
		public static bool isValidHandle(int handle)
		{
			return handle > 0;
		}

		// Token: 0x06003054 RID: 12372 RVA: 0x000DF4D2 File Offset: 0x000DD6D2
		private static int getUniqueHandle()
		{
			BuildRequestManager.highestHandleId++;
			return BuildRequestManager.highestHandleId;
		}

		// Token: 0x04001982 RID: 6530
		private static List<BuildRequestManager.PendingBuild> pendingBuilds = new List<BuildRequestManager.PendingBuild>();

		// Token: 0x04001983 RID: 6531
		private static int highestHandleId;

		// Token: 0x02000A24 RID: 2596
		private struct PendingBuild
		{
			// Token: 0x0400392D RID: 14637
			public int handle;

			// Token: 0x0400392E RID: 14638
			public Vector3 location;
		}
	}
}
