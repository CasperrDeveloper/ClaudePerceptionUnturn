﻿using System;
using System.Collections;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020007E4 RID: 2020
	public class CarepackageDestroy : MonoBehaviour
	{
		// Token: 0x06004515 RID: 17685 RVA: 0x0015F954 File Offset: 0x0015DB54
		private IEnumerator cleanup()
		{
			yield return new WaitForSeconds(600f);
			BarricadeManager.damage(base.transform, 65000f, 1f, false, default(CSteamID), EDamageOrigin.Carepackage_Timeout);
			yield break;
		}

		// Token: 0x06004516 RID: 17686 RVA: 0x0015F963 File Offset: 0x0015DB63
		private void Start()
		{
			base.StartCoroutine("cleanup");
		}
	}
}
