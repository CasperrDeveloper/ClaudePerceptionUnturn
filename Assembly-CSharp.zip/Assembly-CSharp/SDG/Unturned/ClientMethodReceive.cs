﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000257 RID: 599
	// (Invoke) Token: 0x06001275 RID: 4725
	public delegate void ClientMethodReceive(in ClientInvocationContext context);
}
