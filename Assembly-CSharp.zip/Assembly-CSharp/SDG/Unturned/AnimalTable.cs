﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004FA RID: 1274
	public class AnimalTable
	{
		// Token: 0x1700086F RID: 2159
		// (get) Token: 0x060029BF RID: 10687 RVA: 0x000B49BC File Offset: 0x000B2BBC
		public List<AnimalTier> tiers
		{
			get
			{
				return this._tiers;
			}
		}

		// Token: 0x17000870 RID: 2160
		// (get) Token: 0x060029C0 RID: 10688 RVA: 0x000B49C4 File Offset: 0x000B2BC4
		// (set) Token: 0x060029C1 RID: 10689 RVA: 0x000B49CC File Offset: 0x000B2BCC
		public Color color
		{
			get
			{
				return this._color;
			}
			set
			{
				this._color = value;
				ushort num = 0;
				while ((int)num < LevelAnimals.spawns.Count)
				{
					AnimalSpawnpoint animalSpawnpoint = LevelAnimals.spawns[(int)num];
					if (animalSpawnpoint.type == EditorSpawns.selectedAnimal)
					{
						animalSpawnpoint.node.GetComponent<Renderer>().material.color = this.color;
					}
					num += 1;
				}
				EditorSpawns.animalSpawn.GetComponent<Renderer>().material.color = this.color;
			}
		}

		// Token: 0x060029C2 RID: 10690 RVA: 0x000B4A44 File Offset: 0x000B2C44
		public void addTier(string name)
		{
			if (this.tiers.Count == 255)
			{
				return;
			}
			for (int i = 0; i < this.tiers.Count; i++)
			{
				if (this.tiers[i].name == name)
				{
					return;
				}
			}
			if (this.tiers.Count == 0)
			{
				this.tiers.Add(new AnimalTier(new List<AnimalSpawn>(), name, 1f));
				return;
			}
			this.tiers.Add(new AnimalTier(new List<AnimalSpawn>(), name, 0f));
		}

		// Token: 0x060029C3 RID: 10691 RVA: 0x000B4AD8 File Offset: 0x000B2CD8
		public void removeTier(int tierIndex)
		{
			this.updateChance(tierIndex, 0f);
			this.tiers.RemoveAt(tierIndex);
		}

		// Token: 0x060029C4 RID: 10692 RVA: 0x000B4AF2 File Offset: 0x000B2CF2
		public void addAnimal(byte tierIndex, ushort id)
		{
			this.tiers[(int)tierIndex].addAnimal(id);
		}

		// Token: 0x060029C5 RID: 10693 RVA: 0x000B4B06 File Offset: 0x000B2D06
		public void removeAnimal(byte tierIndex, byte animalIndex)
		{
			this.tiers[(int)tierIndex].removeAnimal(animalIndex);
		}

		// Token: 0x060029C6 RID: 10694 RVA: 0x000B4B1C File Offset: 0x000B2D1C
		public ushort getAnimal()
		{
			if (this.tableID != 0)
			{
				return SpawnTableTool.ResolveLegacyId(this.tableID, EAssetType.ANIMAL, new Func<string>(this.OnGetSpawnTableErrorContext));
			}
			float value = UnityEngine.Random.value;
			if (this.tiers.Count == 0)
			{
				return 0;
			}
			int i = 0;
			while (i < this.tiers.Count)
			{
				if (value < this.tiers[i].chance)
				{
					AnimalTier animalTier = this.tiers[i];
					if (animalTier.table.Count > 0)
					{
						return animalTier.table[UnityEngine.Random.Range(0, animalTier.table.Count)].animal;
					}
					return 0;
				}
				else
				{
					i++;
				}
			}
			AnimalTier animalTier2 = this.tiers[UnityEngine.Random.Range(0, this.tiers.Count)];
			if (animalTier2.table.Count > 0)
			{
				return animalTier2.table[UnityEngine.Random.Range(0, animalTier2.table.Count)].animal;
			}
			return 0;
		}

		// Token: 0x060029C7 RID: 10695 RVA: 0x000B4C18 File Offset: 0x000B2E18
		public void buildTable()
		{
			List<AnimalTier> list = new List<AnimalTier>();
			for (int i = 0; i < this.tiers.Count; i++)
			{
				if (list.Count == 0)
				{
					list.Add(this.tiers[i]);
				}
				else
				{
					bool flag = false;
					for (int j = 0; j < list.Count; j++)
					{
						if (this.tiers[i].chance < list[j].chance)
						{
							flag = true;
							list.Insert(j, this.tiers[i]);
							break;
						}
					}
					if (!flag)
					{
						list.Add(this.tiers[i]);
					}
				}
			}
			float num = 0f;
			for (int k = 0; k < list.Count; k++)
			{
				num += list[k].chance;
				list[k].chance = num;
			}
			this._tiers = list;
		}

		// Token: 0x060029C8 RID: 10696 RVA: 0x000B4D08 File Offset: 0x000B2F08
		public void updateChance(int tierIndex, float chance)
		{
			float num = chance - this.tiers[tierIndex].chance;
			this.tiers[tierIndex].chance = chance;
			if (this.tiers.Count < 2)
			{
				return;
			}
			float num2 = Mathf.Abs(num);
			while (num2 > 0.001f)
			{
				int num3 = 0;
				for (int i = 0; i < this.tiers.Count; i++)
				{
					if (((num < 0f && this.tiers[i].chance < 1f) || (num > 0f && this.tiers[i].chance > 0f)) && i != tierIndex)
					{
						num3++;
					}
				}
				if (num3 == 0)
				{
					break;
				}
				float num4 = num2 / (float)num3;
				for (int j = 0; j < this.tiers.Count; j++)
				{
					if (((num < 0f && this.tiers[j].chance < 1f) || (num > 0f && this.tiers[j].chance > 0f)) && j != tierIndex)
					{
						if (num > 0f)
						{
							if (this.tiers[j].chance >= num4)
							{
								num2 -= num4;
								this.tiers[j].chance -= num4;
							}
							else
							{
								num2 -= this.tiers[j].chance;
								this.tiers[j].chance = 0f;
							}
						}
						else if (this.tiers[j].chance <= 1f - num4)
						{
							num2 -= num4;
							this.tiers[j].chance += num4;
						}
						else
						{
							num2 -= 1f - this.tiers[j].chance;
							this.tiers[j].chance = 1f;
						}
					}
				}
			}
			float num5 = 0f;
			for (int k = 0; k < this.tiers.Count; k++)
			{
				num5 += this.tiers[k].chance;
			}
			for (int l = 0; l < this.tiers.Count; l++)
			{
				this.tiers[l].chance /= num5;
			}
		}

		// Token: 0x060029C9 RID: 10697 RVA: 0x000B4F8E File Offset: 0x000B318E
		public AnimalTable(string newName)
		{
			this._tiers = new List<AnimalTier>();
			this._color = Color.white;
			this.name = newName;
			this.tableID = 0;
		}

		// Token: 0x060029CA RID: 10698 RVA: 0x000B4FBA File Offset: 0x000B31BA
		public AnimalTable(List<AnimalTier> newTiers, Color newColor, string newName, ushort newTableID)
		{
			this._tiers = newTiers;
			this._color = newColor;
			this.name = newName;
			this.tableID = newTableID;
		}

		// Token: 0x060029CB RID: 10699 RVA: 0x000B4FDF File Offset: 0x000B31DF
		private string OnGetSpawnTableErrorContext()
		{
			return string.Concat(new string[]
			{
				"\"",
				Level.info.name,
				"\" animal table \"",
				this.name,
				"\""
			});
		}

		// Token: 0x060029CC RID: 10700 RVA: 0x000B501A File Offset: 0x000B321A
		internal string OnGetSpawnTableValidationErrorContext()
		{
			return string.Concat(new string[]
			{
				"\"",
				Level.info.name,
				"\" animal table \"",
				this.name,
				"\" validation"
			});
		}

		// Token: 0x04001513 RID: 5395
		private List<AnimalTier> _tiers;

		// Token: 0x04001514 RID: 5396
		private Color _color;

		// Token: 0x04001515 RID: 5397
		public string name;

		// Token: 0x04001516 RID: 5398
		public ushort tableID;
	}
}
