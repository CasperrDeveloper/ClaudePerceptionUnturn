﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005AF RID: 1455
	public class ClaimPlant : ClaimBase
	{
		// Token: 0x060030A8 RID: 12456 RVA: 0x000E05FD File Offset: 0x000DE7FD
		public ClaimPlant(Transform newParent, ulong newOwner, ulong newGroup) : base(newOwner, newGroup)
		{
			this.parent = newParent;
		}

		// Token: 0x040019B9 RID: 6585
		public Transform parent;
	}
}
