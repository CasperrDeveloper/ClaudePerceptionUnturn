﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002AB RID: 683
	public class Bundles : MonoBehaviour
	{
		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x060014DF RID: 5343 RVA: 0x00051917 File Offset: 0x0004FB17
		public static bool isInitialized
		{
			get
			{
				return Bundles._isInitialized;
			}
		}

		// Token: 0x060014E0 RID: 5344 RVA: 0x0005191E File Offset: 0x0004FB1E
		public static Bundle getBundle(string path)
		{
			return Bundles.getBundle(path, true);
		}

		// Token: 0x060014E1 RID: 5345 RVA: 0x00051927 File Offset: 0x0004FB27
		public static Bundle getBundle(string path, bool prependRoot)
		{
			return new Bundle(path, prependRoot, null);
		}

		// Token: 0x060014E2 RID: 5346 RVA: 0x00051931 File Offset: 0x0004FB31
		[Obsolete]
		public static Bundle getBundle(string path, bool prependRoot, bool loadFromResources)
		{
			return Bundles.getBundle(path, prependRoot);
		}

		// Token: 0x060014E3 RID: 5347 RVA: 0x0005193A File Offset: 0x0004FB3A
		private void Awake()
		{
			if (Bundles.isInitialized)
			{
				UnityEngine.Object.Destroy(base.gameObject);
				return;
			}
			Bundles._isInitialized = true;
			UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
		}

		// Token: 0x0400076F RID: 1903
		private static bool _isInitialized;
	}
}
