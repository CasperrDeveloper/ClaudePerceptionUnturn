﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200058F RID: 1423
	public class BarricadeData
	{
		// Token: 0x1700097B RID: 2427
		// (get) Token: 0x06002F29 RID: 12073 RVA: 0x000D9C66 File Offset: 0x000D7E66
		public Barricade barricade
		{
			get
			{
				return this._barricade;
			}
		}

		// Token: 0x1700097C RID: 2428
		// (get) Token: 0x06002F2A RID: 12074 RVA: 0x000D9C6E File Offset: 0x000D7E6E
		// (set) Token: 0x06002F2B RID: 12075 RVA: 0x000D9C76 File Offset: 0x000D7E76
		public uint instanceID { get; private set; }

		// Token: 0x06002F2C RID: 12076 RVA: 0x000D9C7F File Offset: 0x000D7E7F
		public BarricadeData(Barricade newBarricade, Vector3 newPoint, Quaternion newRotation, ulong newOwner, ulong newGroup, uint newObjActiveDate, uint newInstanceID)
		{
			this._barricade = newBarricade;
			this.point = newPoint;
			this.rotation = newRotation;
			this.owner = newOwner;
			this.group = newGroup;
			this.objActiveDate = newObjActiveDate;
			this.instanceID = newInstanceID;
		}

		// Token: 0x06002F2D RID: 12077 RVA: 0x000D9CBC File Offset: 0x000D7EBC
		[Obsolete]
		public BarricadeData(Barricade newBarricade, Vector3 newPoint, byte newAngle_X, byte newAngle_Y, byte newAngle_Z, ulong newOwner, ulong newGroup, uint newObjActiveDate, uint newInstanceID)
		{
			this._barricade = newBarricade;
			this.point = newPoint;
			this.rotation = Quaternion.Euler((float)newAngle_X * 2f, (float)newAngle_Y * 2f, (float)newAngle_Z * 2f);
			this.angle_x = newAngle_X;
			this.angle_y = newAngle_Y;
			this.angle_z = newAngle_Z;
			this.owner = newOwner;
			this.group = newGroup;
			this.objActiveDate = newObjActiveDate;
			this.instanceID = newInstanceID;
		}

		// Token: 0x04001939 RID: 6457
		private Barricade _barricade;

		// Token: 0x0400193A RID: 6458
		public Vector3 point;

		/// <summary>
		/// Note: If barricade is attached to a vehicle this is the local rotation.
		/// </summary>
		// Token: 0x0400193B RID: 6459
		public Quaternion rotation;

		// Token: 0x0400193C RID: 6460
		[Obsolete("Replaced by rotation quaternion, but you should probably not be accessing either of these directly.")]
		public byte angle_x;

		// Token: 0x0400193D RID: 6461
		[Obsolete("Replaced by rotation quaternion, but you should probably not be accessing either of these directly.")]
		public byte angle_y;

		// Token: 0x0400193E RID: 6462
		[Obsolete("Replaced by rotation quaternion, but you should probably not be accessing either of these directly.")]
		public byte angle_z;

		// Token: 0x0400193F RID: 6463
		public ulong owner;

		// Token: 0x04001940 RID: 6464
		public ulong group;

		// Token: 0x04001941 RID: 6465
		public uint objActiveDate;
	}
}
