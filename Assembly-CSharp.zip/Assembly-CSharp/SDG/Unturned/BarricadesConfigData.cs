﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000771 RID: 1905
	public class BarricadesConfigData
	{
		// Token: 0x0600426C RID: 17004 RVA: 0x00149909 File Offset: 0x00147B09
		public float getArmorMultiplier(EArmorTier armorTier)
		{
			if (armorTier == EArmorTier.LOW || armorTier != EArmorTier.HIGH)
			{
				return this.Armor_Lowtier_Multiplier;
			}
			return this.Armor_Hightier_Multiplier;
		}

		// Token: 0x0600426D RID: 17005 RVA: 0x00149920 File Offset: 0x00147B20
		public BarricadesConfigData(EGameMode mode)
		{
			this.Decay_Time = 604800U;
			this.Armor_Lowtier_Multiplier = 1f;
			this.Armor_Hightier_Multiplier = 0.5f;
			this.Gun_Lowcal_Damage_Multiplier = 1f;
			this.Gun_Highcal_Damage_Multiplier = 1f;
			this.Melee_Damage_Multiplier = 1f;
			this.Melee_Repair_Multiplier = 1f;
			this.Allow_Item_Placement_On_Vehicle = true;
			this.Allow_Trap_Placement_On_Vehicle = true;
			this.Max_Item_Distance_From_Hull = 64f;
			this.Max_Trap_Distance_From_Hull = 16f;
		}

		/// <summary>
		/// How long (in seconds) since the barricade owner/group last played before the barricade won't be saved.
		/// If the server is offline for more than half the Decay_Time, all decay timers are reset.
		/// </summary>
		// Token: 0x04002853 RID: 10323
		public uint Decay_Time;

		/// <summary>
		/// Scales the amount of damage taken by "Armor Tier: Low" barricades.
		/// For example, 0.5 halves the amount of damage dealt to barricades.
		/// </summary>
		// Token: 0x04002854 RID: 10324
		public float Armor_Lowtier_Multiplier;

		/// <summary>
		/// Scales the amount of damage taken by "Armor Tier: High" barricades.
		/// For example, 0.5 halves the amount of damage dealt to barricades.
		/// </summary>
		// Token: 0x04002855 RID: 10325
		public float Armor_Hightier_Multiplier;

		/// <summary>
		/// Scales the amount of damage taken by barricades from non-"Heavy Weapon" guns.
		/// For example, 2.0 doubles the amount of damage dealt to barricades by non-"Heavy Weapon" guns.
		/// </summary>
		// Token: 0x04002856 RID: 10326
		public float Gun_Lowcal_Damage_Multiplier;

		/// <summary>
		/// Scales the amount of damage taken by barricades from "Heavy Weapon" guns.
		/// For example, 2.0 doubles the amount of damage dealt to barricades by "Heavy Weapon" guns.
		/// </summary>
		// Token: 0x04002857 RID: 10327
		public float Gun_Highcal_Damage_Multiplier;

		/// <summary>
		/// Scales the amount of damage taken by barricades from melee weapons and fists.
		/// For example, 2.0 doubles the amount of damage dealt to barricades by melee.
		/// </summary>
		// Token: 0x04002858 RID: 10328
		public float Melee_Damage_Multiplier;

		/// <summary>
		/// Scales the amount of HP restored by melee items like the Blowtorch.
		/// For example, 2.0 doubles the amount of health restored by melee items.
		/// </summary>
		// Token: 0x04002859 RID: 10329
		public float Melee_Repair_Multiplier;

		/// <summary>
		/// Should players be allowed to build on their vehicles?
		/// </summary>
		// Token: 0x0400285A RID: 10330
		public bool Allow_Item_Placement_On_Vehicle;

		/// <summary>
		/// Should players be allowed to build traps (e.g. barbed wire) on their vehicles?
		/// </summary>
		// Token: 0x0400285B RID: 10331
		public bool Allow_Trap_Placement_On_Vehicle;

		/// <summary>
		/// Furthest away from colliders a player can build an item onto their vehicle.
		/// </summary>
		// Token: 0x0400285C RID: 10332
		public float Max_Item_Distance_From_Hull;

		/// <summary>
		/// Furthest away from colliders a player can build a trap (e.g. barbed wire) onto their vehicle.
		/// </summary>
		// Token: 0x0400285D RID: 10333
		public float Max_Trap_Distance_From_Hull;
	}
}
