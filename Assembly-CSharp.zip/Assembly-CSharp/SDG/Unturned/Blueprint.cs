﻿using System;
using System.Collections.Generic;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x020004D5 RID: 1237
	public class Blueprint
	{
		/// <summary>
		/// Optional case-sensitive identifier in list of blueprints.
		/// Added as an alternative to referencing blueprints by index.
		/// Defaults to null.
		/// </summary>
		// Token: 0x17000835 RID: 2101
		// (get) Token: 0x060028E2 RID: 10466 RVA: 0x000B1F46 File Offset: 0x000B0146
		// (set) Token: 0x060028E3 RID: 10467 RVA: 0x000B1F4E File Offset: 0x000B014E
		public string Name { get; internal set; }

		// Token: 0x17000836 RID: 2102
		// (get) Token: 0x060028E4 RID: 10468 RVA: 0x000B1F57 File Offset: 0x000B0157
		// (set) Token: 0x060028E5 RID: 10469 RVA: 0x000B1F5F File Offset: 0x000B015F
		public IBlueprintOwner Owner { get; internal set; }

		// Token: 0x060028E6 RID: 10470 RVA: 0x000B1F68 File Offset: 0x000B0168
		public Asset GetOwnerAsset()
		{
			return this.Owner.GetBlueprintOwnerAsset();
		}

		/// <summary>
		/// Index into Owner's blueprints list.
		/// </summary>
		// Token: 0x17000837 RID: 2103
		// (get) Token: 0x060028E7 RID: 10471 RVA: 0x000B1F75 File Offset: 0x000B0175
		public byte Index
		{
			get
			{
				return this.index;
			}
		}

		/// <summary>
		/// Operation replaces the special behavior for EBlueprintType.Ammo and EBlueprintType.Repair.
		/// </summary>
		// Token: 0x17000838 RID: 2104
		// (get) Token: 0x060028E8 RID: 10472 RVA: 0x000B1F7D File Offset: 0x000B017D
		public EBlueprintOperation Operation
		{
			get
			{
				return this._operation;
			}
		}

		/// <summary>
		/// Note: if resolving ref please use GetCategoryTag instead for caching.
		/// </summary>
		// Token: 0x17000839 RID: 2105
		// (get) Token: 0x060028E9 RID: 10473 RVA: 0x000B1F85 File Offset: 0x000B0185
		public CachingAssetRef CategoryTagRef
		{
			get
			{
				return this._categoryTagRef;
			}
		}

		/// <summary>
		/// Category tag replaces the blueprint "Type" which acted as both category AND behaviour modifier.
		/// </summary>
		// Token: 0x060028EA RID: 10474 RVA: 0x000B1F8D File Offset: 0x000B018D
		public TagAsset GetCategoryTag()
		{
			return this._categoryTagRef.Get<TagAsset>();
		}

		// Token: 0x1700083A RID: 2106
		// (get) Token: 0x060028EB RID: 10475 RVA: 0x000B1F9A File Offset: 0x000B019A
		public BlueprintSupply[] supplies
		{
			get
			{
				return this._supplies;
			}
		}

		/// <summary>
		/// Only applicable for operations with a target item.
		///
		/// Nelson 2025-04-11: initially, this was implemented as the last item in supplies list. However, there are a
		/// lot of checks for special handling of target item, so I think it makes sense to separate.
		/// </summary>
		// Token: 0x1700083B RID: 2107
		// (get) Token: 0x060028EC RID: 10476 RVA: 0x000B1FA2 File Offset: 0x000B01A2
		// (set) Token: 0x060028ED RID: 10477 RVA: 0x000B1FAA File Offset: 0x000B01AA
		public BlueprintSupply TargetItem { get; set; }

		// Token: 0x1700083C RID: 2108
		// (get) Token: 0x060028EE RID: 10478 RVA: 0x000B1FB3 File Offset: 0x000B01B3
		public BlueprintOutput[] outputs
		{
			get
			{
				return this._outputs;
			}
		}

		/// <summary>
		/// If not null, these tags must be provided by nearby objects to craft this blueprint.
		/// Note: this is the list as-configured. It has not been filtered according to gameplay config.
		/// </summary>
		// Token: 0x1700083D RID: 2109
		// (get) Token: 0x060028EF RID: 10479 RVA: 0x000B1FBB File Offset: 0x000B01BB
		// (set) Token: 0x060028F0 RID: 10480 RVA: 0x000B1FC3 File Offset: 0x000B01C3
		public CachingAssetRef[] RequiresNearbyCraftingTags { get; internal set; }

		/// <summary>
		/// Not shown in the UI. These tags are checked once per-level-startup.
		/// For example, used to check for "singleplayer" tag or a map-specific tag.
		/// </summary>
		// Token: 0x1700083E RID: 2110
		// (get) Token: 0x060028F1 RID: 10481 RVA: 0x000B1FCC File Offset: 0x000B01CC
		// (set) Token: 0x060028F2 RID: 10482 RVA: 0x000B1FD4 File Offset: 0x000B01D4
		public CachingAssetRef[] RequiresStaticTags { get; set; }

		// Token: 0x060028F3 RID: 10483 RVA: 0x000B1FE0 File Offset: 0x000B01E0
		public CachingAssetRef[] GetApplicableRequiredNearbyCraftingTags()
		{
			if (this.RequiresNearbyCraftingTags == null || this.RequiresNearbyCraftingTags.Length < 1)
			{
				return null;
			}
			ModeConfigData modeConfigData = Provider.modeConfigData;
			bool? flag;
			if (modeConfigData == null)
			{
				flag = null;
			}
			else
			{
				GameplayConfigData gameplay = modeConfigData.Gameplay;
				flag = ((gameplay != null) ? new bool?(gameplay.Enable_Workstation_Requirements) : null);
			}
			if (flag ?? true)
			{
				return this.RequiresNearbyCraftingTags;
			}
			if (!this.hasCheckedForVanillaHeatSourceTag)
			{
				this.hasCheckedForVanillaHeatSourceTag = true;
				CachingAssetRef[] requiresNearbyCraftingTags = this.RequiresNearbyCraftingTags;
				for (int i = 0; i < requiresNearbyCraftingTags.Length; i++)
				{
					if (requiresNearbyCraftingTags[i] == PowerTool.VanillaCraftingHeatTag)
					{
						this.requiresVanillaHeatSourceTag = true;
						break;
					}
				}
			}
			if (!this.requiresVanillaHeatSourceTag)
			{
				return null;
			}
			return Blueprint.onlyVanillaHeatSourceTag;
		}

		// Token: 0x1700083F RID: 2111
		// (get) Token: 0x060028F4 RID: 10484 RVA: 0x000B20A0 File Offset: 0x000B02A0
		public Guid BuildEffectGuid
		{
			get
			{
				return this.effectAssetRef.Guid;
			}
		}

		// Token: 0x060028F5 RID: 10485 RVA: 0x000B20AD File Offset: 0x000B02AD
		public EffectAsset FindBuildEffectAsset()
		{
			return this.effectAssetRef.Get<EffectAsset>();
		}

		// Token: 0x17000840 RID: 2112
		// (get) Token: 0x060028F6 RID: 10486 RVA: 0x000B20BA File Offset: 0x000B02BA
		public byte level
		{
			get
			{
				return this._level;
			}
		}

		// Token: 0x17000841 RID: 2113
		// (get) Token: 0x060028F7 RID: 10487 RVA: 0x000B20C2 File Offset: 0x000B02C2
		// (set) Token: 0x060028F8 RID: 10488 RVA: 0x000B20CA File Offset: 0x000B02CA
		public int SkillSpecialityIndex { get; internal set; } = -1;

		// Token: 0x17000842 RID: 2114
		// (get) Token: 0x060028F9 RID: 10489 RVA: 0x000B20D3 File Offset: 0x000B02D3
		// (set) Token: 0x060028FA RID: 10490 RVA: 0x000B20DB File Offset: 0x000B02DB
		public int SkillIndex { get; internal set; } = -1;

		// Token: 0x060028FB RID: 10491 RVA: 0x000B20E4 File Offset: 0x000B02E4
		public string DebugGetSkillName()
		{
			if (this.RequiresSkill)
			{
				switch (this.SkillSpecialityIndex)
				{
				case 0:
					return ((EPlayerOffense)this.SkillIndex).ToString();
				case 1:
					return ((EPlayerDefense)this.SkillIndex).ToString();
				case 2:
					return ((EPlayerSupport)this.SkillIndex).ToString();
				}
			}
			return null;
		}

		// Token: 0x17000843 RID: 2115
		// (get) Token: 0x060028FC RID: 10492 RVA: 0x000B2154 File Offset: 0x000B0354
		public bool transferState
		{
			get
			{
				return this._transferState;
			}
		}

		// Token: 0x17000844 RID: 2116
		// (get) Token: 0x060028FD RID: 10493 RVA: 0x000B215C File Offset: 0x000B035C
		// (set) Token: 0x060028FE RID: 10494 RVA: 0x000B2164 File Offset: 0x000B0364
		public string map { get; private set; }

		/// <summary>
		/// Must match conditions to craft.
		/// </summary>
		// Token: 0x17000845 RID: 2117
		// (get) Token: 0x060028FF RID: 10495 RVA: 0x000B216D File Offset: 0x000B036D
		public INPCCondition[] questConditions
		{
			get
			{
				return this.questConditionsList.conditions;
			}
		}

		/// <summary>
		/// Extra rewards given after crafting. Not displayed.
		/// </summary>
		// Token: 0x17000846 RID: 2118
		// (get) Token: 0x06002900 RID: 10496 RVA: 0x000B217A File Offset: 0x000B037A
		public INPCReward[] questRewards
		{
			get
			{
				return this.questRewardsList.rewards;
			}
		}

		/// <summary>
		/// Defaults to false. If true, blueprint can become visible in the crafting list even when NPC conditions
		/// are not met. This should typically only be enabled if all conditions are configured to be visible in the
		/// details panel. Otherwise, the default "conditions unmet" label isn't very informative for players.
		/// </summary>
		// Token: 0x17000847 RID: 2119
		// (get) Token: 0x06002901 RID: 10497 RVA: 0x000B2187 File Offset: 0x000B0387
		// (set) Token: 0x06002902 RID: 10498 RVA: 0x000B218F File Offset: 0x000B038F
		public bool CanBeVisibleWithUnmetConditions { get; set; }

		// Token: 0x06002903 RID: 10499 RVA: 0x000B2198 File Offset: 0x000B0398
		public bool areConditionsMet(Player player)
		{
			return this.questConditionsList.AreConditionsMet(player);
		}

		// Token: 0x06002904 RID: 10500 RVA: 0x000B21A6 File Offset: 0x000B03A6
		public void ApplyConditions(Player player)
		{
			this.questConditionsList.ApplyConditions(player);
		}

		// Token: 0x06002905 RID: 10501 RVA: 0x000B21B4 File Offset: 0x000B03B4
		public void GrantRewards(Player player)
		{
			this.questRewardsList.Grant(player);
		}

		// Token: 0x06002906 RID: 10502 RVA: 0x000B21C4 File Offset: 0x000B03C4
		public bool DoesRequireNearbyCraftingTag(TagAsset tag)
		{
			if (tag == null || this.RequiresNearbyCraftingTags == null)
			{
				return false;
			}
			for (int i = 0; i < this.RequiresNearbyCraftingTags.Length; i++)
			{
				if (this.RequiresNearbyCraftingTags[i].IsReferenceTo(tag))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06002907 RID: 10503 RVA: 0x000B2208 File Offset: 0x000B0408
		public int CountOverlappingRequiredNearbyCraftingTags(HashSet<TagAsset> tags)
		{
			if (tags == null || tags.Count < 1 || this.RequiresNearbyCraftingTags.IsNullOrEmpty())
			{
				return 0;
			}
			int num = 0;
			for (int i = 0; i < this.RequiresNearbyCraftingTags.Length; i++)
			{
				TagAsset tagAsset = this.RequiresNearbyCraftingTags[i].Get<TagAsset>();
				if (tagAsset != null && tags.Contains(tagAsset))
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x06002908 RID: 10504 RVA: 0x000B2268 File Offset: 0x000B0468
		public bool ContainsAnyOfItems(HashSet<ItemAsset> availableItems)
		{
			if (this.supplies == null)
			{
				return false;
			}
			BlueprintSupply[] supplies = this.supplies;
			for (int i = 0; i < supplies.Length; i++)
			{
				ItemAsset itemAsset = supplies[i].FindItemAsset();
				if (itemAsset != null && availableItems.Contains(itemAsset))
				{
					return true;
				}
			}
			BlueprintSupply targetItem = this.TargetItem;
			ItemAsset itemAsset2 = (targetItem != null) ? targetItem.FindItemAsset() : null;
			return itemAsset2 != null && availableItems.Contains(itemAsset2);
		}

		/// <summary>
		/// Search output items (excluding target item) for specific item.
		/// </summary>
		// Token: 0x06002909 RID: 10505 RVA: 0x000B22D0 File Offset: 0x000B04D0
		public bool DoesOutputCreateItem(ItemAsset itemAsset)
		{
			if (itemAsset == null || this._outputs == null || this._outputs.Length < 1)
			{
				return false;
			}
			BlueprintOutput[] outputs = this._outputs;
			for (int i = 0; i < outputs.Length; i++)
			{
				if (outputs[i].FindItemAsset() == itemAsset)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x17000848 RID: 2120
		// (get) Token: 0x0600290A RID: 10506 RVA: 0x000B2318 File Offset: 0x000B0518
		internal bool IsOutputFreeformBuildable
		{
			get
			{
				if (this._outputs == null || this._outputs.Length < 1)
				{
					return false;
				}
				BlueprintOutput[] outputs = this._outputs;
				for (int i = 0; i < outputs.Length; i++)
				{
					ItemBarricadeAsset itemBarricadeAsset = outputs[i].FindItemAsset() as ItemBarricadeAsset;
					if (itemBarricadeAsset != null && itemBarricadeAsset.build == EBuild.FREEFORM)
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x17000849 RID: 2121
		// (get) Token: 0x0600290B RID: 10507 RVA: 0x000B236D File Offset: 0x000B056D
		public bool RequiresSkill
		{
			get
			{
				return this.SkillSpecialityIndex >= 0 && this.SkillIndex >= 0 && this.level > 0;
			}
		}

		// Token: 0x0600290C RID: 10508 RVA: 0x000B238C File Offset: 0x000B058C
		public EBlueprintSkill GetLegacyBlueprintSkill()
		{
			if (this.SkillSpecialityIndex == 2)
			{
				if (this.SkillIndex == 1)
				{
					return EBlueprintSkill.CRAFT;
				}
				if (this.SkillIndex == 3)
				{
					return EBlueprintSkill.COOK;
				}
				if (this.SkillIndex == 7)
				{
					return EBlueprintSkill.REPAIR;
				}
			}
			return EBlueprintSkill.NONE;
		}

		// Token: 0x0600290D RID: 10509 RVA: 0x000B23B9 File Offset: 0x000B05B9
		public int GetPlayerSkillLevel(Player player)
		{
			return (int)player.skills.skills[this.SkillSpecialityIndex][this.SkillIndex].level;
		}

		// Token: 0x0600290E RID: 10510 RVA: 0x000B23DC File Offset: 0x000B05DC
		[Obsolete]
		public Blueprint(ItemAsset newSourceItem, byte newID, EBlueprintType newType, BlueprintSupply[] newSupplies, BlueprintOutput[] newOutputs, ushort newTool, bool newToolCritical, ushort newBuild, byte newLevel, EBlueprintSkill newSkill, bool newTransferState, string newMap, NPCConditionsList newQuestConditionsList, NPCRewardsList newQuestRewardsList) : this(newID, newSupplies, newOutputs, newLevel, newSkill, newTransferState, false, newMap, newQuestConditionsList, newQuestRewardsList)
		{
		}

		// Token: 0x0600290F RID: 10511 RVA: 0x000B2404 File Offset: 0x000B0604
		public Blueprint(byte newIndex, BlueprintSupply[] newSupplies, BlueprintOutput[] newOutputs, byte newLevel, EBlueprintSkill newSkill, bool newTransferState, bool newWithoutAttachments, string newMap, NPCConditionsList newQuestConditionsList, NPCRewardsList newQuestRewardsList)
		{
			this.index = newIndex;
			this._supplies = newSupplies;
			this._outputs = newOutputs;
			this._level = newLevel;
			this._transferState = newTransferState;
			this.withoutAttachments = newWithoutAttachments;
			this.map = newMap;
			this.questConditionsList = newQuestConditionsList;
			this.questRewardsList = newQuestRewardsList;
		}

		// Token: 0x06002910 RID: 10512 RVA: 0x000B2474 File Offset: 0x000B0674
		public override string ToString()
		{
			string text = string.Empty;
			string str = text;
			TagAsset categoryTag = this.GetCategoryTag();
			text = str + ((categoryTag != null) ? categoryTag.FriendlyName : null);
			text += ": ";
			for (int i = 0; i < this.supplies.Length; i++)
			{
				if (i > 0)
				{
					text += " + ";
				}
				string str2 = text;
				ItemAsset itemAsset = this.supplies[i].FindItemAsset();
				text = str2 + (((itemAsset != null) ? itemAsset.FriendlyName : null) ?? "null");
				text += " x";
				text += this.supplies[i].amount.ToString();
			}
			if (this.TargetItem != null)
			{
				text += " -> ";
				string str3 = text;
				ItemAsset itemAsset2 = this.TargetItem.FindItemAsset();
				text = str3 + (((itemAsset2 != null) ? itemAsset2.FriendlyName : null) ?? "null");
				text += " x";
				text += this.TargetItem.amount.ToString();
			}
			if (this.outputs != null && this.outputs.Length != 0)
			{
				text += " = ";
				for (int j = 0; j < this.outputs.Length; j++)
				{
					if (j > 0)
					{
						text += " + ";
					}
					string str4 = text;
					ItemAsset itemAsset3 = this.outputs[j].FindItemAsset();
					text = str4 + (((itemAsset3 != null) ? itemAsset3.FriendlyName : null) ?? "null");
					text += " x";
					text += this.outputs[j].amount.ToString();
				}
			}
			return text;
		}

		// Token: 0x1700084A RID: 2122
		// (get) Token: 0x06002911 RID: 10513 RVA: 0x000B260D File Offset: 0x000B080D
		[Obsolete("Changed to OwnerAsset because blueprints can be contained in CraftingAsset now")]
		public ItemAsset sourceItem
		{
			get
			{
				return this.GetOwnerAsset() as ItemAsset;
			}
		}

		// Token: 0x1700084B RID: 2123
		// (get) Token: 0x06002912 RID: 10514 RVA: 0x000B261C File Offset: 0x000B081C
		[Obsolete("Replaced by input item ShouldConsume false")]
		public ushort tool
		{
			get
			{
				if (this._supplies != null && this._supplies.Length != 0)
				{
					BlueprintSupply blueprintSupply = this._supplies[this._supplies.Length - 1];
					if (!blueprintSupply.ShouldConsume)
					{
						return blueprintSupply.id;
					}
				}
				return 0;
			}
		}

		// Token: 0x1700084C RID: 2124
		// (get) Token: 0x06002913 RID: 10515 RVA: 0x000B265C File Offset: 0x000B085C
		[Obsolete("Replaced by input item ShouldConsume false")]
		public bool toolCritical
		{
			get
			{
				if (this._supplies != null && this._supplies.Length != 0)
				{
					BlueprintSupply blueprintSupply = this._supplies[this._supplies.Length - 1];
					if (!blueprintSupply.ShouldConsume)
					{
						return blueprintSupply.ShouldConsume;
					}
				}
				return false;
			}
		}

		// Token: 0x1700084D RID: 2125
		// (get) Token: 0x06002914 RID: 10516 RVA: 0x000B269C File Offset: 0x000B089C
		[Obsolete("Renamed to Index to distinguish from named blueprint")]
		public byte id
		{
			get
			{
				return this.index;
			}
		}

		// Token: 0x06002915 RID: 10517 RVA: 0x000B26A4 File Offset: 0x000B08A4
		[Obsolete("Removed shouldSend parameter")]
		public void applyConditions(Player player, bool shouldSend)
		{
			this.ApplyConditions(player);
		}

		// Token: 0x06002916 RID: 10518 RVA: 0x000B26AD File Offset: 0x000B08AD
		[Obsolete("Removed shouldSend parameter")]
		public void grantRewards(Player player, bool shouldSend)
		{
			this.GrantRewards(player);
		}

		// Token: 0x1700084E RID: 2126
		// (get) Token: 0x06002917 RID: 10519 RVA: 0x000B26B6 File Offset: 0x000B08B6
		[Obsolete]
		public ushort build
		{
			get
			{
				return this.effectAssetRef.LegacyId;
			}
		}

		// Token: 0x1700084F RID: 2127
		// (get) Token: 0x06002918 RID: 10520 RVA: 0x000B26C4 File Offset: 0x000B08C4
		[Obsolete("Please use CategoryTags and Operation properties instead.")]
		public EBlueprintType type
		{
			get
			{
				EBlueprintOperation operation = this._operation;
				if (operation == EBlueprintOperation.RepairTargetItem)
				{
					return EBlueprintType.REPAIR;
				}
				if (operation == EBlueprintOperation.FillTargetItem)
				{
					return EBlueprintType.AMMO;
				}
				for (int i = 0; i < EBlueprintTypeEx.legacyBlueprintTypeCategoryTagRefs.Length; i++)
				{
					if (this._categoryTagRef == EBlueprintTypeEx.legacyBlueprintTypeCategoryTagRefs[i])
					{
						return (EBlueprintType)i;
					}
				}
				return EBlueprintType.TOOL;
			}
		}

		// Token: 0x17000850 RID: 2128
		// (get) Token: 0x06002919 RID: 10521 RVA: 0x000B2712 File Offset: 0x000B0912
		[Obsolete("Replaced in favor of supporting all skills, ideally more customizable in future.")]
		public EBlueprintSkill skill
		{
			get
			{
				return this.GetLegacyBlueprintSkill();
			}
		}

		// Token: 0x0400147D RID: 5245
		private byte index;

		// Token: 0x0400147E RID: 5246
		internal EBlueprintOperation _operation;

		// Token: 0x0400147F RID: 5247
		internal CachingAssetRef _categoryTagRef;

		// Token: 0x04001480 RID: 5248
		private BlueprintSupply[] _supplies;

		// Token: 0x04001482 RID: 5250
		private BlueprintOutput[] _outputs;

		// Token: 0x04001485 RID: 5253
		private bool hasCheckedForVanillaHeatSourceTag;

		// Token: 0x04001486 RID: 5254
		private bool requiresVanillaHeatSourceTag;

		// Token: 0x04001487 RID: 5255
		private static CachingAssetRef[] onlyVanillaHeatSourceTag = new CachingAssetRef[]
		{
			PowerTool.VanillaCraftingHeatTag
		};

		// Token: 0x04001488 RID: 5256
		internal CachingBcAssetRef effectAssetRef;

		// Token: 0x04001489 RID: 5257
		private byte _level;

		// Token: 0x0400148C RID: 5260
		private bool _transferState;

		/// <summary>
		/// If true, and transferState is enabled, delete attached items.
		/// </summary>
		// Token: 0x0400148D RID: 5261
		public bool withoutAttachments;

		// Token: 0x0400148F RID: 5263
		protected NPCConditionsList questConditionsList;

		// Token: 0x04001490 RID: 5264
		protected NPCRewardsList questRewardsList;

		/// <summary>
		/// Useful for hiding developer/debug internal blueprints that should not be visible when players search by name.
		/// </summary>
		// Token: 0x04001491 RID: 5265
		public bool canBeVisibleWhenSearchedWithoutRequiredItems = true;
	}
}
