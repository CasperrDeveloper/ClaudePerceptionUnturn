﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200058A RID: 1418
	public class AnimalManager : SteamCaller
	{
		// Token: 0x17000977 RID: 2423
		// (get) Token: 0x06002EE1 RID: 12001 RVA: 0x000D81FE File Offset: 0x000D63FE
		public static List<Animal> animals
		{
			get
			{
				return AnimalManager._animals;
			}
		}

		// Token: 0x17000978 RID: 2424
		// (get) Token: 0x06002EE2 RID: 12002 RVA: 0x000D8205 File Offset: 0x000D6405
		public static List<PackInfo> packs
		{
			get
			{
				return AnimalManager._packs;
			}
		}

		// Token: 0x17000979 RID: 2425
		// (get) Token: 0x06002EE3 RID: 12003 RVA: 0x000D820C File Offset: 0x000D640C
		public static List<Animal> tickingAnimals
		{
			get
			{
				return AnimalManager._tickingAnimals;
			}
		}

		// Token: 0x1700097A RID: 2426
		// (get) Token: 0x06002EE4 RID: 12004 RVA: 0x000D8214 File Offset: 0x000D6414
		public static uint maxInstances
		{
			get
			{
				switch (Level.info.size)
				{
				case ELevelSize.TINY:
					return Provider.modeConfigData.Animals.Max_Instances_Tiny;
				case ELevelSize.SMALL:
					return Provider.modeConfigData.Animals.Max_Instances_Small;
				case ELevelSize.MEDIUM:
					return Provider.modeConfigData.Animals.Max_Instances_Medium;
				case ELevelSize.LARGE:
					return Provider.modeConfigData.Animals.Max_Instances_Large;
				case ELevelSize.INSANE:
					return Provider.modeConfigData.Animals.Max_Instances_Insane;
				default:
					return 0U;
				}
			}
		}

		// Token: 0x06002EE5 RID: 12005 RVA: 0x000D829C File Offset: 0x000D649C
		public static bool giveAnimal(Player player, ushort id)
		{
			if (Assets.find(EAssetType.ANIMAL, id) is AnimalAsset)
			{
				Vector3 vector = player.transform.position + player.transform.forward * 6f;
				RaycastHit raycastHit;
				Physics.Raycast(vector + Vector3.up * 16f, Vector3.down, out raycastHit, 32f, RayMasks.BLOCK_VEHICLE);
				if (raycastHit.collider != null)
				{
					vector = raycastHit.point;
				}
				AnimalManager.spawnAnimal(id, vector, player.transform.rotation);
				return true;
			}
			return false;
		}

		// Token: 0x06002EE6 RID: 12006 RVA: 0x000D8338 File Offset: 0x000D6538
		public static void spawnAnimal(ushort id, Vector3 point, Quaternion angle)
		{
			foreach (Animal animal in AnimalManager.animals)
			{
				if (animal.id == id && animal.isDead)
				{
					animal.sendRevive(point, UnityEngine.Random.Range(0f, 360f));
					return;
				}
			}
			if (Assets.find(EAssetType.ANIMAL, id) is AnimalAsset)
			{
				Animal animal2 = AnimalManager.manager.addAnimal(id, point, angle.eulerAngles.y, false);
				AnimalSpawnpoint item = new AnimalSpawnpoint(0, point);
				PackInfo packInfo = new PackInfo();
				animal2.pack = packInfo;
				packInfo.animals.Add(animal2);
				packInfo.spawns.Add(item);
				AnimalManager.packs.Add(packInfo);
				AnimalManager.SendSingleAnimal.Invoke<Animal>(ENetReliability.Reliable, Provider.GatherRemoteClientConnections(), new Action<NetPakWriter, Animal>(AnimalManager.WriteSingleAnimal), animal2);
			}
		}

		// Token: 0x06002EE7 RID: 12007 RVA: 0x000D8434 File Offset: 0x000D6634
		public static void getAnimalsInRadius(Vector3 center, float sqrRadius, List<Animal> result)
		{
			if (AnimalManager.animals == null)
			{
				return;
			}
			for (int i = 0; i < AnimalManager.animals.Count; i++)
			{
				Animal animal = AnimalManager.animals[i];
				if ((animal.transform.position - center).sqrMagnitude < sqrRadius)
				{
					result.Add(animal);
				}
			}
		}

		// Token: 0x06002EE8 RID: 12008 RVA: 0x000D848D File Offset: 0x000D668D
		[Obsolete]
		public void tellAnimalAlive(CSteamID steamID, ushort index, Vector3 newPosition, byte newAngle)
		{
			AnimalManager.ReceiveAnimalAlive(index, newPosition, newAngle);
		}

		// Token: 0x06002EE9 RID: 12009 RVA: 0x000D8498 File Offset: 0x000D6698
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellAnimalAlive")]
		public static void ReceiveAnimalAlive(ushort index, Vector3 newPosition, byte newAngle)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return;
			}
			AnimalManager.animals[(int)index].tellAlive(newPosition, newAngle);
		}

		// Token: 0x06002EEA RID: 12010 RVA: 0x000D84BA File Offset: 0x000D66BA
		[Obsolete]
		public void tellAnimalDead(CSteamID steamID, ushort index, Vector3 newRagdoll, byte newRagdollEffect)
		{
			AnimalManager.ReceiveAnimalDead(index, newRagdoll, (ERagdollEffect)newRagdollEffect);
		}

		// Token: 0x06002EEB RID: 12011 RVA: 0x000D84C5 File Offset: 0x000D66C5
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellAnimalDead")]
		public static void ReceiveAnimalDead(ushort index, Vector3 newRagdoll, ERagdollEffect newRagdollEffect)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return;
			}
			AnimalManager.animals[(int)index].tellDead(newRagdoll, newRagdollEffect);
		}

		// Token: 0x06002EEC RID: 12012 RVA: 0x000D84E7 File Offset: 0x000D66E7
		[Obsolete]
		public void tellAnimalStates(CSteamID steamID)
		{
		}

		// Token: 0x06002EED RID: 12013 RVA: 0x000D84EC File Offset: 0x000D66EC
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveAnimalStates(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			uint num;
			reader.ReadUInt32(out num);
			if (num <= AnimalManager.seq)
			{
				return;
			}
			AnimalManager.seq = num;
			ushort num2;
			reader.ReadUInt16(out num2);
			if (num2 < 1)
			{
				return;
			}
			for (ushort num3 = 0; num3 < num2; num3 += 1)
			{
				ushort num4;
				reader.ReadUInt16(out num4);
				Vector3 newPosition;
				reader.ReadClampedVector3(out newPosition, 13, 7);
				float newAngle;
				reader.ReadDegrees(out newAngle, 8);
				if ((int)num4 < AnimalManager.animals.Count)
				{
					AnimalManager.animals[(int)num4].tellState(newPosition, newAngle);
				}
			}
		}

		// Token: 0x06002EEE RID: 12014 RVA: 0x000D8575 File Offset: 0x000D6775
		[Obsolete]
		public void askAnimalStartle(CSteamID steamID, ushort index)
		{
			AnimalManager.ReceiveAnimalStartle(index, 0);
		}

		// Token: 0x06002EEF RID: 12015 RVA: 0x000D857E File Offset: 0x000D677E
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "askAnimalStartle")]
		public static void ReceiveAnimalStartle(ushort index, byte animationIndex)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return;
			}
			AnimalManager.animals[(int)index].PlayStartleAnimation(animationIndex);
		}

		// Token: 0x06002EF0 RID: 12016 RVA: 0x000D859F File Offset: 0x000D679F
		[Obsolete]
		public void askAnimalAttack(CSteamID steamID, ushort index)
		{
			AnimalManager.ReceiveAnimalAttack(index, 0);
		}

		// Token: 0x06002EF1 RID: 12017 RVA: 0x000D85A8 File Offset: 0x000D67A8
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "askAnimalAttack")]
		public static void ReceiveAnimalAttack(ushort index, byte animationIndex)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return;
			}
			AnimalManager.animals[(int)index].askAttack(animationIndex);
		}

		// Token: 0x06002EF2 RID: 12018 RVA: 0x000D85C9 File Offset: 0x000D67C9
		[Obsolete]
		public void askAnimalPanic(CSteamID steamID, ushort index)
		{
			AnimalManager.ReceiveAnimalPanic(index);
		}

		// Token: 0x06002EF3 RID: 12019 RVA: 0x000D85D1 File Offset: 0x000D67D1
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "askAnimalPanic")]
		public static void ReceiveAnimalPanic(ushort index)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return;
			}
			AnimalManager.animals[(int)index].askPanic();
		}

		// Token: 0x06002EF4 RID: 12020 RVA: 0x000D85F1 File Offset: 0x000D67F1
		[Obsolete]
		public void tellAnimals(CSteamID steamID)
		{
		}

		// Token: 0x06002EF5 RID: 12021 RVA: 0x000D85F4 File Offset: 0x000D67F4
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveMultipleAnimals(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			ushort num;
			reader.ReadUInt16(out num);
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				AnimalManager.ReadSingleAnimal(reader);
			}
		}

		// Token: 0x06002EF6 RID: 12022 RVA: 0x000D8624 File Offset: 0x000D6824
		private static void ReadSingleAnimal(NetPakReader reader)
		{
			ushort id;
			reader.ReadUInt16(out id);
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 7);
			float angle;
			reader.ReadDegrees(out angle, 8);
			bool isDead;
			reader.ReadBit(out isDead);
			AnimalManager.manager.addAnimal(id, point, angle, isDead);
		}

		// Token: 0x06002EF7 RID: 12023 RVA: 0x000D8668 File Offset: 0x000D6868
		[Obsolete]
		public void tellAnimal(CSteamID steamID)
		{
		}

		// Token: 0x06002EF8 RID: 12024 RVA: 0x000D866A File Offset: 0x000D686A
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveSingleAnimal(in ClientInvocationContext context)
		{
			AnimalManager.ReadSingleAnimal(context.reader);
		}

		// Token: 0x06002EF9 RID: 12025 RVA: 0x000D8677 File Offset: 0x000D6877
		[Obsolete]
		public void askAnimals(CSteamID steamID)
		{
		}

		// Token: 0x06002EFA RID: 12026 RVA: 0x000D8679 File Offset: 0x000D6879
		internal static void SendInitialGlobalState(ITransportConnection transportConnection)
		{
			AnimalManager.SendMultipleAnimals.Invoke(ENetReliability.Reliable, transportConnection, new Action<NetPakWriter>(AnimalManager.SendMultipleAnimals_Write));
		}

		// Token: 0x06002EFB RID: 12027 RVA: 0x000D8694 File Offset: 0x000D6894
		private static void SendMultipleAnimals_Write(NetPakWriter writer)
		{
			writer.WriteUInt16((ushort)AnimalManager.animals.Count);
			ushort num = 0;
			while ((int)num < AnimalManager.animals.Count)
			{
				Animal animal = AnimalManager.animals[(int)num];
				AnimalManager.WriteSingleAnimal(writer, animal);
				num += 1;
			}
		}

		// Token: 0x06002EFC RID: 12028 RVA: 0x000D86DC File Offset: 0x000D68DC
		[Obsolete]
		public void sendAnimal(Animal animal, NetPakWriter writer)
		{
		}

		// Token: 0x06002EFD RID: 12029 RVA: 0x000D86E0 File Offset: 0x000D68E0
		private static void WriteSingleAnimal(NetPakWriter writer, Animal animal)
		{
			writer.WriteUInt16(animal.id);
			writer.WriteClampedVector3(animal.transform.position, 13, 7);
			writer.WriteDegrees(animal.transform.eulerAngles.y, 8);
			writer.WriteBit(animal.isDead);
		}

		// Token: 0x06002EFE RID: 12030 RVA: 0x000D8734 File Offset: 0x000D6934
		public static void sendAnimalAlive(Animal animal, Vector3 newPosition, byte newAngle)
		{
			AnimalManager.SendAnimalAlive.InvokeAndLoopback(ENetReliability.Reliable, Provider.GatherRemoteClientConnections(), animal.index, newPosition, newAngle);
		}

		// Token: 0x06002EFF RID: 12031 RVA: 0x000D874E File Offset: 0x000D694E
		public static void sendAnimalDead(Animal animal, Vector3 newRagdoll, ERagdollEffect newRagdollEffect = ERagdollEffect.NONE)
		{
			AnimalManager.SendAnimalDead.InvokeAndLoopback(ENetReliability.Reliable, Provider.GatherRemoteClientConnections(), animal.index, newRagdoll, newRagdollEffect);
		}

		// Token: 0x06002F00 RID: 12032 RVA: 0x000D8768 File Offset: 0x000D6968
		public static void sendAnimalStartle(Animal animal, byte animationIndex)
		{
			AnimalManager.SendAnimalStartle.InvokeAndLoopback(ENetReliability.Unreliable, Provider.GatherRemoteClientConnections(), animal.index, animationIndex);
		}

		// Token: 0x06002F01 RID: 12033 RVA: 0x000D8781 File Offset: 0x000D6981
		public static void sendAnimalAttack(Animal animal, byte animationIndex)
		{
			AnimalManager.SendAnimalAttack.InvokeAndLoopback(ENetReliability.Unreliable, Provider.GatherRemoteClientConnections(), animal.index, animationIndex);
		}

		// Token: 0x06002F02 RID: 12034 RVA: 0x000D879A File Offset: 0x000D699A
		public static void sendAnimalPanic(Animal animal)
		{
			AnimalManager.SendAnimalPanic.InvokeAndLoopback(ENetReliability.Unreliable, Provider.GatherRemoteClientConnections(), animal.index);
		}

		// Token: 0x06002F03 RID: 12035 RVA: 0x000D87B4 File Offset: 0x000D69B4
		public static void dropLoot(Animal animal)
		{
			if (animal == null || animal.asset == null || animal.transform == null)
			{
				return;
			}
			if (animal.asset.rewardID != 0)
			{
				int num = UnityEngine.Random.Range((int)animal.asset.rewardMin, (int)(animal.asset.rewardMax + 1));
				num = Mathf.Clamp(num, 0, 100);
				for (int i = 0; i < num; i++)
				{
					ushort num2 = SpawnTableTool.ResolveLegacyId(animal.asset.rewardID, EAssetType.ITEM, new Func<string>(animal.asset.OnGetRewardSpawnTableErrorContext));
					if (num2 != 0)
					{
						ItemManager.dropItem(new Item(num2, EItemOrigin.NATURE), animal.transform.position, false, Dedicator.IsDedicatedServer, true);
					}
				}
				return;
			}
			if (animal.asset.meat != 0)
			{
				int num3 = UnityEngine.Random.Range(2, 5);
				for (int j = 0; j < num3; j++)
				{
					ItemManager.dropItem(new Item(animal.asset.meat, EItemOrigin.NATURE), animal.transform.position, false, Dedicator.IsDedicatedServer, true);
				}
			}
			if (animal.asset.pelt != 0)
			{
				int num4 = UnityEngine.Random.Range(2, 5);
				for (int k = 0; k < num4; k++)
				{
					ItemManager.dropItem(new Item(animal.asset.pelt, EItemOrigin.NATURE), animal.transform.position, false, Dedicator.IsDedicatedServer, true);
				}
			}
		}

		/// <summary>
		/// Spawns an animal into the world.
		/// </summary>
		/// <param name="id">The ID of the animal.</param>
		/// <param name="point">Position to spawn the animal.</param>
		/// <param name="angle">Angle to spawn the animal.</param>
		/// <param name="isDead">Whether the animal is dead or not.</param>
		// Token: 0x06002F04 RID: 12036 RVA: 0x000D8904 File Offset: 0x000D6B04
		private Animal addAnimal(ushort id, Vector3 point, float angle, bool isDead)
		{
			Animal animal = null;
			AnimalAsset animalAsset = Assets.find(EAssetType.ANIMAL, id) as AnimalAsset;
			if (animalAsset != null)
			{
				try
				{
					GameObject original;
					if (Dedicator.IsDedicatedServer)
					{
						original = animalAsset.dedicated;
					}
					else if (Provider.isServer)
					{
						original = animalAsset.server;
					}
					else
					{
						original = animalAsset.client;
					}
					Quaternion rotation = Quaternion.Euler(0f, angle, 0f);
					GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(original, point, rotation);
					gameObject.name = id.ToString();
					animal = gameObject.AddComponent<Animal>();
					animal.index = (ushort)AnimalManager.animals.Count;
					animal.id = id;
					animal.isDead = isDead;
					animal.init();
					AnimalManager.animals.Add(animal);
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e, string.Format("Caught an exception instantiating animal \"{0}\" ({1:N})", animalAsset.FriendlyName, animalAsset.GUID));
				}
			}
			return animal;
		}

		/// <summary>
		/// Gets the animal at a specific index.
		/// </summary>
		/// <param name="index">The index of the animal.</param>
		/// <returns></returns>
		// Token: 0x06002F05 RID: 12037 RVA: 0x000D89E0 File Offset: 0x000D6BE0
		public static Animal getAnimal(ushort index)
		{
			if ((int)index >= AnimalManager.animals.Count)
			{
				return null;
			}
			return AnimalManager.animals[(int)index];
		}

		/// <summary>
		/// Find replacement spawnpoint for an animal and teleport it there.
		/// </summary>
		// Token: 0x06002F06 RID: 12038 RVA: 0x000D89FC File Offset: 0x000D6BFC
		public static void TeleportAnimalBackIntoMap(Animal animal)
		{
			Vector3? vector = null;
			if (animal.pack != null)
			{
				if (animal.pack.animals != null)
				{
					foreach (Animal animal2 in animal.pack.animals)
					{
						if (!(animal == animal2) && !animal2.isDead)
						{
							Vector3 position = animal2.transform.position;
							if (UndergroundAllowlist.IsPositionWithinValidHeight(position, 0.1f))
							{
								vector = new Vector3?(position);
								break;
							}
						}
					}
				}
				if (vector == null && animal.pack.spawns != null && animal.pack.spawns.Count > 0)
				{
					vector = new Vector3?(animal.pack.spawns[animal.pack.spawns.GetRandomIndex<AnimalSpawnpoint>()].point);
				}
			}
			if (vector == null)
			{
				if (LevelAnimals.spawns != null && LevelAnimals.spawns.Count > 0)
				{
					vector = new Vector3?(LevelAnimals.spawns[LevelAnimals.spawns.GetRandomIndex<AnimalSpawnpoint>()].point);
				}
				else
				{
					Vector3 position2 = animal.transform.position;
					position2.y = Level.HEIGHT - 10f;
					vector = new Vector3?(position2);
				}
			}
			EffectAsset effectAsset = ZombieManager.Souls_1_Ref.Find();
			if (effectAsset != null)
			{
				EffectManager.triggerEffect(new TriggerEffectParameters(effectAsset)
				{
					relevantDistance = 16f,
					position = animal.transform.position + Vector3.up
				});
			}
			animal.transform.position = vector.Value + Vector3.up;
		}

		/// <summary>
		/// Used in arena mode to reset all animals to dead.
		/// </summary>
		// Token: 0x06002F07 RID: 12039 RVA: 0x000D8BC4 File Offset: 0x000D6DC4
		public static void askClearAllAnimals()
		{
			foreach (Animal animal in AnimalManager.animals)
			{
				EPlayerKill eplayerKill;
				uint num;
				animal.askDamage(ushort.MaxValue, Vector3.up, out eplayerKill, out num, false, false, ERagdollEffect.NONE);
			}
		}

		// Token: 0x06002F08 RID: 12040 RVA: 0x000D8C24 File Offset: 0x000D6E24
		private void respawnAnimals()
		{
			if (Level.info == null || Level.info.type == ELevelType.ARENA)
			{
				return;
			}
			if ((int)AnimalManager.respawnPackIndex >= AnimalManager.packs.Count)
			{
				AnimalManager.respawnPackIndex = (ushort)(AnimalManager.packs.Count - 1);
			}
			PackInfo packInfo = AnimalManager.packs[(int)AnimalManager.respawnPackIndex];
			AnimalManager.respawnPackIndex += 1;
			if ((int)AnimalManager.respawnPackIndex >= AnimalManager.packs.Count)
			{
				AnimalManager.respawnPackIndex = 0;
			}
			if (packInfo == null)
			{
				return;
			}
			for (int i = 0; i < packInfo.animals.Count; i++)
			{
				Animal animal = packInfo.animals[i];
				if (animal == null || animal.IsAlive || Time.realtimeSinceStartup - animal.lastDead < Provider.modeConfigData.Animals.Respawn_Time)
				{
					return;
				}
			}
			List<AnimalSpawnpoint> list = new List<AnimalSpawnpoint>();
			for (int j = 0; j < packInfo.spawns.Count; j++)
			{
				list.Add(packInfo.spawns[j]);
			}
			for (int k = 0; k < packInfo.animals.Count; k++)
			{
				Animal animal2 = packInfo.animals[k];
				if (!(animal2 == null))
				{
					int index = UnityEngine.Random.Range(0, list.Count);
					AnimalSpawnpoint animalSpawnpoint = list[index];
					list.RemoveAt(index);
					Vector3 point = animalSpawnpoint.point;
					point.y += 0.1f;
					animal2.sendRevive(point, UnityEngine.Random.Range(0f, 360f));
				}
			}
		}

		// Token: 0x06002F09 RID: 12041 RVA: 0x000D8DA8 File Offset: 0x000D6FA8
		private void onLevelLoaded(int level)
		{
			if (level > Level.BUILD_INDEX_SETUP)
			{
				AnimalManager.seq = 0U;
				AnimalManager._animals = new List<Animal>();
				AnimalManager._packs = null;
				AnimalManager.updates = 0;
				AnimalManager.tickIndex = 0;
				AnimalManager._tickingAnimals = new List<Animal>();
				if (Provider.isServer)
				{
					AnimalManager._packs = new List<PackInfo>();
					if (LevelAnimals.spawns.Count > 0 && Level.info != null && Level.info.type != ELevelType.ARENA)
					{
						for (int i = 0; i < LevelAnimals.spawns.Count; i++)
						{
							AnimalSpawnpoint animalSpawnpoint = LevelAnimals.spawns[i];
							int num = -1;
							for (int j = AnimalManager.packs.Count - 1; j >= 0; j--)
							{
								List<AnimalSpawnpoint> spawns = AnimalManager.packs[j].spawns;
								for (int k = 0; k < spawns.Count; k++)
								{
									if ((spawns[k].point - animalSpawnpoint.point).sqrMagnitude < 256f)
									{
										if (num == -1)
										{
											spawns.Add(animalSpawnpoint);
										}
										else
										{
											List<AnimalSpawnpoint> spawns2 = AnimalManager.packs[num].spawns;
											for (int l = 0; l < spawns2.Count; l++)
											{
												spawns.Add(spawns2[l]);
											}
											AnimalManager.packs.RemoveAtFast(num);
										}
										num = j;
										break;
									}
								}
							}
							if (num == -1)
							{
								PackInfo packInfo = new PackInfo();
								packInfo.spawns.Add(animalSpawnpoint);
								AnimalManager.packs.Add(packInfo);
							}
						}
						List<AnimalManager.ValidAnimalSpawnsInfo> list = new List<AnimalManager.ValidAnimalSpawnsInfo>();
						for (int m = 0; m < AnimalManager.packs.Count; m++)
						{
							PackInfo packInfo2 = AnimalManager.packs[m];
							List<AnimalSpawnpoint> list2 = new List<AnimalSpawnpoint>();
							for (int n = 0; n < packInfo2.spawns.Count; n++)
							{
								list2.Add(packInfo2.spawns[n]);
							}
							list.Add(new AnimalManager.ValidAnimalSpawnsInfo
							{
								spawns = list2,
								pack = packInfo2
							});
						}
						while ((long)AnimalManager.animals.Count < (long)((ulong)AnimalManager.maxInstances) && list.Count > 0)
						{
							int index = UnityEngine.Random.Range(0, list.Count);
							AnimalManager.ValidAnimalSpawnsInfo validAnimalSpawnsInfo = list[index];
							int index2 = UnityEngine.Random.Range(0, validAnimalSpawnsInfo.spawns.Count);
							AnimalSpawnpoint animalSpawnpoint2 = validAnimalSpawnsInfo.spawns[index2];
							validAnimalSpawnsInfo.spawns.RemoveAt(index2);
							if (validAnimalSpawnsInfo.spawns.Count == 0)
							{
								list.RemoveAt(index);
							}
							Vector3 point = animalSpawnpoint2.point;
							point.y += 0.1f;
							ushort id;
							if (validAnimalSpawnsInfo.pack.animals.Count > 0)
							{
								id = validAnimalSpawnsInfo.pack.animals[0].id;
							}
							else
							{
								id = LevelAnimals.getAnimal(animalSpawnpoint2);
							}
							Animal animal = this.addAnimal(id, point, UnityEngine.Random.Range(0f, 360f), false);
							if (animal != null)
							{
								animal.pack = validAnimalSpawnsInfo.pack;
								validAnimalSpawnsInfo.pack.animals.Add(animal);
							}
						}
						for (int num2 = AnimalManager.packs.Count - 1; num2 >= 0; num2--)
						{
							if (AnimalManager.packs[num2].animals.Count <= 0)
							{
								AnimalManager.packs.RemoveAt(num2);
							}
						}
					}
				}
			}
		}

		// Token: 0x06002F0A RID: 12042 RVA: 0x000D9128 File Offset: 0x000D7328
		private void OnDrawGizmos()
		{
			if (AnimalManager.packs == null)
			{
				return;
			}
			for (int i = 0; i < AnimalManager.packs.Count; i++)
			{
				PackInfo packInfo = AnimalManager.packs[i];
				if (packInfo != null && packInfo.spawns != null && packInfo.animals != null)
				{
					Vector3 averageSpawnPoint = packInfo.getAverageSpawnPoint();
					Vector3 averageAnimalPoint = packInfo.getAverageAnimalPoint();
					Vector3 wanderDirection = packInfo.getWanderDirection();
					Gizmos.color = Color.gray;
					for (int j = 0; j < packInfo.spawns.Count; j++)
					{
						AnimalSpawnpoint animalSpawnpoint = packInfo.spawns[j];
						if (animalSpawnpoint != null)
						{
							Gizmos.DrawLine(averageSpawnPoint, animalSpawnpoint.point);
						}
					}
					Gizmos.color = Color.yellow;
					Gizmos.DrawLine(averageSpawnPoint, averageAnimalPoint);
					for (int k = 0; k < packInfo.animals.Count; k++)
					{
						Animal animal = packInfo.animals[k];
						if (!(animal == null))
						{
							Gizmos.color = (animal.isDead ? Color.red : Color.green);
							Gizmos.DrawLine(averageAnimalPoint, animal.transform.position);
							if (animal.IsAlive)
							{
								Gizmos.color = Color.magenta;
								Gizmos.DrawLine(animal.transform.position, animal.target);
							}
						}
					}
					Gizmos.color = Color.cyan;
					Gizmos.DrawLine(averageAnimalPoint, averageAnimalPoint + wanderDirection * 4f);
				}
			}
		}

		// Token: 0x06002F0B RID: 12043 RVA: 0x000D929C File Offset: 0x000D749C
		private void sendAnimalStates()
		{
			AnimalManager.seq += 1U;
			for (int i = 0; i < Provider.clients.Count; i++)
			{
				SteamPlayer steamPlayer = Provider.clients[i];
				if (steamPlayer != null && !(steamPlayer.player == null))
				{
					ushort num = 0;
					this.animalsToSend.Clear();
					for (int j = 0; j < AnimalManager.animals.Count; j++)
					{
						Animal animal = AnimalManager.animals[j];
						if (!(animal == null) && animal.isUpdated)
						{
							this.animalsToSend.Add(animal);
							num += 1;
						}
					}
					if (num != 0)
					{
						AnimalManager.SendAnimalStates.Invoke<ushort>(ENetReliability.Unreliable, steamPlayer.transportConnection, new Action<NetPakWriter, ushort>(this.SendAnimalStates_Write), num);
					}
				}
			}
			for (int k = 0; k < AnimalManager.animals.Count; k++)
			{
				Animal animal2 = AnimalManager.animals[k];
				if (!(animal2 == null))
				{
					animal2.isUpdated = false;
				}
			}
		}

		// Token: 0x06002F0C RID: 12044 RVA: 0x000D93A0 File Offset: 0x000D75A0
		private void SendAnimalStates_Write(NetPakWriter writer, ushort updateCount)
		{
			writer.WriteUInt32(AnimalManager.seq);
			writer.WriteUInt16(updateCount);
			foreach (Animal animal in this.animalsToSend)
			{
				writer.WriteUInt16(animal.index);
				writer.WriteClampedVector3(animal.transform.position, 13, 7);
				writer.WriteDegrees(animal.transform.eulerAngles.y, 8);
			}
		}

		// Token: 0x06002F0D RID: 12045 RVA: 0x000D943C File Offset: 0x000D763C
		private void Update()
		{
			if (!Provider.isServer || !Level.isLoaded)
			{
				return;
			}
			if (AnimalManager.animals == null || AnimalManager.animals.Count == 0)
			{
				return;
			}
			if (AnimalManager.tickingAnimals == null)
			{
				return;
			}
			int num;
			int num2;
			if (Dedicator.IsDedicatedServer)
			{
				if (AnimalManager.tickIndex >= AnimalManager.tickingAnimals.Count)
				{
					AnimalManager.tickIndex = 0;
				}
				num = AnimalManager.tickIndex;
				num2 = num + 25;
				if (num2 >= AnimalManager.tickingAnimals.Count)
				{
					num2 = AnimalManager.tickingAnimals.Count;
				}
				AnimalManager.tickIndex = num2;
			}
			else
			{
				num = 0;
				num2 = AnimalManager.tickingAnimals.Count;
			}
			for (int i = num2 - 1; i >= num; i--)
			{
				Animal animal = AnimalManager.tickingAnimals[i];
				if (animal == null)
				{
					UnturnedLog.error("Missing animal " + i.ToString());
				}
				else
				{
					animal.tick();
				}
			}
			if (Dedicator.IsDedicatedServer && Time.realtimeSinceStartup - AnimalManager.lastTick > Provider.UPDATE_TIME)
			{
				AnimalManager.lastTick += Provider.UPDATE_TIME;
				if (Time.realtimeSinceStartup - AnimalManager.lastTick > Provider.UPDATE_TIME)
				{
					AnimalManager.lastTick = Time.realtimeSinceStartup;
				}
				this.sendAnimalStates();
			}
			this.respawnAnimals();
		}

		// Token: 0x06002F0E RID: 12046 RVA: 0x000D955C File Offset: 0x000D775C
		private void Start()
		{
			AnimalManager.manager = this;
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Combine(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
			Level.onLevelLoaded = (LevelLoaded)Delegate.Combine(Level.onLevelLoaded, new LevelLoaded(this.onLevelLoaded));
		}

		// Token: 0x06002F0F RID: 12047 RVA: 0x000D95B0 File Offset: 0x000D77B0
		private void OnLogMemoryUsage(List<string> results)
		{
			string format = "Animals: {0}";
			List<Animal> animals = AnimalManager.animals;
			results.Add(string.Format(format, (animals != null) ? new int?(animals.Count) : null));
			string format2 = "Animal packs: {0}";
			List<PackInfo> packs = AnimalManager.packs;
			results.Add(string.Format(format2, (packs != null) ? new int?(packs.Count) : null));
			string format3 = "Ticking animals: {0}";
			List<Animal> tickingAnimals = AnimalManager.tickingAnimals;
			results.Add(string.Format(format3, (tickingAnimals != null) ? new int?(tickingAnimals.Count) : null));
		}

		// Token: 0x06002F10 RID: 12048 RVA: 0x000D9656 File Offset: 0x000D7856
		[Obsolete]
		public static void sendAnimalStartle(Animal animal)
		{
			AnimalManager.sendAnimalStartle(animal, 0);
		}

		// Token: 0x06002F11 RID: 12049 RVA: 0x000D965F File Offset: 0x000D785F
		[Obsolete]
		public static void sendAnimalAttack(Animal animal)
		{
			AnimalManager.sendAnimalAttack(animal, 0);
		}

		// Token: 0x04001912 RID: 6418
		private static AnimalManager manager;

		// Token: 0x04001913 RID: 6419
		private static List<Animal> _animals;

		// Token: 0x04001914 RID: 6420
		private static List<PackInfo> _packs;

		// Token: 0x04001915 RID: 6421
		private static int tickIndex;

		// Token: 0x04001916 RID: 6422
		private static List<Animal> _tickingAnimals;

		// Token: 0x04001917 RID: 6423
		public static ushort updates;

		// Token: 0x04001918 RID: 6424
		private static ushort respawnPackIndex;

		// Token: 0x04001919 RID: 6425
		private static float lastTick;

		// Token: 0x0400191A RID: 6426
		private static readonly ClientStaticMethod<ushort, Vector3, byte> SendAnimalAlive = ClientStaticMethod<ushort, Vector3, byte>.Get(new ClientStaticMethod<ushort, Vector3, byte>.ReceiveDelegate(AnimalManager.ReceiveAnimalAlive));

		// Token: 0x0400191B RID: 6427
		private static readonly ClientStaticMethod<ushort, Vector3, ERagdollEffect> SendAnimalDead = ClientStaticMethod<ushort, Vector3, ERagdollEffect>.Get(new ClientStaticMethod<ushort, Vector3, ERagdollEffect>.ReceiveDelegate(AnimalManager.ReceiveAnimalDead));

		// Token: 0x0400191C RID: 6428
		private static uint seq;

		// Token: 0x0400191D RID: 6429
		private static readonly ClientStaticMethod SendAnimalStates = ClientStaticMethod.Get(new ClientStaticMethod.ReceiveDelegateWithContext(AnimalManager.ReceiveAnimalStates));

		// Token: 0x0400191E RID: 6430
		private static readonly ClientStaticMethod<ushort, byte> SendAnimalStartle = ClientStaticMethod<ushort, byte>.Get(new ClientStaticMethod<ushort, byte>.ReceiveDelegate(AnimalManager.ReceiveAnimalStartle));

		// Token: 0x0400191F RID: 6431
		private static readonly ClientStaticMethod<ushort, byte> SendAnimalAttack = ClientStaticMethod<ushort, byte>.Get(new ClientStaticMethod<ushort, byte>.ReceiveDelegate(AnimalManager.ReceiveAnimalAttack));

		// Token: 0x04001920 RID: 6432
		private static readonly ClientStaticMethod<ushort> SendAnimalPanic = ClientStaticMethod<ushort>.Get(new ClientStaticMethod<ushort>.ReceiveDelegate(AnimalManager.ReceiveAnimalPanic));

		// Token: 0x04001921 RID: 6433
		private static readonly ClientStaticMethod SendMultipleAnimals = ClientStaticMethod.Get(new ClientStaticMethod.ReceiveDelegateWithContext(AnimalManager.ReceiveMultipleAnimals));

		// Token: 0x04001922 RID: 6434
		private static readonly ClientStaticMethod SendSingleAnimal = ClientStaticMethod.Get(new ClientStaticMethod.ReceiveDelegateWithContext(AnimalManager.ReceiveSingleAnimal));

		// Token: 0x04001923 RID: 6435
		private List<Animal> animalsToSend = new List<Animal>();

		// Token: 0x02000A1F RID: 2591
		private class ValidAnimalSpawnsInfo
		{
			// Token: 0x0400391A RID: 14618
			public List<AnimalSpawnpoint> spawns;

			// Token: 0x0400391B RID: 14619
			public PackInfo pack;
		}
	}
}
