﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000294 RID: 660
	public class AnimalAsset : Asset, IArmorFalloff
	{
		// Token: 0x17000293 RID: 659
		// (get) Token: 0x060013AC RID: 5036 RVA: 0x0004BC87 File Offset: 0x00049E87
		// (set) Token: 0x060013AD RID: 5037 RVA: 0x0004BC8F File Offset: 0x00049E8F
		public float ArmorFalloffMaxRange { get; set; }

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x060013AE RID: 5038 RVA: 0x0004BC98 File Offset: 0x00049E98
		// (set) Token: 0x060013AF RID: 5039 RVA: 0x0004BCA0 File Offset: 0x00049EA0
		public float ArmorFalloffRange { get; set; }

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x060013B0 RID: 5040 RVA: 0x0004BCA9 File Offset: 0x00049EA9
		// (set) Token: 0x060013B1 RID: 5041 RVA: 0x0004BCB1 File Offset: 0x00049EB1
		public float ArmorFalloffMultiplier { get; set; }

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x060013B2 RID: 5042 RVA: 0x0004BCBA File Offset: 0x00049EBA
		public string animalName
		{
			get
			{
				return this._animalName;
			}
		}

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x060013B3 RID: 5043 RVA: 0x0004BCC2 File Offset: 0x00049EC2
		public override string FriendlyName
		{
			get
			{
				return this._animalName;
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x060013B4 RID: 5044 RVA: 0x0004BCCA File Offset: 0x00049ECA
		public GameObject client
		{
			get
			{
				return this._client;
			}
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x060013B5 RID: 5045 RVA: 0x0004BCD2 File Offset: 0x00049ED2
		public GameObject server
		{
			get
			{
				return this._server;
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x060013B6 RID: 5046 RVA: 0x0004BCDA File Offset: 0x00049EDA
		public GameObject dedicated
		{
			get
			{
				return this._dedicated;
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x060013B7 RID: 5047 RVA: 0x0004BCE2 File Offset: 0x00049EE2
		public GameObject ragdoll
		{
			get
			{
				return this._ragdoll;
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x060013B8 RID: 5048 RVA: 0x0004BCEA File Offset: 0x00049EEA
		public float speedRun
		{
			get
			{
				return this._speedRun;
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x060013B9 RID: 5049 RVA: 0x0004BCF2 File Offset: 0x00049EF2
		public float speedWalk
		{
			get
			{
				return this._speedWalk;
			}
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x060013BA RID: 5050 RVA: 0x0004BCFA File Offset: 0x00049EFA
		public EAnimalBehaviour behaviour
		{
			get
			{
				return this._behaviour;
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x060013BB RID: 5051 RVA: 0x0004BD02 File Offset: 0x00049F02
		public ushort health
		{
			get
			{
				return this._health;
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x060013BC RID: 5052 RVA: 0x0004BD0A File Offset: 0x00049F0A
		public uint rewardXP
		{
			get
			{
				return this._rewardXP;
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060013BD RID: 5053 RVA: 0x0004BD12 File Offset: 0x00049F12
		public float regen
		{
			get
			{
				return this._regen;
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060013BE RID: 5054 RVA: 0x0004BD1A File Offset: 0x00049F1A
		public byte damage
		{
			get
			{
				return this._damage;
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060013BF RID: 5055 RVA: 0x0004BD22 File Offset: 0x00049F22
		public ushort meat
		{
			get
			{
				return this._meat;
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060013C0 RID: 5056 RVA: 0x0004BD2A File Offset: 0x00049F2A
		public ushort pelt
		{
			get
			{
				return this._pelt;
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x060013C1 RID: 5057 RVA: 0x0004BD32 File Offset: 0x00049F32
		public byte rewardMin
		{
			get
			{
				return this._rewardMin;
			}
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x060013C2 RID: 5058 RVA: 0x0004BD3A File Offset: 0x00049F3A
		public byte rewardMax
		{
			get
			{
				return this._rewardMax;
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x060013C3 RID: 5059 RVA: 0x0004BD42 File Offset: 0x00049F42
		public ushort rewardID
		{
			get
			{
				return this._rewardID;
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x060013C4 RID: 5060 RVA: 0x0004BD4A File Offset: 0x00049F4A
		public AudioClip[] roars
		{
			get
			{
				return this._roars;
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x060013C5 RID: 5061 RVA: 0x0004BD52 File Offset: 0x00049F52
		public AudioClip[] panics
		{
			get
			{
				return this._panics;
			}
		}

		/// <summary>
		/// Number of Attack_# animations.
		/// </summary>
		// Token: 0x170002AA RID: 682
		// (get) Token: 0x060013C6 RID: 5062 RVA: 0x0004BD5A File Offset: 0x00049F5A
		// (set) Token: 0x060013C7 RID: 5063 RVA: 0x0004BD62 File Offset: 0x00049F62
		public int attackAnimVariantsCount { get; protected set; }

		/// <summary>
		/// Number of Eat_# animations.
		/// </summary>
		// Token: 0x170002AB RID: 683
		// (get) Token: 0x060013C8 RID: 5064 RVA: 0x0004BD6B File Offset: 0x00049F6B
		// (set) Token: 0x060013C9 RID: 5065 RVA: 0x0004BD73 File Offset: 0x00049F73
		public int eatAnimVariantsCount { get; protected set; }

		/// <summary>
		/// Number of Glance_# animations.
		/// </summary>
		// Token: 0x170002AC RID: 684
		// (get) Token: 0x060013CA RID: 5066 RVA: 0x0004BD7C File Offset: 0x00049F7C
		// (set) Token: 0x060013CB RID: 5067 RVA: 0x0004BD84 File Offset: 0x00049F84
		public int glanceAnimVariantsCount { get; protected set; }

		/// <summary>
		/// Number of Startle_# animations.
		/// </summary>
		// Token: 0x170002AD RID: 685
		// (get) Token: 0x060013CC RID: 5068 RVA: 0x0004BD8D File Offset: 0x00049F8D
		// (set) Token: 0x060013CD RID: 5069 RVA: 0x0004BD95 File Offset: 0x00049F95
		public int startleAnimVariantsCount { get; protected set; }

		/// <summary>
		/// Maximum distance on the XZ plane.
		/// </summary>
		// Token: 0x170002AE RID: 686
		// (get) Token: 0x060013CE RID: 5070 RVA: 0x0004BD9E File Offset: 0x00049F9E
		// (set) Token: 0x060013CF RID: 5071 RVA: 0x0004BDA6 File Offset: 0x00049FA6
		public float horizontalAttackRangeSquared { get; protected set; }

		/// <summary>
		/// Maximum distance on the XZ plane when attacking vehicles.
		/// </summary>
		// Token: 0x170002AF RID: 687
		// (get) Token: 0x060013D0 RID: 5072 RVA: 0x0004BDAF File Offset: 0x00049FAF
		// (set) Token: 0x060013D1 RID: 5073 RVA: 0x0004BDB7 File Offset: 0x00049FB7
		public float horizontalVehicleAttackRangeSquared { get; protected set; }

		/// <summary>
		/// Maximum distance on the Y axis.
		/// </summary>
		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x060013D2 RID: 5074 RVA: 0x0004BDC0 File Offset: 0x00049FC0
		// (set) Token: 0x060013D3 RID: 5075 RVA: 0x0004BDC8 File Offset: 0x00049FC8
		public float verticalAttackRange { get; protected set; }

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x060013D4 RID: 5076 RVA: 0x0004BDD1 File Offset: 0x00049FD1
		public override EAssetType assetCategory
		{
			get
			{
				return EAssetType.ANIMAL;
			}
		}

		/// <summary>
		/// Temporary until something better makes sense?
		/// Originally added for modded animals triggering damage from animations.
		/// </summary>
		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060013D5 RID: 5077 RVA: 0x0004BDD4 File Offset: 0x00049FD4
		// (set) Token: 0x060013D6 RID: 5078 RVA: 0x0004BDDC File Offset: 0x00049FDC
		public bool shouldPlayAnimsOnDedicatedServer { get; private set; }

		/// <summary>
		/// If true, animal won't start moving until startle animation finishes.
		/// </summary>
		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060013D7 RID: 5079 RVA: 0x0004BDE5 File Offset: 0x00049FE5
		// (set) Token: 0x060013D8 RID: 5080 RVA: 0x0004BDED File Offset: 0x00049FED
		public bool ShouldPreventMoveDuringStartle { get; protected set; }

		// Token: 0x060013D9 RID: 5081 RVA: 0x0004BDF8 File Offset: 0x00049FF8
		protected void validateAnimations(GameObject root)
		{
			Transform transform = root.transform.Find("Character");
			Animation animation = (transform != null) ? transform.GetComponent<Animation>() : null;
			if (animation == null)
			{
				Assets.ReportError(this, "{0} missing Animation component on Character", root);
				return;
			}
			base.validateAnimation(animation, "Idle");
			base.validateAnimation(animation, "Walk");
			base.validateAnimation(animation, "Run");
			if (this.attackAnimVariantsCount > 1)
			{
				for (int i = 0; i < this.attackAnimVariantsCount; i++)
				{
					base.validateAnimation(animation, "Attack_" + i.ToString());
				}
			}
			if (this.eatAnimVariantsCount == 1)
			{
				base.validateAnimation(animation, "Eat");
			}
			else
			{
				for (int j = 0; j < this.eatAnimVariantsCount; j++)
				{
					base.validateAnimation(animation, "Eat_" + j.ToString());
				}
			}
			for (int k = 0; k < this.glanceAnimVariantsCount; k++)
			{
				base.validateAnimation(animation, "Glance_" + k.ToString());
			}
			if (this.startleAnimVariantsCount == 1)
			{
				base.validateAnimation(animation, "Startle");
				return;
			}
			for (int l = 0; l < this.startleAnimVariantsCount; l++)
			{
				base.validateAnimation(animation, "Startle_" + l.ToString());
			}
		}

		// Token: 0x060013DA RID: 5082 RVA: 0x0004BF3C File Offset: 0x0004A13C
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			if (this.id < 50 && !base.OriginAllowsVanillaLegacyId && !p.data.ContainsKey("Bypass_ID_Limit"))
			{
				throw new NotSupportedException("ID < 50");
			}
			this._animalName = p.localization.format("Name");
			this._client = p.bundle.load<GameObject>("Animal_Client");
			this._server = p.bundle.load<GameObject>("Animal_Server");
			this._dedicated = p.bundle.load<GameObject>("Animal_Dedicated");
			this._ragdoll = p.bundle.load<GameObject>("Ragdoll");
			if (this.client == null)
			{
				throw new NotSupportedException("missing \"Animal_Client\" GameObject");
			}
			if (Assets.shouldValidateAssets)
			{
				this.validateAnimations(this.client);
			}
			if (this.server == null)
			{
				throw new NotSupportedException("missing \"Animal_Server\" GameObject");
			}
			if (Assets.shouldValidateAssets)
			{
				this.validateAnimations(this.server);
			}
			if (this.dedicated == null)
			{
				throw new NotSupportedException("missing \"Animal_Dedicated\" GameObject");
			}
			if (this.ragdoll == null)
			{
				Assets.ReportError(this, "missing 'Ragdoll' GameObject. Highly recommended to fix.");
			}
			this._speedRun = p.data.ParseFloat("Speed_Run", 0f);
			this._speedWalk = p.data.ParseFloat("Speed_Walk", 0f);
			this._behaviour = (EAnimalBehaviour)Enum.Parse(typeof(EAnimalBehaviour), p.data.GetString("Behaviour", null), true);
			this._health = p.data.ParseUInt16("Health", 0);
			this._regen = p.data.ParseFloat("Regen", 0f);
			if (!p.data.ContainsKey("Regen"))
			{
				this._regen = 10f;
			}
			this._damage = p.data.ParseUInt8("Damage", 0);
			this._meat = p.data.ParseUInt16("Meat", 0);
			this._pelt = p.data.ParseUInt16("Pelt", 0);
			this._rewardID = p.data.ParseUInt16("Reward_ID", 0);
			if (p.data.ContainsKey("Reward_Min"))
			{
				this._rewardMin = p.data.ParseUInt8("Reward_Min", 0);
			}
			else
			{
				this._rewardMin = 3;
			}
			if (p.data.ContainsKey("Reward_Max"))
			{
				this._rewardMax = p.data.ParseUInt8("Reward_Max", 0);
			}
			else
			{
				this._rewardMax = 4;
			}
			this._roars = new AudioClip[(int)p.data.ParseUInt8("Roars", 0)];
			byte b = 0;
			while ((int)b < this.roars.Length)
			{
				this.roars[(int)b] = p.bundle.load<AudioClip>("Roar_" + b.ToString());
				b += 1;
			}
			this._panics = new AudioClip[(int)p.data.ParseUInt8("Panics", 0)];
			byte b2 = 0;
			while ((int)b2 < this.panics.Length)
			{
				this.panics[(int)b2] = p.bundle.load<AudioClip>("Panic_" + b2.ToString());
				b2 += 1;
			}
			this.attackAnimVariantsCount = p.data.ParseInt32("Attack_Anim_Variants", 1);
			this.eatAnimVariantsCount = p.data.ParseInt32("Eat_Anim_Variants", 1);
			this.glanceAnimVariantsCount = p.data.ParseInt32("Glance_Anim_Variants", 2);
			this.startleAnimVariantsCount = p.data.ParseInt32("Startle_Anim_Variants", 1);
			this.horizontalAttackRangeSquared = MathfEx.Square(p.data.ParseFloat("Horizontal_Attack_Range", 2.25f));
			this.horizontalVehicleAttackRangeSquared = MathfEx.Square(p.data.ParseFloat("Horizontal_Vehicle_Attack_Range", 4.4f));
			this.verticalAttackRange = p.data.ParseFloat("Vertical_Attack_Range", 2f);
			this.attackInterval = p.data.ParseFloat("Attack_Interval", 1f);
			this.shouldPlayAnimsOnDedicatedServer = p.data.ParseBool("Should_Play_Anims_On_Dedicated_Server", false);
			this.ShouldPreventMoveDuringStartle = p.data.ParseBool("Should_Prevent_Move_During_Startle", false);
			this._rewardXP = p.data.ParseUInt32("Reward_XP", 0U);
			this.PopulateArmorFalloff(p);
		}

		// Token: 0x060013DB RID: 5083 RVA: 0x0004C3B8 File Offset: 0x0004A5B8
		internal override void BuildCargoData(CargoBuilder builder)
		{
			base.BuildCargoData(builder);
			CargoDeclaration orAddDeclaration = builder.GetOrAddDeclaration("Locale_Animal");
			orAddDeclaration.Append("GUID", this.GUID);
			orAddDeclaration.Append("Name", this.FriendlyName);
			CargoDeclaration orAddDeclaration2 = builder.GetOrAddDeclaration("Animal");
			orAddDeclaration2.Append("GUID", this.GUID);
			orAddDeclaration2.Append("Attack_Anim_Variants", this.attackAnimVariantsCount);
			orAddDeclaration2.Append("Attack_Interval", this.attackInterval);
			orAddDeclaration2.Append("Behaviour", this.behaviour);
			orAddDeclaration2.Append("Damage", this.damage);
			orAddDeclaration2.Append("Eat_Anim_Variants", this.eatAnimVariantsCount);
			orAddDeclaration2.Append("Glance_Anim_Variants", this.glanceAnimVariantsCount);
			orAddDeclaration2.Append("Health", this.health);
			orAddDeclaration2.Append("Horizontal_Attack_Range", Mathf.Sqrt(this.horizontalAttackRangeSquared));
			orAddDeclaration2.Append("Horizontal_Vehicle_Attack_Range", Mathf.Sqrt(this.horizontalVehicleAttackRangeSquared));
			orAddDeclaration2.Append("Meat", this.meat);
			orAddDeclaration2.Append("Panics", this.panics.Length);
			orAddDeclaration2.Append("Pelt", this.pelt);
			orAddDeclaration2.Append("Regen", this.regen);
			orAddDeclaration2.Append("Reward_ID", this.rewardID);
			orAddDeclaration2.Append("Reward_Max", this.rewardMax);
			orAddDeclaration2.Append("Reward_Min", this.rewardMin);
			orAddDeclaration2.Append("Reward_XP", this.rewardXP);
			orAddDeclaration2.Append("Roars", this.roars.Length);
			orAddDeclaration2.Append("Should_Play_Anims_On_Dedicated_Server", this.shouldPlayAnimsOnDedicatedServer);
			orAddDeclaration2.Append("Speed_Run", this.speedRun);
			orAddDeclaration2.Append("Speed_Walk", this.speedWalk);
			orAddDeclaration2.Append("Startle_Anim_Variants", this.startleAnimVariantsCount);
			orAddDeclaration2.Append("Vertical_Attack_Range", this.verticalAttackRange);
		}

		// Token: 0x060013DC RID: 5084 RVA: 0x0004C5B7 File Offset: 0x0004A7B7
		internal string OnGetRewardSpawnTableErrorContext()
		{
			return this.FriendlyName + " reward";
		}

		// Token: 0x040006D5 RID: 1749
		protected string _animalName;

		// Token: 0x040006D6 RID: 1750
		protected GameObject _client;

		// Token: 0x040006D7 RID: 1751
		protected GameObject _server;

		// Token: 0x040006D8 RID: 1752
		protected GameObject _dedicated;

		// Token: 0x040006D9 RID: 1753
		protected GameObject _ragdoll;

		// Token: 0x040006DA RID: 1754
		protected float _speedRun;

		// Token: 0x040006DB RID: 1755
		protected float _speedWalk;

		// Token: 0x040006DC RID: 1756
		private EAnimalBehaviour _behaviour;

		// Token: 0x040006DD RID: 1757
		protected ushort _health;

		// Token: 0x040006DE RID: 1758
		protected uint _rewardXP;

		// Token: 0x040006DF RID: 1759
		protected float _regen;

		// Token: 0x040006E0 RID: 1760
		protected byte _damage;

		// Token: 0x040006E1 RID: 1761
		protected ushort _meat;

		// Token: 0x040006E2 RID: 1762
		protected ushort _pelt;

		// Token: 0x040006E3 RID: 1763
		private byte _rewardMin;

		// Token: 0x040006E4 RID: 1764
		private byte _rewardMax;

		// Token: 0x040006E5 RID: 1765
		private ushort _rewardID;

		// Token: 0x040006E6 RID: 1766
		protected AudioClip[] _roars;

		// Token: 0x040006E7 RID: 1767
		protected AudioClip[] _panics;

		/// <summary>
		/// Minimum seconds between attacks.
		/// </summary>
		// Token: 0x040006EF RID: 1775
		public float attackInterval;
	}
}
