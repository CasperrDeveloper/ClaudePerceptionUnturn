﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x0200022B RID: 555
	public abstract class ClientInstanceMethodBase : ClientMethodHandle
	{
		// Token: 0x06001145 RID: 4421 RVA: 0x0003F44F File Offset: 0x0003D64F
		protected NetPakWriter GetWriterWithInstanceHeader(NetId netId)
		{
			NetPakWriter writerWithStaticHeader = base.GetWriterWithStaticHeader();
			writerWithStaticHeader.WriteNetId(netId);
			return writerWithStaticHeader;
		}

		// Token: 0x06001146 RID: 4422 RVA: 0x0003F45F File Offset: 0x0003D65F
		protected ClientInstanceMethodBase(ClientMethodInfo clientMethodInfo) : base(clientMethodInfo)
		{
		}
	}
}
