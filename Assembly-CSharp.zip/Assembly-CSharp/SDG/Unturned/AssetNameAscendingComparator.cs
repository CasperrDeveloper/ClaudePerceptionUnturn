﻿using System;
using System.Collections.Generic;

namespace SDG.Unturned
{
	// Token: 0x02000823 RID: 2083
	public class AssetNameAscendingComparator : IComparer<Asset>
	{
		// Token: 0x060046E3 RID: 18147 RVA: 0x0016EC97 File Offset: 0x0016CE97
		public int Compare(Asset a, Asset b)
		{
			return a.name.CompareTo(b.name);
		}
	}
}
