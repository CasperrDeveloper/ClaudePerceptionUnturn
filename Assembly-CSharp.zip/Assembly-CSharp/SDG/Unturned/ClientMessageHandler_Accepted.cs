﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using BattlEye;
using SDG.NetPak;
using Steamworks;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x02000274 RID: 628
	internal static class ClientMessageHandler_Accepted
	{
		// Token: 0x060012F3 RID: 4851 RVA: 0x000443CC File Offset: 0x000425CC
		internal static void ReadMessage(NetPakReader reader)
		{
			Provider.isWaitingForAuthenticationResponse = false;
			uint num;
			reader.ReadUInt32(out num);
			ushort num2;
			reader.ReadUInt16(out num2);
			bool flag = SteamNetworkingUtils.IsFakeIPv4(num);
			UnturnedLog.info("Accepted by server");
			if (Provider.IsBattlEyeActiveOnCurrentServer)
			{
				string text = ReadWrite.PATH + "/BattlEye/BEClient_x64.dll";
				if (!File.Exists(text))
				{
					text = ReadWrite.PATH + "/BattlEye/BEClient.dll";
				}
				if (!File.Exists(text))
				{
					Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
					Provider._connectionFailureReason = "Missing BattlEye client library! (" + text + ")";
					UnturnedLog.error(Provider.connectionFailureReason);
					Provider.RequestDisconnect("BattlEye missing");
					return;
				}
				UnturnedLog.info("Loading BattlEye client library from: " + text);
				try
				{
					Provider.battlEyeClientHandle = BEClient.LoadLibraryW(text);
					if (!(Provider.battlEyeClientHandle != IntPtr.Zero))
					{
						Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
						Provider._connectionFailureReason = "Failed to load BattlEye client library!";
						UnturnedLog.error(Provider.connectionFailureReason);
						Provider.RequestDisconnect("BattlEye load error");
						return;
					}
					BEClient.BEClientInitFn beclientInitFn = Marshal.GetDelegateForFunctionPointer(BEClient.GetProcAddress(Provider.battlEyeClientHandle, "Init"), typeof(BEClient.BEClientInitFn)) as BEClient.BEClientInitFn;
					if (beclientInitFn == null)
					{
						BEClient.FreeLibrary(Provider.battlEyeClientHandle);
						Provider.battlEyeClientHandle = IntPtr.Zero;
						Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
						Provider._connectionFailureReason = "Failed to get BattlEye client init delegate!";
						UnturnedLog.error(Provider.connectionFailureReason);
						Provider.RequestDisconnect("BattlEye get init error");
						return;
					}
					uint ulAddress;
					ushort usPort;
					if (flag)
					{
						ulAddress = 0U;
						usPort = 0;
					}
					else
					{
						ulAddress = ((num & 255U) << 24 | (num & 65280U) << 8 | (num & 16711680U) >> 8 | (num & 4278190080U) >> 24);
						usPort = (ushort)((int)(num2 & 255) << 8 | (int)((uint)(num2 & 65280) >> 8));
					}
					Provider.battlEyeClientInitData = new BEClient.BECL_GAME_DATA();
					Provider.battlEyeClientInitData.pstrGameVersion = Provider.APP_NAME + " " + Provider.APP_VERSION;
					Provider.battlEyeClientInitData.ulAddress = ulAddress;
					Provider.battlEyeClientInitData.usPort = usPort;
					Provider.battlEyeClientInitData.pfnPrintMessage = new BEClient.BECL_GAME_DATA.PrintMessageFn(Provider.battlEyeClientPrintMessage);
					Provider.battlEyeClientInitData.pfnRequestRestart = new BEClient.BECL_GAME_DATA.RequestRestartFn(Provider.battlEyeClientRequestRestart);
					Provider.battlEyeClientInitData.pfnSendPacket = new BEClient.BECL_GAME_DATA.SendPacketFn(Provider.battlEyeClientSendPacket);
					Provider.battlEyeClientRunData = new BEClient.BECL_BE_DATA();
					if (!beclientInitFn(2, Provider.battlEyeClientInitData, Provider.battlEyeClientRunData))
					{
						BEClient.FreeLibrary(Provider.battlEyeClientHandle);
						Provider.battlEyeClientHandle = IntPtr.Zero;
						Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
						Provider._connectionFailureReason = "Failed to call BattlEye client init!";
						UnturnedLog.error(Provider.connectionFailureReason);
						Provider.RequestDisconnect("BattlEye init error");
						return;
					}
				}
				catch (Exception e)
				{
					Provider._connectionFailureInfo = ESteamConnectionFailureInfo.KICKED;
					Provider._connectionFailureReason = "Unhandled exception when loading BattlEye client library!";
					UnturnedLog.error(Provider.connectionFailureReason);
					UnturnedLog.exception(e);
					Provider.RequestDisconnect("BattlEye load exception");
					return;
				}
			}
			ModeConfigData modeConfigData = Provider._modeConfigData;
			bool? flag2;
			if (modeConfigData == null)
			{
				flag2 = null;
			}
			else
			{
				GameplayConfigData gameplay = modeConfigData.Gameplay;
				flag2 = ((gameplay != null) ? new bool?(gameplay.Use_2D_Scope_Overlay) : null);
			}
			bool? flag3 = flag2;
			bool valueOrDefault = flag3.GetValueOrDefault();
			Provider._modeConfigData = new ModeConfigData(Provider.mode);
			byte repair_Level_Max;
			reader.ReadUInt8(out repair_Level_Max);
			Provider._modeConfigData.Gameplay.Repair_Level_Max = (uint)repair_Level_Max;
			reader.ReadBit(out Provider._modeConfigData.Players.Skillset_Reduces_Skill_Cost);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Hitmarkers);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Crosshair);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Ballistics);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Chart);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Satellite);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Compass);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Group_Map);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Group_HUD);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Group_Player_List);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Allow_Static_Groups);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Allow_Dynamic_Groups);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Allow_Shoulder_Camera);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Can_Suicide);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Friendly_Fire);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Bypass_Buildable_Mobility);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Allow_Freeform_Buildables);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Allow_Freeform_Buildables_On_Vehicles);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Enable_Damage_Flinch);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Enable_Explosion_Camera_Shake);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Enable_Workstation_Requirements);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Disable_Motion_Sickness_Options);
			reader.ReadBit(out Provider._modeConfigData.Gameplay.Use_2D_Scope_Overlay);
			if (Provider._modeConfigData.Gameplay.Use_2D_Scope_Overlay != valueOrDefault && Player.LocalPlayer != null)
			{
				Player.LocalPlayer.look.updateScope(GraphicsSettings.scopeQuality);
			}
			ushort a;
			reader.ReadUInt16(out a);
			Provider._modeConfigData.Gameplay.Timer_Exit = MathfEx.Min((uint)a, 60U);
			ushort timer_Respawn;
			reader.ReadUInt16(out timer_Respawn);
			Provider._modeConfigData.Gameplay.Timer_Respawn = (uint)timer_Respawn;
			ushort timer_Home;
			reader.ReadUInt16(out timer_Home);
			Provider._modeConfigData.Gameplay.Timer_Home = (uint)timer_Home;
			ushort max_Group_Members;
			reader.ReadUInt16(out max_Group_Members);
			Provider._modeConfigData.Gameplay.Max_Group_Members = (uint)max_Group_Members;
			reader.ReadBit(out Provider._modeConfigData.Barricades.Allow_Item_Placement_On_Vehicle);
			reader.ReadBit(out Provider._modeConfigData.Barricades.Allow_Trap_Placement_On_Vehicle);
			reader.ReadFloat(out Provider._modeConfigData.Barricades.Max_Item_Distance_From_Hull);
			reader.ReadFloat(out Provider._modeConfigData.Barricades.Max_Trap_Distance_From_Hull);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.AirStrafing_Acceleration_Multiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.AirStrafing_Deceleration_Multiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.FirstPerson_RecoilMultiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.FirstPerson_AimingRecoilMultiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.FirstPerson_AimingZoomRecoilReduction);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.ThirdPerson_RecoilMultiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.ThirdPerson_SpreadMultiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.Viewmodel_AimingJumpLandMultiplier);
			reader.ReadFloat(out Provider._modeConfigData.Gameplay.Viewmodel_AimingMisalignmentMultiplier);
			ClientMessageHandler_Accepted.RichPresenceConnectionTarget = Provider.server.ToString();
			if (flag)
			{
				IPv4Address pv4Address = new IPv4Address(num);
				ClientMessageHandler_Accepted.RichPresenceConnectionTarget = string.Format("{0}:{1}", pv4Address, num2);
				UnturnedLog.info("Rich presence advertisement using Fake IP address (" + ClientMessageHandler_Accepted.RichPresenceConnectionTarget + ")");
			}
			else
			{
				UnturnedLog.info("Rich presence advertisement using server code (" + ClientMessageHandler_Accepted.RichPresenceConnectionTarget + ")");
			}
			if (OptionsSettings.ShouldHideRichPresence)
			{
				SteamFriends.SetRichPresence("connect", "");
			}
			else
			{
				SteamUser.AdvertiseGame(Provider.server, 0U, 0);
				SteamFriends.SetRichPresence("connect", "+connect " + ClientMessageHandler_Accepted.RichPresenceConnectionTarget);
			}
			Lobbies.leaveLobby();
			SteamMatchmaking.AddFavoriteGame(Provider.APP_ID, num, num2 + 1, num2, Provider.STEAM_FAVORITE_FLAG_HISTORY, SteamUtils.GetServerRealTime());
			Provider.updateRichPresence();
			Provider.ClientConnected onClientConnected = Provider.onClientConnected;
			if (onClientConnected != null)
			{
				onClientConnected();
			}
			Action onGameplayConfigReceived = ClientMessageHandler_Accepted.OnGameplayConfigReceived;
			if (onGameplayConfigReceived == null)
			{
				return;
			}
			onGameplayConfigReceived();
		}

		/// <summary>
		/// Nelson 2025-06-19: using server-provided connection details is useful because
		/// it can find its public IP (e.g., joining by LAN and sharing WAN IP), and/or
		/// its fake IP (again when joining by LAN).
		/// </summary>
		// Token: 0x17000267 RID: 615
		// (get) Token: 0x060012F4 RID: 4852 RVA: 0x00044BC8 File Offset: 0x00042DC8
		// (set) Token: 0x060012F5 RID: 4853 RVA: 0x00044BCF File Offset: 0x00042DCF
		internal static string RichPresenceConnectionTarget { get; private set; }

		// Token: 0x14000071 RID: 113
		// (add) Token: 0x060012F6 RID: 4854 RVA: 0x00044BD8 File Offset: 0x00042DD8
		// (remove) Token: 0x060012F7 RID: 4855 RVA: 0x00044C0C File Offset: 0x00042E0C
		internal static event Action OnGameplayConfigReceived;
	}
}
