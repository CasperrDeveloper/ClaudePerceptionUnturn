﻿using System;
using System.Diagnostics;
using SDG.NetPak;

namespace SDG.Unturned
{
	/// <summary>
	/// Optional parameter for error logging.
	/// </summary>
	// Token: 0x02000239 RID: 569
	public readonly struct ClientInvocationContext
	{
		// Token: 0x060011B0 RID: 4528 RVA: 0x00040800 File Offset: 0x0003EA00
		[Conditional("UNITY_EDITOR")]
		[Conditional("DEVELOPMENT_BUILD")]
		[Conditional("DEBUG_NETINVOKABLES")]
		public void ReadParameterFailed(string parameterName)
		{
			UnturnedLog.warn("{0}: unable to read {1}", new object[]
			{
				this.clientMethodInfo,
				parameterName
			});
		}

		// Token: 0x060011B1 RID: 4529 RVA: 0x0004081F File Offset: 0x0003EA1F
		[Conditional("UNITY_EDITOR")]
		[Conditional("DEVELOPMENT_BUILD")]
		[Conditional("DEBUG_NETINVOKABLES")]
		public void IndexOutOfRange(string parameterName, int index, int max)
		{
			UnturnedLog.error("{0}: {1} out of range ({2}/{3})", new object[]
			{
				this.clientMethodInfo,
				parameterName,
				index,
				max
			});
		}

		// Token: 0x060011B2 RID: 4530 RVA: 0x00040850 File Offset: 0x0003EA50
		[Conditional("UNITY_EDITOR")]
		[Conditional("DEVELOPMENT_BUILD")]
		[Conditional("DEBUG_NETINVOKABLES")]
		public void LogWarning(string message)
		{
			UnturnedLog.warn("{0}: {1}", new object[]
			{
				this.clientMethodInfo,
				message
			});
		}

		// Token: 0x060011B3 RID: 4531 RVA: 0x0004086F File Offset: 0x0003EA6F
		internal ClientInvocationContext(ClientInvocationContext.EOrigin origin, NetPakReader reader, ClientMethodInfo clientMethodInfo)
		{
			this.origin = origin;
			this.reader = reader;
			this.clientMethodInfo = clientMethodInfo;
		}

		// Token: 0x040005D5 RID: 1493
		public readonly ClientInvocationContext.EOrigin origin;

		// Token: 0x040005D6 RID: 1494
		public readonly NetPakReader reader;

		// Token: 0x040005D7 RID: 1495
		internal readonly ClientMethodInfo clientMethodInfo;

		// Token: 0x02000944 RID: 2372
		public enum EOrigin
		{
			// Token: 0x04003741 RID: 14145
			Remote,
			// Token: 0x04003742 RID: 14146
			Loopback,
			// Token: 0x04003743 RID: 14147
			Deferred
		}
	}
}
