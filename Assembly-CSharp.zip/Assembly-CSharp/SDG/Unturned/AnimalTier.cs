﻿using System;
using System.Collections.Generic;

namespace SDG.Unturned
{
	// Token: 0x020004FB RID: 1275
	public class AnimalTier
	{
		// Token: 0x17000871 RID: 2161
		// (get) Token: 0x060029CD RID: 10701 RVA: 0x000B5055 File Offset: 0x000B3255
		public List<AnimalSpawn> table
		{
			get
			{
				return this._table;
			}
		}

		// Token: 0x060029CE RID: 10702 RVA: 0x000B5060 File Offset: 0x000B3260
		public void addAnimal(ushort id)
		{
			if (this.table.Count == 255)
			{
				return;
			}
			byte b = 0;
			while ((int)b < this.table.Count)
			{
				if (this.table[(int)b].animal == id)
				{
					return;
				}
				b += 1;
			}
			this.table.Add(new AnimalSpawn(id));
		}

		// Token: 0x060029CF RID: 10703 RVA: 0x000B50BD File Offset: 0x000B32BD
		public void removeAnimal(byte index)
		{
			this.table.RemoveAt((int)index);
		}

		// Token: 0x060029D0 RID: 10704 RVA: 0x000B50CB File Offset: 0x000B32CB
		public AnimalTier(List<AnimalSpawn> newTable, string newName, float newChance)
		{
			this._table = newTable;
			this.name = newName;
			this.chance = newChance;
		}

		// Token: 0x04001517 RID: 5399
		private List<AnimalSpawn> _table;

		// Token: 0x04001518 RID: 5400
		public string name;

		// Token: 0x04001519 RID: 5401
		public float chance;
	}
}
