﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004F8 RID: 1272
	public class AnimalSpawn
	{
		// Token: 0x1700086C RID: 2156
		// (get) Token: 0x060029B9 RID: 10681 RVA: 0x000B48E5 File Offset: 0x000B2AE5
		public ushort animal
		{
			get
			{
				return this._animal;
			}
		}

		// Token: 0x060029BA RID: 10682 RVA: 0x000B48ED File Offset: 0x000B2AED
		public AnimalSpawn(ushort newAnimal)
		{
			this._animal = newAnimal;
		}

		// Token: 0x0400150F RID: 5391
		private ushort _animal;
	}
}
