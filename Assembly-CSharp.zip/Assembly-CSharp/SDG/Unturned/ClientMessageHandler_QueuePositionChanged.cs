﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x0200027F RID: 639
	internal static class ClientMessageHandler_QueuePositionChanged
	{
		// Token: 0x06001305 RID: 4869 RVA: 0x00045558 File Offset: 0x00043758
		internal static void ReadMessage(NetPakReader reader)
		{
			if (Provider.isWaitingForConnectResponse)
			{
				Provider.isWaitingForConnectResponse = false;
				UnturnedLog.info("Connection pending verification");
			}
			byte queuePosition = Provider.queuePosition;
			byte b;
			reader.ReadUInt8(out b);
			Provider._queuePosition = b;
			if (queuePosition != b)
			{
				UnturnedLog.info("Queue position: {0}", new object[]
				{
					Provider.queuePosition
				});
			}
			Provider.QueuePositionUpdated onQueuePositionUpdated = Provider.onQueuePositionUpdated;
			if (onQueuePositionUpdated == null)
			{
				return;
			}
			onQueuePositionUpdated();
		}
	}
}
