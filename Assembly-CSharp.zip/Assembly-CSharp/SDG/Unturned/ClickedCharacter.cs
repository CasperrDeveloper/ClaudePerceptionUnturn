﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007A4 RID: 1956
	// (Invoke) Token: 0x06004387 RID: 17287
	public delegate void ClickedCharacter(SleekCharacter character, byte index);
}
