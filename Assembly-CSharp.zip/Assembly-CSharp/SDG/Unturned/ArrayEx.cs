﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020008A5 RID: 2213
	public static class ArrayEx
	{
		// Token: 0x06004EC6 RID: 20166 RVA: 0x001E62D7 File Offset: 0x001E44D7
		public static int GetRandomIndex<T>(this T[] array)
		{
			return UnityEngine.Random.Range(0, array.Length);
		}

		// Token: 0x06004EC7 RID: 20167 RVA: 0x001E62E4 File Offset: 0x001E44E4
		public static T RandomOrDefault<T>(this T[] array)
		{
			if (array.Length != 0)
			{
				return array[UnityEngine.Random.Range(0, array.Length)];
			}
			return default(T);
		}
	}
}
