﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SDG.Unturned
{
	/// <summary>
	/// Converts Steam BBcode tokens into widgets displayable using Glazier UI.
	/// </summary>
	// Token: 0x02000460 RID: 1120
	public class BbCodeWidgetConverter
	{
		// Token: 0x0600232D RID: 9005 RVA: 0x0009297E File Offset: 0x00090B7E
		public BbCodeWidgetConverter()
		{
			this.richTextStringBuilder = new StringBuilder();
		}

		/// <summary>
		/// If false, expect LineBreak tokens in input. (default false)
		/// If true, insert line breaks where appropriate.
		/// Steam's new visual editor doesn't emit newlines, instead inferring line breaks from paragraph blocks. To
		/// make life easier we will do the same for the main menu announcement feed.
		/// </summary>
		// Token: 0x1700075D RID: 1885
		// (get) Token: 0x0600232E RID: 9006 RVA: 0x00092991 File Offset: 0x00090B91
		// (set) Token: 0x0600232F RID: 9007 RVA: 0x00092999 File Offset: 0x00090B99
		public bool InferLineBreaks
		{
			get
			{
				return this._inferLineBreaks;
			}
			set
			{
				this._inferLineBreaks = value;
			}
		}

		// Token: 0x06002330 RID: 9008 RVA: 0x000929A4 File Offset: 0x00090BA4
		public List<BbCodeWidget> Convert(List<BbCodeToken> tokens)
		{
			this.richTextStringBuilder.Clear();
			this.inputTokens = tokens;
			this.inputIndex = -1;
			this.hasToken = false;
			List<BbCodeWidget> list = new List<BbCodeWidget>();
			this.AdvanceToken();
			int num = 0;
			while (this.hasToken)
			{
				this.ConvertToken(list);
				num++;
				if (num >= 10000)
				{
					this.ErrorMessage = "Infinite loop attempting to convert tokens into widgets";
					break;
				}
			}
			return list;
		}

		// Token: 0x1700075E RID: 1886
		// (get) Token: 0x06002331 RID: 9009 RVA: 0x00092A0B File Offset: 0x00090C0B
		public bool HasError
		{
			get
			{
				return this.hasError;
			}
		}

		// Token: 0x1700075F RID: 1887
		// (get) Token: 0x06002332 RID: 9010 RVA: 0x00092A13 File Offset: 0x00090C13
		// (set) Token: 0x06002333 RID: 9011 RVA: 0x00092A1B File Offset: 0x00090C1B
		public string ErrorMessage
		{
			get
			{
				return this.errorMessage;
			}
			private set
			{
				this.errorMessage = value;
				this.hasError = !string.IsNullOrEmpty(this.errorMessage);
			}
		}

		// Token: 0x06002334 RID: 9012 RVA: 0x00092A38 File Offset: 0x00090C38
		private void AdvanceToken()
		{
			this.inputIndex++;
			this.hasToken = (this.inputIndex < this.inputTokens.Count);
			if (this.hasToken)
			{
				this.currentToken = this.inputTokens[this.inputIndex];
			}
		}

		// Token: 0x06002335 RID: 9013 RVA: 0x00092A8B File Offset: 0x00090C8B
		private EBbCodeTokenType PeekNextTokenType()
		{
			if (this.inputIndex + 1 < this.inputTokens.Count)
			{
				return this.inputTokens[this.inputIndex + 1].tokenType;
			}
			return EBbCodeTokenType.Invalid;
		}

		// Token: 0x06002336 RID: 9014 RVA: 0x00092ABC File Offset: 0x00090CBC
		private void ConvertToken(List<BbCodeWidget> outputWidgets)
		{
			if (this.currentToken.tokenType == EBbCodeTokenType.PreviewYouTubeOpen)
			{
				this.ConvertPreviewYouTube(outputWidgets);
				return;
			}
			if (this.currentToken.tokenType == EBbCodeTokenType.ImgOpen)
			{
				this.ConvertImage(outputWidgets);
				return;
			}
			if (this.currentToken.tokenType == EBbCodeTokenType.UrlOpen)
			{
				this.ConvertLinkButton(outputWidgets);
				return;
			}
			this.ConvertRichText(outputWidgets);
		}

		// Token: 0x06002337 RID: 9015 RVA: 0x00092B18 File Offset: 0x00090D18
		private void ConvertPreviewYouTube(List<BbCodeWidget> outputWidgets)
		{
			string unquotedValue = this.currentToken.GetUnquotedValue();
			if (!string.IsNullOrEmpty(unquotedValue))
			{
				int num = unquotedValue.IndexOf(';');
				string widgetData;
				if (num > 0)
				{
					widgetData = unquotedValue.Substring(0, num);
				}
				else
				{
					widgetData = unquotedValue;
				}
				outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.YouTubeButton, widgetData));
			}
			this.AdvanceToken();
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.PreviewYouTubeClose)
			{
				this.AdvanceToken();
			}
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.LineBreak)
			{
				this.AdvanceToken();
			}
		}

		// Token: 0x06002338 RID: 9016 RVA: 0x00092BA0 File Offset: 0x00090DA0
		private void ConvertImage(List<BbCodeWidget> outputWidgets)
		{
			string tokenValue;
			bool flag = this.currentToken.TryParseValue("src", out tokenValue);
			this.AdvanceToken();
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.String)
			{
				if (!flag)
				{
					tokenValue = this.currentToken.tokenValue;
				}
				outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.Image, tokenValue));
				this.AdvanceToken();
				if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.ImgClose)
				{
					this.AdvanceToken();
				}
			}
			else if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.ImgClose)
			{
				if (flag)
				{
					outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.Image, tokenValue));
				}
				this.AdvanceToken();
			}
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.LineBreak)
			{
				this.AdvanceToken();
			}
		}

		// Token: 0x06002339 RID: 9017 RVA: 0x00092C68 File Offset: 0x00090E68
		private void ConvertLinkButton(List<BbCodeWidget> outputWidgets)
		{
			string text = this.currentToken.GetUnquotedValue();
			string text2 = null;
			this.AdvanceToken();
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.String)
			{
				if (string.IsNullOrEmpty(text))
				{
					text = this.currentToken.tokenValue;
				}
				else
				{
					text2 = this.currentToken.tokenValue;
				}
				this.AdvanceToken();
			}
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.UrlClose)
			{
				this.AdvanceToken();
			}
			if (this.hasToken && this.currentToken.tokenType == EBbCodeTokenType.LineBreak)
			{
				this.AdvanceToken();
			}
			if (string.IsNullOrEmpty(text2))
			{
				outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.LinkButton, text));
				return;
			}
			outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.LinkButton, text + "," + text2));
		}

		// Token: 0x0600233A RID: 9018 RVA: 0x00092D30 File Offset: 0x00090F30
		private void ConvertRichText(List<BbCodeWidget> outputWidgets)
		{
			this.richTextStringBuilder.Clear();
			bool flag = false;
			int num = 0;
			bool flag2 = true;
			do
			{
				bool flag3 = false;
				switch (this.currentToken.tokenType)
				{
				case EBbCodeTokenType.String:
					this.richTextStringBuilder.Append(this.currentToken.tokenValue);
					break;
				case EBbCodeTokenType.BoldOpen:
					this.richTextStringBuilder.Append("<b>");
					break;
				case EBbCodeTokenType.BoldClose:
					this.richTextStringBuilder.Append("</b>");
					break;
				case EBbCodeTokenType.ItalicOpen:
					this.richTextStringBuilder.Append("<i>");
					break;
				case EBbCodeTokenType.ItalicClose:
					this.richTextStringBuilder.Append("</i>");
					break;
				case EBbCodeTokenType.BulletListOpen:
				case EBbCodeTokenType.BulletListClose:
					this.PushPendingRichText(outputWidgets);
					flag3 = true;
					break;
				case EBbCodeTokenType.OrderedListOpen:
					flag = true;
					num = 0;
					this.PushPendingRichText(outputWidgets);
					flag3 = true;
					break;
				case EBbCodeTokenType.OrderedListClose:
					flag = false;
					this.PushPendingRichText(outputWidgets);
					flag3 = true;
					break;
				case EBbCodeTokenType.ListItemOpen:
					if (!flag2 && this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append('\n');
					}
					flag3 = true;
					if (flag)
					{
						this.richTextStringBuilder.Append(num + 1);
						this.richTextStringBuilder.Append(". ");
						num++;
					}
					else
					{
						this.richTextStringBuilder.Append("• ");
					}
					break;
				case EBbCodeTokenType.ListItemClose:
				case EBbCodeTokenType.ParagraphClose:
					if (this._inferLineBreaks)
					{
						if (!flag2)
						{
							this.richTextStringBuilder.Append('\n');
						}
						EBbCodeTokenType ebbCodeTokenType = this.PeekNextTokenType();
						switch (ebbCodeTokenType)
						{
						case EBbCodeTokenType.H1Open:
						case EBbCodeTokenType.H2Open:
						case EBbCodeTokenType.H3Open:
							break;
						case EBbCodeTokenType.H1Close:
						case EBbCodeTokenType.H2Close:
							goto IL_13A;
						default:
							if (ebbCodeTokenType != EBbCodeTokenType.ParagraphOpen)
							{
								goto IL_13A;
							}
							break;
						}
						this.richTextStringBuilder.Append('\n');
					}
					IL_13A:
					flag3 = true;
					break;
				case EBbCodeTokenType.H1Open:
					if (!flag2 && this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					this.richTextStringBuilder.Append("<size=20>");
					break;
				case EBbCodeTokenType.H1Close:
					this.richTextStringBuilder.Append("</size>");
					if (this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					break;
				case EBbCodeTokenType.H2Open:
					if (!flag2 && this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					this.richTextStringBuilder.Append("<size=17>");
					break;
				case EBbCodeTokenType.H2Close:
					this.richTextStringBuilder.Append("</size>");
					if (this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					break;
				case EBbCodeTokenType.H3Open:
					if (!flag2 && this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					this.richTextStringBuilder.Append("<size=14>");
					break;
				case EBbCodeTokenType.H3Close:
					this.richTextStringBuilder.Append("</size>");
					if (this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append("\n\n");
					}
					flag3 = true;
					break;
				case EBbCodeTokenType.LineBreak:
					this.richTextStringBuilder.Append('\n');
					flag3 = true;
					break;
				case EBbCodeTokenType.QuoteOpen:
					if (string.IsNullOrEmpty(this.currentToken.tokenValue))
					{
						this.richTextStringBuilder.Append("<indent=2em>");
					}
					else
					{
						this.richTextStringBuilder.Append("<indent=2em><b>" + this.currentToken.tokenValue + ":</b>\n");
					}
					break;
				case EBbCodeTokenType.QuoteClose:
					this.richTextStringBuilder.Append("</indent>");
					if (this._inferLineBreaks)
					{
						this.richTextStringBuilder.Append('\n');
					}
					flag3 = true;
					break;
				}
				EBbCodeTokenType tokenType = this.currentToken.tokenType;
				this.AdvanceToken();
				if (this.currentToken.tokenType == EBbCodeTokenType.PreviewYouTubeOpen || this.currentToken.tokenType == EBbCodeTokenType.ImgOpen || (this.currentToken.tokenType == EBbCodeTokenType.UrlOpen && (tokenType == EBbCodeTokenType.LineBreak || tokenType == EBbCodeTokenType.ParagraphOpen)))
				{
					break;
				}
				flag2 = flag3;
			}
			while (this.hasToken);
			this.PushPendingRichText(outputWidgets);
		}

		// Token: 0x0600233B RID: 9019 RVA: 0x00093150 File Offset: 0x00091350
		private void PushPendingRichText(List<BbCodeWidget> outputWidgets)
		{
			if (this.richTextStringBuilder.Length > 0)
			{
				string widgetData = this.richTextStringBuilder.ToString();
				outputWidgets.Add(new BbCodeWidget(EBbCodeWidgetType.RichTextLabel, widgetData));
				this.richTextStringBuilder.Clear();
			}
		}

		// Token: 0x04001194 RID: 4500
		private bool _inferLineBreaks;

		// Token: 0x04001195 RID: 4501
		private List<BbCodeToken> inputTokens;

		// Token: 0x04001196 RID: 4502
		private int inputIndex;

		// Token: 0x04001197 RID: 4503
		private bool hasToken;

		// Token: 0x04001198 RID: 4504
		private BbCodeToken currentToken;

		// Token: 0x04001199 RID: 4505
		private bool hasError;

		// Token: 0x0400119A RID: 4506
		private string errorMessage;

		// Token: 0x0400119B RID: 4507
		private StringBuilder richTextStringBuilder;
	}
}
