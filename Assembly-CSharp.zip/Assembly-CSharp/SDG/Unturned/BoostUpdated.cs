﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020006D5 RID: 1749
	// (Invoke) Token: 0x06003C60 RID: 15456
	public delegate void BoostUpdated(EPlayerBoost newBoost);
}
