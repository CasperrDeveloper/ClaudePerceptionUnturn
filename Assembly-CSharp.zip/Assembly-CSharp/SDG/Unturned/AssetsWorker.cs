﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;

namespace SDG.Unturned
{
	/// <summary>
	/// Responsible for loading asset definitions on a separate thread.
	/// </summary>
	// Token: 0x020002A4 RID: 676
	internal class AssetsWorker
	{
		/// <summary>
		/// Used on main thread to determine when all queued tasks have finished.
		/// </summary>
		// Token: 0x170002DA RID: 730
		// (get) Token: 0x060014A9 RID: 5289 RVA: 0x000505B3 File Offset: 0x0004E7B3
		public bool IsWorking
		{
			get
			{
				return this.isWorking;
			}
		}

		// Token: 0x060014AA RID: 5290 RVA: 0x000505BB File Offset: 0x0004E7BB
		public void Initialize()
		{
			this.language = Provider.language;
			this.languageIsEnglish = Provider.languageIsEnglish;
			this.shouldWorkerThreadsContinue = 1;
			this.foundMasterBundles = new ConcurrentQueue<AssetsWorker.MasterBundle>();
			this.foundAssetDefinitions = new ConcurrentQueue<AssetsWorker.AssetDefinition>();
			this.exceptions = new ConcurrentQueue<AssetsWorker.ExceptionDetails>();
		}

		// Token: 0x060014AB RID: 5291 RVA: 0x000505FB File Offset: 0x0004E7FB
		public void Shutdown()
		{
			Interlocked.Exchange(ref this.shouldWorkerThreadsContinue, 0);
		}

		// Token: 0x060014AC RID: 5292 RVA: 0x0005060C File Offset: 0x0004E80C
		public void RequestSearch(string path, AssetOrigin origin)
		{
			this.totalSearchLocationRequests++;
			AssetsWorker.WorkerThreadState workerThreadState = new AssetsWorker.WorkerThreadState
			{
				owner = this,
				rootPath = path,
				searchPaths = new Queue<string>(),
				masterBundleFilePaths = new ConcurrentQueue<string>(),
				assetDefinitionFilePaths = new ConcurrentQueue<AssetsWorker.WorkerThreadState.AssetDefFilePath>(),
				datParser = new DatParser(),
				origin = origin
			};
			workerThreadState.datParser.EnableMetadata = Assets.shouldParseMetadata;
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.SearcherThreadMain), workerThreadState);
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.ReaderThreadMain), workerThreadState);
			this.isWorking = true;
		}

		// Token: 0x060014AD RID: 5293 RVA: 0x000506B0 File Offset: 0x0004E8B0
		public bool TryDequeueMasterBundle(out AssetsWorker.MasterBundle result)
		{
			return this.foundMasterBundles.TryDequeue(out result);
		}

		// Token: 0x060014AE RID: 5294 RVA: 0x000506BE File Offset: 0x0004E8BE
		public bool TryDequeueAssetDefinition(out AssetsWorker.AssetDefinition result)
		{
			return this.foundAssetDefinitions.TryDequeue(out result);
		}

		// Token: 0x060014AF RID: 5295 RVA: 0x000506CC File Offset: 0x0004E8CC
		public void Update()
		{
			this.isWorking = (this.totalSearchLocationRequests > this.totalSearchLocationsFinishedReading || this.foundMasterBundles.Count > 0 || this.foundAssetDefinitions.Count > 0);
			AssetsWorker.ExceptionDetails exceptionDetails;
			while (this.exceptions.TryDequeue(out exceptionDetails))
			{
				UnturnedLog.exception(exceptionDetails.exception, exceptionDetails.message);
			}
		}

		/// <summary>
		/// Loop searching directories recursively for asset bundle and asset definition files.
		/// </summary>
		// Token: 0x060014B0 RID: 5296 RVA: 0x00050730 File Offset: 0x0004E930
		private void SearcherThreadMain(object untypedState)
		{
			AssetsWorker.WorkerThreadState workerThreadState = (AssetsWorker.WorkerThreadState)untypedState;
			workerThreadState.searchPaths.Enqueue(workerThreadState.rootPath);
			while (this.shouldWorkerThreadsContinue > 0 && workerThreadState.searchPaths.Count > 0)
			{
				string text = workerThreadState.searchPaths.Dequeue();
				string text2 = Path.Combine(text, "MasterBundle.dat");
				try
				{
					if (File.Exists(text2))
					{
						Interlocked.Increment(ref this.totalMasterBundlesFound);
						workerThreadState.masterBundleFilePaths.Enqueue(text2);
					}
				}
				catch (Exception exception)
				{
					workerThreadState.AddException(exception, "Caught exception reading master bundle config at: \"" + text2 + "\"");
				}
				workerThreadState.FindAssets(text, workerThreadState.origin);
				try
				{
					foreach (string item in Directory.EnumerateDirectories(text))
					{
						workerThreadState.searchPaths.Enqueue(item);
					}
				}
				catch (Exception exception2)
				{
					workerThreadState.AddException(exception2, "Caught exception finding asset subdirectories in: \"" + text + "\"");
				}
			}
			Interlocked.Exchange(ref workerThreadState.isFinishedSearching, 1);
			Interlocked.Increment(ref this.totalSearchLocationsFinishedSearching);
		}

		// Token: 0x060014B1 RID: 5297 RVA: 0x00050870 File Offset: 0x0004EA70
		private void ReaderThreadMain(object untypedState)
		{
			AssetsWorker.<ReaderThreadMain>d__11 <ReaderThreadMain>d__;
			<ReaderThreadMain>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ReaderThreadMain>d__.<>4__this = this;
			<ReaderThreadMain>d__.untypedState = untypedState;
			<ReaderThreadMain>d__.<>1__state = -1;
			<ReaderThreadMain>d__.<>t__builder.Start<AssetsWorker.<ReaderThreadMain>d__11>(ref <ReaderThreadMain>d__);
		}

		// Token: 0x0400074F RID: 1871
		private int shouldWorkerThreadsContinue;

		// Token: 0x04000750 RID: 1872
		private ConcurrentQueue<AssetsWorker.MasterBundle> foundMasterBundles;

		// Token: 0x04000751 RID: 1873
		private ConcurrentQueue<AssetsWorker.AssetDefinition> foundAssetDefinitions;

		// Token: 0x04000752 RID: 1874
		internal int totalMasterBundlesFound;

		// Token: 0x04000753 RID: 1875
		internal int totalMasterBundlesRead;

		// Token: 0x04000754 RID: 1876
		internal int totalAssetDefinitionsFound;

		// Token: 0x04000755 RID: 1877
		internal int totalAssetDefinitionsRead;

		// Token: 0x04000756 RID: 1878
		internal int totalSearchLocationRequests;

		// Token: 0x04000757 RID: 1879
		internal int totalSearchLocationsFinishedSearching;

		// Token: 0x04000758 RID: 1880
		internal int totalSearchLocationsFinishedReading;

		// Token: 0x04000759 RID: 1881
		private ConcurrentQueue<AssetsWorker.ExceptionDetails> exceptions;

		// Token: 0x0400075A RID: 1882
		private bool isWorking;

		// Token: 0x0400075B RID: 1883
		private string language;

		// Token: 0x0400075C RID: 1884
		private bool languageIsEnglish;

		// Token: 0x020009BB RID: 2491
		public struct MasterBundle
		{
			// Token: 0x040037A7 RID: 14247
			public MasterBundleConfig config;

			// Token: 0x040037A8 RID: 14248
			public byte[] assetBundleData;

			// Token: 0x040037A9 RID: 14249
			public byte[] hash;
		}

		// Token: 0x020009BC RID: 2492
		public struct AssetDefinition
		{
			// Token: 0x040037AA RID: 14250
			public string path;

			// Token: 0x040037AB RID: 14251
			public byte[] hash;

			// Token: 0x040037AC RID: 14252
			public IDatDictionary assetData;

			// Token: 0x040037AD RID: 14253
			public IDatDictionary translationData;

			// Token: 0x040037AE RID: 14254
			public IDatDictionary fallbackTranslationData;

			/// <summary>
			/// Parser error messages, if any.
			/// </summary>
			// Token: 0x040037AF RID: 14255
			public List<string> assetErrors;

			/// <summary>
			/// Warning: on worker thread this only acts as handle. Do not access.
			/// </summary>
			// Token: 0x040037B0 RID: 14256
			public AssetOrigin origin;
		}

		// Token: 0x020009BD RID: 2493
		private class WorkerThreadState
		{
			// Token: 0x06005338 RID: 21304 RVA: 0x001F7358 File Offset: 0x001F5558
			public IDatDictionary ReadFileWithoutHash(string path)
			{
				IDatDictionary result;
				using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (StreamReader streamReader = new StreamReader(fileStream))
					{
						result = this.datParser.Parse(streamReader);
					}
				}
				return result;
			}

			// Token: 0x06005339 RID: 21305 RVA: 0x001F73B8 File Offset: 0x001F55B8
			public void FindAssets(string dirPath, AssetOrigin origin)
			{
				string fileName = Path.GetFileName(dirPath);
				string text = Path.Combine(dirPath, fileName + ".asset");
				try
				{
					if (File.Exists(text))
					{
						Interlocked.Increment(ref this.owner.totalAssetDefinitionsFound);
						this.assetDefinitionFilePaths.Enqueue(new AssetsWorker.WorkerThreadState.AssetDefFilePath
						{
							filePath = text,
							checkForTranslations = true
						});
						return;
					}
				}
				catch (Exception exception)
				{
					this.AddException(exception, "Caught exception checking for assets at: \"" + text + "\"");
					return;
				}
				text = Path.Combine(dirPath, fileName + ".dat");
				try
				{
					if (File.Exists(text))
					{
						Interlocked.Increment(ref this.owner.totalAssetDefinitionsFound);
						this.assetDefinitionFilePaths.Enqueue(new AssetsWorker.WorkerThreadState.AssetDefFilePath
						{
							filePath = text,
							checkForTranslations = true
						});
						return;
					}
				}
				catch (Exception exception2)
				{
					this.AddException(exception2, "Caught exception checking for assets at: \"" + text + "\"");
					return;
				}
				text = Path.Combine(dirPath, "Asset.dat");
				try
				{
					if (File.Exists(text))
					{
						Interlocked.Increment(ref this.owner.totalAssetDefinitionsFound);
						this.assetDefinitionFilePaths.Enqueue(new AssetsWorker.WorkerThreadState.AssetDefFilePath
						{
							filePath = text,
							checkForTranslations = true
						});
						return;
					}
				}
				catch (Exception exception3)
				{
					this.AddException(exception3, "Caught exception checking for assets at: \"" + text + "\"");
					return;
				}
				try
				{
					foreach (string filePath in Directory.EnumerateFiles(dirPath, "*.asset"))
					{
						Interlocked.Increment(ref this.owner.totalAssetDefinitionsFound);
						this.assetDefinitionFilePaths.Enqueue(new AssetsWorker.WorkerThreadState.AssetDefFilePath
						{
							filePath = filePath,
							checkForTranslations = true
						});
					}
				}
				catch (Exception exception4)
				{
					this.AddException(exception4, "Caught exception checking for assets in: \"" + dirPath + "\"");
				}
			}

			// Token: 0x0600533A RID: 21306 RVA: 0x001F75EC File Offset: 0x001F57EC
			public void AddFoundAsset(string filePath, bool checkForTranslations)
			{
				string directoryName = Path.GetDirectoryName(filePath);
				using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (SHA1Stream sha1Stream = new SHA1Stream(fileStream))
					{
						using (StreamReader streamReader = new StreamReader(sha1Stream))
						{
							IDatDictionary assetData = this.datParser.Parse(streamReader);
							List<string> assetErrors = this.datParser.HasError ? new List<string>(this.datParser.ErrorMessages) : null;
							byte[] hash = sha1Stream.Hash;
							IDatDictionary translationData = null;
							IDatDictionary fallbackTranslationData = null;
							if (checkForTranslations)
							{
								string path = Path.Combine(directoryName, this.owner.language + ".dat");
								string path2 = Path.Combine(directoryName, "English.dat");
								if (File.Exists(path))
								{
									translationData = this.ReadFileWithoutHash(path);
									if (!this.owner.languageIsEnglish && File.Exists(path2))
									{
										fallbackTranslationData = this.ReadFileWithoutHash(path2);
									}
								}
								else if (File.Exists(path2))
								{
									translationData = this.ReadFileWithoutHash(path2);
								}
							}
							Interlocked.Increment(ref this.owner.totalAssetDefinitionsRead);
							this.owner.foundAssetDefinitions.Enqueue(new AssetsWorker.AssetDefinition
							{
								path = filePath,
								assetData = assetData,
								assetErrors = assetErrors,
								hash = hash,
								translationData = translationData,
								fallbackTranslationData = fallbackTranslationData,
								origin = this.origin
							});
						}
					}
				}
			}

			// Token: 0x0600533B RID: 21307 RVA: 0x001F77AC File Offset: 0x001F59AC
			public void AddException(Exception exception, string message)
			{
				this.owner.exceptions.Enqueue(new AssetsWorker.ExceptionDetails
				{
					message = message,
					exception = exception
				});
			}

			// Token: 0x040037B1 RID: 14257
			public AssetsWorker owner;

			// Token: 0x040037B2 RID: 14258
			public DatParser datParser;

			// Token: 0x040037B3 RID: 14259
			public string rootPath;

			// Token: 0x040037B4 RID: 14260
			public Queue<string> searchPaths;

			// Token: 0x040037B5 RID: 14261
			public ConcurrentQueue<string> masterBundleFilePaths;

			// Token: 0x040037B6 RID: 14262
			public ConcurrentQueue<AssetsWorker.WorkerThreadState.AssetDefFilePath> assetDefinitionFilePaths;

			// Token: 0x040037B7 RID: 14263
			public int isFinishedSearching;

			/// <summary>
			/// Warning: on worker thread this only acts as handle. Do not access.
			/// </summary>
			// Token: 0x040037B8 RID: 14264
			public AssetOrigin origin;

			// Token: 0x02000AED RID: 2797
			public struct AssetDefFilePath
			{
				// Token: 0x04003B42 RID: 15170
				public string filePath;

				// Token: 0x04003B43 RID: 15171
				public bool checkForTranslations;
			}
		}

		// Token: 0x020009BE RID: 2494
		private struct ExceptionDetails
		{
			// Token: 0x040037B9 RID: 14265
			public string message;

			// Token: 0x040037BA RID: 14266
			public Exception exception;
		}
	}
}
