﻿using System;
using System.Text;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000461 RID: 1121
	public class Block
	{
		// Token: 0x0600233C RID: 9020 RVA: 0x00093190 File Offset: 0x00091390
		private static object[] getObjects(int index)
		{
			object[] array = Block.objects[index];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = null;
			}
			return array;
		}

		// Token: 0x0600233D RID: 9021 RVA: 0x000931B8 File Offset: 0x000913B8
		public string readString()
		{
			if (this.block != null && this.step < this.block.Length)
			{
				byte b = this.block[this.step];
				this.step++;
				string result;
				if (this.step + (int)b <= this.block.Length)
				{
					result = Encoding.UTF8.GetString(this.block, this.step, (int)b);
				}
				else
				{
					result = string.Empty;
				}
				this.step += (int)b;
				return result;
			}
			return string.Empty;
		}

		// Token: 0x0600233E RID: 9022 RVA: 0x00093240 File Offset: 0x00091440
		public string[] readStringArray()
		{
			if (this.block != null && this.step < this.block.Length)
			{
				string[] array = new string[(int)this.readByte()];
				byte b = 0;
				while ((int)b < array.Length)
				{
					array[(int)b] = this.readString();
					b += 1;
				}
				return array;
			}
			return new string[0];
		}

		// Token: 0x0600233F RID: 9023 RVA: 0x00093291 File Offset: 0x00091491
		public bool readBoolean()
		{
			if (this.block != null && this.step <= this.block.Length - 1)
			{
				bool result = BitConverter.ToBoolean(this.block, this.step);
				this.step++;
				return result;
			}
			return false;
		}

		// Token: 0x06002340 RID: 9024 RVA: 0x000932D0 File Offset: 0x000914D0
		public bool[] readBooleanArray()
		{
			if (this.block != null && this.step < this.block.Length)
			{
				bool[] array = new bool[(int)this.readUInt16()];
				ushort num = (ushort)Mathf.CeilToInt((float)array.Length / 8f);
				for (ushort num2 = 0; num2 < num; num2 += 1)
				{
					byte b = 0;
					while (b < 8 && (int)(num2 * 8 + (ushort)b) < array.Length)
					{
						array[(int)(num2 * 8 + (ushort)b)] = ((this.block[this.step + (int)num2] & Types.SHIFTS[(int)b]) == Types.SHIFTS[(int)b]);
						b += 1;
					}
				}
				this.step += (int)num;
				return array;
			}
			return new bool[0];
		}

		// Token: 0x06002341 RID: 9025 RVA: 0x00093376 File Offset: 0x00091576
		public byte readByte()
		{
			if (this.block != null && this.step <= this.block.Length - 1)
			{
				byte result = this.block[this.step];
				this.step++;
				return result;
			}
			return 0;
		}

		// Token: 0x06002342 RID: 9026 RVA: 0x000933B0 File Offset: 0x000915B0
		public byte[] readByteArray()
		{
			if (this.block != null && this.step < this.block.Length)
			{
				byte[] array;
				if (this.longBinaryData)
				{
					int num = this.readInt32();
					if (num >= 30000)
					{
						return new byte[0];
					}
					array = new byte[num];
				}
				else
				{
					array = new byte[(int)this.block[this.step]];
					this.step++;
				}
				if (this.step + array.Length <= this.block.Length)
				{
					try
					{
						Buffer.BlockCopy(this.block, this.step, array, 0, array.Length);
					}
					catch
					{
					}
				}
				this.step += array.Length;
				return array;
			}
			return new byte[0];
		}

		// Token: 0x06002343 RID: 9027 RVA: 0x0009347C File Offset: 0x0009167C
		public short readInt16()
		{
			if (this.block != null && this.step <= this.block.Length - 2)
			{
				this.readBitConverterBytes(2);
				short result = BitConverter.ToInt16(this.block, this.step);
				this.step += 2;
				return result;
			}
			return 0;
		}

		// Token: 0x06002344 RID: 9028 RVA: 0x000934CC File Offset: 0x000916CC
		public ushort readUInt16()
		{
			if (this.block != null && this.step <= this.block.Length - 2)
			{
				this.readBitConverterBytes(2);
				ushort result = BitConverter.ToUInt16(this.block, this.step);
				this.step += 2;
				return result;
			}
			return 0;
		}

		// Token: 0x06002345 RID: 9029 RVA: 0x0009351C File Offset: 0x0009171C
		public int readInt32()
		{
			if (this.block != null && this.step <= this.block.Length - 4)
			{
				this.readBitConverterBytes(4);
				int result = BitConverter.ToInt32(this.block, this.step);
				this.step += 4;
				return result;
			}
			return 0;
		}

		// Token: 0x06002346 RID: 9030 RVA: 0x0009356C File Offset: 0x0009176C
		public int[] readInt32Array()
		{
			ushort num = this.readUInt16();
			int[] array = new int[(int)num];
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				int num3 = this.readInt32();
				array[(int)num2] = num3;
			}
			return array;
		}

		// Token: 0x06002347 RID: 9031 RVA: 0x000935A0 File Offset: 0x000917A0
		public uint readUInt32()
		{
			if (this.block != null && this.step <= this.block.Length - 4)
			{
				this.readBitConverterBytes(4);
				uint result = BitConverter.ToUInt32(this.block, this.step);
				this.step += 4;
				return result;
			}
			return 0U;
		}

		// Token: 0x06002348 RID: 9032 RVA: 0x000935F0 File Offset: 0x000917F0
		public float readSingle()
		{
			if (this.block != null && this.step <= this.block.Length - 4)
			{
				this.readBitConverterBytes(4);
				float result = BitConverter.ToSingle(this.block, this.step);
				this.step += 4;
				return result;
			}
			return 0f;
		}

		// Token: 0x06002349 RID: 9033 RVA: 0x00093644 File Offset: 0x00091844
		public long readInt64()
		{
			if (this.block != null && this.step <= this.block.Length - 8)
			{
				this.readBitConverterBytes(8);
				long result = BitConverter.ToInt64(this.block, this.step);
				this.step += 8;
				return result;
			}
			return 0L;
		}

		// Token: 0x0600234A RID: 9034 RVA: 0x00093694 File Offset: 0x00091894
		public ulong readUInt64()
		{
			if (this.block != null && this.step <= this.block.Length - 8)
			{
				this.readBitConverterBytes(8);
				ulong result = BitConverter.ToUInt64(this.block, this.step);
				this.step += 8;
				return result;
			}
			return 0UL;
		}

		// Token: 0x0600234B RID: 9035 RVA: 0x000936E4 File Offset: 0x000918E4
		public ulong[] readUInt64Array()
		{
			ushort num = this.readUInt16();
			ulong[] array = new ulong[(int)num];
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				ulong num3 = this.readUInt64();
				array[(int)num2] = num3;
			}
			return array;
		}

		// Token: 0x0600234C RID: 9036 RVA: 0x00093718 File Offset: 0x00091918
		public CSteamID readSteamID()
		{
			return new CSteamID(this.readUInt64());
		}

		// Token: 0x0600234D RID: 9037 RVA: 0x00093728 File Offset: 0x00091928
		public Guid readGUID()
		{
			GuidBuffer guidBuffer = default(GuidBuffer);
			guidBuffer.Read(this.readByteArray(), 0);
			return guidBuffer.GUID;
		}

		// Token: 0x0600234E RID: 9038 RVA: 0x00093754 File Offset: 0x00091954
		public Vector3 readUInt16RVector3()
		{
			double num = (double)this.readByte();
			double num2 = (double)this.readUInt16() / 65535.0;
			double num3 = (double)this.readUInt16() / 65535.0;
			byte b = this.readByte();
			double num4 = (double)this.readUInt16() / 65535.0;
			num2 = num * (double)Regions.REGION_SIZE + num2 * (double)Regions.REGION_SIZE - 4096.0;
			num3 = num3 * 2048.0 - 1024.0;
			num4 = (double)(b * Regions.REGION_SIZE) + num4 * (double)Regions.REGION_SIZE - 4096.0;
			return new Vector3((float)num2, (float)num3, (float)num4);
		}

		// Token: 0x0600234F RID: 9039 RVA: 0x000937FC File Offset: 0x000919FC
		public Vector3 readSingleVector3()
		{
			return new Vector3(this.readSingle(), this.readSingle(), this.readSingle());
		}

		// Token: 0x06002350 RID: 9040 RVA: 0x00093815 File Offset: 0x00091A15
		public Quaternion readSingleQuaternion()
		{
			return Quaternion.Euler(this.readSingle(), this.readSingle(), this.readSingle());
		}

		// Token: 0x06002351 RID: 9041 RVA: 0x0009382E File Offset: 0x00091A2E
		public Color readColor()
		{
			return new Color((float)this.readByte() / 255f, (float)this.readByte() / 255f, (float)this.readByte() / 255f);
		}

		// Token: 0x06002352 RID: 9042 RVA: 0x0009385C File Offset: 0x00091A5C
		public object read(Type type)
		{
			if (type == Types.STRING_TYPE)
			{
				return this.readString();
			}
			if (type == Types.STRING_ARRAY_TYPE)
			{
				return this.readStringArray();
			}
			if (type == Types.BOOLEAN_TYPE)
			{
				return this.readBoolean();
			}
			if (type == Types.BOOLEAN_ARRAY_TYPE)
			{
				return this.readBooleanArray();
			}
			if (type == Types.BYTE_TYPE)
			{
				return this.readByte();
			}
			if (type == Types.BYTE_ARRAY_TYPE)
			{
				return this.readByteArray();
			}
			if (type == Types.INT16_TYPE)
			{
				return this.readInt16();
			}
			if (type == Types.UINT16_TYPE)
			{
				return this.readUInt16();
			}
			if (type == Types.INT32_TYPE)
			{
				return this.readInt32();
			}
			if (type == Types.INT32_ARRAY_TYPE)
			{
				return this.readInt32Array();
			}
			if (type == Types.UINT32_TYPE)
			{
				return this.readUInt32();
			}
			if (type == Types.SINGLE_TYPE)
			{
				return this.readSingle();
			}
			if (type == Types.INT64_TYPE)
			{
				return this.readInt64();
			}
			if (type == Types.UINT64_TYPE)
			{
				return this.readUInt64();
			}
			if (type == Types.UINT64_ARRAY_TYPE)
			{
				return this.readUInt64Array();
			}
			if (type == Types.STEAM_ID_TYPE)
			{
				return this.readSteamID();
			}
			if (type == Types.GUID_TYPE)
			{
				return this.readGUID();
			}
			if (type == Types.VECTOR3_TYPE)
			{
				return this.readSingleVector3();
			}
			if (type == Types.COLOR_TYPE)
			{
				return this.readColor();
			}
			throw new NotSupportedException(string.Format("Cannot read type {0}", type));
		}

		// Token: 0x06002353 RID: 9043 RVA: 0x00093A38 File Offset: 0x00091C38
		public object[] read(int offset, Type type_0)
		{
			object[] array = Block.getObjects(0);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			return array;
		}

		// Token: 0x06002354 RID: 9044 RVA: 0x00093A5C File Offset: 0x00091C5C
		public object[] read(int offset, Type type_0, Type type_1)
		{
			object[] array = Block.getObjects(1);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			return array;
		}

		// Token: 0x06002355 RID: 9045 RVA: 0x00093A8D File Offset: 0x00091C8D
		public object[] read(Type type_0, Type type_1)
		{
			return this.read(0, type_0, type_1);
		}

		// Token: 0x06002356 RID: 9046 RVA: 0x00093A98 File Offset: 0x00091C98
		public object[] read(int offset, Type type_0, Type type_1, Type type_2)
		{
			object[] array = Block.getObjects(2);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			if (offset < 3)
			{
				array[2] = this.read(type_2);
			}
			return array;
		}

		// Token: 0x06002357 RID: 9047 RVA: 0x00093AD8 File Offset: 0x00091CD8
		public object[] read(Type type_0, Type type_1, Type type_2)
		{
			return this.read(0, type_0, type_1, type_2);
		}

		// Token: 0x06002358 RID: 9048 RVA: 0x00093AE4 File Offset: 0x00091CE4
		public object[] read(int offset, Type type_0, Type type_1, Type type_2, Type type_3)
		{
			object[] array = Block.getObjects(3);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			if (offset < 3)
			{
				array[2] = this.read(type_2);
			}
			if (offset < 4)
			{
				array[3] = this.read(type_3);
			}
			return array;
		}

		// Token: 0x06002359 RID: 9049 RVA: 0x00093B33 File Offset: 0x00091D33
		public object[] read(Type type_0, Type type_1, Type type_2, Type type_3)
		{
			return this.read(0, type_0, type_1, type_2, type_3);
		}

		// Token: 0x0600235A RID: 9050 RVA: 0x00093B44 File Offset: 0x00091D44
		public object[] read(int offset, Type type_0, Type type_1, Type type_2, Type type_3, Type type_4)
		{
			object[] array = Block.getObjects(4);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			if (offset < 3)
			{
				array[2] = this.read(type_2);
			}
			if (offset < 4)
			{
				array[3] = this.read(type_3);
			}
			if (offset < 5)
			{
				array[4] = this.read(type_4);
			}
			return array;
		}

		// Token: 0x0600235B RID: 9051 RVA: 0x00093BA2 File Offset: 0x00091DA2
		public object[] read(Type type_0, Type type_1, Type type_2, Type type_3, Type type_4)
		{
			return this.read(0, type_0, type_1, type_2, type_3, type_4);
		}

		// Token: 0x0600235C RID: 9052 RVA: 0x00093BB4 File Offset: 0x00091DB4
		public object[] read(int offset, Type type_0, Type type_1, Type type_2, Type type_3, Type type_4, Type type_5)
		{
			object[] array = Block.getObjects(5);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			if (offset < 3)
			{
				array[2] = this.read(type_2);
			}
			if (offset < 4)
			{
				array[3] = this.read(type_3);
			}
			if (offset < 5)
			{
				array[4] = this.read(type_4);
			}
			if (offset < 6)
			{
				array[5] = this.read(type_5);
			}
			return array;
		}

		// Token: 0x0600235D RID: 9053 RVA: 0x00093C21 File Offset: 0x00091E21
		public object[] read(Type type_0, Type type_1, Type type_2, Type type_3, Type type_4, Type type_5)
		{
			return this.read(0, type_0, type_1, type_2, type_3, type_4, type_5);
		}

		// Token: 0x0600235E RID: 9054 RVA: 0x00093C34 File Offset: 0x00091E34
		public object[] read(int offset, Type type_0, Type type_1, Type type_2, Type type_3, Type type_4, Type type_5, Type type_6)
		{
			object[] array = Block.getObjects(6);
			if (offset < 1)
			{
				array[0] = this.read(type_0);
			}
			if (offset < 2)
			{
				array[1] = this.read(type_1);
			}
			if (offset < 3)
			{
				array[2] = this.read(type_2);
			}
			if (offset < 4)
			{
				array[3] = this.read(type_3);
			}
			if (offset < 5)
			{
				array[4] = this.read(type_4);
			}
			if (offset < 6)
			{
				array[5] = this.read(type_5);
			}
			if (offset < 7)
			{
				array[6] = this.read(type_6);
			}
			return array;
		}

		// Token: 0x0600235F RID: 9055 RVA: 0x00093CB0 File Offset: 0x00091EB0
		public object[] read(Type type_0, Type type_1, Type type_2, Type type_3, Type type_4, Type type_5, Type type_6)
		{
			return this.read(0, type_0, type_1, type_2, type_3, type_4, type_5, type_6);
		}

		// Token: 0x06002360 RID: 9056 RVA: 0x00093CD0 File Offset: 0x00091ED0
		public object[] read(int offset, params Type[] types)
		{
			object[] array = new object[types.Length];
			for (int i = offset; i < types.Length; i++)
			{
				array[i] = this.read(types[i]);
			}
			return array;
		}

		// Token: 0x06002361 RID: 9057 RVA: 0x00093D01 File Offset: 0x00091F01
		public object[] read(params Type[] types)
		{
			return this.read(0, types);
		}

		// Token: 0x06002362 RID: 9058 RVA: 0x00093D0B File Offset: 0x00091F0B
		protected void readBitConverterBytes(int length)
		{
		}

		// Token: 0x06002363 RID: 9059 RVA: 0x00093D10 File Offset: 0x00091F10
		protected void writeBitConverterBytes(byte[] bytes)
		{
			int dstOffset = this.step;
			int count = bytes.Length;
			Buffer.BlockCopy(bytes, 0, Block.buffer, dstOffset, count);
		}

		// Token: 0x06002364 RID: 9060 RVA: 0x00093D38 File Offset: 0x00091F38
		public void writeString(string value)
		{
			if (value == null)
			{
				value = string.Empty;
			}
			byte[] bytes = Encoding.UTF8.GetBytes(value);
			byte b = (byte)bytes.Length;
			Block.buffer[this.step] = b;
			this.step++;
			Buffer.BlockCopy(bytes, 0, Block.buffer, this.step, (int)b);
			this.step += (int)b;
		}

		// Token: 0x06002365 RID: 9061 RVA: 0x00093D9C File Offset: 0x00091F9C
		public void writeStringArray(string[] values)
		{
			byte b = (byte)values.Length;
			this.writeByte(b);
			for (byte b2 = 0; b2 < b; b2 += 1)
			{
				this.writeString(values[(int)b2]);
			}
		}

		// Token: 0x06002366 RID: 9062 RVA: 0x00093DCC File Offset: 0x00091FCC
		public void writeBoolean(bool value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			Block.buffer[this.step] = bytes[0];
			this.step++;
		}

		// Token: 0x06002367 RID: 9063 RVA: 0x00093E00 File Offset: 0x00092000
		public void writeBooleanArray(bool[] values)
		{
			this.writeUInt16((ushort)values.Length);
			ushort num = (ushort)Mathf.CeilToInt((float)values.Length / 8f);
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				Block.buffer[this.step + (int)num2] = 0;
				byte b = 0;
				while (b < 8 && (int)(num2 * 8 + (ushort)b) < values.Length)
				{
					if (values[(int)(num2 * 8 + (ushort)b)])
					{
						byte[] array = Block.buffer;
						int num3 = this.step + (int)num2;
						array[num3] |= Types.SHIFTS[(int)b];
					}
					b += 1;
				}
			}
			this.step += (int)num;
		}

		// Token: 0x06002368 RID: 9064 RVA: 0x00093E90 File Offset: 0x00092090
		public void writeByte(byte value)
		{
			Block.buffer[this.step] = value;
			this.step++;
		}

		// Token: 0x06002369 RID: 9065 RVA: 0x00093EB0 File Offset: 0x000920B0
		public void writeByteArray(byte[] values)
		{
			if (values.Length >= 30000)
			{
				return;
			}
			if (this.longBinaryData)
			{
				this.writeInt32(values.Length);
				Buffer.BlockCopy(values, 0, Block.buffer, this.step, values.Length);
				this.step += values.Length;
				return;
			}
			byte b = (byte)values.Length;
			Block.buffer[this.step] = b;
			this.step++;
			Buffer.BlockCopy(values, 0, Block.buffer, this.step, (int)b);
			this.step += (int)b;
		}

		// Token: 0x0600236A RID: 9066 RVA: 0x00093F40 File Offset: 0x00092140
		public void writeInt16(short value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 2;
		}

		// Token: 0x0600236B RID: 9067 RVA: 0x00093F6C File Offset: 0x0009216C
		public void writeUInt16(ushort value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 2;
		}

		// Token: 0x0600236C RID: 9068 RVA: 0x00093F98 File Offset: 0x00092198
		public void writeInt32(int value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 4;
		}

		// Token: 0x0600236D RID: 9069 RVA: 0x00093FC4 File Offset: 0x000921C4
		public void writeInt32Array(int[] values)
		{
			this.writeUInt16((ushort)values.Length);
			ushort num = 0;
			while ((int)num < values.Length)
			{
				this.writeInt32(values[(int)num]);
				num += 1;
			}
		}

		// Token: 0x0600236E RID: 9070 RVA: 0x00093FF4 File Offset: 0x000921F4
		public void writeUInt32(uint value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 4;
		}

		// Token: 0x0600236F RID: 9071 RVA: 0x00094020 File Offset: 0x00092220
		public void writeSingle(float value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 4;
		}

		// Token: 0x06002370 RID: 9072 RVA: 0x0009404C File Offset: 0x0009224C
		public void writeInt64(long value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 8;
		}

		// Token: 0x06002371 RID: 9073 RVA: 0x00094078 File Offset: 0x00092278
		public void writeUInt64(ulong value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.writeBitConverterBytes(bytes);
			this.step += 8;
		}

		// Token: 0x06002372 RID: 9074 RVA: 0x000940A4 File Offset: 0x000922A4
		public void writeUInt64Array(ulong[] values)
		{
			this.writeUInt16((ushort)values.Length);
			ushort num = 0;
			while ((int)num < values.Length)
			{
				this.writeUInt64(values[(int)num]);
				num += 1;
			}
		}

		// Token: 0x06002373 RID: 9075 RVA: 0x000940D3 File Offset: 0x000922D3
		public void writeSteamID(CSteamID steamID)
		{
			this.writeUInt64(steamID.m_SteamID);
		}

		// Token: 0x06002374 RID: 9076 RVA: 0x000940E4 File Offset: 0x000922E4
		public void writeGUID(Guid GUID)
		{
			GuidBuffer guidBuffer = new GuidBuffer(GUID);
			guidBuffer.Write(GuidBuffer.GUID_BUFFER, 0);
			this.writeByteArray(GuidBuffer.GUID_BUFFER);
		}

		// Token: 0x06002375 RID: 9077 RVA: 0x00094114 File Offset: 0x00092314
		public void writeUInt16RVector3(Vector3 value)
		{
			double num = (double)value.x + 4096.0;
			double num2 = (double)value.y + 1024.0;
			double num3 = (double)value.z + 4096.0;
			byte value2 = (byte)(num / (double)Regions.REGION_SIZE);
			byte value3 = (byte)(num3 / (double)Regions.REGION_SIZE);
			num %= (double)Regions.REGION_SIZE;
			num2 %= 2048.0;
			num3 %= (double)Regions.REGION_SIZE;
			num /= (double)Regions.REGION_SIZE;
			num2 /= 2048.0;
			num3 /= (double)Regions.REGION_SIZE;
			this.writeByte(value2);
			this.writeUInt16((ushort)(num * 65535.0));
			this.writeUInt16((ushort)(num2 * 65535.0));
			this.writeByte(value3);
			this.writeUInt16((ushort)(num3 * 65535.0));
		}

		// Token: 0x06002376 RID: 9078 RVA: 0x000941ED File Offset: 0x000923ED
		public void writeSingleVector3(Vector3 value)
		{
			this.writeSingle(value.x);
			this.writeSingle(value.y);
			this.writeSingle(value.z);
		}

		// Token: 0x06002377 RID: 9079 RVA: 0x00094214 File Offset: 0x00092414
		public void writeSingleQuaternion(Quaternion value)
		{
			Vector3 eulerAngles = value.eulerAngles;
			this.writeSingle(eulerAngles.x);
			this.writeSingle(eulerAngles.y);
			this.writeSingle(eulerAngles.z);
		}

		// Token: 0x06002378 RID: 9080 RVA: 0x0009424D File Offset: 0x0009244D
		public void writeColor(Color value)
		{
			this.writeByte((byte)(value.r * 255f));
			this.writeByte((byte)(value.g * 255f));
			this.writeByte((byte)(value.b * 255f));
		}

		// Token: 0x06002379 RID: 9081 RVA: 0x00094288 File Offset: 0x00092488
		public void write(object objects)
		{
			Type type = objects.GetType();
			if (type == Types.STRING_TYPE)
			{
				this.writeString((string)objects);
				return;
			}
			if (type == Types.STRING_ARRAY_TYPE)
			{
				this.writeStringArray((string[])objects);
				return;
			}
			if (type == Types.BOOLEAN_TYPE)
			{
				this.writeBoolean((bool)objects);
				return;
			}
			if (type == Types.BOOLEAN_ARRAY_TYPE)
			{
				this.writeBooleanArray((bool[])objects);
				return;
			}
			if (type == Types.BYTE_TYPE)
			{
				this.writeByte((byte)objects);
				return;
			}
			if (type == Types.BYTE_ARRAY_TYPE)
			{
				this.writeByteArray((byte[])objects);
				return;
			}
			if (type == Types.INT16_TYPE)
			{
				this.writeInt16((short)objects);
				return;
			}
			if (type == Types.UINT16_TYPE)
			{
				this.writeUInt16((ushort)objects);
				return;
			}
			if (type == Types.INT32_TYPE)
			{
				this.writeInt32((int)objects);
				return;
			}
			if (type == Types.INT32_ARRAY_TYPE)
			{
				this.writeInt32Array((int[])objects);
				return;
			}
			if (type == Types.UINT32_TYPE)
			{
				this.writeUInt32((uint)objects);
				return;
			}
			if (type == Types.SINGLE_TYPE)
			{
				this.writeSingle((float)objects);
				return;
			}
			if (type == Types.INT64_TYPE)
			{
				this.writeInt64((long)objects);
				return;
			}
			if (type == Types.UINT64_TYPE)
			{
				this.writeUInt64((ulong)objects);
				return;
			}
			if (type == Types.UINT64_ARRAY_TYPE)
			{
				this.writeUInt64Array((ulong[])objects);
				return;
			}
			if (type == Types.STEAM_ID_TYPE)
			{
				this.writeSteamID((CSteamID)objects);
				return;
			}
			if (type == Types.GUID_TYPE)
			{
				this.writeGUID((Guid)objects);
				return;
			}
			if (type == Types.VECTOR3_TYPE)
			{
				this.writeSingleVector3((Vector3)objects);
				return;
			}
			if (type == Types.COLOR_TYPE)
			{
				this.writeColor((Color)objects);
				return;
			}
			throw new NotSupportedException(string.Format("Cannot write {0} of type {1}", objects, type));
		}

		// Token: 0x0600237A RID: 9082 RVA: 0x0009449B File Offset: 0x0009269B
		public void write(object object_0, object object_1)
		{
			this.write(object_0);
			this.write(object_1);
		}

		// Token: 0x0600237B RID: 9083 RVA: 0x000944AB File Offset: 0x000926AB
		public void write(object object_0, object object_1, object object_2)
		{
			this.write(object_0, object_1);
			this.write(object_2);
		}

		// Token: 0x0600237C RID: 9084 RVA: 0x000944BC File Offset: 0x000926BC
		public void write(object object_0, object object_1, object object_2, object object_3)
		{
			this.write(object_0, object_1, object_2);
			this.write(object_3);
		}

		// Token: 0x0600237D RID: 9085 RVA: 0x000944CF File Offset: 0x000926CF
		public void write(object object_0, object object_1, object object_2, object object_3, object object_4)
		{
			this.write(object_0, object_1, object_2, object_3);
			this.write(object_4);
		}

		// Token: 0x0600237E RID: 9086 RVA: 0x000944E4 File Offset: 0x000926E4
		public void write(object object_0, object object_1, object object_2, object object_3, object object_4, object object_5)
		{
			this.write(object_0, object_1, object_2, object_3, object_4);
			this.write(object_5);
		}

		// Token: 0x0600237F RID: 9087 RVA: 0x000944FB File Offset: 0x000926FB
		public void write(object object_0, object object_1, object object_2, object object_3, object object_4, object object_5, object object_6)
		{
			this.write(object_0, object_1, object_2, object_3, object_4, object_5);
			this.write(object_6);
		}

		// Token: 0x06002380 RID: 9088 RVA: 0x00094514 File Offset: 0x00092714
		public void write(params object[] objects)
		{
			for (int i = 0; i < objects.Length; i++)
			{
				this.write(objects[i]);
			}
		}

		// Token: 0x06002381 RID: 9089 RVA: 0x00094538 File Offset: 0x00092738
		public byte[] getBytes(out int size)
		{
			if (this.block == null)
			{
				size = this.step;
				return Block.buffer;
			}
			size = this.block.Length;
			return this.block;
		}

		// Token: 0x06002382 RID: 9090 RVA: 0x00094560 File Offset: 0x00092760
		public byte[] getHash()
		{
			if (this.block == null)
			{
				return Hash.SHA1(Block.buffer);
			}
			return Hash.SHA1(this.block);
		}

		// Token: 0x06002383 RID: 9091 RVA: 0x00094580 File Offset: 0x00092780
		public void reset(int prefix, byte[] contents)
		{
			this.step = prefix;
			this.block = contents;
		}

		// Token: 0x06002384 RID: 9092 RVA: 0x00094590 File Offset: 0x00092790
		public void reset(byte[] contents)
		{
			this.step = 0;
			this.block = contents;
		}

		// Token: 0x06002385 RID: 9093 RVA: 0x000945A0 File Offset: 0x000927A0
		public void reset(int prefix)
		{
			this.step = prefix;
			this.block = null;
		}

		// Token: 0x06002386 RID: 9094 RVA: 0x000945B0 File Offset: 0x000927B0
		public void reset()
		{
			this.step = 0;
			this.block = null;
		}

		// Token: 0x06002387 RID: 9095 RVA: 0x000945C0 File Offset: 0x000927C0
		public Block(int prefix, byte[] contents)
		{
			this.reset(prefix, contents);
		}

		// Token: 0x06002388 RID: 9096 RVA: 0x000945D0 File Offset: 0x000927D0
		public Block(byte[] contents)
		{
			this.reset(contents);
		}

		// Token: 0x06002389 RID: 9097 RVA: 0x000945DF File Offset: 0x000927DF
		public Block(int prefix)
		{
			this.reset(prefix);
		}

		// Token: 0x0600238A RID: 9098 RVA: 0x000945EE File Offset: 0x000927EE
		public Block()
		{
			this.reset();
		}

		// Token: 0x0400119C RID: 4508
		public static readonly int BUFFER_SIZE = 65535;

		// Token: 0x0400119D RID: 4509
		public static byte[] buffer = new byte[Block.BUFFER_SIZE];

		// Token: 0x0400119E RID: 4510
		private static object[][] objects = new object[][]
		{
			new object[1],
			new object[2],
			new object[3],
			new object[4],
			new object[5],
			new object[6],
			new object[7]
		};

		// Token: 0x0400119F RID: 4511
		public bool longBinaryData;

		// Token: 0x040011A0 RID: 4512
		public int step;

		// Token: 0x040011A1 RID: 4513
		public byte[] block;
	}
}
