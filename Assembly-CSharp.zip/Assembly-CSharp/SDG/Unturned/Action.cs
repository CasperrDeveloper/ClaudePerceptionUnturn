﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004D2 RID: 1234
	public class Action
	{
		// Token: 0x17000826 RID: 2086
		// (get) Token: 0x060028C5 RID: 10437 RVA: 0x000B1B84 File Offset: 0x000AFD84
		public EActionType type
		{
			get
			{
				return this._type;
			}
		}

		// Token: 0x17000827 RID: 2087
		// (get) Token: 0x060028C6 RID: 10438 RVA: 0x000B1B8C File Offset: 0x000AFD8C
		public ActionBlueprint[] blueprints
		{
			get
			{
				return this._blueprints;
			}
		}

		// Token: 0x17000828 RID: 2088
		// (get) Token: 0x060028C7 RID: 10439 RVA: 0x000B1B94 File Offset: 0x000AFD94
		public string text
		{
			get
			{
				return this._text;
			}
		}

		// Token: 0x17000829 RID: 2089
		// (get) Token: 0x060028C8 RID: 10440 RVA: 0x000B1B9C File Offset: 0x000AFD9C
		public string tooltip
		{
			get
			{
				return this._tooltip;
			}
		}

		// Token: 0x1700082A RID: 2090
		// (get) Token: 0x060028C9 RID: 10441 RVA: 0x000B1BA4 File Offset: 0x000AFDA4
		public string key
		{
			get
			{
				return this._key;
			}
		}

		// Token: 0x060028CA RID: 10442 RVA: 0x000B1BAC File Offset: 0x000AFDAC
		public Asset FindBlueprintOwnerAsset()
		{
			return this.blueprintOwnerRef.Get();
		}

		// Token: 0x1700082B RID: 2091
		// (get) Token: 0x060028CB RID: 10443 RVA: 0x000B1BBC File Offset: 0x000AFDBC
		public bool IsAnyBlueprintLink
		{
			get
			{
				if (this._blueprints == null)
				{
					return false;
				}
				ActionBlueprint[] blueprints = this._blueprints;
				for (int i = 0; i < blueprints.Length; i++)
				{
					if (blueprints[i].isLink)
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x060028CC RID: 10444 RVA: 0x000B1BF5 File Offset: 0x000AFDF5
		public Action(ushort newSource, EActionType newType, ActionBlueprint[] newBlueprints, string newText, string newTooltip, string newKey)
		{
			this._type = newType;
			this._blueprints = newBlueprints;
			this._text = newText;
			this._tooltip = newTooltip;
			this._key = newKey;
		}

		// Token: 0x060028CD RID: 10445 RVA: 0x000B1C24 File Offset: 0x000AFE24
		public override string ToString()
		{
			string format = "(Type: {0} Blueprints: {1} Text: {2} Tooltip: {3} Key: {4})";
			object[] array = new object[5];
			array[0] = this._type;
			int num = 1;
			ActionBlueprint[] blueprints = this._blueprints;
			array[num] = ((blueprints != null) ? new int?(blueprints.Length) : null);
			array[2] = this._text;
			array[3] = this._tooltip;
			array[4] = this._key;
			return string.Format(format, array);
		}

		// Token: 0x1700082C RID: 2092
		// (get) Token: 0x060028CE RID: 10446 RVA: 0x000B1C8E File Offset: 0x000AFE8E
		[Obsolete("Please use FindBlueprintOwnerAsset for GUID support")]
		public ushort source
		{
			get
			{
				return this.blueprintOwnerRef.LegacyId;
			}
		}

		// Token: 0x0400146F RID: 5231
		internal CachingBcAssetRef blueprintOwnerRef;

		// Token: 0x04001470 RID: 5232
		private EActionType _type;

		// Token: 0x04001471 RID: 5233
		private ActionBlueprint[] _blueprints;

		// Token: 0x04001472 RID: 5234
		private string _text;

		// Token: 0x04001473 RID: 5235
		private string _tooltip;

		// Token: 0x04001474 RID: 5236
		private string _key;
	}
}
