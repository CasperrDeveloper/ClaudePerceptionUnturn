﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004F6 RID: 1270
	public class Achievement : MonoBehaviour
	{
		// Token: 0x060029B5 RID: 10677 RVA: 0x000B483C File Offset: 0x000B2A3C
		private void OnTriggerEnter(Collider other)
		{
			if (Dedicator.IsDedicatedServer || !other.transform.CompareTag("Player") || other.transform != Player.LocalPlayer.transform)
			{
				return;
			}
			bool flag;
			if (Provider.provider.achievementsService.getAchievement(base.transform.name, out flag) && !flag)
			{
				Provider.provider.achievementsService.setAchievement(base.transform.name);
			}
		}
	}
}
