﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using Steamworks;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200027D RID: 637
	internal static class ClientMessageHandler_PlayerConnected
	{
		// Token: 0x06001302 RID: 4866 RVA: 0x00045224 File Offset: 0x00043424
		internal static void ReadMessage(NetPakReader reader)
		{
			NetId netId;
			reader.ReadNetId(out netId);
			CSteamID newSteamID;
			reader.ReadSteamID(out newSteamID);
			byte newCharacterID;
			reader.ReadUInt8(out newCharacterID);
			string newPlayerName;
			reader.ReadString(out newPlayerName, 11);
			string newCharacterName;
			reader.ReadString(out newCharacterName, 11);
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 7);
			byte angle;
			reader.ReadUInt8(out angle);
			bool isPro;
			reader.ReadBit(out isPro);
			bool isAdmin;
			reader.ReadBit(out isAdmin);
			byte channel;
			reader.ReadUInt8(out channel);
			CSteamID newGroup;
			reader.ReadSteamID(out newGroup);
			string newNickName;
			reader.ReadString(out newNickName, 11);
			byte face;
			reader.ReadUInt8(out face);
			byte hair;
			reader.ReadUInt8(out hair);
			byte beard;
			reader.ReadUInt8(out beard);
			Color32 c;
			reader.ReadColor32RGB(out c);
			Color32 c2;
			reader.ReadColor32RGB(out c2);
			Color32 c3;
			reader.ReadColor32RGB(out c3);
			Color32 c4;
			reader.ReadColor32RGB(out c4);
			bool hand;
			reader.ReadBit(out hand);
			int shirtItem;
			reader.ReadInt32(out shirtItem);
			int pantsItem;
			reader.ReadInt32(out pantsItem);
			int hatItem;
			reader.ReadInt32(out hatItem);
			int backpackItem;
			reader.ReadInt32(out backpackItem);
			int vestItem;
			reader.ReadInt32(out vestItem);
			int maskItem;
			reader.ReadInt32(out maskItem);
			int glassesItem;
			reader.ReadInt32(out glassesItem);
			ClientMessageHandler_PlayerConnected.skinItems.Clear();
			reader.ReadList(ClientMessageHandler_PlayerConnected.skinItems, delegate(out int item)
			{
				return reader.ReadInt32(out item);
			}, ClientMessageHandler_PlayerConnected.MAX_LENGTH);
			ClientMessageHandler_PlayerConnected.skinTags.Clear();
			reader.ReadList(ClientMessageHandler_PlayerConnected.skinTags, delegate(out string tag)
			{
				return reader.ReadString(out tag, 11);
			}, ClientMessageHandler_PlayerConnected.MAX_LENGTH);
			ClientMessageHandler_PlayerConnected.skinDynamicProps.Clear();
			reader.ReadList(ClientMessageHandler_PlayerConnected.skinDynamicProps, delegate(out string dynProp)
			{
				return reader.ReadString(out dynProp, 11);
			}, ClientMessageHandler_PlayerConnected.MAX_LENGTH);
			EPlayerSkillset skillset;
			reader.ReadEnum(out skillset);
			string language;
			reader.ReadString(out language, 11);
			Provider.addPlayer(null, netId, new SteamPlayerID(newSteamID, newCharacterID, newPlayerName, newCharacterName, newNickName, newGroup), point, angle, isPro, isAdmin, (int)channel, face, hair, beard, c, c2, c3, c4, hand, shirtItem, pantsItem, hatItem, backpackItem, vestItem, maskItem, glassesItem, ClientMessageHandler_PlayerConnected.skinItems.ToArray(), ClientMessageHandler_PlayerConnected.skinTags.ToArray(), ClientMessageHandler_PlayerConnected.skinDynamicProps.ToArray(), skillset, language, CSteamID.Nil, EClientPlatform.Windows).player.InitializePlayer();
		}

		// Token: 0x04000646 RID: 1606
		private static List<int> skinItems = new List<int>();

		// Token: 0x04000647 RID: 1607
		private static List<string> skinTags = new List<string>();

		// Token: 0x04000648 RID: 1608
		private static List<string> skinDynamicProps = new List<string>();

		// Token: 0x04000649 RID: 1609
		private static readonly NetLength MAX_LENGTH = new NetLength(255U);
	}
}
