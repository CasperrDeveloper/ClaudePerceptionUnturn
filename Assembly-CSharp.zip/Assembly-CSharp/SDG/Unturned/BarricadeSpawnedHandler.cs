﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000597 RID: 1431
	// (Invoke) Token: 0x06002F67 RID: 12135
	public delegate void BarricadeSpawnedHandler(BarricadeRegion region, BarricadeDrop drop);
}
