﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x02000278 RID: 632
	internal static class ClientMessageHandler_DownloadWorkshopFiles
	{
		// Token: 0x060012FB RID: 4859 RVA: 0x00044D64 File Offset: 0x00042F64
		internal static void ReadMessage(NetPakReader reader)
		{
			Provider.isWaitingForWorkshopResponse = false;
			ENPCHoliday enpcholiday;
			reader.ReadEnum(out enpcholiday);
			UnturnedLog.info(string.Format("Server holiday: {0}", enpcholiday));
			ClientMessageHandler_DownloadWorkshopFiles.requiredFiles.Clear();
			reader.ReadList(ClientMessageHandler_DownloadWorkshopFiles.requiredFiles, new SystemNetPakReaderEx.ReadListItemWithReader<Provider.ServerRequiredWorkshopFile>(ClientMessageHandler_DownloadWorkshopFiles.ReadRequiredWorkshopFile), ClientMessageHandler_DownloadWorkshopFiles.MAX_FILES);
			string text;
			reader.ReadString(out text, 11);
			UnturnedLog.info("Server name: \"" + text + "\"");
			string text2;
			reader.ReadString(out text2, 11);
			UnturnedLog.info("Server level name: \"" + text2 + "\"");
			bool flag;
			reader.ReadBit(out flag);
			UnturnedLog.info(string.Format("Server is PvP: {0}", flag));
			bool flag2;
			reader.ReadBit(out flag2);
			UnturnedLog.info(string.Format("Server allows admin cheat codes: {0}", flag2));
			bool flag3;
			reader.ReadBit(out flag3);
			UnturnedLog.info(string.Format("Server is VAC secure: {0}", flag3));
			bool flag4;
			reader.ReadBit(out flag4);
			UnturnedLog.info(string.Format("Server is BattlEye secure: {0}", flag4));
			bool flag5;
			reader.ReadBit(out flag5);
			UnturnedLog.info(string.Format("Server requires gold: {0}", flag5));
			EGameMode egameMode;
			reader.ReadEnum(out egameMode);
			UnturnedLog.info(string.Format("Server difficulty: {0}", egameMode));
			ECameraMode ecameraMode;
			reader.ReadEnum(out ecameraMode);
			UnturnedLog.info(string.Format("Server camera mode: {0}", ecameraMode));
			byte b;
			reader.ReadUInt8(out b);
			UnturnedLog.info(string.Format("Server max players: {0}", b));
			string text3;
			reader.ReadString(out text3, 11);
			UnturnedLog.info("Server bookmark host: \"" + text3 + "\"");
			string text4;
			reader.ReadString(out text4, 11);
			UnturnedLog.info("Server thumbnail URL: \"" + text4 + "\"");
			string text5;
			reader.ReadString(out text5, 11);
			UnturnedLog.info("Server description: \"" + text5 + "\"");
			IPv4Address pv4Address;
			uint num = Provider.clientTransport.TryGetIPv4Address(out pv4Address) ? pv4Address.value : 0U;
			if (num == 0U)
			{
				UnturnedLog.warn("Unable to determine server IP for download restrictions");
			}
			Provider.CachedWorkshopResponse cachedWorkshopResponse = null;
			foreach (Provider.CachedWorkshopResponse cachedWorkshopResponse2 in Provider.cachedWorkshopResponses)
			{
				if (cachedWorkshopResponse2.server == Provider.server)
				{
					cachedWorkshopResponse = cachedWorkshopResponse2;
					break;
				}
			}
			if (cachedWorkshopResponse == null)
			{
				cachedWorkshopResponse = new Provider.CachedWorkshopResponse();
				cachedWorkshopResponse.server = Provider.server;
				Provider.cachedWorkshopResponses.Add(cachedWorkshopResponse);
			}
			cachedWorkshopResponse.holiday = enpcholiday;
			cachedWorkshopResponse.serverName = text;
			cachedWorkshopResponse.levelName = text2;
			cachedWorkshopResponse.isPvP = flag;
			cachedWorkshopResponse.allowAdminCheatCodes = flag2;
			cachedWorkshopResponse.isVACSecure = flag3;
			cachedWorkshopResponse.isBattlEyeSecure = flag4;
			cachedWorkshopResponse.isGold = flag5;
			cachedWorkshopResponse.gameMode = egameMode;
			cachedWorkshopResponse.cameraMode = ecameraMode;
			cachedWorkshopResponse.maxPlayers = b;
			cachedWorkshopResponse.bookmarkHost = text3;
			cachedWorkshopResponse.thumbnailUrl = text4;
			cachedWorkshopResponse.serverDescription = text5;
			cachedWorkshopResponse.ip = num;
			cachedWorkshopResponse.requiredFiles = ClientMessageHandler_DownloadWorkshopFiles.requiredFiles;
			cachedWorkshopResponse.realTime = Time.realtimeSinceStartup;
			Provider.receiveWorkshopResponse(cachedWorkshopResponse);
		}

		// Token: 0x060012FC RID: 4860 RVA: 0x000450A0 File Offset: 0x000432A0
		private static bool ReadRequiredWorkshopFile(NetPakReader reader, out Provider.ServerRequiredWorkshopFile requiredFile)
		{
			requiredFile = default(Provider.ServerRequiredWorkshopFile);
			return reader.ReadUInt64(out requiredFile.fileId) && reader.ReadDateTime(out requiredFile.timestamp);
		}

		// Token: 0x04000644 RID: 1604
		private static List<Provider.ServerRequiredWorkshopFile> requiredFiles = new List<Provider.ServerRequiredWorkshopFile>();

		// Token: 0x04000645 RID: 1605
		private static readonly NetLength MAX_FILES = new NetLength(255U);
	}
}
