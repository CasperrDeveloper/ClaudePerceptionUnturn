﻿using System;
using SDG.Framework.IO.FormattedFiles;

namespace SDG.Unturned
{
	/// <summary>
	/// Nelson 2025-04-08: newer code should probably use CachingAssetRef instead. (Or CachingLegacyAssetRef if legacy
	/// ID support is necessary.)
	/// </summary>
	// Token: 0x0200029E RID: 670
	public struct AssetReference<T> : IFormattedFileReadable, IFormattedFileWritable, IDatParseable, IAssetReference, IEquatable<AssetReference<T>> where T : Asset
	{
		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x0600141B RID: 5147 RVA: 0x0004D3FF File Offset: 0x0004B5FF
		// (set) Token: 0x0600141C RID: 5148 RVA: 0x0004D407 File Offset: 0x0004B607
		public Guid GUID
		{
			get
			{
				return this._guid;
			}
			set
			{
				this._guid = value;
			}
		}

		/// <summary>
		/// Whether the asset has been assigned. Note that this doesn't mean an asset with <see cref="P:SDG.Unturned.AssetReference`1.GUID" /> exists.
		/// </summary>
		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x0600141D RID: 5149 RVA: 0x0004D410 File Offset: 0x0004B610
		public bool isValid
		{
			get
			{
				return this.GUID != Guid.Empty;
			}
		}

		/// <summary>
		/// Is this asset not assigned?
		/// </summary>
		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x0600141E RID: 5150 RVA: 0x0004D422 File Offset: 0x0004B622
		public bool isNull
		{
			get
			{
				return this.GUID == Guid.Empty;
			}
		}

		/// <summary>
		/// True if resolving this asset reference would get that asset.
		/// </summary>
		// Token: 0x0600141F RID: 5151 RVA: 0x0004D434 File Offset: 0x0004B634
		public bool isReferenceTo(Asset asset)
		{
			return asset != null && this.GUID == asset.GUID;
		}

		/// <summary>
		/// Resolve reference with asset manager.
		/// </summary>
		// Token: 0x06001420 RID: 5152 RVA: 0x0004D44C File Offset: 0x0004B64C
		public T Find()
		{
			return Assets.find<T>(this);
		}

		// Token: 0x06001421 RID: 5153 RVA: 0x0004D459 File Offset: 0x0004B659
		[Obsolete("Renamed to Find because Get might imply that asset is cached")]
		public T get()
		{
			return Assets.find<T>(this);
		}

		// Token: 0x06001422 RID: 5154 RVA: 0x0004D468 File Offset: 0x0004B668
		public bool TryParse(IDatNode node)
		{
			IDatValue datValue = node as IDatValue;
			if (datValue != null)
			{
				Guid guid;
				bool result = datValue.TryParseGuid(out guid);
				this.GUID = guid;
				return result;
			}
			IDatDictionary datDictionary = node as IDatDictionary;
			if (datDictionary != null)
			{
				Guid guid2;
				bool result2 = datDictionary.TryParseGuid("GUID", out guid2);
				this.GUID = guid2;
				return result2;
			}
			return false;
		}

		// Token: 0x06001423 RID: 5155 RVA: 0x0004D4B0 File Offset: 0x0004B6B0
		public void read(IFormattedFileReader reader)
		{
			IFormattedFileReader formattedFileReader = reader.readObject();
			if (formattedFileReader == null)
			{
				this.GUID = reader.readValue<Guid>();
				return;
			}
			this.GUID = formattedFileReader.readValue<Guid>("GUID");
		}

		// Token: 0x06001424 RID: 5156 RVA: 0x0004D4E5 File Offset: 0x0004B6E5
		public void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.writeValue<Guid>("GUID", this.GUID);
			writer.endObject();
		}

		// Token: 0x06001425 RID: 5157 RVA: 0x0004D504 File Offset: 0x0004B704
		public static bool TryParse(string input, out AssetReference<T> result)
		{
			Guid guid;
			if (Guid.TryParse(input, out guid))
			{
				result = new AssetReference<T>(guid);
				return true;
			}
			result = AssetReference<T>.invalid;
			return false;
		}

		// Token: 0x06001426 RID: 5158 RVA: 0x0004D535 File Offset: 0x0004B735
		public static bool operator ==(AssetReference<T> a, AssetReference<T> b)
		{
			return a.GUID == b.GUID;
		}

		// Token: 0x06001427 RID: 5159 RVA: 0x0004D54A File Offset: 0x0004B74A
		public static bool operator !=(AssetReference<T> a, AssetReference<T> b)
		{
			return !(a == b);
		}

		// Token: 0x06001428 RID: 5160 RVA: 0x0004D558 File Offset: 0x0004B758
		public override int GetHashCode()
		{
			return this.GUID.GetHashCode();
		}

		// Token: 0x06001429 RID: 5161 RVA: 0x0004D57C File Offset: 0x0004B77C
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			AssetReference<T> assetReference = (AssetReference<T>)obj;
			return this.GUID.Equals(assetReference.GUID);
		}

		// Token: 0x0600142A RID: 5162 RVA: 0x0004D5AC File Offset: 0x0004B7AC
		public override string ToString()
		{
			return this.GUID.ToString("N");
		}

		// Token: 0x0600142B RID: 5163 RVA: 0x0004D5CC File Offset: 0x0004B7CC
		public bool Equals(AssetReference<T> other)
		{
			return this.GUID.Equals(other.GUID);
		}

		// Token: 0x0600142C RID: 5164 RVA: 0x0004D5EE File Offset: 0x0004B7EE
		public AssetReference(Guid GUID)
		{
			this._guid = GUID;
		}

		// Token: 0x0600142D RID: 5165 RVA: 0x0004D5F7 File Offset: 0x0004B7F7
		public AssetReference(string GUID)
		{
			Guid.TryParse(GUID, out this._guid);
		}

		// Token: 0x0600142E RID: 5166 RVA: 0x0004D606 File Offset: 0x0004B806
		[Obsolete]
		public AssetReference(IAssetReference assetReference)
		{
			this._guid = assetReference.GUID;
		}

		// Token: 0x04000711 RID: 1809
		public static AssetReference<T> invalid = new AssetReference<T>(Guid.Empty);

		// Token: 0x04000712 RID: 1810
		private Guid _guid;
	}
}
