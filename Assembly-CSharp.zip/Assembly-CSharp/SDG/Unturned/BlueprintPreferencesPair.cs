﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200068E RID: 1678
	internal struct BlueprintPreferencesPair
	{
		// Token: 0x04001FD2 RID: 8146
		public byte index;

		// Token: 0x04001FD3 RID: 8147
		public EBlueprintPreferences preferences;
	}
}
