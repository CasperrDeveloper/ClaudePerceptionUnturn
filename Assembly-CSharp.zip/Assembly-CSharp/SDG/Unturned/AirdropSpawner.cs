﻿using System;
using SDG.Framework.Devkit;
using UnityEngine;

namespace SDG.Unturned
{
	/// <summary>
	/// Allows Unity events to call in airdrops.
	/// </summary>
	// Token: 0x0200061F RID: 1567
	[AddComponentMenu("Unturned/Airdrop Spawner")]
	public class AirdropSpawner : MonoBehaviour
	{
		// Token: 0x060035B6 RID: 13750 RVA: 0x000FF706 File Offset: 0x000FD906
		public void SpawnDefault()
		{
			this.Spawn(this.DefaultCargoSpawnTable);
		}

		// Token: 0x060035B7 RID: 13751 RVA: 0x000FF714 File Offset: 0x000FD914
		public void Spawn(string cargoSpawnTableId)
		{
			if (!Provider.isServer)
			{
				return;
			}
			if (EffectManager.isInstantiatingEffectForPreload)
			{
				return;
			}
			AirdropDevkitNode airdropDevkitNode = null;
			if (this.UseRandomAirdropNode)
			{
				airdropDevkitNode = LevelManager.GetRandomAirdropNode();
				if (airdropDevkitNode == null)
				{
					UnturnedLog.info("{0} unable to get a random airdrop node", new object[]
					{
						base.transform.GetSceneHierarchyPath()
					});
					return;
				}
			}
			SpawnAsset spawnAsset;
			if (!string.IsNullOrEmpty(cargoSpawnTableId))
			{
				CachingBcAssetRef cachingBcAssetRef;
				if (!CachingBcAssetRef.TryParse(cargoSpawnTableId, EAssetType.SPAWN, out cachingBcAssetRef))
				{
					UnturnedLog.warn("{0} unable to parse cargo spawn table ID \"{1}\"", new object[]
					{
						base.transform.GetSceneHierarchyPath(),
						cargoSpawnTableId
					});
					return;
				}
				spawnAsset = cachingBcAssetRef.Get<SpawnAsset>();
				if (spawnAsset == null)
				{
					UnturnedLog.warn("{0} unable to find cargo spawn table \"{1}\"", new object[]
					{
						base.transform.GetSceneHierarchyPath(),
						cargoSpawnTableId
					});
					return;
				}
			}
			else
			{
				if (airdropDevkitNode == null)
				{
					UnturnedLog.warn("{0} cargo spawn table required because UseAirdropNodes is false", new object[]
					{
						base.transform.GetSceneHierarchyPath()
					});
					return;
				}
				spawnAsset = airdropDevkitNode.GetCargoSpawnTableOrLogWarning();
				if (spawnAsset == null)
				{
					return;
				}
			}
			Vector3 position = base.transform.position;
			if (airdropDevkitNode != null)
			{
				position = airdropDevkitNode.transform.position;
			}
			else if (!string.IsNullOrEmpty(this.SpawnpointName))
			{
				Spawnpoint spawnpoint = SpawnpointSystemV2.Get().FindFirstSpawnpoint(this.SpawnpointName);
				if (spawnpoint != null)
				{
					position = spawnpoint.transform.position;
				}
				else
				{
					UnturnedLog.warn("{0} unable to find spawnpoint \"{1}\"", new object[]
					{
						base.transform.GetSceneHierarchyPath(),
						this.SpawnpointName
					});
				}
			}
			LevelManager.SpawnAirdrop(position, spawnAsset);
		}

		// Token: 0x04001CB0 RID: 7344
		[Tooltip("Optional ID or GUID of spawn table asset to override cargo with when SpawnDefault is invoked.")]
		public string DefaultCargoSpawnTable;

		// Token: 0x04001CB1 RID: 7345
		[Tooltip("If set, find spawnpoint node by name and call in airdrop there.")]
		public string SpawnpointName;

		// Token: 0x04001CB2 RID: 7346
		[Tooltip("If true, select a random valid airdrop node and call in airdrop there.")]
		public bool UseRandomAirdropNode;
	}
}
