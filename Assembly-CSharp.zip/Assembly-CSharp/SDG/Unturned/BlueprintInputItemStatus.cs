﻿using System;
using System.Collections.Generic;

namespace SDG.Unturned
{
	// Token: 0x020004D8 RID: 1240
	internal class BlueprintInputItemStatus
	{
		// Token: 0x17000854 RID: 2132
		// (get) Token: 0x0600292E RID: 10542 RVA: 0x000B2BF4 File Offset: 0x000B0DF4
		public PlayerInventorySearchResultV2? FirstResultOrNull
		{
			get
			{
				if (this.searchResults.Count <= 0)
				{
					return null;
				}
				return new PlayerInventorySearchResultV2?(this.searchResults[0]);
			}
		}

		// Token: 0x17000855 RID: 2133
		// (get) Token: 0x0600292F RID: 10543 RVA: 0x000B2C2C File Offset: 0x000B0E2C
		public Item FirstItemOrNull
		{
			get
			{
				if (this.FirstResultOrNull == null)
				{
					return null;
				}
				PlayerInventorySearchResultV2? playerInventorySearchResultV;
				ItemJar jar = playerInventorySearchResultV.GetValueOrDefault().Jar;
				if (jar == null)
				{
					return null;
				}
				return jar.item;
			}
		}

		// Token: 0x040014A2 RID: 5282
		public List<PlayerInventorySearchResultV2> searchResults;

		// Token: 0x040014A3 RID: 5283
		public int totalAmount;

		/// <summary>
		/// If not zero, use this amount instead of <see cref="F:SDG.Unturned.BlueprintSupply.amount" />.
		/// Used by <see cref="F:SDG.Unturned.EBlueprintOperation.FillTargetItem" /> as amount of ammo needed.
		/// </summary>
		// Token: 0x040014A4 RID: 5284
		public int requiredAmountOverride;

		// Token: 0x040014A5 RID: 5285
		public bool isMissingRequiredAmount;
	}
}
