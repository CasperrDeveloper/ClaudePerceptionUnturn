﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000277 RID: 631
	internal static class ClientMessageHandler_BattlEye
	{
		// Token: 0x060012FA RID: 4858 RVA: 0x00044CD4 File Offset: 0x00042ED4
		internal unsafe static void ReadMessage(NetPakReader reader)
		{
			if (Provider.battlEyeClientHandle != IntPtr.Zero && Provider.battlEyeClientRunData != null && Provider.battlEyeClientRunData.pfnReceivedPacket != null)
			{
				uint num;
				reader.ReadBits(Provider.battlEyeBufferSize.bitCount, out num);
				byte[] array;
				int num2;
				if (num > 0U && reader.ReadBytesPtr((int)num, out array, out num2))
				{
					byte[] array2;
					byte* ptr;
					if ((array2 = array) == null || array2.Length == 0)
					{
						ptr = null;
					}
					else
					{
						ptr = &array2[0];
					}
					IntPtr pvPacket = new IntPtr((void*)(ptr + num2));
					Provider.battlEyeClientRunData.pfnReceivedPacket(pvPacket, (int)num);
					array2 = null;
				}
			}
		}
	}
}
