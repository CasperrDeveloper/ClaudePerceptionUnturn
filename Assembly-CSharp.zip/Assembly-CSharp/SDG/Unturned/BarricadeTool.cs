﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020007EF RID: 2031
	public class BarricadeTool : MonoBehaviour
	{
		// Token: 0x06004539 RID: 17721 RVA: 0x001605F8 File Offset: 0x0015E7F8
		public static Transform getBarricade(Transform parent, byte hp, Vector3 pos, Quaternion rot, ushort id, byte[] state)
		{
			ItemBarricadeAsset asset = Assets.find(EAssetType.ITEM, id) as ItemBarricadeAsset;
			return BarricadeTool.getBarricade(parent, hp, 0UL, 0UL, pos, rot, id, state, asset);
		}

		// Token: 0x0600453A RID: 17722 RVA: 0x00160625 File Offset: 0x0015E825
		private static Transform getEmptyBarricade(ushort id)
		{
			Transform transform = new GameObject().transform;
			transform.name = id.ToString();
			transform.tag = "Barricade";
			transform.gameObject.layer = 27;
			return transform;
		}

		// Token: 0x0600453B RID: 17723 RVA: 0x00160658 File Offset: 0x0015E858
		public static Transform getBarricade(Transform parent, byte hp, ulong owner, ulong group, Vector3 pos, Quaternion rot, ushort id, byte[] state, ItemBarricadeAsset asset)
		{
			if (asset != null)
			{
				Transform transform;
				if (asset.barricade != null)
				{
					InstantiateParameters parameters = new InstantiateParameters
					{
						parent = parent,
						worldSpace = false
					};
					transform = UnityEngine.Object.Instantiate<GameObject>(asset.barricade, pos, rot, parameters).transform;
				}
				else
				{
					transform = null;
				}
				if (transform == null)
				{
					transform = BarricadeTool.getEmptyBarricade(id);
					transform.parent = parent;
					transform.localPosition = pos;
					transform.localRotation = rot;
				}
				if (asset.useWaterHeightTransparentSort && !Dedicator.IsDedicatedServer)
				{
					transform.gameObject.AddComponent<WaterHeightTransparentSort>();
				}
				transform.name = id.ToString();
				if (Provider.isServer && asset.nav != null)
				{
					Transform transform2 = UnityEngine.Object.Instantiate<GameObject>(asset.nav).transform;
					transform2.name = "Nav";
					if (asset.build == EBuild.DOOR || asset.build == EBuild.GATE || asset.build == EBuild.SHUTTER || asset.build == EBuild.HATCH)
					{
						Transform transform3 = transform.Find("Skeleton").Find("Hinge");
						if (transform3 != null)
						{
							transform2.parent = transform3;
						}
						else
						{
							transform2.parent = transform;
						}
					}
					else
					{
						transform2.parent = transform;
					}
					transform2.localPosition = Vector3.zero;
					transform2.localRotation = Quaternion.identity;
				}
				Transform transform4 = transform.FindChildRecursive("Burning");
				if (transform4 != null)
				{
					transform4.gameObject.AddComponent<TemperatureTrigger>().temperature = EPlayerTemperature.BURNING;
				}
				Transform transform5 = transform.FindChildRecursive("Warm");
				if (transform5 != null)
				{
					transform5.gameObject.AddComponent<TemperatureTrigger>().temperature = EPlayerTemperature.WARM;
				}
				if (asset.build == EBuild.DOOR || asset.build == EBuild.GATE || asset.build == EBuild.SHUTTER || asset.build == EBuild.HATCH)
				{
					transform.gameObject.AddComponent<InteractableDoor>().updateState(asset, state);
				}
				else if (asset.build == EBuild.BED)
				{
					transform.gameObject.AddComponent<InteractableBed>().updateState(asset, state);
				}
				else if (asset.build == EBuild.STORAGE || asset.build == EBuild.STORAGE_WALL)
				{
					transform.gameObject.AddComponent<InteractableStorage>().updateState(asset, state);
				}
				else if (asset.build == EBuild.FARM)
				{
					transform.gameObject.AddComponent<InteractableFarm>().updateState(asset, state);
				}
				else if (asset.build == EBuild.TORCH || asset.build == EBuild.CAMPFIRE)
				{
					transform.gameObject.AddComponent<InteractableFire>().updateState(asset, state);
				}
				else if (asset.build == EBuild.OVEN)
				{
					transform.gameObject.AddComponent<InteractableOven>().updateState(asset, state);
				}
				else if (asset.build == EBuild.SPIKE || asset.build == EBuild.WIRE)
				{
					Transform transform6 = transform.Find("Trap");
					if (transform6 != null)
					{
						InteractableTrapTrigger interactableTrapTrigger = transform6.gameObject.AddComponent<InteractableTrapTrigger>();
						InteractableTrap interactableTrap = transform.gameObject.AddComponent<InteractableTrap>();
						interactableTrapTrigger.parentTrap = interactableTrap;
						interactableTrap.updateState(asset, state);
					}
				}
				else if (asset.build == EBuild.CHARGE)
				{
					InteractableCharge interactableCharge = transform.gameObject.AddComponent<InteractableCharge>();
					interactableCharge.updateState(asset, state);
					interactableCharge.owner = owner;
					interactableCharge.group = group;
				}
				else if (asset.build == EBuild.GENERATOR)
				{
					transform.gameObject.AddComponent<InteractableGenerator>().updateState(asset, state);
				}
				else if (asset.build == EBuild.SPOT || asset.build == EBuild.CAGE)
				{
					transform.gameObject.AddComponent<InteractableSpot>().updateState(asset, state);
				}
				else if (asset.build == EBuild.SAFEZONE)
				{
					transform.gameObject.AddComponent<InteractableSafezone>().updateState(asset, state);
				}
				else if (asset.build == EBuild.OXYGENATOR)
				{
					transform.gameObject.AddComponent<InteractableOxygenator>().updateState(asset, state);
				}
				else if (asset.build == EBuild.SIGN || asset.build == EBuild.SIGN_WALL || asset.build == EBuild.NOTE)
				{
					transform.gameObject.AddComponent<InteractableSign>().updateState(asset, state);
				}
				else if (asset.build == EBuild.CLAIM)
				{
					InteractableClaim interactableClaim = transform.gameObject.AddComponent<InteractableClaim>();
					interactableClaim.owner = owner;
					interactableClaim.group = group;
					interactableClaim.updateState(asset);
				}
				else if (asset.build == EBuild.BEACON)
				{
					transform.gameObject.AddComponent<InteractableBeacon>().updateState(asset);
				}
				else if (asset.build == EBuild.BARREL_RAIN)
				{
					transform.gameObject.AddComponent<InteractableRainBarrel>().updateState(asset, state);
				}
				else if (asset.build == EBuild.OIL)
				{
					transform.gameObject.AddComponent<InteractableOil>().updateState(asset, state);
				}
				else if (asset.build == EBuild.TANK)
				{
					transform.gameObject.AddComponent<InteractableTank>().updateState(asset, state);
				}
				else if (asset.build == EBuild.SENTRY || asset.build == EBuild.SENTRY_FREEFORM)
				{
					InteractableSentry interactableSentry = transform.gameObject.AddComponent<InteractableSentry>();
					InteractablePower power = transform.gameObject.AddComponent<InteractablePower>();
					interactableSentry.power = power;
					interactableSentry.updateState(asset, state);
				}
				else if (asset.build == EBuild.LIBRARY)
				{
					transform.gameObject.AddComponent<InteractableLibrary>().updateState(asset, state);
				}
				else if (asset.build == EBuild.MANNEQUIN)
				{
					transform.gameObject.AddComponent<InteractableMannequin>().updateState(asset, state);
				}
				else if (asset.build == EBuild.STEREO)
				{
					transform.gameObject.AddComponent<InteractableStereo>().updateState(asset, state);
				}
				else if (asset.build == EBuild.CLOCK && !Dedicator.IsDedicatedServer)
				{
					transform.gameObject.AddComponent<InteractableClock>().updateState(asset, state);
				}
				if (!asset.isUnpickupable)
				{
					Interactable2HP interactable2HP = transform.gameObject.AddComponent<Interactable2HP>();
					interactable2HP.hp = hp;
					if (asset.build == EBuild.DOOR || asset.build == EBuild.GATE || asset.build == EBuild.SHUTTER || asset.build == EBuild.HATCH)
					{
						Transform transform7 = transform.Find("Skeleton").Find("Hinge");
						if (transform7 != null)
						{
							Interactable2SalvageBarricade interactable2SalvageBarricade = transform7.gameObject.AddComponent<Interactable2SalvageBarricade>();
							interactable2SalvageBarricade.root = transform;
							interactable2SalvageBarricade.hp = interactable2HP;
							interactable2SalvageBarricade.owner = owner;
							interactable2SalvageBarricade.group = group;
							interactable2SalvageBarricade.salvageDurationMultiplier = asset.salvageDurationMultiplier;
						}
						Transform transform8 = transform.Find("Skeleton").Find("Left_Hinge");
						if (transform8 != null)
						{
							Interactable2SalvageBarricade interactable2SalvageBarricade2 = transform8.gameObject.AddComponent<Interactable2SalvageBarricade>();
							interactable2SalvageBarricade2.root = transform;
							interactable2SalvageBarricade2.hp = interactable2HP;
							interactable2SalvageBarricade2.owner = owner;
							interactable2SalvageBarricade2.group = group;
							interactable2SalvageBarricade2.salvageDurationMultiplier = asset.salvageDurationMultiplier;
						}
						Transform transform9 = transform.Find("Skeleton").Find("Right_Hinge");
						if (transform9 != null)
						{
							Interactable2SalvageBarricade interactable2SalvageBarricade3 = transform9.gameObject.AddComponent<Interactable2SalvageBarricade>();
							interactable2SalvageBarricade3.root = transform;
							interactable2SalvageBarricade3.hp = interactable2HP;
							interactable2SalvageBarricade3.owner = owner;
							interactable2SalvageBarricade3.group = group;
							interactable2SalvageBarricade3.salvageDurationMultiplier = asset.salvageDurationMultiplier;
						}
					}
					else
					{
						Interactable2SalvageBarricade interactable2SalvageBarricade4 = transform.gameObject.AddComponent<Interactable2SalvageBarricade>();
						interactable2SalvageBarricade4.root = transform;
						interactable2SalvageBarricade4.hp = interactable2HP;
						interactable2SalvageBarricade4.owner = owner;
						interactable2SalvageBarricade4.group = group;
						interactable2SalvageBarricade4.salvageDurationMultiplier = asset.salvageDurationMultiplier;
					}
				}
				return transform;
			}
			return BarricadeTool.getEmptyBarricade(id);
		}
	}
}
