﻿using System;
using System.Collections.Generic;
using SDG.Framework.Water;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000486 RID: 1158
	public class Buoyancy : MonoBehaviour
	{
		// Token: 0x060024DA RID: 9434 RVA: 0x000993E0 File Offset: 0x000975E0
		private void FixedUpdate()
		{
			foreach (Vector3 position in this.voxels)
			{
				Vector3 vector = base.transform.TransformPoint(position);
				bool flag;
				float num;
				if (this.overrideSurfaceElevation < 0f)
				{
					WaterUtility.getUnderwaterInfo(vector, out flag, out num);
				}
				else
				{
					flag = (vector.y < this.overrideSurfaceElevation);
					num = this.overrideSurfaceElevation;
				}
				if (flag)
				{
					if (!Dedicator.IsDedicatedServer)
					{
						num += Mathf.Sin((vector.x + vector.z) * 8f + Time.time) * 0.1f;
					}
					if (vector.y - this.voxelHalfHeight < num)
					{
						Vector3 force = -this.rootRigidbody.GetPointVelocity(vector) * 0.1f * this.rootRigidbody.mass + Mathf.Sqrt(Mathf.Clamp01((num - vector.y) / (2f * this.voxelHalfHeight) + 0.5f)) * this.localArchimedesForce;
						this.rootRigidbody.AddForceAtPosition(force, vector);
					}
				}
			}
		}

		// Token: 0x060024DB RID: 9435 RVA: 0x00099534 File Offset: 0x00097734
		private void Start()
		{
			this.rootRigidbody = base.gameObject.GetComponentInParent<Rigidbody>();
			BoxCollider component = base.GetComponent<BoxCollider>();
			if (component == null)
			{
				UnturnedLog.warn("Missing BoxCollider for buoyancy simulation: {0}", new object[]
				{
					base.transform.GetSceneHierarchyPath()
				});
				base.enabled = false;
				return;
			}
			Vector3 size = component.size;
			Vector3 vector = size * -0.5f;
			Vector3 vector2 = size / (float)this.slicesPerAxis;
			this.voxelHalfHeight = Mathf.Min(vector2.x, Mathf.Min(vector2.y, vector2.z)) * 0.5f;
			this.voxels = new List<Vector3>(this.slicesPerAxis * this.slicesPerAxis * this.slicesPerAxis);
			for (int i = 0; i < this.slicesPerAxis; i++)
			{
				for (int j = 0; j < this.slicesPerAxis; j++)
				{
					for (int k = 0; k < this.slicesPerAxis; k++)
					{
						float x = vector.x + vector2.x * (0.5f + (float)i);
						float y = vector.y + vector2.y * (0.5f + (float)j);
						float z = vector.z + vector2.z * (0.5f + (float)k);
						Vector3 item = new Vector3(x, y, z);
						this.voxels.Add(item);
					}
				}
			}
			if (this.voxels.Count == 0)
			{
				this.voxels.Add(component.center);
			}
			float num = this.rootRigidbody.mass / this.density;
			float y2 = 1000f * Mathf.Abs(Physics.gravity.y) * num;
			this.localArchimedesForce = new Vector3(0f, y2, 0f) / (float)this.voxels.Count;
		}

		// Token: 0x0400120F RID: 4623
		public float density = 500f;

		// Token: 0x04001210 RID: 4624
		public int slicesPerAxis = 2;

		// Token: 0x04001211 RID: 4625
		private float voxelHalfHeight;

		// Token: 0x04001212 RID: 4626
		private Vector3 localArchimedesForce;

		// Token: 0x04001213 RID: 4627
		private List<Vector3> voxels;

		// Token: 0x04001214 RID: 4628
		private Rigidbody rootRigidbody;

		// Token: 0x04001215 RID: 4629
		public float overrideSurfaceElevation = -1f;
	}
}
