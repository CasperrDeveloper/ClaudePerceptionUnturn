﻿using System;

namespace SDG.Unturned
{
	/// <summary>
	/// Used to aid backwards compatibility as much as possible when transitioning Unity versions breaks asset bundles.
	/// </summary>
	// Token: 0x020002A1 RID: 673
	public static class AssetBundleVersion
	{
		/// <summary>
		/// Unity 5.5 and earlier per-asset .unity3d file.
		/// </summary>
		// Token: 0x04000713 RID: 1811
		public const int UNITY_5 = 1;

		/// <summary>
		/// When "master bundles" were first introduced in order to convert older Unity 5.5 asset bundles in bulk.
		/// </summary>
		// Token: 0x04000714 RID: 1812
		public const int UNITY_2017_LTS = 2;

		/// <summary>
		/// Unity 2018 needed a new version number in order to convert materials from 2017 LTS asset bundles. 2019 did not need a
		/// new version number, but in retrospect it seems unfortunate that we cannot distinguish them, so 2020 does have its own.
		/// </summary>
		// Token: 0x04000715 RID: 1813
		public const int UNITY_2018_AND_2019_LTS = 3;

		// Token: 0x04000716 RID: 1814
		public const int UNITY_2020_LTS = 4;

		// Token: 0x04000717 RID: 1815
		public const int UNITY_2021_LTS = 5;

		/// <summary>
		/// 2022 LTS+
		/// </summary>
		// Token: 0x04000718 RID: 1816
		public const int NEWEST = 6;
	}
}
