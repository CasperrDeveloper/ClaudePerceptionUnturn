﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020007E3 RID: 2019
	public class Carepackage : MonoBehaviour
	{
		/// <summary>
		/// Kill any players inside the spawned interactable box.
		/// Uses hardcoded size of 4 x 4 x 4.
		/// </summary>
		// Token: 0x06004511 RID: 17681 RVA: 0x0015F67C File Offset: 0x0015D87C
		private void squishPlayersUnderBox(Transform barricade)
		{
			foreach (SteamPlayer steamPlayer in Provider.clients)
			{
				if (steamPlayer != null && !(steamPlayer.player == null) && !(steamPlayer.player.life == null))
				{
					Vector3 vector = barricade.InverseTransformPoint(steamPlayer.model.position);
					if (Mathf.Abs(vector.x) < 2f && Mathf.Abs(vector.y) < 2f && Mathf.Abs(vector.z) < 2f)
					{
						EPlayerKill eplayerKill;
						DamageTool.damagePlayer(new DamagePlayerParameters(steamPlayer.player)
						{
							damage = 101f,
							applyGlobalArmorMultiplier = false
						}, out eplayerKill);
					}
				}
			}
		}

		// Token: 0x06004512 RID: 17682 RVA: 0x0015F768 File Offset: 0x0015D968
		private void OnCollisionEnter(Collision collision)
		{
			if (this.isExploded)
			{
				return;
			}
			if (collision.collider.isTrigger)
			{
				return;
			}
			if (!Level.isLoaded)
			{
				return;
			}
			this.isExploded = true;
			if (Provider.isServer)
			{
				Vector3 position = base.transform.position;
				ItemBarricadeAsset itemBarricadeAsset = this.barricadeAsset;
				if (itemBarricadeAsset == null)
				{
					itemBarricadeAsset = (Assets.find(EAssetType.ITEM, this.barricadeID) as ItemBarricadeAsset);
				}
				Transform transform = BarricadeManager.dropBarricade(new Barricade(itemBarricadeAsset), null, base.transform.position, 0f, 0f, 0f, 0UL, 0UL);
				if (transform != null)
				{
					this.squishPlayersUnderBox(transform);
					InteractableStorage component = transform.GetComponent<InteractableStorage>();
					component.despawnWhenDestroyed = true;
					if (component != null && component.items != null)
					{
						if (this.cargoSpawnTable == null && this.id != 0)
						{
							this.cargoSpawnTable = (Assets.find(EAssetType.SPAWN, this.id) as SpawnAsset);
						}
						if (this.cargoSpawnTable != null)
						{
							int i = 0;
							while (i < 8)
							{
								ushort num = SpawnTableTool.ResolveLegacyId(this.cargoSpawnTable, EAssetType.ITEM, new Func<string>(this.OnGetSpawnTableErrorContext));
								if (num == 0)
								{
									break;
								}
								if (!component.items.tryAddItem(new Item(num, EItemOrigin.ADMIN), false))
								{
									i++;
								}
							}
						}
						component.items.onStateUpdated();
					}
					transform.gameObject.AddComponent<CarepackageDestroy>();
					Transform transform2 = transform.Find("Flare");
					if (transform2 != null)
					{
						position = transform2.position;
					}
				}
				EffectAsset effectAsset = Assets.find<EffectAsset>(new AssetReference<EffectAsset>(this.landedEffectGuid));
				if (effectAsset != null)
				{
					EffectManager.triggerEffect(new TriggerEffectParameters(effectAsset)
					{
						position = position,
						reliable = true,
						relevantDistance = EffectManager.INSANE
					});
				}
			}
			UnityEngine.Object.Destroy(base.gameObject);
		}

		// Token: 0x06004513 RID: 17683 RVA: 0x0015F92F File Offset: 0x0015DB2F
		private string OnGetSpawnTableErrorContext()
		{
			return "airdrop care package";
		}

		/// <summary>
		/// Item ID of barricade to spawn after landing.
		/// </summary>
		// Token: 0x04002AE6 RID: 10982
		[Obsolete]
		public ushort barricadeID = 1374;

		/// <summary>
		/// Barricade to spawn after landing.
		/// </summary>
		// Token: 0x04002AE7 RID: 10983
		public ItemBarricadeAsset barricadeAsset;

		/// <summary>
		/// Cargo spawn table legacy ID.
		/// </summary>
		// Token: 0x04002AE8 RID: 10984
		[Obsolete]
		public ushort id;

		// Token: 0x04002AE9 RID: 10985
		public SpawnAsset cargoSpawnTable;

		// Token: 0x04002AEA RID: 10986
		public string landedEffectGuid = "2c17fbd0f0ce49aeb3bc4637b68809a2";

		// Token: 0x04002AEB RID: 10987
		private bool isExploded;
	}
}
