﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200059D RID: 1437
	public class BarricadeRegion
	{
		// Token: 0x17000988 RID: 2440
		// (get) Token: 0x06003035 RID: 12341 RVA: 0x000DF071 File Offset: 0x000DD271
		public List<BarricadeDrop> drops
		{
			get
			{
				return this._drops;
			}
		}

		// Token: 0x17000989 RID: 2441
		// (get) Token: 0x06003036 RID: 12342 RVA: 0x000DF079 File Offset: 0x000DD279
		[Obsolete("Maintaining two separate lists was error prone, but still kept for backwards compat")]
		public List<BarricadeData> barricades
		{
			get
			{
				return this._barricades;
			}
		}

		// Token: 0x1700098A RID: 2442
		// (get) Token: 0x06003037 RID: 12343 RVA: 0x000DF081 File Offset: 0x000DD281
		public Transform parent
		{
			get
			{
				return this._parent;
			}
		}

		/// <summary>
		/// New code should not use this. Only intended for backwards compatibility.
		/// </summary>
		// Token: 0x06003038 RID: 12344 RVA: 0x000DF08C File Offset: 0x000DD28C
		public int IndexOfBarricadeByRootTransform(Transform rootTransform)
		{
			for (int i = 0; i < this._drops.Count; i++)
			{
				if (this._drops[i].model == rootTransform)
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x06003039 RID: 12345 RVA: 0x000DF0CB File Offset: 0x000DD2CB
		public BarricadeDrop FindBarricadeByRootTransform(Transform transform)
		{
			if (transform == null)
			{
				return null;
			}
			BarricadeRefComponent component = transform.GetComponent<BarricadeRefComponent>();
			if (component == null)
			{
				return null;
			}
			return component.tempNotSureIfBarricadeShouldBeAComponentYet;
		}

		/// <summary>
		/// Ideally the interactable components should have a reference to their barricade, but that will maybe happen
		/// after the NetId rewrites. For the meantime this is to avoid calling FindBarricadeByRootTransform. If we go
		/// the component route then FindBarricadeByRootTransform will do the same as this method.
		/// </summary>
		// Token: 0x0600303A RID: 12346 RVA: 0x000DF0E3 File Offset: 0x000DD2E3
		internal BarricadeDrop FindBarricadeByRootFast(Transform rootTransform)
		{
			return rootTransform.GetComponent<BarricadeRefComponent>().tempNotSureIfBarricadeShouldBeAComponentYet;
		}

		// Token: 0x0600303B RID: 12347 RVA: 0x000DF0F0 File Offset: 0x000DD2F0
		[Obsolete("Dead code, please contact if you need this and we will make a plan")]
		public BarricadeData findBarricadeByInstanceID(uint instanceID)
		{
			foreach (BarricadeData barricadeData in this.barricades)
			{
				if (barricadeData.instanceID == instanceID)
				{
					return barricadeData;
				}
			}
			return null;
		}

		// Token: 0x0600303C RID: 12348 RVA: 0x000DF14C File Offset: 0x000DD34C
		[Obsolete("Renamed to DestroyAll")]
		public void destroy()
		{
			this.DestroyAll();
		}

		// Token: 0x0600303D RID: 12349 RVA: 0x000DF154 File Offset: 0x000DD354
		internal void DestroyTail()
		{
			this._drops.GetAndRemoveTail<BarricadeDrop>().CustomDestroy();
		}

		// Token: 0x0600303E RID: 12350 RVA: 0x000DF168 File Offset: 0x000DD368
		internal void DestroyAll()
		{
			foreach (BarricadeDrop barricadeDrop in this._drops)
			{
				barricadeDrop.CustomDestroy();
			}
			this.drops.Clear();
		}

		// Token: 0x0600303F RID: 12351 RVA: 0x000DF1C4 File Offset: 0x000DD3C4
		public BarricadeRegion(Transform newParent)
		{
			this._drops = new List<BarricadeDrop>();
			this._barricades = new List<BarricadeData>();
			this._parent = newParent;
			this.isNetworked = false;
			this.isPendingDestroy = false;
		}

		// Token: 0x04001978 RID: 6520
		private List<BarricadeDrop> _drops;

		// Token: 0x04001979 RID: 6521
		private List<BarricadeData> _barricades;

		// Token: 0x0400197A RID: 6522
		private Transform _parent;

		// Token: 0x0400197B RID: 6523
		public bool isNetworked;

		// Token: 0x0400197C RID: 6524
		internal bool isPendingDestroy;
	}
}
