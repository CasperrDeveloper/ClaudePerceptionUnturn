﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020003C4 RID: 964
	public class CharacterAnimator : MonoBehaviour
	{
		// Token: 0x06001FDC RID: 8156 RVA: 0x0007B46C File Offset: 0x0007966C
		public void sample()
		{
			this.anim.Sample();
		}

		// Token: 0x06001FDD RID: 8157 RVA: 0x0007B47C File Offset: 0x0007967C
		public void mixAnimation(string name)
		{
			AnimationState animationState = this.anim[name];
			if (animationState != null)
			{
				animationState.layer = 1;
			}
		}

		// Token: 0x06001FDE RID: 8158 RVA: 0x0007B4A6 File Offset: 0x000796A6
		public void mixAnimation(string name, bool mixLeftShoulder, bool mixRightShoulder)
		{
			this.mixAnimation(name, mixLeftShoulder, mixRightShoulder, false);
		}

		// Token: 0x06001FDF RID: 8159 RVA: 0x0007B4B4 File Offset: 0x000796B4
		public void mixAnimation(string name, bool mixLeftShoulder, bool mixRightShoulder, bool mixSkull)
		{
			AnimationState animationState = this.anim[name];
			if (animationState == null)
			{
				return;
			}
			if (mixLeftShoulder)
			{
				animationState.AddMixingTransform(this.leftShoulder, true);
			}
			if (mixRightShoulder)
			{
				animationState.AddMixingTransform(this.rightShoulder, true);
			}
			if (mixSkull)
			{
				animationState.AddMixingTransform(this.skull, true);
			}
			animationState.layer = 1;
		}

		// Token: 0x06001FE0 RID: 8160 RVA: 0x0007B510 File Offset: 0x00079710
		public void AddEquippedItemAnimation(AnimationClip clip, Transform itemModelTransform)
		{
			if (clip == null)
			{
				return;
			}
			this.anim.AddClip(clip, clip.name);
			this.mixAnimation(clip.name, true, true);
			if (itemModelTransform != null)
			{
				AnimationState animationState = this.anim[clip.name];
				if (animationState != null)
				{
					animationState.AddMixingTransform(this.spineHook, true);
					animationState.AddMixingTransform(itemModelTransform, true);
				}
			}
		}

		// Token: 0x06001FE1 RID: 8161 RVA: 0x0007B580 File Offset: 0x00079780
		public void removeAnimation(AnimationClip clip)
		{
			if (clip == null)
			{
				return;
			}
			if (this.anim[clip.name] != null)
			{
				this.anim.RemoveClip(clip);
			}
		}

		// Token: 0x06001FE2 RID: 8162 RVA: 0x0007B5B4 File Offset: 0x000797B4
		public void setAnimationSpeed(string name, float speed)
		{
			AnimationState animationState = this.anim[name];
			if (animationState != null)
			{
				animationState.speed = speed;
			}
		}

		// Token: 0x06001FE3 RID: 8163 RVA: 0x0007B5DE File Offset: 0x000797DE
		public float getAnimationLength(string name)
		{
			return this.GetAnimationLength(name, true);
		}

		/// <param name="scaled">If true, include current animation speed modifier.</param>
		// Token: 0x06001FE4 RID: 8164 RVA: 0x0007B5E8 File Offset: 0x000797E8
		public float GetAnimationLength(string name, bool scaled = true)
		{
			AnimationState animationState = this.anim[name];
			if (!(animationState != null))
			{
				return 0f;
			}
			if (!scaled)
			{
				return animationState.clip.length;
			}
			if (animationState.speed != 0f)
			{
				return animationState.clip.length / animationState.speed;
			}
			return 0f;
		}

		// Token: 0x06001FE5 RID: 8165 RVA: 0x0007B645 File Offset: 0x00079845
		public bool getAnimationPlaying()
		{
			return !string.IsNullOrEmpty(this.clip) && this.anim.IsPlaying(this.clip);
		}

		// Token: 0x06001FE6 RID: 8166 RVA: 0x0007B667 File Offset: 0x00079867
		public void state(string name)
		{
			if (this.anim[name] == null)
			{
				return;
			}
			this.anim.CrossFade(name, CharacterAnimator.BLEND);
		}

		// Token: 0x06001FE7 RID: 8167 RVA: 0x0007B68F File Offset: 0x0007988F
		public bool checkExists(string name)
		{
			return this.anim[name] != null;
		}

		/// <returns>True if an animation was found and started playing.</returns>
		// Token: 0x06001FE8 RID: 8168 RVA: 0x0007B6A4 File Offset: 0x000798A4
		public bool play(string name, bool smooth)
		{
			if (this.anim[name] == null)
			{
				return false;
			}
			if (this.clip != "")
			{
				this.anim.Stop(this.clip);
			}
			this.clip = name;
			if (smooth)
			{
				this.anim.CrossFade(name, CharacterAnimator.BLEND);
			}
			else
			{
				this.anim.Play(name);
			}
			return true;
		}

		// Token: 0x06001FE9 RID: 8169 RVA: 0x0007B715 File Offset: 0x00079915
		public void stop(string name)
		{
			if (this.anim[name] == null)
			{
				return;
			}
			if (name == this.clip)
			{
				this.anim.Stop(name);
				this.clip = "";
			}
		}

		// Token: 0x06001FEA RID: 8170 RVA: 0x0007B754 File Offset: 0x00079954
		protected void init()
		{
			this.clip = "";
			this.anim = base.GetComponent<Animation>();
			this.spine = base.transform.Find("Skeleton").Find("Spine");
			this.skull = this.spine.Find("Skull");
			this.leftShoulder = this.spine.Find("Left_Shoulder");
			this.rightShoulder = this.spine.Find("Right_Shoulder");
			this.spineHook = this.spine.Find("Spine_Hook");
		}

		// Token: 0x06001FEB RID: 8171 RVA: 0x0007B7F0 File Offset: 0x000799F0
		private void Awake()
		{
			this.init();
		}

		// Token: 0x04000F14 RID: 3860
		public static readonly float BLEND = 0.25f;

		// Token: 0x04000F15 RID: 3861
		protected Animation anim;

		// Token: 0x04000F16 RID: 3862
		protected Transform spine;

		// Token: 0x04000F17 RID: 3863
		protected Transform skull;

		// Token: 0x04000F18 RID: 3864
		protected Transform leftShoulder;

		// Token: 0x04000F19 RID: 3865
		protected Transform rightShoulder;

		// Token: 0x04000F1A RID: 3866
		protected Transform spineHook;

		// Token: 0x04000F1B RID: 3867
		protected string clip;
	}
}
