﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x0200027E RID: 638
	internal static class ClientMessageHandler_PlayerDisconnected
	{
		// Token: 0x06001304 RID: 4868 RVA: 0x00045518 File Offset: 0x00043718
		internal static void ReadMessage(NetPakReader reader)
		{
			NetId netId;
			if (reader.ReadNetId(out netId))
			{
				SteamPlayer steamPlayer = NetIdRegistry.Get<SteamPlayer>(netId);
				if (steamPlayer != null)
				{
					Provider.RemoveClient(steamPlayer);
					return;
				}
				UnturnedLog.info(string.Format("Received PlayerDisconnected message for unknown NetID: {0}", netId));
			}
		}
	}
}
