﻿using System;
using System.Collections.Generic;
using System.IO;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	/// <summary>
	/// Helper for wiki writers to dump game data into a useful format.
	/// </summary>
	// Token: 0x020002B0 RID: 688
	public static class CargoExporter
	{
		// Token: 0x0600152E RID: 5422 RVA: 0x0005246C File Offset: 0x0005066C
		public static void Export()
		{
			string text = Path.Join(ReadWrite.PATH, "Extras", "WikiCargoData");
			ReadWrite.createFolder(text, false);
			CargoBuilder cargoBuilder = new CargoBuilder();
			foreach (AssetOrigin assetOrigin in Assets.assetOrigins)
			{
				if (!assetOrigin.assets.IsEmpty<Asset>())
				{
					string value = PathEx.ReplaceInvalidFileNameChars(assetOrigin.name, '_');
					if (string.IsNullOrEmpty(value))
					{
						UnturnedLog.error("Unable to export origin " + assetOrigin.name + " Asset IDs because file name would be empty");
					}
					else
					{
						string text2 = Path.Join(text, value);
						ReadWrite.createFolder(text2, false);
						foreach (Asset asset in assetOrigin.assets)
						{
							cargoBuilder.Clear();
							asset.BuildCargoData(cargoBuilder);
							if (cargoBuilder.declarations.Count >= 1)
							{
								string path = PathEx.ReplaceInvalidFileNameChars(asset.GetTypeFriendlyName(), '_');
								string text3 = Path.Combine(text2, path);
								Directory.CreateDirectory(text3);
								string str = PathEx.ReplaceInvalidFileNameChars(asset.name + " (" + asset.FriendlyName + ")", '_');
								using (FileStream fileStream = new FileStream(Path.Join(text3, str + ".txt"), FileMode.Create, FileAccess.Write))
								{
									using (StreamWriter streamWriter = new StreamWriter(fileStream))
									{
										foreach (KeyValuePair<string, List<CargoDeclaration>> keyValuePair in cargoBuilder.declarations)
										{
											foreach (CargoDeclaration cargoDeclaration in keyValuePair.Value)
											{
												streamWriter.Write("{{Cargo/");
												streamWriter.WriteLine(keyValuePair.Key);
												foreach (string value2 in cargoDeclaration.lines)
												{
													streamWriter.WriteLine(value2);
												}
												streamWriter.WriteLine("}}");
												streamWriter.WriteLine();
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
