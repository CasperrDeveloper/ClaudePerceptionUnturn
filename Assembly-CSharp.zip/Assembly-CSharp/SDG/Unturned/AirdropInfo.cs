﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005CC RID: 1484
	public class AirdropInfo
	{
		// Token: 0x170009A2 RID: 2466
		// (get) Token: 0x060031F0 RID: 12784 RVA: 0x000E8FAA File Offset: 0x000E71AA
		// (set) Token: 0x060031F1 RID: 12785 RVA: 0x000E8FB2 File Offset: 0x000E71B2
		public Vector3 Velocity { get; set; }

		// Token: 0x170009A3 RID: 2467
		// (get) Token: 0x060031F2 RID: 12786 RVA: 0x000E8FBB File Offset: 0x000E71BB
		// (set) Token: 0x060031F3 RID: 12787 RVA: 0x000E8FC3 File Offset: 0x000E71C3
		public CachingAssetRef ServerCargoSpawnTableRef { get; set; }

		// Token: 0x170009A4 RID: 2468
		// (get) Token: 0x060031F4 RID: 12788 RVA: 0x000E8FCC File Offset: 0x000E71CC
		// (set) Token: 0x060031F5 RID: 12789 RVA: 0x000E8FD4 File Offset: 0x000E71D4
		public float ServerConstantForce
		{
			get
			{
				return this.force;
			}
			set
			{
				this.force = value;
			}
		}

		// Token: 0x170009A5 RID: 2469
		// (get) Token: 0x060031F6 RID: 12790 RVA: 0x000E8FDD File Offset: 0x000E71DD
		// (set) Token: 0x060031F7 RID: 12791 RVA: 0x000E8FE5 File Offset: 0x000E71E5
		public Vector3 ServerDropPosition
		{
			get
			{
				return this.dropPosition;
			}
			set
			{
				this.dropPosition = value;
			}
		}

		// Token: 0x170009A6 RID: 2470
		// (get) Token: 0x060031F8 RID: 12792 RVA: 0x000E8FEE File Offset: 0x000E71EE
		// (set) Token: 0x060031F9 RID: 12793 RVA: 0x000E8FF6 File Offset: 0x000E71F6
		public bool ServerHasDeployedCarepackage
		{
			get
			{
				return this.dropped;
			}
			set
			{
				this.dropped = value;
			}
		}

		// Token: 0x170009A7 RID: 2471
		// (get) Token: 0x060031FA RID: 12794 RVA: 0x000E8FFF File Offset: 0x000E71FF
		// (set) Token: 0x060031FB RID: 12795 RVA: 0x000E9007 File Offset: 0x000E7207
		public float ServerTimeUntilDrop
		{
			get
			{
				return this.delay;
			}
			set
			{
				this.delay = value;
			}
		}

		// Token: 0x04001AAA RID: 6826
		public Transform model;

		// Token: 0x04001AAB RID: 6827
		[Obsolete("Replaced by CargoSpawnTableRef which is only set on the server")]
		public ushort id;

		/// <summary>
		/// Current position.
		/// </summary>
		// Token: 0x04001AAC RID: 6828
		public Vector3 state;

		// Token: 0x04001AAD RID: 6829
		[Obsolete("Replaced by Velocity property")]
		public Vector3 direction;

		// Token: 0x04001AAE RID: 6830
		[Obsolete("Replaced by Velocity property")]
		public float speed;

		// Token: 0x04001AAF RID: 6831
		[Obsolete("Replaced by ServerTimeUntilDrop which is only set on the server")]
		public float delay;

		// Token: 0x04001AB0 RID: 6832
		[Obsolete("Replaced by ServerConstantForce which is only set on the server")]
		public float force;

		// Token: 0x04001AB1 RID: 6833
		[Obsolete("Replaced by ServerHasDeployedCarepackage which is only set on the server")]
		public bool dropped;

		// Token: 0x04001AB2 RID: 6834
		[Obsolete("Replaced by ServerDropPosition which is only set on the server")]
		public Vector3 dropPosition;
	}
}
