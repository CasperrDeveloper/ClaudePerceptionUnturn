﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000770 RID: 1904
	public class AnimalsConfigData
	{
		// Token: 0x0600426B RID: 17003 RVA: 0x0014986C File Offset: 0x00147A6C
		public AnimalsConfigData(EGameMode mode)
		{
			this.Respawn_Time = 180f;
			if (mode != EGameMode.EASY)
			{
				if (mode != EGameMode.HARD)
				{
					this.Damage_Multiplier = 1f;
					this.Armor_Multiplier = 1f;
				}
				else
				{
					this.Damage_Multiplier = 1.5f;
					this.Armor_Multiplier = 0.75f;
				}
			}
			else
			{
				this.Damage_Multiplier = 0.75f;
				this.Armor_Multiplier = 1.25f;
			}
			this.Max_Instances_Tiny = 4U;
			this.Max_Instances_Small = 8U;
			this.Max_Instances_Medium = 16U;
			this.Max_Instances_Large = 32U;
			this.Max_Instances_Insane = 64U;
			this.Weapons_Use_Player_Damage = (mode == EGameMode.HARD);
		}

		/// <summary>
		/// How long (in seconds) before a dead animal respawns.
		/// </summary>
		// Token: 0x0400284A RID: 10314
		public float Respawn_Time;

		/// <summary>
		/// Scales the amount of damage dealt by animals.
		/// For example, 2.0 doubles the amount of damage from animal attacks.
		/// </summary>
		// Token: 0x0400284B RID: 10315
		public float Damage_Multiplier;

		/// <summary>
		/// Scales the amount of damage taken by animals.
		/// For example, 0.5 halves the amount of damage dealt to animals.
		/// </summary>
		// Token: 0x0400284C RID: 10316
		public float Armor_Multiplier;

		/// <summary>
		/// Maximum number of animals on "Tiny" size levels.
		/// </summary>
		// Token: 0x0400284D RID: 10317
		public uint Max_Instances_Tiny;

		/// <summary>
		/// Maximum number of animals on "Small" size levels.
		/// </summary>
		// Token: 0x0400284E RID: 10318
		public uint Max_Instances_Small;

		/// <summary>
		/// Maximum number of animals on "Medium" size levels.
		/// </summary>
		// Token: 0x0400284F RID: 10319
		public uint Max_Instances_Medium;

		/// <summary>
		/// Maximum number of animals on "Large" size levels.
		/// </summary>
		// Token: 0x04002850 RID: 10320
		public uint Max_Instances_Large;

		/// <summary>
		/// Maximum number of animals on "Insane" size levels.
		/// </summary>
		// Token: 0x04002851 RID: 10321
		public uint Max_Instances_Insane;

		/// <summary>
		/// If true, attacking an animal uses the weapon's PvP damage values rather than animal-specific damage.
		/// </summary>
		// Token: 0x04002852 RID: 10322
		public bool Weapons_Use_Player_Damage;
	}
}
