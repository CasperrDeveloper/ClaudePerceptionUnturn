﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200067A RID: 1658
	// (Invoke) Token: 0x060036BF RID: 14015
	public delegate void AdminUsageFlagsChanged(Player player, EPlayerAdminUsageFlags oldFlags, EPlayerAdminUsageFlags newFlags);
}
