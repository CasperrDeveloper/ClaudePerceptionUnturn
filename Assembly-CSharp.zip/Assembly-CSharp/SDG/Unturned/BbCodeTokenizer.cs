﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SDG.Unturned
{
	/// <summary>
	/// Breaks down Steam's version of BBcode into tokens like, "[b]", "[i]", "actual text", etc.
	/// </summary>
	// Token: 0x0200045D RID: 1117
	public class BbCodeTokenizer
	{
		// Token: 0x0600231F RID: 8991 RVA: 0x00092169 File Offset: 0x00090369
		public BbCodeTokenizer()
		{
			this.tagStringBuilder = new StringBuilder();
			this.stringBuilder = new StringBuilder();
		}

		/// <summary>
		/// If true, parse newlines in the input as LineBreak tokens. (default true)
		/// If false, exclude LineBreak tokens from output.
		/// Steam's new visual editor doesn't emit newlines, instead inferring line breaks from paragraph blocks. To
		/// make life easier we will do the same for the main menu announcement feed.
		/// </summary>
		// Token: 0x1700075A RID: 1882
		// (get) Token: 0x06002320 RID: 8992 RVA: 0x0009218E File Offset: 0x0009038E
		// (set) Token: 0x06002321 RID: 8993 RVA: 0x00092196 File Offset: 0x00090396
		public bool ParseLineBreaks
		{
			get
			{
				return this._parseLineBreaks;
			}
			set
			{
				this._parseLineBreaks = value;
			}
		}

		// Token: 0x06002322 RID: 8994 RVA: 0x000921A0 File Offset: 0x000903A0
		public List<BbCodeToken> Tokenize(TextReader inputReader)
		{
			this.inputReader = inputReader;
			this.ErrorMessage = null;
			this.hasChar = false;
			this.currentLineNumber = 1;
			List<BbCodeToken> list = new List<BbCodeToken>();
			this.ReadChar();
			int num = 0;
			while (this.hasChar)
			{
				this.ReadToken(list);
				num++;
				if (num >= 10000)
				{
					this.ErrorMessage = "Infinite loop attempting to tokenize";
					break;
				}
			}
			return list;
		}

		// Token: 0x06002323 RID: 8995 RVA: 0x00092204 File Offset: 0x00090404
		public List<BbCodeToken> Tokenize(string input)
		{
			List<BbCodeToken> result;
			using (StringReader stringReader = new StringReader(input))
			{
				result = this.Tokenize(stringReader);
			}
			return result;
		}

		// Token: 0x06002324 RID: 8996 RVA: 0x00092240 File Offset: 0x00090440
		public string DebugDumpTokensToString(List<BbCodeToken> tokens)
		{
			this.stringBuilder.Clear();
			for (int i = 0; i < tokens.Count; i++)
			{
				this.stringBuilder.Append(i);
				this.stringBuilder.Append(": ");
				BbCodeToken bbCodeToken = tokens[i];
				if (string.IsNullOrEmpty(bbCodeToken.tokenValue))
				{
					this.stringBuilder.AppendLine(bbCodeToken.tokenType.ToString());
				}
				else
				{
					this.stringBuilder.Append(bbCodeToken.tokenType.ToString());
					this.stringBuilder.Append(": ");
					this.stringBuilder.AppendLine(bbCodeToken.tokenValue);
				}
			}
			return this.stringBuilder.ToString();
		}

		// Token: 0x1700075B RID: 1883
		// (get) Token: 0x06002325 RID: 8997 RVA: 0x0009230F File Offset: 0x0009050F
		public bool HasError
		{
			get
			{
				return this.hasError;
			}
		}

		// Token: 0x1700075C RID: 1884
		// (get) Token: 0x06002326 RID: 8998 RVA: 0x00092317 File Offset: 0x00090517
		// (set) Token: 0x06002327 RID: 8999 RVA: 0x0009231F File Offset: 0x0009051F
		public string ErrorMessage
		{
			get
			{
				return this.errorMessage;
			}
			private set
			{
				this.errorMessage = value;
				this.hasError = !string.IsNullOrEmpty(this.errorMessage);
			}
		}

		// Token: 0x06002328 RID: 9000 RVA: 0x0009233C File Offset: 0x0009053C
		private void ReadChar()
		{
			bool flag = this.hasChar && this.currentChar == '\r';
			this.currentReadResult = this.inputReader.Read();
			this.hasChar = (this.currentReadResult >= 0);
			this.currentChar = (this.hasChar ? ((char)this.currentReadResult) : '\0');
			this.currentLineNumber += ((this.hasChar && (this.currentChar == '\r' || (this.currentChar == '\n' && !flag))) ? 1 : 0);
		}

		// Token: 0x06002329 RID: 9001 RVA: 0x000923CC File Offset: 0x000905CC
		private void ReadToken(List<BbCodeToken> outputTokens)
		{
			if (this.currentChar == '[')
			{
				this.ReadTag(outputTokens);
				return;
			}
			if (this.currentChar == '\r')
			{
				this.ReadChar();
				if (this.hasChar && this.currentChar == '\n')
				{
					this.ReadChar();
				}
				if (this._parseLineBreaks)
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.LineBreak));
					return;
				}
			}
			else if (this.currentChar == '\n')
			{
				this.ReadChar();
				if (this._parseLineBreaks)
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.LineBreak));
					return;
				}
			}
			else
			{
				this.ReadString(outputTokens);
			}
		}

		// Token: 0x0600232A RID: 9002 RVA: 0x00092458 File Offset: 0x00090658
		private void ReadString(List<BbCodeToken> tokens)
		{
			this.stringBuilder.Clear();
			do
			{
				this.stringBuilder.Append(this.currentChar);
				this.ReadChar();
			}
			while (this.currentChar != '[' && this.currentChar != '\r' && this.currentChar != '\n' && this.hasChar);
			if (this.stringBuilder.Length > 0)
			{
				string tokenValue = this.stringBuilder.ToString();
				tokens.Add(new BbCodeToken(EBbCodeTokenType.String, tokenValue));
			}
		}

		// Token: 0x0600232B RID: 9003 RVA: 0x000924D8 File Offset: 0x000906D8
		private void ReadTag(List<BbCodeToken> outputTokens)
		{
			bool flag = false;
			this.stringBuilder.Clear();
			this.stringBuilder.Append(this.currentChar);
			this.tagStringBuilder.Clear();
			this.ReadChar();
			while (this.hasChar)
			{
				this.stringBuilder.Append(this.currentChar);
				if (this.currentChar == ']')
				{
					this.ReadChar();
					break;
				}
				if (this.currentChar == ' ' || this.currentChar == '=')
				{
					flag = true;
					this.ReadChar();
					break;
				}
				this.tagStringBuilder.Append(this.currentChar);
				this.ReadChar();
			}
			string text = this.tagStringBuilder.ToString();
			string tokenValue = null;
			if (flag)
			{
				this.tagStringBuilder.Clear();
				while (this.hasChar)
				{
					this.stringBuilder.Append(this.currentChar);
					if (this.currentChar == ']')
					{
						this.ReadChar();
						break;
					}
					this.tagStringBuilder.Append(this.currentChar);
					this.ReadChar();
				}
				tokenValue = this.tagStringBuilder.ToString();
			}
			bool flag2 = false;
			if (text.StartsWith('/'))
			{
				if (string.Equals(text, "/p"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ParagraphClose));
				}
				else if (string.Equals(text, "/b"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.BoldClose));
				}
				else if (string.Equals(text, "/i"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ItalicClose));
				}
				else if (string.Equals(text, "/u"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.UnderlineClose));
				}
				else if (string.Equals(text, "/*"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ListItemClose));
				}
				else if (string.Equals(text, "/list"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.BulletListClose));
				}
				else if (string.Equals(text, "/olist"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.OrderedListClose));
				}
				else if (string.Equals(text, "/h1"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H1Close));
				}
				else if (string.Equals(text, "/h2"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H2Close));
				}
				else if (string.Equals(text, "/h3"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H3Close));
				}
				else if (string.Equals(text, "/url"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.UrlClose));
				}
				else if (string.Equals(text, "/img"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ImgClose));
				}
				else if (string.Equals(text, "/previewyoutube"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.PreviewYouTubeClose));
				}
				else if (string.Equals(text, "/quote"))
				{
					outputTokens.Add(new BbCodeToken(EBbCodeTokenType.QuoteClose));
				}
				else
				{
					flag2 = true;
				}
			}
			else if (string.Equals(text, "p"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ParagraphOpen));
			}
			else if (string.Equals(text, "b"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.BoldOpen));
			}
			else if (string.Equals(text, "i"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ItalicOpen));
			}
			else if (string.Equals(text, "u"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.UnderlineOpen));
			}
			else if (string.Equals(text, "*"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ListItemOpen));
			}
			else if (string.Equals(text, "list"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.BulletListOpen));
			}
			else if (string.Equals(text, "olist"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.OrderedListOpen));
			}
			else if (string.Equals(text, "h1"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H1Open));
			}
			else if (string.Equals(text, "h2"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H2Open));
			}
			else if (string.Equals(text, "h3"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.H3Open));
			}
			else if (string.Equals(text, "url"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.UrlOpen, tokenValue));
			}
			else if (string.Equals(text, "img"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.ImgOpen, tokenValue));
			}
			else if (string.Equals(text, "previewyoutube"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.PreviewYouTubeOpen, tokenValue));
			}
			else if (string.Equals(text, "quote"))
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.QuoteOpen, tokenValue));
			}
			else
			{
				flag2 = true;
			}
			if (flag2)
			{
				outputTokens.Add(new BbCodeToken(EBbCodeTokenType.String, this.stringBuilder.ToString()));
			}
		}

		// Token: 0x04001183 RID: 4483
		private bool _parseLineBreaks = true;

		// Token: 0x04001184 RID: 4484
		private TextReader inputReader;

		// Token: 0x04001185 RID: 4485
		private int currentLineNumber;

		// Token: 0x04001186 RID: 4486
		private int currentReadResult;

		// Token: 0x04001187 RID: 4487
		private char currentChar;

		// Token: 0x04001188 RID: 4488
		private bool hasChar;

		// Token: 0x04001189 RID: 4489
		private bool hasError;

		// Token: 0x0400118A RID: 4490
		private string errorMessage;

		// Token: 0x0400118B RID: 4491
		private StringBuilder tagStringBuilder;

		// Token: 0x0400118C RID: 4492
		private StringBuilder stringBuilder;
	}
}
