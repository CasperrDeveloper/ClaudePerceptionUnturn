﻿using System;
using SDG.NetPak;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020001DF RID: 479
	[NetInvokableGeneratedClass(typeof(BarricadeDrop))]
	public static class BarricadeDrop_NetMethods
	{
		// Token: 0x06000E85 RID: 3717 RVA: 0x000360A8 File Offset: 0x000342A8
		private static void ReceiveHealth_DeferredRead(object voidNetObj, in ClientInvocationContext context)
		{
			BarricadeDrop barricadeDrop = voidNetObj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			byte hp;
			context.reader.ReadUInt8(out hp);
			barricadeDrop.ReceiveHealth(hp);
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x000360D8 File Offset: 0x000342D8
		[NetInvokableGeneratedMethod("ReceiveHealth", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveHealth_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId key;
			if (!reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				NetInvocationDeferralRegistry.Defer(key, context, new NetInvokeDeferred(BarricadeDrop_NetMethods.ReceiveHealth_DeferredRead));
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			byte hp;
			reader.ReadUInt8(out hp);
			barricadeDrop.ReceiveHealth(hp);
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x00036131 File Offset: 0x00034331
		[NetInvokableGeneratedMethod("ReceiveHealth", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveHealth_Write(NetPakWriter writer, byte hp)
		{
			writer.WriteUInt8(hp);
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0003613C File Offset: 0x0003433C
		private static void ReceiveTransform_DeferredRead(object voidNetObj, in ClientInvocationContext context)
		{
			BarricadeDrop barricadeDrop = voidNetObj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			NetPakReader reader = context.reader;
			byte old_x;
			reader.ReadUInt8(out old_x);
			byte old_y;
			reader.ReadUInt8(out old_y);
			ushort oldPlant;
			reader.ReadUInt16(out oldPlant);
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 11);
			Quaternion rotation;
			reader.ReadSpecialYawOrQuaternion(out rotation, 23, 9);
			barricadeDrop.ReceiveTransform(context, old_x, old_y, oldPlant, point, rotation);
		}

		// Token: 0x06000E89 RID: 3721 RVA: 0x0003619C File Offset: 0x0003439C
		[NetInvokableGeneratedMethod("ReceiveTransform", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveTransform_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId key;
			if (!reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				NetInvocationDeferralRegistry.Defer(key, context, new NetInvokeDeferred(BarricadeDrop_NetMethods.ReceiveTransform_DeferredRead));
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			byte old_x;
			reader.ReadUInt8(out old_x);
			byte old_y;
			reader.ReadUInt8(out old_y);
			ushort oldPlant;
			reader.ReadUInt16(out oldPlant);
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 11);
			Quaternion rotation;
			reader.ReadSpecialYawOrQuaternion(out rotation, 23, 9);
			barricadeDrop.ReceiveTransform(context, old_x, old_y, oldPlant, point, rotation);
		}

		// Token: 0x06000E8A RID: 3722 RVA: 0x0003622A File Offset: 0x0003442A
		[NetInvokableGeneratedMethod("ReceiveTransform", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveTransform_Write(NetPakWriter writer, byte old_x, byte old_y, ushort oldPlant, Vector3 point, Quaternion rotation)
		{
			writer.WriteUInt8(old_x);
			writer.WriteUInt8(old_y);
			writer.WriteUInt16(oldPlant);
			writer.WriteClampedVector3(point, 13, 11);
			writer.WriteSpecialYawOrQuaternion(rotation, 23, 9);
		}

		// Token: 0x06000E8B RID: 3723 RVA: 0x00036260 File Offset: 0x00034460
		[NetInvokableGeneratedMethod("ReceiveTransformRequest", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveTransformRequest_Read(in ServerInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId key;
			if (!reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 11);
			Quaternion rotation;
			reader.ReadSpecialYawOrQuaternion(out rotation, 23, 9);
			barricadeDrop.ReceiveTransformRequest(context, point, rotation);
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x000362BA File Offset: 0x000344BA
		[NetInvokableGeneratedMethod("ReceiveTransformRequest", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveTransformRequest_Write(NetPakWriter writer, Vector3 point, Quaternion rotation)
		{
			writer.WriteClampedVector3(point, 13, 11);
			writer.WriteSpecialYawOrQuaternion(rotation, 23, 9);
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x000362D4 File Offset: 0x000344D4
		private static void ReceiveOwnerAndGroup_DeferredRead(object voidNetObj, in ClientInvocationContext context)
		{
			BarricadeDrop barricadeDrop = voidNetObj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			NetPakReader reader = context.reader;
			ulong newOwner;
			reader.ReadUInt64(out newOwner);
			ulong newGroup;
			reader.ReadUInt64(out newGroup);
			barricadeDrop.ReceiveOwnerAndGroup(newOwner, newGroup);
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x0003630C File Offset: 0x0003450C
		[NetInvokableGeneratedMethod("ReceiveOwnerAndGroup", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveOwnerAndGroup_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId key;
			if (!reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				NetInvocationDeferralRegistry.Defer(key, context, new NetInvokeDeferred(BarricadeDrop_NetMethods.ReceiveOwnerAndGroup_DeferredRead));
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			ulong newOwner;
			reader.ReadUInt64(out newOwner);
			ulong newGroup;
			reader.ReadUInt64(out newGroup);
			barricadeDrop.ReceiveOwnerAndGroup(newOwner, newGroup);
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x00036370 File Offset: 0x00034570
		[NetInvokableGeneratedMethod("ReceiveOwnerAndGroup", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveOwnerAndGroup_Write(NetPakWriter writer, ulong newOwner, ulong newGroup)
		{
			writer.WriteUInt64(newOwner);
			writer.WriteUInt64(newGroup);
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x00036384 File Offset: 0x00034584
		private static void ReceiveUpdateState_DeferredRead(object voidNetObj, in ClientInvocationContext context)
		{
			BarricadeDrop barricadeDrop = voidNetObj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			NetPakReader reader = context.reader;
			byte b;
			reader.ReadUInt8(out b);
			byte[] array = new byte[(int)b];
			reader.ReadBytes(array);
			barricadeDrop.ReceiveUpdateState(array);
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x000363C0 File Offset: 0x000345C0
		[NetInvokableGeneratedMethod("ReceiveUpdateState", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveUpdateState_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId key;
			if (!reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				NetInvocationDeferralRegistry.Defer(key, context, new NetInvokeDeferred(BarricadeDrop_NetMethods.ReceiveUpdateState_DeferredRead));
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			byte b;
			reader.ReadUInt8(out b);
			byte[] array = new byte[(int)b];
			reader.ReadBytes(array);
			barricadeDrop.ReceiveUpdateState(array);
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0003642C File Offset: 0x0003462C
		[NetInvokableGeneratedMethod("ReceiveUpdateState", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveUpdateState_Write(NetPakWriter writer, byte[] newState)
		{
			byte b = (byte)newState.Length;
			writer.WriteUInt8(b);
			writer.WriteBytes(newState, (int)b);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x00036450 File Offset: 0x00034650
		[NetInvokableGeneratedMethod("ReceiveSalvageRequest", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveSalvageRequest_Read(in ServerInvocationContext context)
		{
			NetId key;
			if (!context.reader.ReadNetId(out key))
			{
				return;
			}
			object obj = NetIdRegistry.Get(key);
			if (obj == null)
			{
				return;
			}
			BarricadeDrop barricadeDrop = obj as BarricadeDrop;
			if (barricadeDrop == null)
			{
				return;
			}
			barricadeDrop.ReceiveSalvageRequest(context);
		}
	}
}
