﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000502 RID: 1282
	public class CartographyVolumeManager : VolumeManager<CartographyVolume, CartographyVolumeManager>
	{
		// Token: 0x060029E2 RID: 10722 RVA: 0x000B5357 File Offset: 0x000B3557
		public CartographyVolume GetMainVolume()
		{
			return this.allVolumes.HeadOrDefault<CartographyVolume>();
		}

		// Token: 0x060029E3 RID: 10723 RVA: 0x000B5364 File Offset: 0x000B3564
		protected override void OnUpdateGizmos(RuntimeGizmos runtimeGizmos)
		{
			base.OnUpdateGizmos(runtimeGizmos);
			foreach (CartographyVolume cartographyVolume in this.allVolumes)
			{
				Color color = cartographyVolume.isSelected ? Color.yellow : this.debugColor;
				runtimeGizmos.Arrow(cartographyVolume.transform.position, cartographyVolume.transform.forward, 1f, color, 0f, EGizmoLayer.World);
			}
		}

		// Token: 0x060029E4 RID: 10724 RVA: 0x000B53F8 File Offset: 0x000B35F8
		public CartographyVolumeManager()
		{
			base.FriendlyName = "Cartography (GPS/Chart)";
			base.SetDebugColor(new Color32(150, 125, 100, byte.MaxValue));
		}
	}
}
