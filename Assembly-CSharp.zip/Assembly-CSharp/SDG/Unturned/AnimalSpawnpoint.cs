﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020004F9 RID: 1273
	public class AnimalSpawnpoint
	{
		// Token: 0x1700086D RID: 2157
		// (get) Token: 0x060029BB RID: 10683 RVA: 0x000B48FC File Offset: 0x000B2AFC
		public Vector3 point
		{
			get
			{
				return this._point;
			}
		}

		// Token: 0x1700086E RID: 2158
		// (get) Token: 0x060029BC RID: 10684 RVA: 0x000B4904 File Offset: 0x000B2B04
		public Transform node
		{
			get
			{
				return this._node;
			}
		}

		// Token: 0x060029BD RID: 10685 RVA: 0x000B490C File Offset: 0x000B2B0C
		public void setEnabled(bool isEnabled)
		{
			this.node.transform.gameObject.SetActive(isEnabled);
		}

		// Token: 0x060029BE RID: 10686 RVA: 0x000B4924 File Offset: 0x000B2B24
		public AnimalSpawnpoint(byte newType, Vector3 newPoint)
		{
			this.type = newType;
			this._point = newPoint;
			if (Level.isEditor)
			{
				this._node = ((GameObject)UnityEngine.Object.Instantiate(Resources.Load("Edit/Animal"))).transform;
				this.node.name = this.type.ToString();
				this.node.position = this.point;
				this.node.GetComponent<Renderer>().material.color = LevelAnimals.tables[(int)this.type].color;
			}
		}

		// Token: 0x04001510 RID: 5392
		public byte type;

		// Token: 0x04001511 RID: 5393
		private Vector3 _point;

		// Token: 0x04001512 RID: 5394
		private Transform _node;
	}
}
