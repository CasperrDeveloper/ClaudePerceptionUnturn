﻿using System;
using System.Reflection;

namespace SDG.Unturned
{
	// Token: 0x02000259 RID: 601
	public class ClientMethodInfo
	{
		// Token: 0x0600127C RID: 4732 RVA: 0x00042A76 File Offset: 0x00040C76
		public override string ToString()
		{
			return this.debugName;
		}

		// Token: 0x040005FF RID: 1535
		internal Type declaringType;

		// Token: 0x04000600 RID: 1536
		internal string name;

		// Token: 0x04000601 RID: 1537
		internal string debugName;

		// Token: 0x04000602 RID: 1538
		internal SteamCall customAttribute;

		// Token: 0x04000603 RID: 1539
		internal ClientMethodReceive readMethod;

		// Token: 0x04000604 RID: 1540
		internal MethodInfo writeMethodInfo;

		// Token: 0x04000605 RID: 1541
		internal uint methodIndex;
	}
}
