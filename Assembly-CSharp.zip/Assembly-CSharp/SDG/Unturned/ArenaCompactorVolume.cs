﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004FC RID: 1276
	public class ArenaCompactorVolume : LevelVolume<ArenaCompactorVolume, ArenaCompactorVolumeManager>
	{
		// Token: 0x060029D1 RID: 10705 RVA: 0x000B50E8 File Offset: 0x000B32E8
		protected override void Awake()
		{
			this.supportsBoxShape = false;
			base.Awake();
		}
	}
}
