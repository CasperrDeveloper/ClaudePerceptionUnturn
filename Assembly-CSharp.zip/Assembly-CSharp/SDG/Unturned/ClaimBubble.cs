﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005AE RID: 1454
	public class ClaimBubble : ClaimBase
	{
		// Token: 0x060030A7 RID: 12455 RVA: 0x000E05E4 File Offset: 0x000DE7E4
		public ClaimBubble(Vector3 newOrigin, float newSqrRadius, ulong newOwner, ulong newGroup) : base(newOwner, newGroup)
		{
			this.origin = newOrigin;
			this.sqrRadius = newSqrRadius;
		}

		// Token: 0x040019B7 RID: 6583
		public Vector3 origin;

		// Token: 0x040019B8 RID: 6584
		public float sqrRadius;
	}
}
