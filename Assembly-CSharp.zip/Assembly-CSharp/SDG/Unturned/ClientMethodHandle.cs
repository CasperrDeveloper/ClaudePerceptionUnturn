﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;

namespace SDG.Unturned
{
	// Token: 0x0200023A RID: 570
	public abstract class ClientMethodHandle
	{
		// Token: 0x060011B4 RID: 4532 RVA: 0x00040886 File Offset: 0x0003EA86
		public override string ToString()
		{
			if (this.clientMethodInfo != null)
			{
				return this.clientMethodInfo.ToString();
			}
			return "invalid";
		}

		// Token: 0x060011B5 RID: 4533 RVA: 0x000408A4 File Offset: 0x0003EAA4
		protected static THandle GetInternal<THandle, TWriteDelegate>(Type declaringType, string methodName, Func<ClientMethodInfo, TWriteDelegate, THandle> makeHandle) where THandle : ClientMethodHandle where TWriteDelegate : Delegate
		{
			ClientMethodInfo clientMethodInfo = NetReflection.GetClientMethodInfo(declaringType, methodName);
			if (clientMethodInfo != null)
			{
				TWriteDelegate twriteDelegate = NetReflection.CreateClientWriteDelegate<TWriteDelegate>(clientMethodInfo);
				if (twriteDelegate != null)
				{
					return makeHandle(clientMethodInfo, twriteDelegate);
				}
			}
			return default(THandle);
		}

		/// <summary>
		/// Write header common to both static and instance methods, and return writer.
		/// </summary>
		// Token: 0x060011B6 RID: 4534 RVA: 0x000408E3 File Offset: 0x0003EAE3
		protected NetPakWriter GetWriterWithStaticHeader()
		{
			NetPakWriter invokableWriter = NetMessages.GetInvokableWriter();
			invokableWriter.Reset();
			invokableWriter.WriteEnum(EClientMessage.InvokeMethod);
			invokableWriter.WriteBits(this.clientMethodInfo.methodIndex, NetReflection.clientMethodsBitCount);
			return invokableWriter;
		}

		// Token: 0x060011B7 RID: 4535 RVA: 0x00040910 File Offset: 0x0003EB10
		protected void SendAndLoopbackIfLocal(ENetReliability reliability, ITransportConnection transportConnection, NetPakWriter writer)
		{
			writer.Flush();
			if (!Dedicator.IsDedicatedServer)
			{
				this.InvokeLoopback(writer);
				return;
			}
			transportConnection.Send(writer.buffer, (long)writer.writeByteIndex, reliability);
		}

		// Token: 0x060011B8 RID: 4536 RVA: 0x0004093C File Offset: 0x0003EB3C
		protected void SendAndLoopbackIfAnyAreLocal(ENetReliability reliability, List<ITransportConnection> transportConnections, NetPakWriter writer)
		{
			writer.Flush();
			bool flag = false;
			foreach (ITransportConnection transportConnection in transportConnections)
			{
				if (!Dedicator.IsDedicatedServer)
				{
					flag = true;
					break;
				}
				transportConnection.Send(writer.buffer, (long)writer.writeByteIndex, reliability);
			}
			if (flag)
			{
				this.InvokeLoopback(writer);
			}
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x000409B8 File Offset: 0x0003EBB8
		protected void SendAndLoopback(ENetReliability reliability, List<ITransportConnection> transportConnections, NetPakWriter writer)
		{
			writer.Flush();
			foreach (ITransportConnection transportConnection in transportConnections)
			{
				if (!Dedicator.IsDedicatedServer)
				{
					UnturnedLog.error("Local connection {0} passed to SendAndLoopback {1}", new object[]
					{
						transportConnection,
						this
					});
					break;
				}
				transportConnection.Send(writer.buffer, (long)writer.writeByteIndex, reliability);
			}
			this.InvokeLoopback(writer);
		}

		// Token: 0x060011BA RID: 4538 RVA: 0x00040A44 File Offset: 0x0003EC44
		protected ClientMethodHandle(ClientMethodInfo clientMethodInfo)
		{
			this.clientMethodInfo = clientMethodInfo;
		}

		// Token: 0x060011BB RID: 4539 RVA: 0x00040A54 File Offset: 0x0003EC54
		private void InvokeLoopback(NetPakWriter writer)
		{
			NetPakReader invokableReader = NetMessages.GetInvokableReader();
			invokableReader.SetBufferSegmentCopy(writer.buffer, Provider.buffer, writer.writeByteIndex);
			invokableReader.Reset();
			EClientMessage eclientMessage;
			invokableReader.ReadEnum(out eclientMessage);
			uint num;
			invokableReader.ReadBits(NetReflection.clientMethodsBitCount, out num);
			ClientInvocationContext clientInvocationContext = new ClientInvocationContext(ClientInvocationContext.EOrigin.Loopback, invokableReader, this.clientMethodInfo);
			try
			{
				this.clientMethodInfo.readMethod(clientInvocationContext);
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, "Exception invoking {0} by client loopback:", new object[]
				{
					this.clientMethodInfo
				});
				UnturnedLog.error("Additional context loopback calling stack trace:\n" + Environment.StackTrace);
			}
		}

		// Token: 0x040005D8 RID: 1496
		protected ClientMethodInfo clientMethodInfo;
	}
}
