﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using SDG.NetPak;
using SDG.NetTransport;
using Steamworks;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x0200059C RID: 1436
	public class BarricadeManager : SteamCaller
	{
		// Token: 0x1400009F RID: 159
		// (add) Token: 0x06002F77 RID: 12151 RVA: 0x000DA7E8 File Offset: 0x000D89E8
		// (remove) Token: 0x06002F78 RID: 12152 RVA: 0x000DA81C File Offset: 0x000D8A1C
		public static event RepairBarricadeRequestHandler OnRepairRequested;

		// Token: 0x140000A0 RID: 160
		// (add) Token: 0x06002F79 RID: 12153 RVA: 0x000DA850 File Offset: 0x000D8A50
		// (remove) Token: 0x06002F7A RID: 12154 RVA: 0x000DA884 File Offset: 0x000D8A84
		public static event RepairedBarricadeHandler OnRepaired;

		/// <summary>
		/// Exposed for Rocket transition to modules backwards compatibility.
		/// </summary>
		// Token: 0x17000983 RID: 2435
		// (get) Token: 0x06002F7B RID: 12155 RVA: 0x000DA8B7 File Offset: 0x000D8AB7
		public static BarricadeManager instance
		{
			get
			{
				return BarricadeManager.manager;
			}
		}

		// Token: 0x17000984 RID: 2436
		// (get) Token: 0x06002F7C RID: 12156 RVA: 0x000DA8BE File Offset: 0x000D8ABE
		// (set) Token: 0x06002F7D RID: 12157 RVA: 0x000DA8C5 File Offset: 0x000D8AC5
		public static BarricadeRegion[,] regions { get; private set; }

		/// <summary>
		/// Exposed for Rocket transition to modules backwards compatibility.
		/// </summary>
		// Token: 0x17000985 RID: 2437
		// (get) Token: 0x06002F7E RID: 12158 RVA: 0x000DA8CD File Offset: 0x000D8ACD
		// (set) Token: 0x06002F7F RID: 12159 RVA: 0x000DA8D4 File Offset: 0x000D8AD4
		public static BarricadeRegion[,] BarricadeRegions
		{
			get
			{
				return BarricadeManager.regions;
			}
			set
			{
				BarricadeManager.regions = value;
			}
		}

		// Token: 0x17000986 RID: 2438
		// (get) Token: 0x06002F80 RID: 12160 RVA: 0x000DA8DC File Offset: 0x000D8ADC
		// (set) Token: 0x06002F81 RID: 12161 RVA: 0x000DA8E3 File Offset: 0x000D8AE3
		public static IReadOnlyList<VehicleBarricadeRegion> vehicleRegions { get; private set; }

		// Token: 0x17000987 RID: 2439
		// (get) Token: 0x06002F82 RID: 12162 RVA: 0x000DA8EB File Offset: 0x000D8AEB
		[Obsolete("Please update to vehicleRegions instead (this property copies the list)")]
		public static List<BarricadeRegion> plants
		{
			get
			{
				if (BarricadeManager.backwardsCompatVehicleRegions == null)
				{
					BarricadeManager.backwardsCompatVehicleRegions = new List<BarricadeRegion>(BarricadeManager.vehicleRegions);
				}
				return BarricadeManager.backwardsCompatVehicleRegions;
			}
		}

		// Token: 0x06002F83 RID: 12163 RVA: 0x000DA908 File Offset: 0x000D8B08
		public static void getBarricadesInRadius(Vector3 center, float sqrRadius, List<RegionCoordinate> search, List<Transform> result)
		{
			if (BarricadeManager.regions == null)
			{
				return;
			}
			for (int i = 0; i < search.Count; i++)
			{
				RegionCoordinate regionCoordinate = search[i];
				if (BarricadeManager.regions[(int)regionCoordinate.x, (int)regionCoordinate.y] != null)
				{
					foreach (BarricadeDrop barricadeDrop in BarricadeManager.regions[(int)regionCoordinate.x, (int)regionCoordinate.y].drops)
					{
						Transform model = barricadeDrop.model;
						if (!(model == null) && (model.position - center).sqrMagnitude < sqrRadius)
						{
							result.Add(model);
						}
					}
				}
			}
		}

		// Token: 0x06002F84 RID: 12164 RVA: 0x000DA9D8 File Offset: 0x000D8BD8
		public static void getBarricadesInRadius(Vector3 center, float sqrRadius, ushort plant, List<Transform> result)
		{
			if (BarricadeManager.vehicleRegions == null)
			{
				return;
			}
			if ((int)plant >= BarricadeManager.vehicleRegions.Count)
			{
				return;
			}
			foreach (BarricadeDrop barricadeDrop in BarricadeManager.vehicleRegions[(int)plant].drops)
			{
				Transform model = barricadeDrop.model;
				if (!(model == null) && (model.position - center).sqrMagnitude < sqrRadius)
				{
					result.Add(model);
				}
			}
		}

		// Token: 0x06002F85 RID: 12165 RVA: 0x000DAA70 File Offset: 0x000D8C70
		public static void getBarricadesInRadius(Vector3 center, float sqrRadius, List<Transform> result)
		{
			if (BarricadeManager.vehicleRegions == null)
			{
				return;
			}
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.vehicleRegions)
			{
				if (vehicleBarricadeRegion != null && vehicleBarricadeRegion.drops.Count >= 1)
				{
					Transform parent = vehicleBarricadeRegion.parent;
					if (!(parent == null) && (parent.position - center).sqrMagnitude < 65536f)
					{
						foreach (BarricadeDrop barricadeDrop in vehicleBarricadeRegion.drops)
						{
							Transform model = barricadeDrop.model;
							if (!(model == null) && (model.position - center).sqrMagnitude < sqrRadius)
							{
								result.Add(model);
							}
						}
					}
				}
			}
		}

		// Token: 0x06002F86 RID: 12166 RVA: 0x000DAB74 File Offset: 0x000D8D74
		[Obsolete]
		public void tellBarricadeOwnerAndGroup(CSteamID steamID, byte x, byte y, ushort plant, ushort index, ulong newOwner, ulong newGroup)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F87 RID: 12167 RVA: 0x000DAB80 File Offset: 0x000D8D80
		public static void changeOwnerAndGroup(Transform transform, ulong newOwner, ulong newGroup)
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				return;
			}
			BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootTransform(transform);
			if (barricadeDrop == null)
			{
				return;
			}
			BarricadeDrop.SendOwnerAndGroup.InvokeAndLoopback(barricadeDrop.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), newOwner, newGroup);
			barricadeDrop.serversideData.owner = newOwner;
			barricadeDrop.serversideData.group = newGroup;
			BarricadeManager.sendHealthChanged(x, y, plant, barricadeDrop);
		}

		// Token: 0x06002F88 RID: 12168 RVA: 0x000DABEC File Offset: 0x000D8DEC
		public static void transformBarricade(Transform transform, Vector3 point, Quaternion rotation)
		{
			BarricadeDrop barricadeDrop = BarricadeDrop.FindByRootFast(transform);
			if (barricadeDrop == null)
			{
				return;
			}
			BarricadeDrop.SendTransformRequest.Invoke(barricadeDrop.GetNetId(), ENetReliability.Reliable, point, rotation);
		}

		// Token: 0x06002F89 RID: 12169 RVA: 0x000DAC17 File Offset: 0x000D8E17
		[Obsolete]
		public void tellTransformBarricade(CSteamID steamID, byte x, byte y, ushort plant, uint instanceID, Vector3 point, byte angle_x, byte angle_y, byte angle_z)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F8A RID: 12170 RVA: 0x000DAC24 File Offset: 0x000D8E24
		public static bool ServerSetBarricadeTransform(Transform transform, Vector3 position, Quaternion rotation)
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				return false;
			}
			BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootTransform(transform);
			if (barricadeDrop == null)
			{
				return false;
			}
			BarricadeManager.InternalSetBarricadeTransform(x, y, plant, barricadeDrop, position, rotation);
			return true;
		}

		// Token: 0x06002F8B RID: 12171 RVA: 0x000DAC60 File Offset: 0x000D8E60
		internal static void InternalSetBarricadeTransform(byte x, byte y, ushort plant, BarricadeDrop barricade, Vector3 point, Quaternion rotation)
		{
			BarricadeDrop.SendTransform.InvokeAndLoopback(barricade.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), x, y, plant, point, rotation);
		}

		// Token: 0x06002F8C RID: 12172 RVA: 0x000DAC8D File Offset: 0x000D8E8D
		[Obsolete]
		public void askTransformBarricade(CSteamID steamID, byte x, byte y, ushort plant, uint instanceID, Vector3 point, byte angle_x, byte angle_y, byte angle_z)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F8D RID: 12173 RVA: 0x000DAC9C File Offset: 0x000D8E9C
		[Obsolete]
		public static void poseMannequin(Transform transform, byte poseComp)
		{
			InteractableMannequin component = transform.GetComponent<InteractableMannequin>();
			if (component != null)
			{
				component.ClientSetPose(poseComp);
			}
		}

		// Token: 0x06002F8E RID: 12174 RVA: 0x000DACC0 File Offset: 0x000D8EC0
		[Obsolete]
		public void tellPoseMannequin(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte poseComp)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F8F RID: 12175 RVA: 0x000DACCC File Offset: 0x000D8ECC
		public static bool ServerSetMannequinPose(InteractableMannequin mannequin, byte poseComp)
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(mannequin.transform, out x, out y, out plant, out barricadeRegion))
			{
				return false;
			}
			BarricadeManager.InternalSetMannequinPose(mannequin, x, y, plant, poseComp);
			return true;
		}

		// Token: 0x06002F90 RID: 12176 RVA: 0x000DACFB File Offset: 0x000D8EFB
		internal static void InternalSetMannequinPose(InteractableMannequin mannequin, byte x, byte y, ushort plant, byte poseComp)
		{
			InteractableMannequin.SendPose.InvokeAndLoopback(mannequin.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), poseComp);
			mannequin.rebuildState();
		}

		// Token: 0x06002F91 RID: 12177 RVA: 0x000DAD1E File Offset: 0x000D8F1E
		[Obsolete]
		public void askPoseMannequin(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte poseComp)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F92 RID: 12178 RVA: 0x000DAD2A File Offset: 0x000D8F2A
		[Obsolete]
		public void tellUpdateMannequin(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte[] state)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F93 RID: 12179 RVA: 0x000DAD38 File Offset: 0x000D8F38
		[Obsolete]
		public static void updateMannequin(Transform transform, EMannequinUpdateMode updateMode)
		{
			InteractableMannequin component = transform.GetComponent<InteractableMannequin>();
			if (component != null)
			{
				component.ClientRequestUpdate(updateMode);
			}
		}

		// Token: 0x06002F94 RID: 12180 RVA: 0x000DAD5C File Offset: 0x000D8F5C
		[Obsolete]
		public void askUpdateMannequin(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte mode)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F95 RID: 12181 RVA: 0x000DAD68 File Offset: 0x000D8F68
		[Obsolete]
		public static void rotDisplay(Transform transform, byte rotComp)
		{
			InteractableStorage component = transform.GetComponent<InteractableStorage>();
			if (component != null)
			{
				component.ClientSetDisplayRotation(rotComp);
			}
		}

		// Token: 0x06002F96 RID: 12182 RVA: 0x000DAD8C File Offset: 0x000D8F8C
		[Obsolete]
		public void tellRotDisplay(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte rotComp)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F97 RID: 12183 RVA: 0x000DAD98 File Offset: 0x000D8F98
		[Obsolete]
		public void askRotDisplay(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte rotComp)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F98 RID: 12184 RVA: 0x000DADA4 File Offset: 0x000D8FA4
		[Obsolete]
		public void tellBarricadeHealth(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte hp)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F99 RID: 12185 RVA: 0x000DADB0 File Offset: 0x000D8FB0
		public static void salvageBarricade(Transform transform)
		{
			BarricadeDrop barricadeDrop = BarricadeManager.FindBarricadeByRootTransform(transform);
			if (barricadeDrop != null)
			{
				BarricadeDrop.SendSalvageRequest.Invoke(barricadeDrop.GetNetId(), ENetReliability.Reliable);
			}
		}

		// Token: 0x06002F9A RID: 12186 RVA: 0x000DADD8 File Offset: 0x000D8FD8
		[Obsolete]
		public void askSalvageBarricade(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F9B RID: 12187 RVA: 0x000DADE4 File Offset: 0x000D8FE4
		[Obsolete]
		public void tellTank(CSteamID steamID, byte x, byte y, ushort plant, ushort index, ushort amount)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F9C RID: 12188 RVA: 0x000DADF0 File Offset: 0x000D8FF0
		[Obsolete("Moved into InteractableTank.ServerSetAmount")]
		public static void updateTank(Transform transform, ushort amount)
		{
			InteractableTank component = transform.GetComponent<InteractableTank>();
			if (component != null)
			{
				component.ServerSetAmount(amount);
			}
		}

		// Token: 0x06002F9D RID: 12189 RVA: 0x000DAE14 File Offset: 0x000D9014
		[Obsolete]
		public static void updateSign(Transform transform, string newText)
		{
			InteractableSign component = transform.GetComponent<InteractableSign>();
			if (component != null)
			{
				component.ClientSetText(newText);
			}
		}

		// Token: 0x06002F9E RID: 12190 RVA: 0x000DAE38 File Offset: 0x000D9038
		[Obsolete]
		public void tellUpdateSign(CSteamID steamID, byte x, byte y, ushort plant, ushort index, string newText)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002F9F RID: 12191 RVA: 0x000DAE44 File Offset: 0x000D9044
		public static bool ServerSetSignText(InteractableSign sign, string newText)
		{
			if (sign == null)
			{
				throw new ArgumentNullException("sign");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(sign.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			string text = sign.trimText(newText);
			if (!sign.isTextValid(text))
			{
				return false;
			}
			BarricadeManager.ServerSetSignTextInternal(sign, region, x, y, plant, text);
			return true;
		}

		// Token: 0x06002FA0 RID: 12192 RVA: 0x000DAEA0 File Offset: 0x000D90A0
		internal static void ServerSetSignTextInternal(InteractableSign sign, BarricadeRegion region, byte x, byte y, ushort plant, string trimmedText)
		{
			if (trimmedText == null)
			{
				trimmedText = string.Empty;
			}
			InteractableSign.SendChangeText.InvokeAndLoopback(sign.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), trimmedText);
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(sign.transform);
			Array state = barricadeDrop.serversideData.barricade.state;
			byte[] bytes = Encoding.UTF8.GetBytes(trimmedText);
			byte[] array = new byte[17 + bytes.Length];
			Buffer.BlockCopy(state, 0, array, 0, 16);
			array[16] = (byte)bytes.Length;
			if (bytes.Length != 0)
			{
				Buffer.BlockCopy(bytes, 0, array, 17, bytes.Length);
			}
			barricadeDrop.serversideData.barricade.state = array;
		}

		// Token: 0x06002FA1 RID: 12193 RVA: 0x000DAF3C File Offset: 0x000D913C
		[Obsolete]
		public void askUpdateSign(CSteamID steamID, byte x, byte y, ushort plant, ushort index, string newText)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FA2 RID: 12194 RVA: 0x000DAF48 File Offset: 0x000D9148
		[Obsolete]
		public static void updateStereoTrack(Transform transform, Guid newTrack)
		{
			InteractableStereo component = transform.GetComponent<InteractableStereo>();
			if (component != null)
			{
				component.ClientSetTrack(newTrack);
			}
		}

		// Token: 0x06002FA3 RID: 12195 RVA: 0x000DAF6C File Offset: 0x000D916C
		public static bool ServerSetStereoTrack(InteractableStereo stereo, Guid track)
		{
			if (stereo == null)
			{
				throw new ArgumentNullException("stereo");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(stereo.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetStereoTrackInternal(stereo, x, y, plant, region, track);
			return true;
		}

		// Token: 0x06002FA4 RID: 12196 RVA: 0x000DAFB0 File Offset: 0x000D91B0
		internal static void ServerSetStereoTrackInternal(InteractableStereo stereo, byte x, byte y, ushort plant, BarricadeRegion region, Guid track)
		{
			InteractableStereo.SendTrack.InvokeAndLoopback(stereo.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), track);
			byte[] state = region.FindBarricadeByRootFast(stereo.transform).serversideData.barricade.state;
			GuidBuffer guidBuffer = new GuidBuffer(track);
			guidBuffer.Write(state, 0);
		}

		// Token: 0x06002FA5 RID: 12197 RVA: 0x000DB007 File Offset: 0x000D9207
		[Obsolete]
		public void tellUpdateStereoTrack(CSteamID steamID, byte x, byte y, ushort plant, ushort index, Guid newTrack)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FA6 RID: 12198 RVA: 0x000DB013 File Offset: 0x000D9213
		[Obsolete]
		public void askUpdateStereoTrack(CSteamID steamID, byte x, byte y, ushort plant, ushort index, Guid newTrack)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FA7 RID: 12199 RVA: 0x000DB020 File Offset: 0x000D9220
		[Obsolete]
		public static void updateStereoVolume(Transform transform, byte newVolume)
		{
			InteractableStereo component = transform.GetComponent<InteractableStereo>();
			if (component != null)
			{
				component.ClientSetVolume(newVolume);
			}
		}

		// Token: 0x06002FA8 RID: 12200 RVA: 0x000DB044 File Offset: 0x000D9244
		[Obsolete]
		public void tellUpdateStereoVolume(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte newVolume)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FA9 RID: 12201 RVA: 0x000DB050 File Offset: 0x000D9250
		[Obsolete]
		public void askUpdateStereoVolume(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte newVolume)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FAA RID: 12202 RVA: 0x000DB05C File Offset: 0x000D925C
		[Obsolete]
		public static void transferLibrary(Transform transform, byte transaction, uint delta)
		{
			InteractableLibrary component = transform.GetComponent<InteractableLibrary>();
			if (component != null)
			{
				component.ClientTransfer(transaction, delta);
			}
		}

		// Token: 0x06002FAB RID: 12203 RVA: 0x000DB081 File Offset: 0x000D9281
		[Obsolete]
		public void tellTransferLibrary(CSteamID steamID, byte x, byte y, ushort plant, ushort index, uint newAmount)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FAC RID: 12204 RVA: 0x000DB08D File Offset: 0x000D928D
		[Obsolete]
		public void askTransferLibrary(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte transaction, uint delta)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FAD RID: 12205 RVA: 0x000DB09C File Offset: 0x000D929C
		[Obsolete]
		public static void toggleSafezone(Transform transform)
		{
			InteractableSafezone component = transform.GetComponent<InteractableSafezone>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FAE RID: 12206 RVA: 0x000DB0C0 File Offset: 0x000D92C0
		public static bool ServerSetSafezonePowered(InteractableSafezone safezone, bool isPowered)
		{
			if (safezone == null)
			{
				throw new ArgumentNullException("safezone");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(safezone.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetSafezonePoweredInternal(safezone, x, y, plant, region, isPowered);
			return true;
		}

		// Token: 0x06002FAF RID: 12207 RVA: 0x000DB104 File Offset: 0x000D9304
		internal static void ServerSetSafezonePoweredInternal(InteractableSafezone safezone, byte x, byte y, ushort plant, BarricadeRegion region, bool isPowered)
		{
			InteractableSafezone.SendPowered.InvokeAndLoopback(safezone.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isPowered);
			region.FindBarricadeByRootFast(safezone.transform).serversideData.barricade.state[0] = (safezone.isPowered ? 1 : 0);
		}

		// Token: 0x06002FB0 RID: 12208 RVA: 0x000DB157 File Offset: 0x000D9357
		[Obsolete]
		public void tellToggleSafezone(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isPowered)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FB1 RID: 12209 RVA: 0x000DB163 File Offset: 0x000D9363
		[Obsolete]
		public void askToggleSafezone(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FB2 RID: 12210 RVA: 0x000DB170 File Offset: 0x000D9370
		[Obsolete]
		public static void toggleOxygenator(Transform transform)
		{
			InteractableOxygenator component = transform.GetComponent<InteractableOxygenator>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FB3 RID: 12211 RVA: 0x000DB194 File Offset: 0x000D9394
		public static bool ServerSetOxygenatorPowered(InteractableOxygenator oxygenator, bool isPowered)
		{
			if (oxygenator == null)
			{
				throw new ArgumentNullException("oxygenator");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(oxygenator.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetOxygenatorPoweredInternal(oxygenator, x, y, plant, region, isPowered);
			return true;
		}

		// Token: 0x06002FB4 RID: 12212 RVA: 0x000DB1D8 File Offset: 0x000D93D8
		internal static void ServerSetOxygenatorPoweredInternal(InteractableOxygenator oxygenator, byte x, byte y, ushort plant, BarricadeRegion region, bool isPowered)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(oxygenator.transform);
			InteractableOxygenator.SendPowered.InvokeAndLoopback(oxygenator.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isPowered);
			barricadeDrop.serversideData.barricade.state[0] = (oxygenator.isPowered ? 1 : 0);
		}

		// Token: 0x06002FB5 RID: 12213 RVA: 0x000DB22B File Offset: 0x000D942B
		[Obsolete]
		public void tellToggleOxygenator(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isPowered)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FB6 RID: 12214 RVA: 0x000DB237 File Offset: 0x000D9437
		[Obsolete]
		public void askToggleOxygenator(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FB7 RID: 12215 RVA: 0x000DB244 File Offset: 0x000D9444
		[Obsolete]
		public static void toggleSpot(Transform transform)
		{
			InteractableSpot component = transform.GetComponent<InteractableSpot>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FB8 RID: 12216 RVA: 0x000DB268 File Offset: 0x000D9468
		public static bool ServerSetSpotPowered(InteractableSpot spot, bool isPowered)
		{
			if (spot == null)
			{
				throw new ArgumentNullException("spot");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(spot.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetSpotPoweredInternal(spot, x, y, plant, region, isPowered);
			return true;
		}

		// Token: 0x06002FB9 RID: 12217 RVA: 0x000DB2AC File Offset: 0x000D94AC
		internal static void ServerSetSpotPoweredInternal(InteractableSpot spot, byte x, byte y, ushort plant, BarricadeRegion region, bool isPowered)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(spot.transform);
			InteractableSpot.SendPowered.InvokeAndLoopback(spot.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isPowered);
			barricadeDrop.serversideData.barricade.state[0] = (spot.isPowered ? 1 : 0);
		}

		// Token: 0x06002FBA RID: 12218 RVA: 0x000DB2FF File Offset: 0x000D94FF
		[Obsolete]
		public void tellToggleSpot(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isPowered)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FBB RID: 12219 RVA: 0x000DB30B File Offset: 0x000D950B
		[Obsolete]
		public void askToggleSpot(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FBC RID: 12220 RVA: 0x000DB318 File Offset: 0x000D9518
		public static void sendFuel(Transform transform, ushort fuel)
		{
			InteractableGenerator component = transform.GetComponent<InteractableGenerator>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				InteractableGenerator.SendFuel.InvokeAndLoopback(component.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), fuel);
			}
		}

		// Token: 0x06002FBD RID: 12221 RVA: 0x000DB35F File Offset: 0x000D955F
		[Obsolete]
		public void tellFuel(CSteamID steamID, byte x, byte y, ushort plant, ushort index, ushort fuel)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FBE RID: 12222 RVA: 0x000DB36C File Offset: 0x000D956C
		[Obsolete]
		public static void toggleGenerator(Transform transform)
		{
			InteractableGenerator component = transform.GetComponent<InteractableGenerator>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FBF RID: 12223 RVA: 0x000DB390 File Offset: 0x000D9590
		public static bool ServerSetGeneratorPowered(InteractableGenerator generator, bool isPowered)
		{
			if (generator == null)
			{
				throw new ArgumentNullException("generator");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(generator.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetGeneratorPoweredInternal(generator, x, y, plant, region, isPowered);
			return true;
		}

		// Token: 0x06002FC0 RID: 12224 RVA: 0x000DB3D4 File Offset: 0x000D95D4
		internal static void ServerSetGeneratorPoweredInternal(InteractableGenerator generator, byte x, byte y, ushort plant, BarricadeRegion region, bool isPowered)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(generator.transform);
			InteractableGenerator.SendPowered.InvokeAndLoopback(generator.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isPowered);
			barricadeDrop.serversideData.barricade.state[0] = (generator.isPowered ? 1 : 0);
		}

		// Token: 0x06002FC1 RID: 12225 RVA: 0x000DB427 File Offset: 0x000D9627
		[Obsolete]
		public void tellToggleGenerator(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isPowered)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FC2 RID: 12226 RVA: 0x000DB433 File Offset: 0x000D9633
		[Obsolete]
		public void askToggleGenerator(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FC3 RID: 12227 RVA: 0x000DB440 File Offset: 0x000D9640
		[Obsolete]
		public static void toggleFire(Transform transform)
		{
			InteractableFire component = transform.GetComponent<InteractableFire>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FC4 RID: 12228 RVA: 0x000DB464 File Offset: 0x000D9664
		public static bool ServerSetFireLit(InteractableFire fire, bool isLit)
		{
			if (fire == null)
			{
				throw new ArgumentNullException("fire");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(fire.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetFireLitInternal(fire, x, y, plant, region, isLit);
			return true;
		}

		// Token: 0x06002FC5 RID: 12229 RVA: 0x000DB4A8 File Offset: 0x000D96A8
		internal static void ServerSetFireLitInternal(InteractableFire fire, byte x, byte y, ushort plant, BarricadeRegion region, bool isLit)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(fire.transform);
			InteractableFire.SendLit.InvokeAndLoopback(fire.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isLit);
			barricadeDrop.serversideData.barricade.state[0] = (fire.isLit ? 1 : 0);
		}

		// Token: 0x06002FC6 RID: 12230 RVA: 0x000DB4FB File Offset: 0x000D96FB
		[Obsolete]
		public void tellToggleFire(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isLit)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FC7 RID: 12231 RVA: 0x000DB507 File Offset: 0x000D9707
		[Obsolete]
		public void askToggleFire(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FC8 RID: 12232 RVA: 0x000DB514 File Offset: 0x000D9714
		[Obsolete]
		public static void toggleOven(Transform transform)
		{
			InteractableOven component = transform.GetComponent<InteractableOven>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FC9 RID: 12233 RVA: 0x000DB538 File Offset: 0x000D9738
		public static bool ServerSetOvenLit(InteractableOven oven, bool isLit)
		{
			if (oven == null)
			{
				throw new ArgumentNullException("oven");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(oven.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetOvenLitInternal(oven, x, y, plant, region, isLit);
			return true;
		}

		// Token: 0x06002FCA RID: 12234 RVA: 0x000DB57C File Offset: 0x000D977C
		internal static void ServerSetOvenLitInternal(InteractableOven oven, byte x, byte y, ushort plant, BarricadeRegion region, bool isLit)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(oven.transform);
			InteractableOven.SendLit.InvokeAndLoopback(oven.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isLit);
			barricadeDrop.serversideData.barricade.state[0] = (oven.isLit ? 1 : 0);
		}

		// Token: 0x06002FCB RID: 12235 RVA: 0x000DB5CF File Offset: 0x000D97CF
		[Obsolete]
		public void tellToggleOven(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isLit)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FCC RID: 12236 RVA: 0x000DB5DB File Offset: 0x000D97DB
		[Obsolete]
		public void askToggleOven(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FCD RID: 12237 RVA: 0x000DB5E8 File Offset: 0x000D97E8
		[Obsolete]
		public static void farm(Transform transform)
		{
			InteractableFarm component = transform.GetComponent<InteractableFarm>();
			if (component != null)
			{
				component.ClientHarvest();
			}
		}

		// Token: 0x06002FCE RID: 12238 RVA: 0x000DB60B File Offset: 0x000D980B
		[Obsolete]
		public void tellFarm(CSteamID steamID, byte x, byte y, ushort plant, ushort index, uint planted)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FCF RID: 12239 RVA: 0x000DB617 File Offset: 0x000D9817
		[Obsolete]
		public void askFarm(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FD0 RID: 12240 RVA: 0x000DB624 File Offset: 0x000D9824
		public static void updateFarm(Transform transform, uint planted, bool shouldSend)
		{
			InteractableFarm component = transform.GetComponent<InteractableFarm>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				if (shouldSend)
				{
					InteractableFarm.SendPlanted.InvokeAndLoopback(component.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), planted);
				}
				BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootFast(transform);
				BitConverter.GetBytes(planted).CopyTo(barricadeDrop.serversideData.barricade.state, 0);
			}
		}

		// Token: 0x06002FD1 RID: 12241 RVA: 0x000DB695 File Offset: 0x000D9895
		[Obsolete]
		public void tellOil(CSteamID steamID, byte x, byte y, ushort plant, ushort index, ushort fuel)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FD2 RID: 12242 RVA: 0x000DB6A4 File Offset: 0x000D98A4
		public static void sendOil(Transform transform, ushort fuel)
		{
			InteractableOil component = transform.GetComponent<InteractableOil>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				InteractableOil.SendFuel.InvokeAndLoopback(component.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), fuel);
			}
		}

		// Token: 0x06002FD3 RID: 12243 RVA: 0x000DB6EB File Offset: 0x000D98EB
		[Obsolete]
		public void tellRainBarrel(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isFull)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FD4 RID: 12244 RVA: 0x000DB6F8 File Offset: 0x000D98F8
		public static void updateRainBarrel(Transform transform, bool isFull, bool shouldSend)
		{
			InteractableRainBarrel component = transform.GetComponent<InteractableRainBarrel>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				if (shouldSend)
				{
					InteractableRainBarrel.SendFull.InvokeAndLoopback(component.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isFull);
				}
				barricadeRegion.FindBarricadeByRootFast(transform).serversideData.barricade.state[0] = (isFull ? 1 : 0);
			}
		}

		// Token: 0x06002FD5 RID: 12245 RVA: 0x000DB764 File Offset: 0x000D9964
		public static void sendStorageDisplay(Transform transform, Item item, ushort skin, ushort mythic, string tags, string dynamicProps)
		{
			InteractableStorage component = transform.GetComponent<InteractableStorage>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				ushort arg;
				byte arg2;
				byte[] arg3;
				if (item != null)
				{
					arg = item.id;
					arg2 = item.quality;
					arg3 = item.state;
				}
				else
				{
					arg = 0;
					arg2 = 0;
					arg3 = new byte[0];
				}
				InteractableStorage.SendDisplay.Invoke(component.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherClientConnections(x, y, plant), arg, arg2, arg3, skin, mythic, tags, dynamicProps);
			}
		}

		// Token: 0x06002FD6 RID: 12246 RVA: 0x000DB7E1 File Offset: 0x000D99E1
		[Obsolete]
		public void tellStorageDisplay(CSteamID steamID, byte x, byte y, ushort plant, ushort index, ushort id, byte quality, byte[] state, ushort skin, ushort mythic, string tags, string dynamicProps)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FD7 RID: 12247 RVA: 0x000DB7F0 File Offset: 0x000D99F0
		[Obsolete]
		public static void storeStorage(Transform transform, bool quickGrab)
		{
			InteractableStorage component = transform.GetComponent<InteractableStorage>();
			if (component != null)
			{
				component.ClientInteract(quickGrab);
			}
		}

		// Token: 0x06002FD8 RID: 12248 RVA: 0x000DB814 File Offset: 0x000D9A14
		[Obsolete]
		public void askStoreStorage(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool quickGrab)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FD9 RID: 12249 RVA: 0x000DB820 File Offset: 0x000D9A20
		[Obsolete]
		public static void toggleDoor(Transform transform)
		{
			InteractableDoor component = transform.GetComponent<InteractableDoor>();
			if (component != null)
			{
				component.ClientToggle();
			}
		}

		// Token: 0x06002FDA RID: 12250 RVA: 0x000DB843 File Offset: 0x000D9A43
		[Obsolete]
		public void tellToggleDoor(CSteamID steamID, byte x, byte y, ushort plant, ushort index, bool isOpen)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FDB RID: 12251 RVA: 0x000DB850 File Offset: 0x000D9A50
		public static bool ServerSetDoorOpen(InteractableDoor door, bool isOpen)
		{
			if (door == null)
			{
				throw new ArgumentNullException("door");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(door.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetDoorOpenInternal(door, x, y, plant, region, isOpen);
			return true;
		}

		// Token: 0x06002FDC RID: 12252 RVA: 0x000DB894 File Offset: 0x000D9A94
		internal static void ServerSetDoorOpenInternal(InteractableDoor door, byte x, byte y, ushort plant, BarricadeRegion region, bool isOpen)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(door.transform);
			InteractableDoor.SendOpen.InvokeAndLoopback(door.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), isOpen);
			barricadeDrop.serversideData.barricade.state[16] = (isOpen ? 1 : 0);
		}

		// Token: 0x06002FDD RID: 12253 RVA: 0x000DB8E4 File Offset: 0x000D9AE4
		[Obsolete]
		public void askToggleDoor(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FDE RID: 12254 RVA: 0x000DB8F0 File Offset: 0x000D9AF0
		private static bool tryGetBedInRegion(BarricadeRegion region, CSteamID owner, ref Vector3 point, ref byte angle)
		{
			foreach (BarricadeDrop barricadeDrop in region.drops)
			{
				if (barricadeDrop.serversideData.barricade.state.Length != 0)
				{
					InteractableBed interactableBed = barricadeDrop.interactable as InteractableBed;
					if (interactableBed != null && interactableBed.owner == owner && Level.checkSafeIncludingClipVolumes(interactableBed.transform.position))
					{
						point = interactableBed.transform.position;
						float modelYaw = HousingConnections.GetModelYaw(interactableBed.transform);
						angle = MeasurementTool.angleToByte(modelYaw + 90f);
						int num = Physics.OverlapCapsuleNonAlloc(point + new Vector3(0f, PlayerStance.RADIUS, 0f), point + new Vector3(0f, 2.5f - PlayerStance.RADIUS, 0f), PlayerStance.RADIUS, BarricadeManager.checkColliders, RayMasks.BLOCK_STANCE, QueryTriggerInteraction.Ignore);
						for (int i = 0; i < num; i++)
						{
							if (BarricadeManager.checkColliders[i].gameObject != interactableBed.gameObject)
							{
								return false;
							}
						}
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06002FDF RID: 12255 RVA: 0x000DBA64 File Offset: 0x000D9C64
		public static bool tryGetBed(CSteamID owner, out Vector3 point, out byte angle)
		{
			point = Vector3.zero;
			angle = 0;
			for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
			{
				for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
				{
					if (BarricadeManager.tryGetBedInRegion(BarricadeManager.regions[(int)b, (int)b2], owner, ref point, ref angle))
					{
						return true;
					}
				}
			}
			ushort num = 0;
			while ((int)num < BarricadeManager.vehicleRegions.Count)
			{
				if (BarricadeManager.tryGetBedInRegion(BarricadeManager.vehicleRegions[(int)num], owner, ref point, ref angle))
				{
					return true;
				}
				num += 1;
			}
			return false;
		}

		// Token: 0x06002FE0 RID: 12256 RVA: 0x000DBAE8 File Offset: 0x000D9CE8
		private static bool UnclaimBedsInRegion(CSteamID owner, BarricadeRegion region, byte x, byte y, ushort plant)
		{
			ushort num = 0;
			while ((int)num < region.drops.Count)
			{
				BarricadeDrop barricadeDrop = region.drops[(int)num];
				if (barricadeDrop.serversideData.barricade.state.Length != 0)
				{
					InteractableBed interactableBed = barricadeDrop.interactable as InteractableBed;
					if (interactableBed != null && interactableBed.owner == owner)
					{
						InteractableBed.SendClaim.InvokeAndLoopback(interactableBed.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), CSteamID.Nil);
						BitConverter.GetBytes(interactableBed.owner.m_SteamID).CopyTo(barricadeDrop.serversideData.barricade.state, 0);
						return true;
					}
				}
				num += 1;
			}
			return false;
		}

		// Token: 0x06002FE1 RID: 12257 RVA: 0x000DBBA0 File Offset: 0x000D9DA0
		public static void unclaimBeds(CSteamID owner)
		{
			for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
			{
				for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
				{
					BarricadeRegion region = BarricadeManager.regions[(int)b, (int)b2];
					if (BarricadeManager.UnclaimBedsInRegion(owner, region, b, b2, 65535))
					{
						return;
					}
				}
			}
			ushort num = 0;
			while ((int)num < BarricadeManager.vehicleRegions.Count)
			{
				BarricadeRegion region2 = BarricadeManager.vehicleRegions[(int)num];
				if (BarricadeManager.UnclaimBedsInRegion(owner, region2, 255, 255, num))
				{
					return;
				}
				num += 1;
			}
		}

		// Token: 0x06002FE2 RID: 12258 RVA: 0x000DBC28 File Offset: 0x000D9E28
		[Obsolete]
		public static void claimBed(Transform transform)
		{
			InteractableBed component = transform.GetComponent<InteractableBed>();
			if (component != null)
			{
				component.ClientClaim();
			}
		}

		// Token: 0x06002FE3 RID: 12259 RVA: 0x000DBC4B File Offset: 0x000D9E4B
		[Obsolete]
		public void tellClaimBed(CSteamID steamID, byte x, byte y, ushort plant, ushort index, CSteamID owner)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FE4 RID: 12260 RVA: 0x000DBC57 File Offset: 0x000D9E57
		[Obsolete]
		public void askClaimBed(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FE5 RID: 12261 RVA: 0x000DBC64 File Offset: 0x000D9E64
		public static bool ServerUnclaimBed(InteractableBed bed)
		{
			if (bed == null)
			{
				throw new ArgumentNullException("bed");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(bed.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.ServerSetBedOwnerInternal(bed, x, y, plant, region, CSteamID.Nil);
			return true;
		}

		// Token: 0x06002FE6 RID: 12262 RVA: 0x000DBCAC File Offset: 0x000D9EAC
		public static bool ServerClaimBedForPlayer(InteractableBed bed, Player player)
		{
			if (bed == null)
			{
				throw new ArgumentNullException("bed");
			}
			if (player == null)
			{
				throw new ArgumentNullException("player");
			}
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion region;
			if (!BarricadeManager.tryGetRegion(bed.transform, out x, out y, out plant, out region))
			{
				return false;
			}
			BarricadeManager.unclaimBeds(player.channel.owner.playerID.steamID);
			BarricadeManager.ServerSetBedOwnerInternal(bed, x, y, plant, region, player.channel.owner.playerID.steamID);
			return true;
		}

		// Token: 0x06002FE7 RID: 12263 RVA: 0x000DBD34 File Offset: 0x000D9F34
		internal static void ServerSetBedOwnerInternal(InteractableBed bed, byte x, byte y, ushort plant, BarricadeRegion region, CSteamID steamID)
		{
			BarricadeDrop barricadeDrop = region.FindBarricadeByRootFast(bed.transform);
			InteractableBed.SendClaim.InvokeAndLoopback(bed.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), steamID);
			BitConverter.GetBytes(bed.owner.m_SteamID).CopyTo(barricadeDrop.serversideData.barricade.state, 0);
		}

		// Token: 0x06002FE8 RID: 12264 RVA: 0x000DBD90 File Offset: 0x000D9F90
		[Obsolete]
		public void tellShootSentry(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FE9 RID: 12265 RVA: 0x000DBD9C File Offset: 0x000D9F9C
		public static void sendShootSentry(Transform transform)
		{
			InteractableSentry component = transform.GetComponent<InteractableSentry>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				InteractableSentry.SendShoot.InvokeAndLoopback(component.GetNetId(), ENetReliability.Unreliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant));
			}
		}

		// Token: 0x06002FEA RID: 12266 RVA: 0x000DBDE2 File Offset: 0x000D9FE2
		[Obsolete]
		public void tellAlertSentry(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte yaw, byte pitch)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		// Token: 0x06002FEB RID: 12267 RVA: 0x000DBDF0 File Offset: 0x000D9FF0
		public static void sendAlertSentry(Transform transform, float yaw, float pitch)
		{
			InteractableSentry component = transform.GetComponent<InteractableSentry>();
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (component != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				InteractableSentry.SendAlert.InvokeAndLoopback(component.GetNetId(), ENetReliability.Unreliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), MeasurementTool.angleToByte(yaw), MeasurementTool.angleToByte(pitch));
			}
		}

		// Token: 0x06002FEC RID: 12268 RVA: 0x000DBE44 File Offset: 0x000DA044
		public static void damage(Transform transform, float damage, float times, bool armor, CSteamID instigatorSteamID = default(CSteamID), EDamageOrigin damageOrigin = EDamageOrigin.Unknown)
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				return;
			}
			BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootTransform(transform);
			if (barricadeDrop == null)
			{
				return;
			}
			if (!barricadeDrop.serversideData.barricade.isDead)
			{
				ItemBarricadeAsset asset = barricadeDrop.asset;
				if (asset == null)
				{
					return;
				}
				if (!asset.canBeDamaged)
				{
					return;
				}
				if (armor)
				{
					times *= Provider.modeConfigData.Barricades.getArmorMultiplier(asset.armorTier);
				}
				ushort num = (ushort)(damage * times);
				bool flag = true;
				DamageBarricadeRequestHandler damageBarricadeRequestHandler = BarricadeManager.onDamageBarricadeRequested;
				if (damageBarricadeRequestHandler != null)
				{
					damageBarricadeRequestHandler(instigatorSteamID, transform, ref num, ref flag, damageOrigin);
				}
				if (!flag || num < 1)
				{
					return;
				}
				barricadeDrop.serversideData.barricade.askDamage(num);
				if (barricadeDrop.serversideData.barricade.isDead)
				{
					BarricadeManager.PlayBarricadeExplosionEffect(barricadeDrop);
					asset.SpawnItemDropsOnDestroy(transform.position);
					BarricadeManager.destroyBarricade(barricadeDrop, x, y, plant);
					return;
				}
				BarricadeManager.sendHealthChanged(x, y, plant, barricadeDrop);
			}
		}

		// Token: 0x06002FED RID: 12269 RVA: 0x000DBF38 File Offset: 0x000DA138
		private static void PlayBarricadeExplosionEffect(BarricadeDrop barricade)
		{
			EffectAsset effectAsset;
			if (barricade == null)
			{
				effectAsset = null;
			}
			else
			{
				ItemBarricadeAsset asset = barricade.asset;
				effectAsset = ((asset != null) ? asset.FindExplosionEffectAsset() : null);
			}
			EffectAsset effectAsset2 = effectAsset;
			if (effectAsset2 != null)
			{
				if (((barricade != null) ? barricade.model : null) == null)
				{
					return;
				}
				TriggerEffectParameters parameters = new TriggerEffectParameters(effectAsset2);
				if (barricade.asset.ExplosionEffectFlags.HasFlag(EPlaceableExplosionEffectFlags.CopyModelPosition))
				{
					parameters.position = barricade.model.position;
				}
				else
				{
					parameters.position = barricade.model.position + Vector3.down * barricade.asset.offset;
				}
				if (barricade.asset.ExplosionEffectFlags.HasFlag(EPlaceableExplosionEffectFlags.CopyModelRotation))
				{
					parameters.SetRotation(barricade.model.rotation);
				}
				parameters.relevantDistance = EffectManager.MEDIUM;
				parameters.reliable = true;
				EffectManager.triggerEffect(parameters);
			}
		}

		// Token: 0x06002FEE RID: 12270 RVA: 0x000DC027 File Offset: 0x000DA227
		[Obsolete("Please replace the methods which take an index")]
		public static void destroyBarricade(BarricadeRegion region, byte x, byte y, ushort plant, ushort index)
		{
			BarricadeManager.destroyBarricade(region.drops[(int)index], x, y, plant);
		}

		/// <summary>
		/// Remove barricade instance on server and client.
		/// </summary>
		// Token: 0x06002FEF RID: 12271 RVA: 0x000DC040 File Offset: 0x000DA240
		public static void destroyBarricade(BarricadeDrop barricade, byte x, byte y, ushort plant)
		{
			BarricadeRegion barricadeRegion;
			if (BarricadeManager.tryGetRegion(x, y, plant, out barricadeRegion))
			{
				barricadeRegion.barricades.Remove(barricade.serversideData);
				BarricadeManager.SendDestroyBarricade.InvokeAndLoopback(ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), barricade.GetNetId());
			}
		}

		/// <summary>
		/// Used by ownership change and damaged event to tell relevant clients the new health.
		/// </summary>
		// Token: 0x06002FF0 RID: 12272 RVA: 0x000DC084 File Offset: 0x000DA284
		private static void sendHealthChanged(byte x, byte y, ushort plant, BarricadeDrop barricade)
		{
			if (plant == 65535)
			{
				BarricadeDrop.SendHealth.Invoke(barricade.GetNetId(), ENetReliability.Unreliable, Provider.GatherClientConnectionsMatchingPredicate((SteamPlayer client) => client.player != null && Regions.checkArea(x, y, client.player.movement.region_x, client.player.movement.region_y, BarricadeManager.BARRICADE_REGIONS) && OwnershipTool.checkToggle(client.playerID.steamID, barricade.serversideData.owner, client.player.quests.groupID, barricade.serversideData.group)), (byte)((float)barricade.serversideData.barricade.health / (float)barricade.serversideData.barricade.asset.health * 100f));
				return;
			}
			BarricadeDrop.SendHealth.Invoke(barricade.GetNetId(), ENetReliability.Unreliable, Provider.GatherClientConnectionsMatchingPredicate((SteamPlayer client) => OwnershipTool.checkToggle(client.playerID.steamID, barricade.serversideData.owner, client.player.quests.groupID, barricade.serversideData.group)), (byte)((float)barricade.serversideData.barricade.health / (float)barricade.serversideData.barricade.asset.health * 100f));
		}

		// Token: 0x06002FF1 RID: 12273 RVA: 0x000DC178 File Offset: 0x000DA378
		public static void repair(Transform transform, float damage, float times)
		{
			BarricadeManager.repair(transform, damage, times, default(CSteamID));
		}

		// Token: 0x06002FF2 RID: 12274 RVA: 0x000DC198 File Offset: 0x000DA398
		public static void repair(Transform transform, float damage, float times, CSteamID instigatorSteamID = default(CSteamID))
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				return;
			}
			BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootTransform(transform);
			if (barricadeDrop == null)
			{
				return;
			}
			if (!barricadeDrop.serversideData.barricade.isDead && !barricadeDrop.serversideData.barricade.isRepaired)
			{
				float value = damage * times;
				bool flag = true;
				RepairBarricadeRequestHandler onRepairRequested = BarricadeManager.OnRepairRequested;
				if (onRepairRequested != null)
				{
					onRepairRequested(instigatorSteamID, transform, ref value, ref flag);
				}
				ushort num = MathfEx.RoundAndClampToUShort(value);
				if (!flag || num < 1)
				{
					return;
				}
				barricadeDrop.serversideData.barricade.askRepair(num);
				BarricadeManager.sendHealthChanged(x, y, plant, barricadeDrop);
				RepairedBarricadeHandler onRepaired = BarricadeManager.OnRepaired;
				if (onRepaired == null)
				{
					return;
				}
				onRepaired(instigatorSteamID, transform, (float)num);
			}
		}

		/// <summary>
		/// Legacy function for UseableBarricade.
		/// </summary>
		// Token: 0x06002FF3 RID: 12275 RVA: 0x000DC24C File Offset: 0x000DA44C
		public static Transform dropBarricade(Barricade barricade, Transform hit, Vector3 point, float angle_x, float angle_y, float angle_z, ulong owner, ulong group)
		{
			if (barricade.asset == null)
			{
				return null;
			}
			bool flag = true;
			DeployBarricadeRequestHandler deployBarricadeRequestHandler = BarricadeManager.onDeployBarricadeRequested;
			if (deployBarricadeRequestHandler != null)
			{
				deployBarricadeRequestHandler(barricade, barricade.asset, hit, ref point, ref angle_x, ref angle_y, ref angle_z, ref owner, ref group, ref flag);
			}
			if (!flag)
			{
				return null;
			}
			Quaternion rotation = BarricadeManager.getRotation(barricade.asset, angle_x, angle_y, angle_z);
			if (hit != null && hit.transform.CompareTag("Vehicle"))
			{
				return BarricadeManager.dropPlantedBarricade(hit, barricade, point, rotation, owner, group);
			}
			return BarricadeManager.dropNonPlantedBarricade(barricade, point, rotation, owner, group);
		}

		/// <summary>
		/// Common code between dropping barricade onto vehicle or into world.
		/// </summary>
		// Token: 0x06002FF4 RID: 12276 RVA: 0x000DC2D8 File Offset: 0x000DA4D8
		private static Transform dropBarricadeIntoRegionInternal(BarricadeRegion region, Barricade barricade, Vector3 point, Quaternion rotation, ulong owner, ulong group)
		{
			uint newInstanceID = BarricadeManager.instanceCount += 1U;
			BarricadeData barricadeData = new BarricadeData(barricade, point, rotation, owner, group, Provider.time, newInstanceID);
			NetId netId = NetIdRegistry.ClaimBlock(3U);
			Transform transform = BarricadeManager.manager.spawnBarricade(region, barricade.asset.GUID, barricade.state, barricadeData.point, rotation, 100, barricadeData.owner, barricadeData.group, netId);
			if (transform != null)
			{
				region.drops.GetTail<BarricadeDrop>().serversideData = barricadeData;
				region.barricades.Add(barricadeData);
			}
			return transform;
		}

		/// <summary>
		/// Spawn a new barricade attached to a vehicle and replicate it.
		/// </summary>
		// Token: 0x06002FF5 RID: 12277 RVA: 0x000DC368 File Offset: 0x000DA568
		public static Transform dropPlantedBarricade(Transform parent, Barricade barricade, Vector3 point, Quaternion rotation, ulong owner, ulong group)
		{
			VehicleBarricadeRegion vehicleBarricadeRegion = BarricadeManager.FindVehicleRegionByTransform(parent);
			if (vehicleBarricadeRegion == null)
			{
				return null;
			}
			Transform transform = BarricadeManager.dropBarricadeIntoRegionInternal(vehicleBarricadeRegion, barricade, point, rotation, owner, group);
			if (transform != null)
			{
				BarricadeDrop tail = vehicleBarricadeRegion.drops.GetTail<BarricadeDrop>();
				BarricadeData serversideData = tail.serversideData;
				BarricadeManager.SendSingleBarricade.Invoke(ENetReliability.Reliable, Provider.GatherRemoteClientConnections(), vehicleBarricadeRegion._netId, barricade.asset.GUID, barricade.state, serversideData.point, serversideData.rotation, serversideData.owner, serversideData.group, tail.GetNetId());
				BarricadeSpawnedHandler barricadeSpawnedHandler = BarricadeManager.onBarricadeSpawned;
				if (barricadeSpawnedHandler != null)
				{
					barricadeSpawnedHandler(vehicleBarricadeRegion, tail);
				}
				IBarricadePlacedHandler barricadePlacedHandler = tail.interactable as IBarricadePlacedHandler;
				if (barricadePlacedHandler != null)
				{
					barricadePlacedHandler.OnBarricadePlaced(vehicleBarricadeRegion, tail);
				}
			}
			return transform;
		}

		/// <summary>
		/// Spawn a new barricade and replicate it.
		/// </summary>
		// Token: 0x06002FF6 RID: 12278 RVA: 0x000DC41C File Offset: 0x000DA61C
		public static Transform dropNonPlantedBarricade(Barricade barricade, Vector3 point, Quaternion rotation, ulong owner, ulong group)
		{
			byte x;
			byte y;
			if (!Regions.tryGetCoordinate(point, out x, out y))
			{
				return null;
			}
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(x, y, 65535, out barricadeRegion))
			{
				return null;
			}
			Transform transform = BarricadeManager.dropBarricadeIntoRegionInternal(barricadeRegion, barricade, point, rotation, owner, group);
			if (transform != null)
			{
				BarricadeDrop tail = barricadeRegion.drops.GetTail<BarricadeDrop>();
				BarricadeData serversideData = tail.serversideData;
				BarricadeManager.SendSingleBarricade.Invoke(ENetReliability.Reliable, Regions.GatherRemoteClientConnections(x, y, BarricadeManager.BARRICADE_REGIONS), NetId.INVALID, barricade.asset.GUID, barricade.state, serversideData.point, serversideData.rotation, serversideData.owner, serversideData.group, tail.GetNetId());
				BarricadeSpawnedHandler barricadeSpawnedHandler = BarricadeManager.onBarricadeSpawned;
				if (barricadeSpawnedHandler != null)
				{
					barricadeSpawnedHandler(barricadeRegion, tail);
				}
				IBarricadePlacedHandler barricadePlacedHandler = tail.interactable as IBarricadePlacedHandler;
				if (barricadePlacedHandler != null)
				{
					barricadePlacedHandler.OnBarricadePlaced(barricadeRegion, tail);
				}
			}
			return transform;
		}

		// Token: 0x06002FF7 RID: 12279 RVA: 0x000DC4F0 File Offset: 0x000DA6F0
		[Obsolete]
		public void tellTakeBarricade(CSteamID steamID, byte x, byte y, ushort plant, ushort index)
		{
			throw new NotSupportedException("Removed during barricade NetId rewrite");
		}

		/// <summary>
		/// Not an instance method because structure might not exist yet, in which case we cancel instantiation.
		/// </summary>
		// Token: 0x06002FF8 RID: 12280 RVA: 0x000DC4FC File Offset: 0x000DA6FC
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveDestroyBarricade(in ClientInvocationContext context, NetId netId)
		{
			BarricadeDrop barricadeDrop = NetIdRegistry.Get<BarricadeDrop>(netId);
			if (barricadeDrop == null)
			{
				PlaceableInstantiationManager.CancelInstantiationByNetId(netId, 3U);
				return;
			}
			byte b;
			byte b2;
			ushort num;
			BarricadeRegion barricadeRegion;
			if (!BarricadeManager.tryGetRegion(barricadeDrop.model, out b, out b2, out num, out barricadeRegion))
			{
				return;
			}
			barricadeDrop.CustomDestroy();
			barricadeRegion.drops.Remove(barricadeDrop);
		}

		// Token: 0x06002FF9 RID: 12281 RVA: 0x000DC545 File Offset: 0x000DA745
		[Obsolete]
		public void tellClearRegionBarricades(CSteamID steamID, byte x, byte y)
		{
			BarricadeManager.ReceiveClearRegionBarricades(x, y);
		}

		// Token: 0x06002FFA RID: 12282 RVA: 0x000DC54E File Offset: 0x000DA74E
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER, legacyName = "tellClearRegionBarricades")]
		public static void ReceiveClearRegionBarricades(byte x, byte y)
		{
			if (!Provider.isServer && !BarricadeManager.regions[(int)x, (int)y].isNetworked)
			{
				return;
			}
			BarricadeManager.DestroyAllInRegion(BarricadeManager.regions[(int)x, (int)y]);
			PlaceableInstantiationManager.CancelInstantiationsInRegion(BarricadeManager.regions[(int)x, (int)y], 3U);
		}

		// Token: 0x06002FFB RID: 12283 RVA: 0x000DC590 File Offset: 0x000DA790
		public static void askClearRegionBarricades(byte x, byte y)
		{
			if (Provider.isServer)
			{
				if (!Regions.checkSafe((int)x, (int)y))
				{
					return;
				}
				BarricadeRegion barricadeRegion = BarricadeManager.regions[(int)x, (int)y];
				if (barricadeRegion.drops.Count > 0)
				{
					barricadeRegion.barricades.Clear();
					BarricadeManager.SendClearRegionBarricades.InvokeAndLoopback(ENetReliability.Reliable, Regions.GatherRemoteClientConnections(x, y, BarricadeManager.BARRICADE_REGIONS), x, y);
				}
			}
		}

		// Token: 0x06002FFC RID: 12284 RVA: 0x000DC5F0 File Offset: 0x000DA7F0
		public static void askClearAllBarricades()
		{
			if (Provider.isServer)
			{
				for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
				{
					for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
					{
						BarricadeManager.askClearRegionBarricades(b, b2);
					}
				}
			}
		}

		/// <summary>
		/// Destroy barricades whose pivots are within sphere.
		/// </summary>
		// Token: 0x06002FFD RID: 12285 RVA: 0x000DC630 File Offset: 0x000DA830
		public static void DestroyBarricadesInSphere(Vector3 center, float radius, bool playEffect, bool spawnItems)
		{
			BarricadeManager.tempTransforms.Clear();
			PowerTool.GetBarricadeTransformsInSphere(center, radius, BarricadeManager.tempTransforms);
			foreach (Transform transform in BarricadeManager.tempTransforms)
			{
				BarricadeDrop barricadeDrop = BarricadeDrop.FindByRootFast(transform);
				byte x;
				byte y;
				ushort plant;
				BarricadeRegion barricadeRegion;
				if (barricadeDrop != null && BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
				{
					if (playEffect)
					{
						BarricadeManager.PlayBarricadeExplosionEffect(barricadeDrop);
					}
					if (spawnItems && barricadeDrop.asset != null)
					{
						barricadeDrop.asset.SpawnItemDropsOnDestroy(transform.position);
					}
					BarricadeManager.destroyBarricade(barricadeDrop, x, y, plant);
				}
			}
		}

		// Token: 0x06002FFE RID: 12286 RVA: 0x000DC6DC File Offset: 0x000DA8DC
		public static Quaternion getRotation(ItemBarricadeAsset asset, float angle_x, float angle_y, float angle_z)
		{
			return Quaternion.Euler(0f, angle_y, 0f) * Quaternion.Euler((float)((asset.build == EBuild.DOOR || asset.build == EBuild.GATE || asset.build == EBuild.SHUTTER || asset.build == EBuild.HATCH) ? 0 : -90) + angle_x, 0f, 0f) * Quaternion.Euler(0f, angle_z, 0f);
		}

		// Token: 0x06002FFF RID: 12287 RVA: 0x000DC750 File Offset: 0x000DA950
		private Transform spawnBarricade(BarricadeRegion region, Guid assetGuid, byte[] state, Vector3 point, Quaternion rotation, byte hp, ulong owner, ulong group, NetId netId)
		{
			ItemBarricadeAsset itemBarricadeAsset = Assets.find(assetGuid) as ItemBarricadeAsset;
			if (!Provider.isServer)
			{
				ClientAssetIntegrity.QueueRequest(assetGuid, itemBarricadeAsset, "Barricade");
			}
			if (itemBarricadeAsset == null || itemBarricadeAsset.barricade == null)
			{
				return null;
			}
			Transform transform = null;
			try
			{
				if (itemBarricadeAsset.eligibleForPooling)
				{
					int instanceID = itemBarricadeAsset.barricade.GetInstanceID();
					Stack<GameObject> orAddNew = this.pool.GetOrAddNew(instanceID);
					while (orAddNew.Count > 0)
					{
						GameObject gameObject = orAddNew.Pop();
						if (gameObject != null)
						{
							transform = gameObject.transform;
							transform.parent = region.parent;
							transform.localPosition = point;
							transform.localRotation = rotation;
							transform.localScale = Vector3.one;
							gameObject.SetActive(true);
							break;
						}
					}
				}
				if (transform == null)
				{
					GameObject gameObject2;
					if (region.parent == null)
					{
						gameObject2 = UnityEngine.Object.Instantiate<GameObject>(itemBarricadeAsset.barricade, point, rotation);
						transform = gameObject2.transform;
					}
					else
					{
						InstantiateParameters parameters = new InstantiateParameters
						{
							parent = region.parent,
							worldSpace = false
						};
						gameObject2 = UnityEngine.Object.Instantiate<GameObject>(itemBarricadeAsset.barricade, point, rotation, parameters);
						transform = gameObject2.transform;
					}
					transform.localScale = Vector3.one;
					transform.name = itemBarricadeAsset.id.ToString();
					if (itemBarricadeAsset.useWaterHeightTransparentSort && !Dedicator.IsDedicatedServer)
					{
						gameObject2.AddComponent<WaterHeightTransparentSort>();
					}
					if (Provider.isServer && itemBarricadeAsset.nav != null)
					{
						Transform transform2 = UnityEngine.Object.Instantiate<GameObject>(itemBarricadeAsset.nav).transform;
						transform2.name = "Nav";
						if (itemBarricadeAsset.build == EBuild.DOOR || itemBarricadeAsset.build == EBuild.GATE || itemBarricadeAsset.build == EBuild.SHUTTER || itemBarricadeAsset.build == EBuild.HATCH)
						{
							Transform transform3 = transform.Find("Skeleton").Find("Hinge");
							if (transform3 != null)
							{
								transform2.parent = transform3;
							}
							else
							{
								transform2.parent = transform;
							}
						}
						else
						{
							transform2.parent = transform;
						}
						transform2.localPosition = Vector3.zero;
						transform2.localRotation = Quaternion.identity;
					}
					Transform transform4 = transform.FindChildRecursive("Burning");
					if (transform4 != null)
					{
						transform4.gameObject.AddComponent<TemperatureTrigger>().temperature = EPlayerTemperature.BURNING;
					}
					Transform transform5 = transform.FindChildRecursive("Warm");
					if (transform5 != null)
					{
						transform5.gameObject.AddComponent<TemperatureTrigger>().temperature = EPlayerTemperature.WARM;
					}
				}
				else if (itemBarricadeAsset.useWaterHeightTransparentSort && !Dedicator.IsDedicatedServer)
				{
					transform.GetOrAddComponent<WaterHeightTransparentSort>().updateRenderQueue();
				}
				if (itemBarricadeAsset.build == EBuild.DOOR || itemBarricadeAsset.build == EBuild.GATE || itemBarricadeAsset.build == EBuild.SHUTTER || itemBarricadeAsset.build == EBuild.HATCH)
				{
					transform.GetOrAddComponent<InteractableDoor>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.BED)
				{
					transform.GetOrAddComponent<InteractableBed>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.STORAGE || itemBarricadeAsset.build == EBuild.STORAGE_WALL)
				{
					transform.GetOrAddComponent<InteractableStorage>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.FARM)
				{
					transform.GetOrAddComponent<InteractableFarm>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.TORCH || itemBarricadeAsset.build == EBuild.CAMPFIRE)
				{
					transform.GetOrAddComponent<InteractableFire>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.OVEN)
				{
					transform.GetOrAddComponent<InteractableOven>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.SPIKE || itemBarricadeAsset.build == EBuild.WIRE)
				{
					Transform transform6 = transform.Find("Trap");
					if (transform6 != null)
					{
						InteractableTrapTrigger orAddComponent = transform6.gameObject.GetOrAddComponent<InteractableTrapTrigger>();
						InteractableTrap orAddComponent2 = transform.gameObject.GetOrAddComponent<InteractableTrap>();
						orAddComponent.parentTrap = orAddComponent2;
						orAddComponent2.updateState(itemBarricadeAsset, state);
					}
				}
				else if (itemBarricadeAsset.build == EBuild.CHARGE)
				{
					InteractableCharge orAddComponent3 = transform.GetOrAddComponent<InteractableCharge>();
					orAddComponent3.updateState(itemBarricadeAsset, state);
					orAddComponent3.owner = owner;
					orAddComponent3.group = group;
				}
				else if (itemBarricadeAsset.build == EBuild.GENERATOR)
				{
					transform.GetOrAddComponent<InteractableGenerator>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.SPOT || itemBarricadeAsset.build == EBuild.CAGE)
				{
					transform.GetOrAddComponent<InteractableSpot>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.SAFEZONE)
				{
					transform.GetOrAddComponent<InteractableSafezone>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.OXYGENATOR)
				{
					transform.GetOrAddComponent<InteractableOxygenator>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.SIGN || itemBarricadeAsset.build == EBuild.SIGN_WALL || itemBarricadeAsset.build == EBuild.NOTE)
				{
					transform.GetOrAddComponent<InteractableSign>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.CLAIM)
				{
					InteractableClaim orAddComponent4 = transform.GetOrAddComponent<InteractableClaim>();
					orAddComponent4.owner = owner;
					orAddComponent4.group = group;
					orAddComponent4.updateState(itemBarricadeAsset);
				}
				else if (itemBarricadeAsset.build == EBuild.BEACON)
				{
					transform.GetOrAddComponent<InteractableBeacon>().updateState(itemBarricadeAsset);
				}
				else if (itemBarricadeAsset.build == EBuild.BARREL_RAIN)
				{
					transform.GetOrAddComponent<InteractableRainBarrel>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.OIL)
				{
					transform.GetOrAddComponent<InteractableOil>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.TANK)
				{
					transform.GetOrAddComponent<InteractableTank>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.SENTRY || itemBarricadeAsset.build == EBuild.SENTRY_FREEFORM)
				{
					InteractableSentry orAddComponent5 = transform.GetOrAddComponent<InteractableSentry>();
					InteractablePower orAddComponent6 = transform.GetOrAddComponent<InteractablePower>();
					orAddComponent5.power = orAddComponent6;
					orAddComponent5.updateState(itemBarricadeAsset, state);
					orAddComponent6.RefreshIsConnectedToPower();
				}
				else if (itemBarricadeAsset.build == EBuild.LIBRARY)
				{
					transform.GetOrAddComponent<InteractableLibrary>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.MANNEQUIN)
				{
					transform.GetOrAddComponent<InteractableMannequin>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.STEREO)
				{
					transform.GetOrAddComponent<InteractableStereo>().updateState(itemBarricadeAsset, state);
				}
				else if (itemBarricadeAsset.build == EBuild.CLOCK && !Dedicator.IsDedicatedServer)
				{
					transform.GetOrAddComponent<InteractableClock>().updateState(itemBarricadeAsset, state);
				}
				if (!itemBarricadeAsset.isUnpickupable)
				{
					Interactable2HP orAddComponent7 = transform.GetOrAddComponent<Interactable2HP>();
					orAddComponent7.hp = hp;
					if (itemBarricadeAsset.build == EBuild.DOOR || itemBarricadeAsset.build == EBuild.GATE || itemBarricadeAsset.build == EBuild.SHUTTER || itemBarricadeAsset.build == EBuild.HATCH)
					{
						Transform transform7 = transform.Find("Skeleton").Find("Hinge");
						if (transform7 != null)
						{
							Interactable2SalvageBarricade orAddComponent8 = transform7.GetOrAddComponent<Interactable2SalvageBarricade>();
							orAddComponent8.root = transform;
							orAddComponent8.hp = orAddComponent7;
							orAddComponent8.owner = owner;
							orAddComponent8.group = group;
							orAddComponent8.salvageDurationMultiplier = itemBarricadeAsset.salvageDurationMultiplier;
							orAddComponent8.shouldBypassPickupOwnership = itemBarricadeAsset.shouldBypassPickupOwnership;
						}
						Transform transform8 = transform.Find("Skeleton").Find("Left_Hinge");
						if (transform8 != null)
						{
							Interactable2SalvageBarricade orAddComponent9 = transform8.GetOrAddComponent<Interactable2SalvageBarricade>();
							orAddComponent9.root = transform;
							orAddComponent9.hp = orAddComponent7;
							orAddComponent9.owner = owner;
							orAddComponent9.group = group;
							orAddComponent9.salvageDurationMultiplier = itemBarricadeAsset.salvageDurationMultiplier;
							orAddComponent9.shouldBypassPickupOwnership = itemBarricadeAsset.shouldBypassPickupOwnership;
						}
						Transform transform9 = transform.Find("Skeleton").Find("Right_Hinge");
						if (transform9 != null)
						{
							Interactable2SalvageBarricade orAddComponent10 = transform9.GetOrAddComponent<Interactable2SalvageBarricade>();
							orAddComponent10.root = transform;
							orAddComponent10.hp = orAddComponent7;
							orAddComponent10.owner = owner;
							orAddComponent10.group = group;
							orAddComponent10.salvageDurationMultiplier = itemBarricadeAsset.salvageDurationMultiplier;
							orAddComponent10.shouldBypassPickupOwnership = itemBarricadeAsset.shouldBypassPickupOwnership;
						}
					}
					else
					{
						Interactable2SalvageBarricade orAddComponent11 = transform.GetOrAddComponent<Interactable2SalvageBarricade>();
						orAddComponent11.root = transform;
						orAddComponent11.hp = orAddComponent7;
						orAddComponent11.owner = owner;
						orAddComponent11.group = group;
						orAddComponent11.salvageDurationMultiplier = itemBarricadeAsset.salvageDurationMultiplier;
						orAddComponent11.shouldBypassPickupOwnership = itemBarricadeAsset.shouldBypassPickupOwnership;
					}
				}
				if (region.parent != null)
				{
					BarricadeManager.barricadeColliders.Clear();
					transform.GetComponentsInChildren<Collider>(BarricadeManager.barricadeColliders);
					foreach (Collider collider in BarricadeManager.barricadeColliders)
					{
						bool flag = collider is MeshCollider;
						if (flag)
						{
							collider.enabled = false;
						}
						if (collider.GetComponent<Rigidbody>() == null)
						{
							Rigidbody rigidbody = collider.gameObject.AddComponent<Rigidbody>();
							rigidbody.useGravity = false;
							rigidbody.isKinematic = true;
						}
						if (flag)
						{
							collider.enabled = true;
						}
						if (collider.gameObject.layer == 27)
						{
							collider.gameObject.layer = 14;
						}
					}
					InteractableVehicle component = region.parent.GetComponent<InteractableVehicle>();
					if (component != null)
					{
						component.ignoreCollisionWith(BarricadeManager.barricadeColliders, true);
					}
				}
				BarricadeDrop barricadeDrop = new BarricadeDrop(transform, transform.GetComponent<Interactable>(), itemBarricadeAsset);
				barricadeDrop.AssignNetId(netId);
				transform.GetOrAddComponent<BarricadeRefComponent>().tempNotSureIfBarricadeShouldBeAComponentYet = barricadeDrop;
				region.drops.Add(barricadeDrop);
			}
			catch (Exception e)
			{
				UnturnedLog.warn("Exception while spawning barricade: {0}", new object[]
				{
					itemBarricadeAsset
				});
				UnturnedLog.exception(e);
				if (transform != null)
				{
					UnityEngine.Object.Destroy(transform.gameObject);
					transform = null;
				}
			}
			return transform;
		}

		// Token: 0x06003000 RID: 12288 RVA: 0x000DD02C File Offset: 0x000DB22C
		[Obsolete]
		public void tellBarricade(CSteamID steamID, byte x, byte y, ushort plant, ushort id, byte[] state, Vector3 point, byte angle_x, byte angle_y, byte angle_z, ulong owner, ulong group, uint instanceID)
		{
			throw new NotSupportedException("Barricades no longer function without a unique NetId");
		}

		// Token: 0x06003001 RID: 12289 RVA: 0x000DD038 File Offset: 0x000DB238
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveSingleBarricade(in ClientInvocationContext context, NetId parentNetId, Guid assetId, byte[] state, Vector3 point, Quaternion rotation, ulong owner, ulong group, NetId netId)
		{
			BarricadeRegion barricadeRegion;
			if (parentNetId.IsNull())
			{
				byte x;
				byte y;
				if (!Regions.tryGetCoordinate(point, out x, out y))
				{
					return;
				}
				if (!BarricadeManager.tryGetRegion(x, y, 65535, out barricadeRegion))
				{
					return;
				}
			}
			else
			{
				barricadeRegion = NetIdRegistry.Get<BarricadeRegion>(parentNetId);
				if (barricadeRegion == null)
				{
					return;
				}
			}
			if (!Provider.isServer && !barricadeRegion.isNetworked)
			{
				return;
			}
			PlaceableInstantiationParameters placeableInstantiationParameters = default(PlaceableInstantiationParameters);
			placeableInstantiationParameters.type = EPlaceableInstantiationType.Barricade;
			placeableInstantiationParameters.region = barricadeRegion;
			placeableInstantiationParameters.assetId = assetId;
			placeableInstantiationParameters.state = state;
			placeableInstantiationParameters.position = point;
			placeableInstantiationParameters.rotation = rotation;
			placeableInstantiationParameters.hp = 100;
			placeableInstantiationParameters.owner = owner;
			placeableInstantiationParameters.group = group;
			placeableInstantiationParameters.netId = netId;
			placeableInstantiationParameters.UpdateSortOrder();
			NetInvocationDeferralRegistry.MarkDeferred(netId, 3U);
			PlaceableInstantiationManager.AddInstantiation(ref placeableInstantiationParameters);
		}

		// Token: 0x06003002 RID: 12290 RVA: 0x000DD0FC File Offset: 0x000DB2FC
		[Obsolete]
		public void tellBarricades(CSteamID steamID)
		{
		}

		// Token: 0x06003003 RID: 12291 RVA: 0x000DD100 File Offset: 0x000DB300
		[SteamCall(ESteamCallValidation.ONLY_FROM_SERVER)]
		public static void ReceiveMultipleBarricades(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			byte x;
			reader.ReadUInt8(out x);
			byte y;
			reader.ReadUInt8(out y);
			NetId netId;
			reader.ReadNetId(out netId);
			BarricadeRegion barricadeRegion;
			if (netId == NetId.INVALID)
			{
				if (!BarricadeManager.tryGetRegion(x, y, 65535, out barricadeRegion))
				{
					return;
				}
			}
			else
			{
				barricadeRegion = NetIdRegistry.Get<BarricadeRegion>(netId);
				if (barricadeRegion == null)
				{
					return;
				}
			}
			byte b;
			reader.ReadUInt8(out b);
			if (netId == NetId.INVALID)
			{
				if (b == 0)
				{
					if (barricadeRegion.isNetworked)
					{
						return;
					}
					BarricadeManager.DestroyAllInRegion(barricadeRegion);
				}
				else if (!barricadeRegion.isNetworked)
				{
					return;
				}
			}
			barricadeRegion.isNetworked = true;
			ushort num;
			reader.ReadUInt16(out num);
			if (num > 0)
			{
				float sortOrder;
				reader.ReadFloat(out sortOrder);
				for (ushort num2 = 0; num2 < num; num2 += 1)
				{
					PlaceableInstantiationParameters placeableInstantiationParameters = default(PlaceableInstantiationParameters);
					placeableInstantiationParameters.type = EPlaceableInstantiationType.Barricade;
					placeableInstantiationParameters.region = barricadeRegion;
					placeableInstantiationParameters.sortOrder = sortOrder;
					placeableInstantiationParameters.UpdateSortOrder();
					reader.ReadGuid(out placeableInstantiationParameters.assetId);
					byte b2;
					reader.ReadUInt8(out b2);
					byte[] array = new byte[(int)b2];
					reader.ReadBytes(array);
					placeableInstantiationParameters.state = array;
					reader.ReadClampedVector3(out placeableInstantiationParameters.position, 13, 11);
					reader.ReadSpecialYawOrQuaternion(out placeableInstantiationParameters.rotation, 23, 9);
					reader.ReadUInt8(out placeableInstantiationParameters.hp);
					reader.ReadUInt64(out placeableInstantiationParameters.owner);
					reader.ReadUInt64(out placeableInstantiationParameters.group);
					reader.ReadNetId(out placeableInstantiationParameters.netId);
					NetInvocationDeferralRegistry.MarkDeferred(placeableInstantiationParameters.netId, 3U);
					PlaceableInstantiationManager.AddInstantiation(ref placeableInstantiationParameters);
				}
			}
			Level.isLoadingBarricades = false;
		}

		// Token: 0x06003004 RID: 12292 RVA: 0x000DD29C File Offset: 0x000DB49C
		[Obsolete]
		public void askBarricades(CSteamID steamID, byte x, byte y, ushort plant)
		{
		}

		// Token: 0x06003005 RID: 12293 RVA: 0x000DD2A0 File Offset: 0x000DB4A0
		internal void SendRegion(SteamPlayer client, BarricadeRegion region, byte x, byte y, NetId parentNetId, float sortOrder)
		{
			if (region.drops.Count > 0)
			{
				byte b = 0;
				int i = 0;
				int j = 0;
				while (i < region.drops.Count)
				{
					int num = 0;
					while (j < region.drops.Count)
					{
						num += 44 + region.drops[j].serversideData.barricade.state.Length;
						j++;
						if (num > Block.BUFFER_SIZE / 2)
						{
							break;
						}
					}
					BarricadeManager.SendMultipleBarricadesWriteParameters arg = new BarricadeManager.SendMultipleBarricadesWriteParameters
					{
						region = region,
						x = x,
						y = y,
						parentNetId = parentNetId,
						sortOrder = sortOrder,
						index = i,
						count = j,
						packet = b
					};
					i = j;
					BarricadeManager.SendMultipleBarricades.Invoke<BarricadeManager.SendMultipleBarricadesWriteParameters>(ENetReliability.Reliable, client.transportConnection, new Action<NetPakWriter, BarricadeManager.SendMultipleBarricadesWriteParameters>(BarricadeManager.SendMultipleBarricades_Write), arg);
					b += 1;
				}
				return;
			}
			BarricadeManager.SendMultipleBarricades.Invoke<byte, byte>(ENetReliability.Reliable, client.transportConnection, new Action<NetPakWriter, byte, byte>(BarricadeManager.SendMultipleBarricades_WriteEmpty), x, y);
		}

		// Token: 0x06003006 RID: 12294 RVA: 0x000DD3B8 File Offset: 0x000DB5B8
		private static void SendMultipleBarricades_Write(NetPakWriter writer, BarricadeManager.SendMultipleBarricadesWriteParameters p)
		{
			writer.WriteUInt8(p.x);
			writer.WriteUInt8(p.y);
			writer.WriteNetId(p.parentNetId);
			writer.WriteUInt8(p.packet);
			writer.WriteUInt16((ushort)(p.count - p.index));
			writer.WriteFloat(p.sortOrder);
			while (p.index < p.count)
			{
				BarricadeDrop barricadeDrop = p.region.drops[p.index];
				BarricadeData serversideData = barricadeDrop.serversideData;
				InteractableStorage interactableStorage = barricadeDrop.interactable as InteractableStorage;
				writer.WriteGuid(barricadeDrop.asset.GUID);
				if (interactableStorage != null)
				{
					byte[] array;
					if (interactableStorage.isDisplay)
					{
						string s = (interactableStorage.displayTags != null) ? interactableStorage.displayTags : string.Empty;
						byte[] bytes = Encoding.UTF8.GetBytes(s);
						string s2 = (interactableStorage.displayDynamicProps != null) ? interactableStorage.displayDynamicProps : string.Empty;
						byte[] bytes2 = Encoding.UTF8.GetBytes(s2);
						array = new byte[20 + ((interactableStorage.displayItem != null) ? interactableStorage.displayItem.state.Length : 0) + 4 + 1 + bytes.Length + 1 + bytes2.Length + 1];
						if (interactableStorage.displayItem != null)
						{
							Array.Copy(BitConverter.GetBytes(interactableStorage.displayItem.id), 0, array, 16, 2);
							array[18] = interactableStorage.displayItem.quality;
							array[19] = (byte)interactableStorage.displayItem.state.Length;
							Array.Copy(interactableStorage.displayItem.state, 0, array, 20, interactableStorage.displayItem.state.Length);
							Array.Copy(BitConverter.GetBytes(interactableStorage.displaySkin), 0, array, 20 + interactableStorage.displayItem.state.Length, 2);
							Array.Copy(BitConverter.GetBytes(interactableStorage.displayMythic), 0, array, 20 + interactableStorage.displayItem.state.Length + 2, 2);
							array[20 + interactableStorage.displayItem.state.Length + 4] = (byte)bytes.Length;
							Array.Copy(bytes, 0, array, 20 + interactableStorage.displayItem.state.Length + 5, bytes.Length);
							array[20 + interactableStorage.displayItem.state.Length + 5 + bytes.Length] = (byte)bytes2.Length;
							Array.Copy(bytes2, 0, array, 20 + interactableStorage.displayItem.state.Length + 5 + bytes.Length + 1, bytes2.Length);
							array[20 + interactableStorage.displayItem.state.Length + 5 + bytes.Length + 1 + bytes2.Length] = interactableStorage.rot_comp;
						}
					}
					else
					{
						array = new byte[16];
					}
					Array.Copy(serversideData.barricade.state, 0, array, 0, 16);
					writer.WriteUInt8((byte)array.Length);
					writer.WriteBytes(array);
				}
				else
				{
					writer.WriteUInt8((byte)serversideData.barricade.state.Length);
					writer.WriteBytes(serversideData.barricade.state);
				}
				writer.WriteClampedVector3(serversideData.point, 13, 11);
				writer.WriteSpecialYawOrQuaternion(serversideData.rotation, 23, 9);
				writer.WriteUInt8((byte)Mathf.RoundToInt((float)serversideData.barricade.health / (float)serversideData.barricade.asset.health * 100f));
				writer.WriteUInt64(serversideData.owner);
				writer.WriteUInt64(serversideData.group);
				writer.WriteNetId(barricadeDrop.GetNetId());
				p.index++;
			}
		}

		// Token: 0x06003007 RID: 12295 RVA: 0x000DD733 File Offset: 0x000DB933
		private static void SendMultipleBarricades_WriteEmpty(NetPakWriter writer, byte x, byte y)
		{
			writer.WriteUInt8(x);
			writer.WriteUInt8(y);
			writer.WriteNetId(NetId.INVALID);
			writer.WriteUInt8(0);
			writer.WriteUInt16(0);
		}

		/// <summary>
		/// Clean up before loading vehicles.
		/// </summary>
		// Token: 0x06003008 RID: 12296 RVA: 0x000DD761 File Offset: 0x000DB961
		public static void clearPlants()
		{
			BarricadeManager.internalVehicleRegions = new List<VehicleBarricadeRegion>();
			BarricadeManager.vehicleRegions = BarricadeManager.internalVehicleRegions.AsReadOnly();
			BarricadeManager.backwardsCompatVehicleRegions = null;
		}

		/// <summary>
		/// Register a new vehicle as a valid parent for barricades.
		/// Each train car is registered after the root of the train.
		/// Note: why they are called "plants", refer to "only god and i" meme. 
		/// </summary>
		// Token: 0x06003009 RID: 12297 RVA: 0x000DD784 File Offset: 0x000DB984
		[Obsolete("Plugins should not be calling this")]
		public static void waterPlant(Transform parent)
		{
			InteractableVehicle vehicle = DamageTool.getVehicle(parent);
			BarricadeManager.registerVehicleRegion(parent, vehicle, 0, NetId.INVALID);
		}

		// Token: 0x0600300A RID: 12298 RVA: 0x000DD7A8 File Offset: 0x000DB9A8
		internal static void registerVehicleRegion(Transform parent, InteractableVehicle vehicle, int subvehicleIndex, NetId netId)
		{
			VehicleBarricadeRegion vehicleBarricadeRegion = new VehicleBarricadeRegion(parent, vehicle, subvehicleIndex);
			vehicleBarricadeRegion.isNetworked = true;
			vehicleBarricadeRegion._netId = netId;
			NetIdRegistry.Assign(netId, vehicleBarricadeRegion);
			BarricadeManager.internalVehicleRegions.Add(vehicleBarricadeRegion);
			BarricadeManager.backwardsCompatVehicleRegions = null;
		}

		/// <summary>
		/// Called before destroying a vehicle GameObject because storage needed to be ManualDestroyed.
		/// </summary>
		// Token: 0x0600300B RID: 12299 RVA: 0x000DD7E4 File Offset: 0x000DB9E4
		public static void uprootPlant(Transform parent)
		{
			ushort num = 0;
			while ((int)num < BarricadeManager.vehicleRegions.Count)
			{
				VehicleBarricadeRegion vehicleBarricadeRegion = BarricadeManager.vehicleRegions[(int)num];
				if (vehicleBarricadeRegion.parent == parent)
				{
					vehicleBarricadeRegion.barricades.Clear();
					BarricadeManager.DestroyAllInRegion(vehicleBarricadeRegion);
					PlaceableInstantiationManager.CancelInstantiationsInRegion(vehicleBarricadeRegion, 3U);
					NetIdRegistry.Release(vehicleBarricadeRegion._netId);
					BarricadeManager.internalVehicleRegions.RemoveAt((int)num);
					BarricadeManager.backwardsCompatVehicleRegions = null;
					return;
				}
				num += 1;
			}
		}

		// Token: 0x0600300C RID: 12300 RVA: 0x000DD858 File Offset: 0x000DBA58
		public static void trimPlant(Transform parent)
		{
			ushort num = 0;
			while ((int)num < BarricadeManager.vehicleRegions.Count)
			{
				BarricadeRegion barricadeRegion = BarricadeManager.vehicleRegions[(int)num];
				if (barricadeRegion.parent == parent)
				{
					barricadeRegion.barricades.Clear();
					BarricadeManager.DestroyAllInRegion(barricadeRegion);
					PlaceableInstantiationManager.CancelInstantiationsInRegion(barricadeRegion, 3U);
					return;
				}
				num += 1;
			}
		}

		// Token: 0x0600300D RID: 12301 RVA: 0x000DD8AE File Offset: 0x000DBAAE
		[Obsolete]
		public static void askPlants(CSteamID steamID)
		{
		}

		/// <summary>
		/// Send all vehicle-mounted barricades to client.
		/// Called after sending vehicles so all plant indexes will be valid.
		/// </summary>
		// Token: 0x0600300E RID: 12302 RVA: 0x000DD8B0 File Offset: 0x000DBAB0
		internal static void SendVehicleRegions(SteamPlayer client)
		{
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.vehicleRegions)
			{
				if (vehicleBarricadeRegion.drops.Count > 0)
				{
					float sqrMagnitude = (client.player.transform.position - vehicleBarricadeRegion.parent.position).sqrMagnitude;
					BarricadeManager.manager.SendRegion(client, vehicleBarricadeRegion, byte.MaxValue, byte.MaxValue, vehicleBarricadeRegion._netId, sqrMagnitude);
				}
			}
		}

		// Token: 0x0600300F RID: 12303 RVA: 0x000DD94C File Offset: 0x000DBB4C
		public static BarricadeDrop FindBarricadeByRootTransform(Transform transform)
		{
			byte b;
			byte b2;
			ushort num;
			BarricadeRegion barricadeRegion;
			if (BarricadeManager.tryGetRegion(transform, out b, out b2, out num, out barricadeRegion))
			{
				return barricadeRegion.FindBarricadeByRootTransform(transform);
			}
			return null;
		}

		// Token: 0x06003010 RID: 12304 RVA: 0x000DD974 File Offset: 0x000DBB74
		[Obsolete("Please use FindBarricadeByRootTransform instead")]
		public static bool tryGetInfo(Transform barricade, out byte x, out byte y, out ushort plant, out ushort index, out BarricadeRegion region)
		{
			x = 0;
			y = 0;
			plant = 0;
			index = 0;
			region = null;
			if (BarricadeManager.tryGetRegion(barricade, out x, out y, out plant, out region))
			{
				index = 0;
				while ((int)index < region.drops.Count)
				{
					if (barricade == region.drops[(int)index].model)
					{
						return true;
					}
					index += 1;
				}
			}
			return false;
		}

		// Token: 0x06003011 RID: 12305 RVA: 0x000DD9E0 File Offset: 0x000DBBE0
		[Obsolete("Please use FindBarricadeByRootTransform instead")]
		public static bool tryGetInfo(Transform barricade, out byte x, out byte y, out ushort plant, out ushort index, out BarricadeRegion region, out BarricadeDrop drop)
		{
			x = 0;
			y = 0;
			plant = 0;
			index = 0;
			region = null;
			drop = null;
			if (BarricadeManager.tryGetRegion(barricade, out x, out y, out plant, out region))
			{
				index = 0;
				while ((int)index < region.drops.Count)
				{
					if (barricade == region.drops[(int)index].model)
					{
						drop = region.drops[(int)index];
						return true;
					}
					index += 1;
				}
			}
			return false;
		}

		// Token: 0x06003012 RID: 12306 RVA: 0x000DDA64 File Offset: 0x000DBC64
		public static bool tryGetPlant(Transform parent, out byte x, out byte y, out ushort plant, out BarricadeRegion region)
		{
			x = byte.MaxValue;
			y = byte.MaxValue;
			plant = ushort.MaxValue;
			region = null;
			if (parent == null)
			{
				return false;
			}
			plant = 0;
			while ((int)plant < BarricadeManager.vehicleRegions.Count)
			{
				region = BarricadeManager.vehicleRegions[(int)plant];
				if (region.parent == parent)
				{
					return true;
				}
				plant += 1;
			}
			return false;
		}

		// Token: 0x06003013 RID: 12307 RVA: 0x000DDAD4 File Offset: 0x000DBCD4
		public static bool tryGetRegion(Transform barricade, out byte x, out byte y, out ushort plant, out BarricadeRegion region)
		{
			x = 0;
			y = 0;
			plant = 0;
			region = null;
			if (barricade == null)
			{
				return false;
			}
			if (barricade.parent != null && barricade.parent.CompareTag("Vehicle"))
			{
				plant = 0;
				while ((int)plant < BarricadeManager.vehicleRegions.Count)
				{
					region = BarricadeManager.vehicleRegions[(int)plant];
					if (region.parent == barricade.parent)
					{
						return true;
					}
					plant += 1;
				}
			}
			else
			{
				plant = ushort.MaxValue;
				if (Regions.tryGetCoordinate(barricade.position, out x, out y))
				{
					region = BarricadeManager.regions[(int)x, (int)y];
					return true;
				}
			}
			return false;
		}

		// Token: 0x06003014 RID: 12308 RVA: 0x000DDB85 File Offset: 0x000DBD85
		public static InteractableVehicle getVehicleFromPlant(ushort plant)
		{
			if ((int)plant < BarricadeManager.vehicleRegions.Count)
			{
				return BarricadeManager.vehicleRegions[(int)plant].vehicle;
			}
			return null;
		}

		// Token: 0x06003015 RID: 12309 RVA: 0x000DDBA6 File Offset: 0x000DBDA6
		public static BarricadeRegion getRegionFromVehicle(InteractableVehicle vehicle)
		{
			return BarricadeManager.findRegionFromVehicle(vehicle, 0);
		}

		// Token: 0x06003016 RID: 12310 RVA: 0x000DDBB0 File Offset: 0x000DBDB0
		public static VehicleBarricadeRegion findRegionFromVehicle(InteractableVehicle vehicle, int subvehicleIndex = 0)
		{
			if (vehicle == null)
			{
				return null;
			}
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.vehicleRegions)
			{
				if (vehicleBarricadeRegion.vehicle == vehicle && vehicleBarricadeRegion.subvehicleIndex == subvehicleIndex)
				{
					return vehicleBarricadeRegion;
				}
			}
			return null;
		}

		// Token: 0x06003017 RID: 12311 RVA: 0x000DDC20 File Offset: 0x000DBE20
		public static VehicleBarricadeRegion findVehicleRegionByNetInstanceID(uint instanceID, int subvehicleIndex = 0)
		{
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.vehicleRegions)
			{
				if (vehicleBarricadeRegion.vehicle.instanceID == instanceID && vehicleBarricadeRegion.subvehicleIndex == subvehicleIndex)
				{
					return vehicleBarricadeRegion;
				}
			}
			return null;
		}

		// Token: 0x06003018 RID: 12312 RVA: 0x000DDC84 File Offset: 0x000DBE84
		public static VehicleBarricadeRegion FindVehicleRegionByTransform(Transform parent)
		{
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.internalVehicleRegions)
			{
				if (vehicleBarricadeRegion.parent == parent)
				{
					return vehicleBarricadeRegion;
				}
			}
			return null;
		}

		// Token: 0x06003019 RID: 12313 RVA: 0x000DDCE4 File Offset: 0x000DBEE4
		public static bool tryGetRegion(byte x, byte y, ushort plant, out BarricadeRegion region)
		{
			region = null;
			if (plant < 65535)
			{
				if ((int)plant < BarricadeManager.vehicleRegions.Count)
				{
					region = BarricadeManager.vehicleRegions[(int)plant];
					return true;
				}
				return false;
			}
			else
			{
				if (Regions.checkSafe((int)x, (int)y))
				{
					region = BarricadeManager.regions[(int)x, (int)y];
					return true;
				}
				return false;
			}
		}

		// Token: 0x0600301A RID: 12314 RVA: 0x000DDD34 File Offset: 0x000DBF34
		[Obsolete]
		public void tellBarricadeUpdateState(CSteamID steamID, byte x, byte y, ushort plant, ushort index, byte[] newState)
		{
			throw new NotSupportedException("Moved into instance method as part of barricade NetId rewrite");
		}

		/// <summary>
		/// Original server-only version that does not replicate changes to clients.
		/// </summary>
		// Token: 0x0600301B RID: 12315 RVA: 0x000DDD40 File Offset: 0x000DBF40
		public static void updateState(Transform transform, byte[] state, int size)
		{
			BarricadeManager.updateStateInternal(transform, state, size, false);
		}

		/// <summary>
		/// Only used by plugins. Replicates state change to clients.
		/// </summary>
		// Token: 0x0600301C RID: 12316 RVA: 0x000DDD4B File Offset: 0x000DBF4B
		public static void updateReplicatedState(Transform transform, byte[] state, int size)
		{
			BarricadeManager.updateStateInternal(transform, state, size, true);
		}

		// Token: 0x0600301D RID: 12317 RVA: 0x000DDD58 File Offset: 0x000DBF58
		private static void updateStateInternal(Transform transform, byte[] state, int size, bool shouldReplicate = false)
		{
			byte x;
			byte y;
			ushort plant;
			BarricadeRegion barricadeRegion;
			if (BarricadeManager.tryGetRegion(transform, out x, out y, out plant, out barricadeRegion))
			{
				BarricadeDrop barricadeDrop = barricadeRegion.FindBarricadeByRootTransform(transform);
				if (barricadeDrop.serversideData.barricade.state.Length != size)
				{
					barricadeDrop.serversideData.barricade.state = new byte[size];
				}
				Array.Copy(state, barricadeDrop.serversideData.barricade.state, size);
				if (shouldReplicate)
				{
					BarricadeDrop.SendUpdateState.InvokeAndLoopback(barricadeDrop.GetNetId(), ENetReliability.Reliable, BarricadeManager.GatherRemoteClientConnections(x, y, plant), state);
				}
			}
		}

		// Token: 0x0600301E RID: 12318 RVA: 0x000DDDE4 File Offset: 0x000DBFE4
		private static void updateActivity(BarricadeRegion region, CSteamID owner, CSteamID group)
		{
			foreach (BarricadeDrop barricadeDrop in region.drops)
			{
				BarricadeData serversideData = barricadeDrop.serversideData;
				if (OwnershipTool.checkToggle(owner, serversideData.owner, group, serversideData.group))
				{
					serversideData.objActiveDate = Provider.time;
				}
			}
		}

		// Token: 0x0600301F RID: 12319 RVA: 0x000DDE58 File Offset: 0x000DC058
		private static void updateActivity(CSteamID owner, CSteamID group)
		{
			for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
			{
				for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
				{
					BarricadeManager.updateActivity(BarricadeManager.regions[(int)b, (int)b2], owner, group);
				}
			}
			ushort num = 0;
			while ((int)num < BarricadeManager.vehicleRegions.Count)
			{
				BarricadeManager.updateActivity(BarricadeManager.vehicleRegions[(int)num], owner, group);
				num += 1;
			}
		}

		/// <summary>
		/// Not ideal, but there was a problem because onLevelLoaded was not resetting these after disconnecting.
		/// </summary>
		// Token: 0x06003020 RID: 12320 RVA: 0x000DDEC2 File Offset: 0x000DC0C2
		internal static void ClearNetworkStuff()
		{
			BarricadeManager.regionsPendingDestroy = new List<BarricadeRegion>();
		}

		// Token: 0x06003021 RID: 12321 RVA: 0x000DDED0 File Offset: 0x000DC0D0
		private void onLevelLoaded(int level)
		{
			if (level > Level.BUILD_INDEX_SETUP)
			{
				BarricadeManager.regions = new BarricadeRegion[(int)Regions.WORLD_SIZE, (int)Regions.WORLD_SIZE];
				for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
				{
					for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
					{
						BarricadeManager.regions[(int)b, (int)b2] = new BarricadeRegion(null);
					}
				}
				BarricadeManager.barricadeColliders = new List<Collider>();
				BarricadeManager.version = BarricadeManager.SAVEDATA_VERSION;
				BarricadeManager.instanceCount = 0U;
				this.pool = new Dictionary<int, Stack<GameObject>>();
				if (Provider.isServer)
				{
					BarricadeManager.load();
				}
			}
		}

		// Token: 0x06003022 RID: 12322 RVA: 0x000DDF60 File Offset: 0x000DC160
		private void onRegionUpdated(Player player, byte old_x, byte old_y, byte new_x, byte new_y, byte step, ref bool canIncrementIndex)
		{
			if (step == 0)
			{
				for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
				{
					for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
					{
						if (Provider.isServer)
						{
							if (player.movement.loadedRegions[(int)b, (int)b2].isBarricadesLoaded && !Regions.checkArea(b, b2, new_x, new_y, BarricadeManager.BARRICADE_REGIONS))
							{
								player.movement.loadedRegions[(int)b, (int)b2].isBarricadesLoaded = false;
							}
						}
						else if (player.channel.IsLocalPlayer && BarricadeManager.regions[(int)b, (int)b2].isNetworked && !Regions.checkArea(b, b2, new_x, new_y, BarricadeManager.BARRICADE_REGIONS))
						{
							if (BarricadeManager.regions[(int)b, (int)b2].drops.Count > 0)
							{
								BarricadeManager.regions[(int)b, (int)b2].isPendingDestroy = true;
								BarricadeManager.regionsPendingDestroy.Add(BarricadeManager.regions[(int)b, (int)b2]);
							}
							PlaceableInstantiationManager.CancelInstantiationsInRegion(BarricadeManager.regions[(int)b, (int)b2], 3U);
							BarricadeManager.regions[(int)b, (int)b2].isNetworked = false;
						}
					}
				}
			}
			if (step == 2 && Dedicator.IsDedicatedServer && Regions.checkSafe((int)new_x, (int)new_y))
			{
				Vector3 position = player.transform.position;
				for (int i = (int)(new_x - BarricadeManager.BARRICADE_REGIONS); i <= (int)(new_x + BarricadeManager.BARRICADE_REGIONS); i++)
				{
					for (int j = (int)(new_y - BarricadeManager.BARRICADE_REGIONS); j <= (int)(new_y + BarricadeManager.BARRICADE_REGIONS); j++)
					{
						if (Regions.checkSafe((int)((byte)i), (int)((byte)j)) && !player.movement.loadedRegions[i, j].isBarricadesLoaded)
						{
							player.movement.loadedRegions[i, j].isBarricadesLoaded = true;
							float sortOrder = Regions.HorizontalDistanceFromCenterSquared(i, j, position);
							this.SendRegion(player.channel.owner, BarricadeManager.regions[i, j], (byte)i, (byte)j, NetId.INVALID, sortOrder);
						}
					}
				}
			}
		}

		// Token: 0x06003023 RID: 12323 RVA: 0x000DE174 File Offset: 0x000DC374
		private void onPlayerCreated(Player player)
		{
			PlayerMovement movement = player.movement;
			movement.onRegionUpdated = (PlayerRegionUpdated)Delegate.Combine(movement.onRegionUpdated, new PlayerRegionUpdated(this.onRegionUpdated));
			if (Provider.isServer)
			{
				BarricadeManager.updateActivity(player.channel.owner.playerID.steamID, player.quests.groupID);
			}
		}

		// Token: 0x06003024 RID: 12324 RVA: 0x000DE1D4 File Offset: 0x000DC3D4
		private void Start()
		{
			BarricadeManager.manager = this;
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Combine(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
			Level.onPreLevelLoaded = (PreLevelLoaded)Delegate.Combine(Level.onPreLevelLoaded, new PreLevelLoaded(this.onLevelLoaded));
			Player.onPlayerCreated = (PlayerCreated)Delegate.Combine(Player.onPlayerCreated, new PlayerCreated(this.onPlayerCreated));
		}

		// Token: 0x06003025 RID: 12325 RVA: 0x000DE248 File Offset: 0x000DC448
		private void OnLogMemoryUsage(List<string> results)
		{
			int num = 0;
			int num2 = 0;
			BarricadeRegion[,] regions = BarricadeManager.regions;
			int upperBound = regions.GetUpperBound(0);
			int upperBound2 = regions.GetUpperBound(1);
			for (int i = regions.GetLowerBound(0); i <= upperBound; i++)
			{
				for (int j = regions.GetLowerBound(1); j <= upperBound2; j++)
				{
					BarricadeRegion barricadeRegion = regions[i, j];
					if (barricadeRegion.drops.Count > 0)
					{
						num++;
					}
					num2 += barricadeRegion.drops.Count;
				}
			}
			results.Add(string.Format("Barricade regions: {0}", num));
			results.Add(string.Format("Barricades placed on ground: {0}", num2));
			int num3 = 0;
			int num4 = 0;
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.internalVehicleRegions)
			{
				if (vehicleBarricadeRegion.drops.Count > 0)
				{
					num3++;
				}
				num4 += vehicleBarricadeRegion.drops.Count;
			}
			results.Add(string.Format("Barricade vehicle regions: {0}", BarricadeManager.internalVehicleRegions.Count));
			results.Add(string.Format("Vehicles with barricades: {0}", num3));
			results.Add(string.Format("Barricades placed on vehicles: {0}", num4));
		}

		// Token: 0x06003026 RID: 12326 RVA: 0x000DE3B0 File Offset: 0x000DC5B0
		public static void load()
		{
			bool flag = false;
			if (LevelSavedata.fileExists("/Barricades.dat") && Level.info.type == ELevelType.SURVIVAL)
			{
				River river = LevelSavedata.openRiver("/Barricades.dat", true);
				BarricadeManager.version = river.readByte();
				if (BarricadeManager.version > 6)
				{
					BarricadeManager.serverActiveDate = river.readUInt32();
				}
				else
				{
					BarricadeManager.serverActiveDate = Provider.time;
				}
				if (BarricadeManager.version < 15)
				{
					BarricadeManager.instanceCount = 0U;
				}
				else
				{
					BarricadeManager.instanceCount = river.readUInt32();
				}
				if (BarricadeManager.version > 0)
				{
					for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
					{
						for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
						{
							BarricadeManager.loadRegion(BarricadeManager.version, river, null);
						}
					}
					if (BarricadeManager.version > 1)
					{
						if (BarricadeManager.version > 13)
						{
							ushort num = river.readUInt16();
							for (ushort num2 = 0; num2 < num; num2 += 1)
							{
								uint num3 = river.readUInt32();
								int num4;
								if (BarricadeManager.version < 16)
								{
									num4 = 0;
								}
								else
								{
									num4 = (int)river.readByte();
								}
								BarricadeRegion barricadeRegion = BarricadeManager.findVehicleRegionByNetInstanceID(num3, num4);
								if (barricadeRegion == null)
								{
									CommandWindow.LogWarning(string.Format("Barricades associated with missing vehicle instance ID '{0}' subindex {1} were lost", num3, num4));
									barricadeRegion = BarricadeManager.regions[0, 0];
								}
								BarricadeManager.loadRegion(BarricadeManager.version, river, barricadeRegion);
							}
						}
						else
						{
							ushort num5 = river.readUInt16();
							num5 = (ushort)Mathf.Min((int)num5, BarricadeManager.vehicleRegions.Count);
							for (int i = 0; i < (int)num5; i++)
							{
								BarricadeRegion regionOverride = BarricadeManager.vehicleRegions[i];
								BarricadeManager.loadRegion(BarricadeManager.version, river, regionOverride);
							}
						}
					}
				}
				if (BarricadeManager.version < 11)
				{
					flag = true;
				}
				river.closeRiver();
			}
			else
			{
				flag = true;
			}
			if (flag && LevelObjects.buildables != null)
			{
				int num6 = 0;
				for (byte b3 = 0; b3 < Regions.WORLD_SIZE; b3 += 1)
				{
					for (byte b4 = 0; b4 < Regions.WORLD_SIZE; b4 += 1)
					{
						List<LevelBuildableObject> list = LevelObjects.buildables[(int)b3, (int)b4];
						if (list != null && list.Count != 0)
						{
							BarricadeRegion barricadeRegion2 = BarricadeManager.regions[(int)b3, (int)b4];
							for (int j = 0; j < list.Count; j++)
							{
								LevelBuildableObject levelBuildableObject = list[j];
								if (levelBuildableObject != null)
								{
									ItemBarricadeAsset itemBarricadeAsset = levelBuildableObject.asset as ItemBarricadeAsset;
									if (itemBarricadeAsset != null)
									{
										Barricade barricade = new Barricade(itemBarricadeAsset);
										BarricadeData barricadeData = new BarricadeData(barricade, levelBuildableObject.point, levelBuildableObject.rotation, 0UL, 0UL, uint.MaxValue, BarricadeManager.instanceCount += 1U);
										NetId netId = NetIdRegistry.ClaimBlock(3U);
										if (BarricadeManager.manager.spawnBarricade(barricadeRegion2, barricade.asset.GUID, barricade.state, barricadeData.point, barricadeData.rotation, (byte)Mathf.RoundToInt((float)barricade.health / (float)itemBarricadeAsset.health * 100f), 0UL, 0UL, netId) != null)
										{
											barricadeRegion2.drops.GetTail<BarricadeDrop>().serversideData = barricadeData;
											barricadeRegion2.barricades.Add(barricadeData);
											num6++;
										}
										else
										{
											UnturnedLog.warn(string.Format("Failed to spawn default barricade object {0} at {1}", itemBarricadeAsset.name, levelBuildableObject.point));
										}
									}
								}
							}
						}
					}
				}
				UnturnedLog.info(string.Format("Spawned {0} default barricades from level", num6));
			}
			Level.isLoadingBarricades = false;
		}

		// Token: 0x06003027 RID: 12327 RVA: 0x000DE718 File Offset: 0x000DC918
		public static void save()
		{
			River river = LevelSavedata.openRiver("/Barricades.dat", false);
			river.writeByte(19);
			river.writeUInt32(Provider.time);
			river.writeUInt32(BarricadeManager.instanceCount);
			for (byte b = 0; b < Regions.WORLD_SIZE; b += 1)
			{
				for (byte b2 = 0; b2 < Regions.WORLD_SIZE; b2 += 1)
				{
					BarricadeRegion region = BarricadeManager.regions[(int)b, (int)b2];
					BarricadeManager.saveRegion(river, region);
				}
			}
			ushort num = 0;
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion in BarricadeManager.vehicleRegions)
			{
				InteractableVehicle vehicle = vehicleBarricadeRegion.vehicle;
				if (vehicle != null && !vehicle.isAutoClearable)
				{
					num += 1;
				}
			}
			river.writeUInt16(num);
			foreach (VehicleBarricadeRegion vehicleBarricadeRegion2 in BarricadeManager.vehicleRegions)
			{
				InteractableVehicle vehicle2 = vehicleBarricadeRegion2.vehicle;
				if (vehicle2 != null && !vehicle2.isAutoClearable)
				{
					river.writeUInt32(vehicle2.instanceID);
					river.writeByte((byte)vehicleBarricadeRegion2.subvehicleIndex);
					BarricadeManager.saveRegion(river, vehicleBarricadeRegion2);
				}
			}
			river.closeRiver();
		}

		// Token: 0x06003028 RID: 12328 RVA: 0x000DE86C File Offset: 0x000DCA6C
		[Conditional("LOG_BARRICADE_LOADING")]
		private static void LogLoading(string message)
		{
			UnturnedLog.info(message);
		}

		// Token: 0x06003029 RID: 12329 RVA: 0x000DE874 File Offset: 0x000DCA74
		private static void loadRegion(byte version, River river, BarricadeRegion regionOverride)
		{
			ushort num = river.readUInt16();
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				ItemBarricadeAsset itemBarricadeAsset;
				if (version < 17)
				{
					ushort id = river.readUInt16();
					itemBarricadeAsset = (Assets.find(EAssetType.ITEM, id) as ItemBarricadeAsset);
				}
				else
				{
					itemBarricadeAsset = (Assets.find(river.readGUID()) as ItemBarricadeAsset);
				}
				uint newInstanceID;
				if (version < 15)
				{
					newInstanceID = (BarricadeManager.instanceCount += 1U);
				}
				else
				{
					newInstanceID = river.readUInt32();
				}
				ushort num3 = river.readUInt16();
				byte[] array = river.readBytes();
				Vector3 vector = river.readSingleVector3();
				Quaternion quaternion;
				if (version < 19)
				{
					byte b = 0;
					if (version > 2)
					{
						b = river.readByte();
					}
					byte b2 = river.readByte();
					byte b3 = 0;
					if (version > 3)
					{
						b3 = river.readByte();
					}
					if (version < 10 && itemBarricadeAsset != null)
					{
						quaternion = BarricadeManager.getRotation(itemBarricadeAsset, (float)(b * 2), (float)(b2 * 2), (float)(b3 * 2));
					}
					else
					{
						quaternion = Quaternion.Euler((float)b * 2f, (float)b2 * 2f, (float)b3 * 2f);
					}
				}
				else
				{
					quaternion = river.readSingleQuaternion();
				}
				ulong num4 = 0UL;
				ulong num5 = 0UL;
				if (version > 4)
				{
					num4 = river.readUInt64();
					num5 = river.readUInt64();
				}
				uint newObjActiveDate;
				if (version > 5)
				{
					newObjActiveDate = river.readUInt32();
					if (Provider.time - BarricadeManager.serverActiveDate > Provider.modeConfigData.Barricades.Decay_Time / 2U)
					{
						newObjActiveDate = Provider.time;
					}
				}
				else
				{
					newObjActiveDate = Provider.time;
				}
				byte b4;
				if (version >= 18)
				{
					b4 = river.readByte();
				}
				else
				{
					b4 = byte.MaxValue;
				}
				if (itemBarricadeAsset != null)
				{
					if (version >= 18 && b4 != (byte)itemBarricadeAsset.build)
					{
						UnturnedLog.info("Discarding barricade \"" + itemBarricadeAsset.FriendlyName + "\" because asset Build property changed which might cause bigger problems (public issue #3725)");
					}
					else
					{
						if (itemBarricadeAsset.type == EItemType.TANK && array.Length < 2)
						{
							array = itemBarricadeAsset.getState(EItemOrigin.ADMIN);
						}
						if (itemBarricadeAsset.build == EBuild.OIL && array.Length < 2)
						{
							array = itemBarricadeAsset.getState(EItemOrigin.ADMIN);
						}
						BarricadeRegion barricadeRegion = regionOverride;
						if (barricadeRegion == null)
						{
							byte b5;
							byte b6;
							if (!Regions.tryGetCoordinate(vector, out b5, out b6))
							{
								UnturnedLog.warn(string.Format("Discarding loaded barricade {0} because it is outside the maximum level size at {1}", itemBarricadeAsset.FriendlyName, vector));
								goto IL_284;
							}
							barricadeRegion = BarricadeManager.regions[(int)b5, (int)b6];
						}
						NetId netId = NetIdRegistry.ClaimBlock(3U);
						if (BarricadeManager.manager.spawnBarricade(barricadeRegion, itemBarricadeAsset.GUID, array, vector, quaternion, (byte)Mathf.RoundToInt((float)num3 / (float)itemBarricadeAsset.health * 100f), num4, num5, netId) != null)
						{
							BarricadeDrop tail = barricadeRegion.drops.GetTail<BarricadeDrop>();
							BarricadeData barricadeData = new BarricadeData(new Barricade(itemBarricadeAsset, num3, array), vector, quaternion, num4, num5, newObjActiveDate, newInstanceID);
							tail.serversideData = barricadeData;
							barricadeRegion.barricades.Add(barricadeData);
						}
					}
				}
				IL_284:;
			}
		}

		// Token: 0x0600302A RID: 12330 RVA: 0x000DEB14 File Offset: 0x000DCD14
		private static void saveRegion(River river, BarricadeRegion region)
		{
			uint time = Provider.time;
			ushort num = 0;
			foreach (BarricadeDrop barricadeDrop in region.drops)
			{
				BarricadeData serversideData = barricadeDrop.serversideData;
				if ((!Dedicator.IsDedicatedServer || Provider.modeConfigData.Barricades.Decay_Time == 0U || time < serversideData.objActiveDate || time - serversideData.objActiveDate < Provider.modeConfigData.Barricades.Decay_Time) && serversideData.barricade.asset.isSaveable)
				{
					num += 1;
				}
			}
			river.writeUInt16(num);
			foreach (BarricadeDrop barricadeDrop2 in region.drops)
			{
				BarricadeData serversideData2 = barricadeDrop2.serversideData;
				if ((!Dedicator.IsDedicatedServer || Provider.modeConfigData.Barricades.Decay_Time == 0U || time < serversideData2.objActiveDate || time - serversideData2.objActiveDate < Provider.modeConfigData.Barricades.Decay_Time) && serversideData2.barricade.asset.isSaveable)
				{
					river.writeGUID(barricadeDrop2.asset.GUID);
					river.writeUInt32(serversideData2.instanceID);
					river.writeUInt16(serversideData2.barricade.health);
					river.writeBytes(serversideData2.barricade.state);
					river.writeSingleVector3(serversideData2.point);
					river.writeSingleQuaternion(serversideData2.rotation);
					river.writeUInt64(serversideData2.owner);
					river.writeUInt64(serversideData2.group);
					river.writeUInt32(serversideData2.objActiveDate);
					river.writeByte((byte)barricadeDrop2.asset.build);
				}
			}
		}

		// Token: 0x0600302B RID: 12331 RVA: 0x000DED14 File Offset: 0x000DCF14
		public static PooledTransportConnectionList GatherClientConnections(byte x, byte y, ushort plant)
		{
			if (plant == 65535)
			{
				return Regions.GatherClientConnections(x, y, BarricadeManager.BARRICADE_REGIONS);
			}
			return Provider.GatherClientConnections();
		}

		// Token: 0x0600302C RID: 12332 RVA: 0x000DED30 File Offset: 0x000DCF30
		[Obsolete("Replaced by GatherClients")]
		public static IEnumerable<ITransportConnection> EnumerateClients(byte x, byte y, ushort plant)
		{
			return BarricadeManager.GatherClientConnections(x, y, plant);
		}

		// Token: 0x0600302D RID: 12333 RVA: 0x000DED3A File Offset: 0x000DCF3A
		public static PooledTransportConnectionList GatherRemoteClientConnections(byte x, byte y, ushort plant)
		{
			if (plant == 65535)
			{
				return Regions.GatherRemoteClientConnections(x, y, BarricadeManager.BARRICADE_REGIONS);
			}
			return Provider.GatherRemoteClientConnections();
		}

		// Token: 0x0600302E RID: 12334 RVA: 0x000DED56 File Offset: 0x000DCF56
		[Obsolete("Replaced by GatherRemoteClients")]
		public static IEnumerable<ITransportConnection> EnumerateClients_Remote(byte x, byte y, ushort plant)
		{
			return BarricadeManager.GatherRemoteClientConnections(x, y, plant);
		}

		// Token: 0x0600302F RID: 12335 RVA: 0x000DED60 File Offset: 0x000DCF60
		private static void DestroyAllInRegion(BarricadeRegion region)
		{
			if (region.drops.Count > 0)
			{
				region.DestroyAll();
			}
			if (region.isPendingDestroy)
			{
				region.isPendingDestroy = false;
				BarricadeManager.regionsPendingDestroy.RemoveFast(region);
			}
		}

		// Token: 0x06003030 RID: 12336 RVA: 0x000DED94 File Offset: 0x000DCF94
		internal void DestroyOrReleaseBarricade(ItemBarricadeAsset asset, GameObject instance)
		{
			Transform transform = instance.transform;
			EffectManager.ClearAttachments(transform);
			if (asset.eligibleForPooling)
			{
				if (transform.parent != null)
				{
					BarricadeManager.barricadeColliders.Clear();
					instance.GetComponentsInChildren<Collider>(BarricadeManager.barricadeColliders);
					foreach (Collider collider in BarricadeManager.barricadeColliders)
					{
						if (collider.gameObject.layer == 14)
						{
							collider.gameObject.layer = 27;
						}
					}
					InteractableVehicle component = transform.parent.GetComponent<InteractableVehicle>();
					if (component != null)
					{
						component.ignoreCollisionWith(BarricadeManager.barricadeColliders, false);
					}
				}
				instance.SetActive(false);
				transform.parent = null;
				int instanceID = asset.barricade.GetInstanceID();
				this.pool.GetOrAddNew(instanceID).Push(instance);
				return;
			}
			UnityEngine.Object.Destroy(instance);
		}

		// Token: 0x06003031 RID: 12337 RVA: 0x000DEE90 File Offset: 0x000DD090
		internal static void HandleInstantiation(ref PlaceableInstantiationParameters instantiation)
		{
			BarricadeRegion region = (BarricadeRegion)instantiation.region;
			if (BarricadeManager.instance.spawnBarricade(region, instantiation.assetId, instantiation.state, instantiation.position, instantiation.rotation, instantiation.hp, instantiation.owner, instantiation.group, instantiation.netId) != null)
			{
				NetInvocationDeferralRegistry.Invoke(instantiation.netId, 3U);
				return;
			}
			NetInvocationDeferralRegistry.Cancel(instantiation.netId, 3U);
		}

		// Token: 0x06003032 RID: 12338 RVA: 0x000DEF08 File Offset: 0x000DD108
		private void Update()
		{
			if (!Provider.isConnected)
			{
				return;
			}
			PlaceableInstantiationManager.ProcessPendingInstantiations();
			if (BarricadeManager.regionsPendingDestroy != null && BarricadeManager.regionsPendingDestroy.Count > 0)
			{
				this.destroyTimer.Restart();
				int num = 0;
				do
				{
					BarricadeRegion tail = BarricadeManager.regionsPendingDestroy.GetTail<BarricadeRegion>();
					if (tail.drops.Count > 0)
					{
						tail.DestroyTail();
						num++;
						if (tail.drops.Count < 1)
						{
							tail.isPendingDestroy = false;
							BarricadeManager.regionsPendingDestroy.RemoveTail<BarricadeRegion>();
						}
					}
					else
					{
						tail.isPendingDestroy = false;
						BarricadeManager.regionsPendingDestroy.RemoveTail<BarricadeRegion>();
					}
				}
				while (BarricadeManager.regionsPendingDestroy.Count > 0 && (this.destroyTimer.ElapsedMilliseconds < 1L || num < 10));
				this.destroyTimer.Stop();
			}
		}

		// Token: 0x04001953 RID: 6483
		private static Collider[] checkColliders = new Collider[2];

		/// <summary>
		/// Barricade asset's EBuild included in saves to fix state length problems. (public issue #3725)
		/// </summary>
		// Token: 0x04001954 RID: 6484
		public const byte SAVEDATA_VERSION_INCLUDE_BUILD_ENUM = 18;

		// Token: 0x04001955 RID: 6485
		public const byte SAVEDATA_VERSION_REPLACE_EULER_ANGLES_WITH_QUATERNION = 19;

		// Token: 0x04001956 RID: 6486
		private const byte SAVEDATA_VERSION_NEWEST = 19;

		// Token: 0x04001957 RID: 6487
		public static readonly byte SAVEDATA_VERSION = 19;

		// Token: 0x04001958 RID: 6488
		public static readonly byte BARRICADE_REGIONS = 2;

		// Token: 0x04001959 RID: 6489
		public static DeployBarricadeRequestHandler onDeployBarricadeRequested;

		// Token: 0x0400195A RID: 6490
		[Obsolete("Please use BarricadeDrop.OnSalvageRequested_Global instead")]
		public static SalvageBarricadeRequestHandler onSalvageBarricadeRequested;

		// Token: 0x0400195B RID: 6491
		public static DamageBarricadeRequestHandler onDamageBarricadeRequested;

		// Token: 0x0400195E RID: 6494
		[Obsolete("Please use InteractableFarm.OnHarvestRequested_Global instead")]
		public static SalvageBarricadeRequestHandler onHarvestPlantRequested;

		// Token: 0x0400195F RID: 6495
		public static BarricadeSpawnedHandler onBarricadeSpawned;

		// Token: 0x04001960 RID: 6496
		public static ModifySignRequestHandler onModifySignRequested;

		// Token: 0x04001961 RID: 6497
		public static OpenStorageRequestHandler onOpenStorageRequested;

		// Token: 0x04001962 RID: 6498
		public static TransformBarricadeRequestHandler onTransformRequested;

		// Token: 0x04001963 RID: 6499
		private static BarricadeManager manager;

		// Token: 0x04001964 RID: 6500
		public static byte version = BarricadeManager.SAVEDATA_VERSION;

		/// <summary>
		/// Writable list of vehicle regions. Public add/remove methods should not be necessary.
		/// </summary>
		// Token: 0x04001966 RID: 6502
		private static List<VehicleBarricadeRegion> internalVehicleRegions;

		// Token: 0x04001968 RID: 6504
		private static List<BarricadeRegion> backwardsCompatVehicleRegions;

		// Token: 0x04001969 RID: 6505
		private static List<BarricadeRegion> regionsPendingDestroy;

		// Token: 0x0400196A RID: 6506
		private static List<Collider> barricadeColliders;

		// Token: 0x0400196B RID: 6507
		private static uint instanceCount;

		// Token: 0x0400196C RID: 6508
		private static uint serverActiveDate;

		// Token: 0x0400196D RID: 6509
		private static readonly ClientStaticMethod<NetId> SendDestroyBarricade = ClientStaticMethod<NetId>.Get(new ClientStaticMethod<NetId>.ReceiveDelegateWithContext(BarricadeManager.ReceiveDestroyBarricade));

		// Token: 0x0400196E RID: 6510
		private static readonly ClientStaticMethod<byte, byte> SendClearRegionBarricades = ClientStaticMethod<byte, byte>.Get(new ClientStaticMethod<byte, byte>.ReceiveDelegate(BarricadeManager.ReceiveClearRegionBarricades));

		// Token: 0x0400196F RID: 6511
		private static List<Transform> tempTransforms = new List<Transform>();

		// Token: 0x04001970 RID: 6512
		private static readonly ClientStaticMethod<NetId, Guid, byte[], Vector3, Quaternion, ulong, ulong, NetId> SendSingleBarricade = ClientStaticMethod<NetId, Guid, byte[], Vector3, Quaternion, ulong, ulong, NetId>.Get(new ClientStaticMethod<NetId, Guid, byte[], Vector3, Quaternion, ulong, ulong, NetId>.ReceiveDelegateWithContext(BarricadeManager.ReceiveSingleBarricade));

		// Token: 0x04001971 RID: 6513
		private static readonly ClientStaticMethod SendMultipleBarricades = ClientStaticMethod.Get(new ClientStaticMethod.ReceiveDelegateWithContext(BarricadeManager.ReceiveMultipleBarricades));

		/// <summary>
		/// Maps prefab unique id to inactive list.
		/// </summary>
		// Token: 0x04001972 RID: 6514
		private Dictionary<int, Stack<GameObject>> pool;

		// Token: 0x04001973 RID: 6515
		private Stopwatch destroyTimer = new Stopwatch();

		// Token: 0x04001974 RID: 6516
		private const int MIN_DESTROY_PER_FRAME = 10;

		// Token: 0x04001975 RID: 6517
		internal const int POSITION_FRAC_BIT_COUNT = 11;

		/// <summary>
		/// Sending yaw only costs 1 bit (flag) plus yaw bits, so compared to the old 24-bit rotation we may as well
		/// make it high-precision. Quaternion mode uses 1+27 bits!
		/// </summary>
		// Token: 0x04001976 RID: 6518
		internal const int YAW_BIT_COUNT = 23;

		/// <summary>
		/// +0 = BarricadeDrop
		/// +1 = root transform
		/// +2 = Interactable (if exists)
		/// </summary>
		// Token: 0x04001977 RID: 6519
		internal const int NETIDS_PER_BARRICADE = 3;

		// Token: 0x02000A22 RID: 2594
		private struct SendMultipleBarricadesWriteParameters
		{
			// Token: 0x04003922 RID: 14626
			public BarricadeRegion region;

			// Token: 0x04003923 RID: 14627
			public int index;

			// Token: 0x04003924 RID: 14628
			public int count;

			// Token: 0x04003925 RID: 14629
			public float sortOrder;

			// Token: 0x04003926 RID: 14630
			public NetId parentNetId;

			// Token: 0x04003927 RID: 14631
			public byte packet;

			// Token: 0x04003928 RID: 14632
			public byte x;

			// Token: 0x04003929 RID: 14633
			public byte y;
		}
	}
}
