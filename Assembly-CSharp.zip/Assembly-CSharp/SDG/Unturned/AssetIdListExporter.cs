﻿using System;
using System.Collections.Generic;
using System.IO;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x0200029B RID: 667
	public static class AssetIdListExporter
	{
		// Token: 0x06001411 RID: 5137 RVA: 0x0004CC74 File Offset: 0x0004AE74
		public static void Export()
		{
			List<Asset> list = new List<Asset>();
			Assets.FindAssetsByType_UseDefaultAssetMapping<Asset>(list);
			string text = Path.Join(ReadWrite.PATH, "Extras", "AssetIDs");
			ReadWrite.createFolder(text, false);
			string text2 = Path.Join(text, "All Assets");
			ReadWrite.createFolder(text2, false);
			AssetIdListExporter.ExportAssetsToCsv(list, Path.Join(text2, "All Assets.csv"));
			AssetIdListExporter.ExportAssetsToCsvGroupedByLegacyCategory(text2, list);
			AssetIdListExporter.ExportAssetsToCsvGroupedByType(text2, list);
			foreach (AssetOrigin assetOrigin in Assets.assetOrigins)
			{
				if (!assetOrigin.assets.IsEmpty<Asset>())
				{
					string text3 = PathEx.ReplaceInvalidFileNameChars(assetOrigin.name, '_');
					if (string.IsNullOrEmpty(text3))
					{
						UnturnedLog.error("Unable to export origin " + assetOrigin.name + " Asset IDs because file name would be empty");
					}
					else
					{
						string text4 = Path.Join(text, text3);
						ReadWrite.createFolder(text4, false);
						string csvPath = Path.Join(text4, text3 + ".csv");
						AssetIdListExporter.ExportAssetsToCsv(assetOrigin.assets, csvPath);
						AssetIdListExporter.ExportAssetsToCsvGroupedByLegacyCategory(text4, assetOrigin.assets);
						AssetIdListExporter.ExportAssetsToCsvGroupedByType(text4, assetOrigin.assets);
					}
				}
			}
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0004CDE8 File Offset: 0x0004AFE8
		private static void ExportAssetsToCsvGroupedByLegacyCategory(string basePath, List<Asset> assets)
		{
			basePath = Path.Join(basePath, "Grouped by Legacy Category");
			ReadWrite.createFolder(basePath, false);
			foreach (KeyValuePair<EAssetType, List<Asset>> keyValuePair in AssetIdListExporter.GroupAssetsByLegacyCategory(assets))
			{
				string str = keyValuePair.Key.ToString();
				string csvPath = Path.Combine(basePath, str + ".csv");
				AssetIdListExporter.ExportAssetsToCsv(keyValuePair.Value, csvPath);
				string csvPath2 = Path.Combine(basePath, str + " Legacy ID Availability.csv");
				AssetIdListExporter.ExportLegacyIdAvailabilityToCsv(keyValuePair.Key, keyValuePair.Value, csvPath2);
			}
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x0004CEB0 File Offset: 0x0004B0B0
		private static void ExportAssetsToCsvGroupedByType(string basePath, List<Asset> assets)
		{
			basePath = Path.Join(basePath, "Grouped by Type");
			ReadWrite.createFolder(basePath, false);
			foreach (KeyValuePair<Type, List<Asset>> keyValuePair in AssetIdListExporter.GroupAssetsByType(assets))
			{
				string typeFriendlyName = keyValuePair.Value[0].GetTypeFriendlyName();
				string csvPath = Path.Combine(basePath, typeFriendlyName + ".csv");
				AssetIdListExporter.ExportAssetsToCsv(keyValuePair.Value, csvPath);
			}
		}

		// Token: 0x06001414 RID: 5140 RVA: 0x0004CF4C File Offset: 0x0004B14C
		private static Dictionary<EAssetType, List<Asset>> GroupAssetsByLegacyCategory(List<Asset> assets)
		{
			Dictionary<EAssetType, List<Asset>> dictionary = new Dictionary<EAssetType, List<Asset>>();
			foreach (Asset asset in assets)
			{
				EAssetType assetCategory = asset.assetCategory;
				List<Asset> list;
				if (!dictionary.TryGetValue(assetCategory, out list))
				{
					list = new List<Asset>();
					dictionary[assetCategory] = list;
				}
				list.Add(asset);
			}
			return dictionary;
		}

		// Token: 0x06001415 RID: 5141 RVA: 0x0004CFC4 File Offset: 0x0004B1C4
		private static Dictionary<Type, List<Asset>> GroupAssetsByType(List<Asset> assets)
		{
			Dictionary<Type, List<Asset>> dictionary = new Dictionary<Type, List<Asset>>();
			foreach (Asset asset in assets)
			{
				Type type = asset.GetType();
				List<Asset> list;
				if (!dictionary.TryGetValue(type, out list))
				{
					list = new List<Asset>();
					dictionary[type] = list;
				}
				list.Add(asset);
			}
			return dictionary;
		}

		// Token: 0x06001416 RID: 5142 RVA: 0x0004D03C File Offset: 0x0004B23C
		private static void ExportAssetsToCsv(IEnumerable<Asset> assets, string csvPath)
		{
			using (FileStream fileStream = new FileStream(csvPath, FileMode.Create, FileAccess.Write))
			{
				using (StreamWriter streamWriter = new StreamWriter(fileStream))
				{
					streamWriter.WriteLine("Name,GUID,Type,Origin,Legacy ID,Legacy Category");
					foreach (Asset asset in assets)
					{
						AssetIdListExporter.WriteEscapedString(streamWriter, asset.FriendlyName);
						streamWriter.Write(',');
						streamWriter.Write(asset.GUID.ToString("N"));
						streamWriter.Write(',');
						streamWriter.Write(asset.GetTypeFriendlyName());
						streamWriter.Write(',');
						AssetIdListExporter.WriteEscapedString(streamWriter, asset.GetOriginName());
						streamWriter.Write(',');
						streamWriter.Write((int)asset.id);
						streamWriter.Write(',');
						streamWriter.WriteLine(asset.assetCategory.ToString());
					}
				}
			}
		}

		// Token: 0x06001417 RID: 5143 RVA: 0x0004D154 File Offset: 0x0004B354
		private static void ExportLegacyIdAvailabilityToCsv(EAssetType legacyType, IEnumerable<Asset> assets, string csvPath)
		{
			Dictionary<int, List<Asset>> dictionary = new Dictionary<int, List<Asset>>();
			foreach (Asset asset in assets)
			{
				List<Asset> list;
				if (dictionary.TryGetValue((int)asset.id, out list))
				{
					list.Add(asset);
				}
				else
				{
					list = new List<Asset>
					{
						asset
					};
					dictionary.Add((int)asset.id, list);
				}
			}
			using (FileStream fileStream = new FileStream(csvPath, FileMode.Create, FileAccess.Write))
			{
				using (StreamWriter streamWriter = new StreamWriter(fileStream))
				{
					streamWriter.WriteLine("Legacy ID,Used By,Reserved for Vanilla");
					int num = 0;
					switch (legacyType)
					{
					case EAssetType.ITEM:
						num = 2000;
						break;
					case EAssetType.EFFECT:
						num = 200;
						break;
					case EAssetType.RESOURCE:
						num = 50;
						break;
					case EAssetType.ANIMAL:
						num = 50;
						break;
					case EAssetType.MYTHIC:
						num = 500;
						break;
					case EAssetType.SKIN:
						num = 2000;
						break;
					case EAssetType.NPC:
						num = 2000;
						break;
					}
					for (int i = 1; i <= 65535; i++)
					{
						streamWriter.Write(i);
						streamWriter.Write(',');
						List<Asset> list2;
						if (dictionary.TryGetValue(i, out list2))
						{
							string text = list2[0].FriendlyName;
							for (int j = 1; j < list2.Count; j++)
							{
								text += ", ";
								text += list2[j].FriendlyName;
							}
							AssetIdListExporter.WriteEscapedString(streamWriter, text);
						}
						else
						{
							streamWriter.Write("---");
						}
						streamWriter.Write(',');
						if (i < num)
						{
							if (legacyType == EAssetType.ITEM && (i == 786 || (i >= 1800 && i <= 1806)))
							{
								streamWriter.Write("Hawaii Overlap");
							}
							else
							{
								streamWriter.Write("Reserved");
							}
						}
						streamWriter.WriteLine();
					}
				}
			}
		}

		// Token: 0x06001418 RID: 5144 RVA: 0x0004D398 File Offset: 0x0004B598
		private static void WriteEscapedString(StreamWriter sw, string value)
		{
			sw.Write('"');
			foreach (char c in value)
			{
				if (c == '"')
				{
					sw.Write('"');
				}
				sw.Write(c);
			}
			sw.Write('"');
		}
	}
}
