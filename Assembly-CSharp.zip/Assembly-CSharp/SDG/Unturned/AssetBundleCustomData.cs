﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000620 RID: 1568
	[CreateAssetMenu(fileName = "AssetBundleCustomData", menuName = "Unturned/Asset Bundle Custom Data")]
	public class AssetBundleCustomData : ScriptableObject
	{
		/// <summary>
		/// If Unturned is loading this asset bundle from a Steam workshop file but the file ID does not match then
		/// loading will be canceled. Makes it somewhat harder to copy/re-upload without permission.
		/// </summary>
		// Token: 0x04001CB3 RID: 7347
		public ulong ownerWorkshopFileId;

		/// <summary>
		/// Same as ownerWorkshopFileId for cases where the asset bundle is allowed in multiple uploads.
		///
		/// Uploading the same asset bundle multiple times is not ideal because the game doesn't handle
		/// multiple of them with the same name well, and Unity logs an error if an asset bundle with the
		/// same files is already loaded. That being said, the game doesn't handle dependencies between
		/// workshop files well either (as of 2023-01-12), so this is perhaps the lesser of two evils.
		///
		/// My understanding is that some mod creators license their work to multiple servers that upload
		/// the files and this property will make it easier so it doesn't need to be re-exported multiple times.
		/// </summary>
		// Token: 0x04001CB4 RID: 7348
		public List<ulong> ownerWorkshopFileIds;
	}
}
