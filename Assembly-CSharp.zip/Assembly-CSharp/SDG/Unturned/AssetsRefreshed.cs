﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020002A0 RID: 672
	// (Invoke) Token: 0x06001434 RID: 5172
	public delegate void AssetsRefreshed();
}
