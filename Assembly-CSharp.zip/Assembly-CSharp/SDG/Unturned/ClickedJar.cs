﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007BF RID: 1983
	// (Invoke) Token: 0x06004433 RID: 17459
	public delegate void ClickedJar(SleekJars jars, int index);
}
