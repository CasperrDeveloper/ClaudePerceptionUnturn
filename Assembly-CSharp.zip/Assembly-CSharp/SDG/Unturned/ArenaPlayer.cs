﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005CB RID: 1483
	public class ArenaPlayer
	{
		// Token: 0x170009A0 RID: 2464
		// (get) Token: 0x060031EC RID: 12780 RVA: 0x000E8F3C File Offset: 0x000E713C
		public SteamPlayer steamPlayer
		{
			get
			{
				return this._steamPlayer;
			}
		}

		// Token: 0x170009A1 RID: 2465
		// (get) Token: 0x060031ED RID: 12781 RVA: 0x000E8F44 File Offset: 0x000E7144
		public bool hasDied
		{
			get
			{
				return this._hasDied;
			}
		}

		// Token: 0x060031EE RID: 12782 RVA: 0x000E8F4C File Offset: 0x000E714C
		private void onLifeUpdated(bool isDead)
		{
			if (isDead)
			{
				this._hasDied = true;
			}
		}

		// Token: 0x060031EF RID: 12783 RVA: 0x000E8F58 File Offset: 0x000E7158
		public ArenaPlayer(SteamPlayer newSteamPlayer)
		{
			this._steamPlayer = newSteamPlayer;
			this._hasDied = false;
			PlayerLife life = this.steamPlayer.player.life;
			life.onLifeUpdated = (LifeUpdated)Delegate.Combine(life.onLifeUpdated, new LifeUpdated(this.onLifeUpdated));
		}

		// Token: 0x04001AA6 RID: 6822
		private SteamPlayer _steamPlayer;

		// Token: 0x04001AA7 RID: 6823
		private bool _hasDied;

		/// <summary>
		/// Time.time damage was last dealt so that damage is applied once per second.
		/// </summary>
		// Token: 0x04001AA8 RID: 6824
		public float lastAreaDamage;

		/// <summary>
		/// Timer increased while taking damage, and reset to zero while inside zone.
		/// </summary>
		// Token: 0x04001AA9 RID: 6825
		public float timeOutsideArea;
	}
}
