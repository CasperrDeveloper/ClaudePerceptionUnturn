﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020004D3 RID: 1235
	public class ActionBlueprint
	{
		/// <summary>
		/// Index into Blueprints list. -1 means blueprint name is used instead.
		/// </summary>
		// Token: 0x1700082D RID: 2093
		// (get) Token: 0x060028CF RID: 10447 RVA: 0x000B1C9B File Offset: 0x000AFE9B
		public int Index
		{
			get
			{
				return this.index;
			}
		}

		/// <summary>
		/// Name to look for in Blueprints list.
		/// </summary>
		// Token: 0x1700082E RID: 2094
		// (get) Token: 0x060028D0 RID: 10448 RVA: 0x000B1CA3 File Offset: 0x000AFEA3
		public string BlueprintName
		{
			get
			{
				return this.blueprintName;
			}
		}

		// Token: 0x1700082F RID: 2095
		// (get) Token: 0x060028D1 RID: 10449 RVA: 0x000B1CAB File Offset: 0x000AFEAB
		public bool isLink
		{
			get
			{
				return this._isLink;
			}
		}

		// Token: 0x060028D2 RID: 10450 RVA: 0x000B1CB3 File Offset: 0x000AFEB3
		public Blueprint FindBlueprint(IBlueprintOwner blueprintOwner)
		{
			if (this.index >= 0)
			{
				return blueprintOwner.GetBlueprintByIndex(this.index);
			}
			if (!string.IsNullOrEmpty(this.blueprintName))
			{
				return blueprintOwner.FindBlueprintByName(this.blueprintName);
			}
			return null;
		}

		// Token: 0x060028D3 RID: 10451 RVA: 0x000B1CE6 File Offset: 0x000AFEE6
		public override string ToString()
		{
			return string.Format("(Index: {0} Name: {1} Link: {2})", this.index, this.blueprintName, this._isLink);
		}

		// Token: 0x060028D4 RID: 10452 RVA: 0x000B1D0E File Offset: 0x000AFF0E
		public ActionBlueprint(int newIndex, bool newLink)
		{
			this.index = newIndex;
			this._isLink = newLink;
		}

		// Token: 0x17000830 RID: 2096
		// (get) Token: 0x060028D5 RID: 10453 RVA: 0x000B1D24 File Offset: 0x000AFF24
		[Obsolete("Renamed to Index")]
		public byte id
		{
			get
			{
				return (byte)this.index;
			}
		}

		// Token: 0x04001475 RID: 5237
		internal int index;

		// Token: 0x04001476 RID: 5238
		internal string blueprintName;

		// Token: 0x04001477 RID: 5239
		internal bool _isLink;
	}
}
