﻿using System;

namespace SDG.Unturned
{
	// Token: 0x02000775 RID: 1909
	public class ArenaLoadout
	{
		// Token: 0x0400289A RID: 10394
		public ushort Table_ID;

		// Token: 0x0400289B RID: 10395
		public ushort Amount;
	}
}
