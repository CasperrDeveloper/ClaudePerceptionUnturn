﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	/// <summary>
	/// Allow Unity events to forcefully remove any barricades inside a sphere.
	/// </summary>
	// Token: 0x02000621 RID: 1569
	[AddComponentMenu("Unturned/Barricade Destroyer")]
	public class BarricadeDestroyerComponent : MonoBehaviour
	{
		// Token: 0x060035BA RID: 13754 RVA: 0x000FF89A File Offset: 0x000FDA9A
		public void Apply()
		{
			if (!Provider.isServer)
			{
				return;
			}
			BarricadeManager.DestroyBarricadesInSphere(base.transform.position, this.Radius, this.PlayEffect, this.SpawnItems);
		}

		// Token: 0x04001CB5 RID: 7349
		[Tooltip("Barricades whose pivot points are within this radius will be removed.")]
		public float Radius;

		// Token: 0x04001CB6 RID: 7350
		[Tooltip("If true, barricade's Explosion effect is played.")]
		public bool PlayEffect = true;

		// Token: 0x04001CB7 RID: 7351
		[Tooltip("If true, barricade's Item_Dropped_On_Destroy is spawned. (Different from stored items.)")]
		public bool SpawnItems = true;
	}
}
