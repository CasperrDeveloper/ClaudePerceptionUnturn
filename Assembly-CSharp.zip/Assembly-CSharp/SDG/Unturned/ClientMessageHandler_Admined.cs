﻿using System;
using SDG.NetPak;

namespace SDG.Unturned
{
	// Token: 0x02000275 RID: 629
	internal static class ClientMessageHandler_Admined
	{
		// Token: 0x060012F8 RID: 4856 RVA: 0x00044C40 File Offset: 0x00042E40
		internal static void ReadMessage(NetPakReader reader)
		{
			byte b;
			reader.ReadUInt8(out b);
			SteamPlayer steamPlayer = PlayerTool.findSteamPlayerByChannel((int)b);
			if (steamPlayer != null)
			{
				steamPlayer.isAdmin = true;
				return;
			}
			UnturnedLog.error("Admined unable to find channel {0}", new object[]
			{
				b
			});
		}
	}
}
