﻿using System;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x02000590 RID: 1424
	internal class BarricadeRefComponent : MonoBehaviour, IExplosionDamageable, IEquatable<IExplosionDamageable>, ICraftingTagProvider, IOwnershipInfo
	{
		// Token: 0x06002F2E RID: 12078 RVA: 0x000D9D39 File Offset: 0x000D7F39
		public bool Equals(IExplosionDamageable obj)
		{
			return this == obj;
		}

		// Token: 0x1700097D RID: 2429
		// (get) Token: 0x06002F2F RID: 12079 RVA: 0x000D9D40 File Offset: 0x000D7F40
		public bool IsEligibleForExplosionDamage
		{
			get
			{
				BarricadeDrop barricadeDrop = this.tempNotSureIfBarricadeShouldBeAComponentYet;
				if (barricadeDrop != null)
				{
					ItemBarricadeAsset asset = barricadeDrop.asset;
					if (asset != null && !asset.proofExplosion)
					{
						return true;
					}
				}
				return false;
			}
		}

		// Token: 0x06002F30 RID: 12080 RVA: 0x000D9D6C File Offset: 0x000D7F6C
		public Vector3 GetClosestPointToExplosion(Vector3 explosionCenter)
		{
			return CollisionUtil.ClosestPoint(base.gameObject, explosionCenter, false, -4194305);
		}

		// Token: 0x06002F31 RID: 12081 RVA: 0x000D9D80 File Offset: 0x000D7F80
		public void ApplyExplosionDamage(in ExplosionParameters explosionParameters, ref ExplosionDamageParameters damageParameters)
		{
			if (!damageParameters.shouldAffectBarricades)
			{
				return;
			}
			Vector3 a = damageParameters.closestPoint - explosionParameters.point;
			float magnitude = a.magnitude;
			if (magnitude > explosionParameters.damageRadius)
			{
				return;
			}
			Vector3 direction = a / magnitude;
			RaycastHit raycastHit;
			if (damageParameters.LineOfSightTest(explosionParameters.point, direction, magnitude, out raycastHit) && raycastHit.transform != null && !raycastHit.transform.IsChildOf(base.transform))
			{
				return;
			}
			BarricadeManager.damage(base.transform, explosionParameters.barricadeDamage, 1f - magnitude / explosionParameters.damageRadius, true, explosionParameters.killer, explosionParameters.damageOrigin);
		}

		// Token: 0x06002F32 RID: 12082 RVA: 0x000D9E24 File Offset: 0x000D8024
		public Asset GetTagProviderAsset()
		{
			BarricadeDrop barricadeDrop = this.tempNotSureIfBarricadeShouldBeAComponentYet;
			if (barricadeDrop == null)
			{
				return null;
			}
			return barricadeDrop.asset;
		}

		// Token: 0x06002F33 RID: 12083 RVA: 0x000D9E38 File Offset: 0x000D8038
		public void GetAvailableTags(ref CraftingTagProviderGetAvailableTagsParameters p)
		{
			BarricadeDrop barricadeDrop = this.tempNotSureIfBarricadeShouldBeAComponentYet;
			ItemPlaceableAsset itemPlaceableAsset = (barricadeDrop != null) ? barricadeDrop.asset : null;
			if (itemPlaceableAsset != null && itemPlaceableAsset.PlaceableProvidedCraftingTags != null)
			{
				for (int i = 0; i < itemPlaceableAsset.PlaceableProvidedCraftingTags.Length; i++)
				{
					TagAsset tagAsset = itemPlaceableAsset.PlaceableProvidedCraftingTags[i].Get<TagAsset>();
					if (tagAsset != null)
					{
						p.ResultTags.Add(tagAsset);
					}
				}
			}
			if (this.modHook != null)
			{
				p.ApplyModHooks(this.modHook);
			}
		}

		// Token: 0x06002F34 RID: 12084 RVA: 0x000D9EB4 File Offset: 0x000D80B4
		public bool HasAnyCraftingTagsConfigured()
		{
			if (!(this.modHook != null))
			{
				BarricadeDrop barricadeDrop = this.tempNotSureIfBarricadeShouldBeAComponentYet;
				int? num;
				if (barricadeDrop == null)
				{
					num = null;
				}
				else
				{
					ItemBarricadeAsset asset = barricadeDrop.asset;
					num = ((asset != null) ? new bool?(asset.PlaceableProvidedCraftingTags.IsNullOrEmpty()) : null);
				}
				return (num ?? 1) == 0;
			}
			return true;
		}

		// Token: 0x06002F35 RID: 12085 RVA: 0x000D9F20 File Offset: 0x000D8120
		public bool Equals(ICraftingTagProvider obj)
		{
			return this == obj;
		}

		// Token: 0x06002F36 RID: 12086 RVA: 0x000D9F28 File Offset: 0x000D8128
		public bool TryGetOwnership(out ulong ownerUser, out ulong ownerGroup)
		{
			BarricadeDrop barricadeDrop = this.tempNotSureIfBarricadeShouldBeAComponentYet;
			BarricadeData barricadeData = (barricadeDrop != null) ? barricadeDrop.GetServersideData() : null;
			if (barricadeData != null)
			{
				ownerUser = barricadeData.owner;
				ownerGroup = barricadeData.group;
				return true;
			}
			ownerUser = 0UL;
			ownerGroup = 0UL;
			return false;
		}

		// Token: 0x06002F37 RID: 12087 RVA: 0x000D9F66 File Offset: 0x000D8166
		private void Start()
		{
			this.modHook = base.GetComponent<CraftingTagProviderComponent>();
		}

		// Token: 0x06002F39 RID: 12089 RVA: 0x000D9F7C File Offset: 0x000D817C
		void IExplosionDamageable.ApplyExplosionDamage(in ExplosionParameters explosionParameters, ref ExplosionDamageParameters damageParameters)
		{
			this.ApplyExplosionDamage(explosionParameters, ref damageParameters);
		}

		// Token: 0x04001943 RID: 6467
		internal BarricadeDrop tempNotSureIfBarricadeShouldBeAComponentYet;

		// Token: 0x04001944 RID: 6468
		private CraftingTagProviderComponent modHook;
	}
}
