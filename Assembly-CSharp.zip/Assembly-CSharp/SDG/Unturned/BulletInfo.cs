﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000897 RID: 2199
	public class BulletInfo
	{
		/// <summary>
		/// Only available on the server. For use by plugins developers who want to analyze deviation between approximate
		/// start direction and final hit position using <see cref="E:SDG.Unturned.UseableGun.onBulletSpawned" /> and <see cref="E:SDG.Unturned.UseableGun.onBulletHit" />
		/// per public issue #4450. Note that origin and direction on server are not necessarily exactly the same as on
		/// the client for a variety of reasons, including that bullets on the client can be spawned between simulation
		/// frames when the aim direction was different. (Aim direction is updated every drawn frame on the client as
		/// opposed to every simulation frame on the server.) Rather than kicking for one particularly large deviation
		/// we would recommend tracking stats for each shot's actual deviation vs max theoretical deviation. Remember
		/// to account for bullet drop and that aim spread is relative to this direction. (For example, a shotgun may
		/// fire ~8 pellets in a cone around this direction.) Note also that in third-person the bullet can turn up to
		/// 90 degrees from the aim direction if the camera is up against a wall.
		/// </summary>
		// Token: 0x17000D14 RID: 3348
		// (get) Token: 0x06004D99 RID: 19865 RVA: 0x001D1BC5 File Offset: 0x001CFDC5
		// (set) Token: 0x06004D9A RID: 19866 RVA: 0x001D1BCD File Offset: 0x001CFDCD
		public Vector3 ApproximatePlayerAimDirection { get; internal set; }

		// Token: 0x17000D15 RID: 3349
		// (get) Token: 0x06004D9B RID: 19867 RVA: 0x001D1BD6 File Offset: 0x001CFDD6
		// (set) Token: 0x06004D9C RID: 19868 RVA: 0x001D1BDE File Offset: 0x001CFDDE
		public Vector3 position { get; internal set; }

		// Token: 0x17000D16 RID: 3350
		// (get) Token: 0x06004D9D RID: 19869 RVA: 0x001D1BE7 File Offset: 0x001CFDE7
		// (set) Token: 0x06004D9E RID: 19870 RVA: 0x001D1BEF File Offset: 0x001CFDEF
		public Vector3 velocity { get; internal set; }

		// Token: 0x06004D9F RID: 19871 RVA: 0x001D1BF8 File Offset: 0x001CFDF8
		public Vector3 GetDirection()
		{
			return this.velocity.normalized;
		}

		/// <summary>
		/// Starting position when the bullet was fired.
		/// </summary>
		// Token: 0x0400337F RID: 13183
		public Vector3 origin;

		// Token: 0x04003383 RID: 13187
		public byte steps;

		// Token: 0x04003384 RID: 13188
		public float quality;

		// Token: 0x04003385 RID: 13189
		public byte pellet;

		// Token: 0x04003386 RID: 13190
		public ushort dropID;

		// Token: 0x04003387 RID: 13191
		public byte dropAmount;

		// Token: 0x04003388 RID: 13192
		public byte dropQuality;

		// Token: 0x04003389 RID: 13193
		public ItemBarrelAsset barrelAsset;

		// Token: 0x0400338A RID: 13194
		public ItemMagazineAsset magazineAsset;

		/// <summary>
		/// Combination of gun and attachments' bullet gravity multipliers.
		/// </summary>
		// Token: 0x0400338B RID: 13195
		internal float gravityMultiplier = 1f;
	}
}
