﻿using System;
using System.Collections.Generic;
using SDG.Framework.Devkit;
using SDG.Framework.Utilities;
using UnityEngine;
using UnityEngine.Profiling;

namespace SDG.Unturned
{
	// Token: 0x02000160 RID: 352
	public class AirdropDevkitNodeSystem : TempNodeSystemBase
	{
		// Token: 0x060008E3 RID: 2275 RVA: 0x00021D95 File Offset: 0x0001FF95
		public static AirdropDevkitNodeSystem Get()
		{
			return AirdropDevkitNodeSystem.instance;
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x00021D9C File Offset: 0x0001FF9C
		public IReadOnlyList<AirdropDevkitNode> GetAllNodes()
		{
			return this.allNodes;
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x00021DA4 File Offset: 0x0001FFA4
		internal override Type GetComponentType()
		{
			return typeof(AirdropDevkitNode);
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x00021DB0 File Offset: 0x0001FFB0
		internal override IEnumerable<GameObject> EnumerateGameObjects()
		{
			foreach (AirdropDevkitNode airdropDevkitNode in this.allNodes)
			{
				yield return airdropDevkitNode.gameObject;
			}
			List<AirdropDevkitNode>.Enumerator enumerator = default(List<AirdropDevkitNode>.Enumerator);
			yield break;
			yield break;
		}

		// Token: 0x060008E7 RID: 2279 RVA: 0x00021DC0 File Offset: 0x0001FFC0
		internal void AddNode(AirdropDevkitNode node)
		{
			this.allNodes.Add(node);
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x00021DCE File Offset: 0x0001FFCE
		internal void RemoveNode(AirdropDevkitNode node)
		{
			this.allNodes.RemoveFast(node);
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x00021DDD File Offset: 0x0001FFDD
		internal AirdropDevkitNodeSystem()
		{
			AirdropDevkitNodeSystem.instance = this;
			this.allNodes = new List<AirdropDevkitNode>();
			this.gizmoUpdateSampler = CustomSampler.Create("AirdropDevkitNodeSystem.UpdateGizmos", false);
			TimeUtility.updated += this.OnUpdateGizmos;
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x00021E18 File Offset: 0x00020018
		private void OnUpdateGizmos()
		{
			if (!SpawnpointSystemV2.Get().IsVisible || !Level.isEditor)
			{
				return;
			}
			foreach (AirdropDevkitNode airdropDevkitNode in this.allNodes)
			{
				Color color = airdropDevkitNode.isSelected ? Color.yellow : Color.red;
				RuntimeGizmos.Get().Arrow(airdropDevkitNode.transform.position + airdropDevkitNode.transform.up * 32f, -airdropDevkitNode.transform.up, 32f, color, 0f, EGizmoLayer.World);
			}
		}

		// Token: 0x040003A3 RID: 931
		private static AirdropDevkitNodeSystem instance;

		// Token: 0x040003A4 RID: 932
		private List<AirdropDevkitNode> allNodes;

		// Token: 0x040003A5 RID: 933
		private CustomSampler gizmoUpdateSampler;
	}
}
