﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200060E RID: 1550
	// (Invoke) Token: 0x06003532 RID: 13618
	public delegate void CharacterUpdated(byte index, Character character);
}
