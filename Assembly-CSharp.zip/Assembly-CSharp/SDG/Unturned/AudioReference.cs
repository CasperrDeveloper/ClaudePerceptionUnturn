﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002A6 RID: 678
	public struct AudioReference
	{
		// Token: 0x060014BD RID: 5309 RVA: 0x000511BD File Offset: 0x0004F3BD
		public AudioReference(string assetBundleName, string path)
		{
			this.assetBundleName = assetBundleName;
			this.path = path;
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x060014BE RID: 5310 RVA: 0x000511CD File Offset: 0x0004F3CD
		public bool IsNullOrEmpty
		{
			get
			{
				return string.IsNullOrEmpty(this.assetBundleName) || string.IsNullOrEmpty(this.path);
			}
		}

		// Token: 0x060014BF RID: 5311 RVA: 0x000511EC File Offset: 0x0004F3EC
		public AudioClip LoadAudioClip(out float volumeMultiplier, out float pitchMultiplier)
		{
			volumeMultiplier = 1f;
			pitchMultiplier = 1f;
			AudioClip audioClip;
			if (this.IsNullOrEmpty)
			{
				audioClip = null;
			}
			else
			{
				MasterBundleConfig masterBundleConfig = Assets.findMasterBundleByName(this.assetBundleName, true);
				if (masterBundleConfig == null || masterBundleConfig.assetBundle == null)
				{
					UnturnedLog.warn("Unable to find master bundle '{0}' when loading audio reference '{1}'", new object[]
					{
						this.assetBundleName,
						this.path
					});
					audioClip = null;
				}
				else
				{
					string text = masterBundleConfig.FormatAssetPathAndCache(this.path);
					if (text.EndsWith(".asset"))
					{
						OneShotAudioDefinition oneShotAudioDefinition = masterBundleConfig.assetBundle.LoadAsset<OneShotAudioDefinition>(text);
						if (oneShotAudioDefinition == null)
						{
							UnturnedLog.warn("Failed to load audio def '{0}' from master bundle '{1}'", new object[]
							{
								text,
								this.assetBundleName
							});
							audioClip = null;
						}
						else
						{
							volumeMultiplier = oneShotAudioDefinition.volumeMultiplier;
							pitchMultiplier = UnityEngine.Random.Range(oneShotAudioDefinition.minPitch, oneShotAudioDefinition.maxPitch);
							audioClip = oneShotAudioDefinition.GetRandomClip();
						}
					}
					else
					{
						audioClip = masterBundleConfig.assetBundle.LoadAsset<AudioClip>(text);
						if (audioClip == null)
						{
							UnturnedLog.warn("Failed to load audio clip '{0}' from master bundle '{1}'", new object[]
							{
								text,
								this.assetBundleName
							});
						}
					}
				}
			}
			return audioClip;
		}

		// Token: 0x04000765 RID: 1893
		private string assetBundleName;

		// Token: 0x04000766 RID: 1894
		private string path;
	}
}
