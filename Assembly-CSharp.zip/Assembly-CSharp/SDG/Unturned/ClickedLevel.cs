﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007C1 RID: 1985
	// (Invoke) Token: 0x06004439 RID: 17465
	public delegate void ClickedLevel(SleekLevel level, byte index);
}
