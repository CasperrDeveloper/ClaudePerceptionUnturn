﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005A0 RID: 1440
	public class BeaconManager : MonoBehaviour
	{
		// Token: 0x06003049 RID: 12361 RVA: 0x000DF230 File Offset: 0x000DD430
		public static int getParticipants(byte nav)
		{
			int num = 0;
			for (int i = 0; i < Provider.clients.Count; i++)
			{
				SteamPlayer steamPlayer = Provider.clients[i];
				if (!(steamPlayer.player == null) && !(steamPlayer.player.movement == null) && !(steamPlayer.player.life == null) && !steamPlayer.player.life.isDead && steamPlayer.player.movement.nav == nav)
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x0600304A RID: 12362 RVA: 0x000DF2BE File Offset: 0x000DD4BE
		public static InteractableBeacon checkBeacon(byte nav)
		{
			if (BeaconManager.beacons[(int)nav].Count > 0)
			{
				return BeaconManager.beacons[(int)nav][0];
			}
			return null;
		}

		// Token: 0x0600304B RID: 12363 RVA: 0x000DF2DE File Offset: 0x000DD4DE
		public static void registerBeacon(byte nav, InteractableBeacon beacon)
		{
			if (!LevelNavigation.checkSafe(nav))
			{
				return;
			}
			BeaconManager.beacons[(int)nav].Add(beacon);
			BeaconUpdated beaconUpdated = BeaconManager.onBeaconUpdated;
			if (beaconUpdated == null)
			{
				return;
			}
			beaconUpdated(nav, BeaconManager.beacons[(int)nav].Count > 0);
		}

		// Token: 0x0600304C RID: 12364 RVA: 0x000DF315 File Offset: 0x000DD515
		public static void deregisterBeacon(byte nav, InteractableBeacon beacon)
		{
			if (!LevelNavigation.checkSafe(nav))
			{
				return;
			}
			BeaconManager.beacons[(int)nav].Remove(beacon);
			BeaconUpdated beaconUpdated = BeaconManager.onBeaconUpdated;
			if (beaconUpdated == null)
			{
				return;
			}
			beaconUpdated(nav, BeaconManager.beacons[(int)nav].Count > 0);
		}

		// Token: 0x0600304D RID: 12365 RVA: 0x000DF350 File Offset: 0x000DD550
		private void onLevelLoaded(int level)
		{
			if (LevelNavigation.bounds == null)
			{
				return;
			}
			BeaconManager.beacons = new List<InteractableBeacon>[LevelNavigation.bounds.Count];
			for (int i = 0; i < BeaconManager.beacons.Length; i++)
			{
				BeaconManager.beacons[i] = new List<InteractableBeacon>();
			}
		}

		// Token: 0x0600304E RID: 12366 RVA: 0x000DF397 File Offset: 0x000DD597
		private void Start()
		{
			Level.onPrePreLevelLoaded = (PrePreLevelLoaded)Delegate.Combine(Level.onPrePreLevelLoaded, new PrePreLevelLoaded(this.onLevelLoaded));
		}

		// Token: 0x04001980 RID: 6528
		private static List<InteractableBeacon>[] beacons;

		// Token: 0x04001981 RID: 6529
		public static BeaconUpdated onBeaconUpdated;
	}
}
