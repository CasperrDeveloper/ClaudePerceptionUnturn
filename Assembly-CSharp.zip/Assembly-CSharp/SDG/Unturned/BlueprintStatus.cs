﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	/// <summary>
	/// Represents whether a player can craft a provided blueprint. If yes, which items to use, if no, why not.
	/// Previously, some of this data was (confusingly) stored in the blueprint definition.
	/// For performance, caller should re-use a list of BlueprintStatus and *not* discard unused results.
	/// </summary>
	// Token: 0x020004D7 RID: 1239
	internal class BlueprintStatus
	{
		// Token: 0x17000853 RID: 2131
		// (get) Token: 0x06002922 RID: 10530 RVA: 0x000B2794 File Offset: 0x000B0994
		public bool IsCraftable
		{
			get
			{
				return !this.isMissingRequiredSkill && this.missingCraftingTagsCount <= 0 && !this.isMissingAnyNpcConditions && !this.isMissingTargetItem && this.totalMissingInputItemsCount <= 0 && !this.isMissingAnyCriticalInputItem;
			}
		}

		/// <summary>
		/// Currently only used by housing planner.
		/// Doesn't work with NPC conditions / rewards.
		/// </summary>
		// Token: 0x06002923 RID: 10531 RVA: 0x000B27CC File Offset: 0x000B09CC
		public int EstimateMaxCraftingRepeatCount()
		{
			if (!this.IsCraftable)
			{
				return 0;
			}
			int num = -1;
			for (int i = 0; i < this.blueprint.supplies.Length; i++)
			{
				BlueprintSupply blueprintSupply = this.blueprint.supplies[i];
				BlueprintInputItemStatus blueprintInputItemStatus = this.inputItems[i];
				if (blueprintSupply.ShouldConsume)
				{
					int num2 = blueprintInputItemStatus.totalAmount / blueprintSupply.amount;
					if (num == -1)
					{
						num = num2;
					}
					else
					{
						num = Mathf.Min(num, num2);
					}
				}
			}
			return Mathf.Max(0, num);
		}

		/// <summary>
		/// Currently only used by housing planner.
		/// Doesn't work with NPC conditions / rewards.
		/// </summary>
		// Token: 0x06002924 RID: 10532 RVA: 0x000B2848 File Offset: 0x000B0A48
		public int EstimateOutputMaxAmount(int outputIndex)
		{
			if (outputIndex < 0 || this.blueprint.outputs == null || outputIndex >= this.blueprint.outputs.Length)
			{
				return 0;
			}
			return this.blueprint.outputs[outputIndex].amount * this.EstimateMaxCraftingRepeatCount();
		}

		// Token: 0x06002925 RID: 10533 RVA: 0x000B2888 File Offset: 0x000B0A88
		internal void UpdateCraftabilityScore()
		{
			this.normalizedCraftability = 1f;
			if (!this.blueprint.supplies.IsNullOrEmpty())
			{
				for (int i = 0; i < this.blueprint.supplies.Length; i++)
				{
					BlueprintSupply blueprintSupply = this.blueprint.supplies[i];
					BlueprintInputItemStatus blueprintInputItemStatus = this.inputItems[i];
					if (blueprintInputItemStatus.isMissingRequiredAmount)
					{
						float t = Mathf.Clamp01((float)blueprintInputItemStatus.totalAmount / (float)blueprintSupply.amount);
						this.normalizedCraftability *= Mathf.Lerp(0.1f, 1f, t);
					}
				}
			}
			if (this.blueprint.TargetItem != null && this.targetStatus.isMissingRequiredAmount)
			{
				float t2 = Mathf.Clamp01((float)this.targetStatus.totalAmount / (float)this.blueprint.TargetItem.amount);
				this.normalizedCraftability *= Mathf.Lerp(0.1f, 1f, t2);
			}
			if (this.isMissingRequiredSkill)
			{
				this.normalizedCraftability *= 0.1f;
			}
			if (this.missingCraftingTagsCount > 0)
			{
				CachingAssetRef[] applicableRequiredNearbyCraftingTags = this.blueprint.GetApplicableRequiredNearbyCraftingTags();
				float t3 = (float)this.missingCraftingTagsCount / (float)applicableRequiredNearbyCraftingTags.Length;
				this.normalizedCraftability *= Mathf.Lerp(1f, 0.1f, t3);
			}
			if (this.isMissingAnyNpcConditions)
			{
				this.normalizedCraftability *= 0.1f;
			}
		}

		// Token: 0x06002926 RID: 10534 RVA: 0x000B29F3 File Offset: 0x000B0BF3
		public void Reset()
		{
			this.isMissingRequiredSkill = false;
			this.missingCraftingTagsCount = 0;
			this.ResetDynamicStatus();
		}

		/// <summary>
		/// Reset values set by PlayerCrafting.UpdateBlueprintDynamicStatus.
		/// </summary>
		// Token: 0x06002927 RID: 10535 RVA: 0x000B2A0C File Offset: 0x000B0C0C
		public void ResetDynamicStatus()
		{
			this.isMissingAnyNpcConditions = false;
			this.isMissingTargetItem = false;
			this.totalMissingInputItemsCount = 0;
			this.isMissingAnyCriticalInputItem = false;
			this.hasAnyInputItem = false;
			BlueprintStatus.inputItemsPool.AddRange(this.inputItems);
			this.inputItems.Clear();
			if (this.targetStatus != null)
			{
				BlueprintStatus.inputItemsPool.Add(this.targetStatus);
				this.targetStatus = null;
			}
		}

		// Token: 0x06002928 RID: 10536 RVA: 0x000B2A78 File Offset: 0x000B0C78
		public BlueprintInputItemStatus AddInputItem()
		{
			BlueprintInputItemStatus blueprintInputItemStatus = this.CreateInputItemStatus();
			this.inputItems.Add(blueprintInputItemStatus);
			return blueprintInputItemStatus;
		}

		// Token: 0x06002929 RID: 10537 RVA: 0x000B2A99 File Offset: 0x000B0C99
		public BlueprintInputItemStatus AddTargetItem()
		{
			this.targetStatus = this.CreateInputItemStatus();
			return this.targetStatus;
		}

		// Token: 0x0600292A RID: 10538 RVA: 0x000B2AB0 File Offset: 0x000B0CB0
		internal void GetPreviewOutputTransferState(ItemAsset outputItemAsset, out byte quality, out byte[] state)
		{
			if (this.blueprint.withoutAttachments)
			{
				quality = 100;
				state = new byte[18];
				return;
			}
			Item item = null;
			if (this.inputItems.Count > 0 && this.inputItems[0].searchResults.Count > 0)
			{
				item = this.inputItems[0].FirstItemOrNull;
			}
			if (item != null)
			{
				quality = item.quality;
				state = new byte[item.state.Length];
				item.state.CopyTo(state, 0);
				return;
			}
			quality = 100;
			ItemAsset itemAsset = null;
			if (!this.blueprint.supplies.IsNullOrEmpty())
			{
				itemAsset = this.blueprint.supplies[0].FindItemAsset();
			}
			if (itemAsset != null)
			{
				state = itemAsset.getState();
				return;
			}
			state = outputItemAsset.getState();
		}

		// Token: 0x0600292B RID: 10539 RVA: 0x000B2B7C File Offset: 0x000B0D7C
		private BlueprintInputItemStatus CreateInputItemStatus()
		{
			BlueprintInputItemStatus blueprintInputItemStatus;
			if (BlueprintStatus.inputItemsPool.Count > 0)
			{
				blueprintInputItemStatus = BlueprintStatus.inputItemsPool.GetAndRemoveTail<BlueprintInputItemStatus>();
				blueprintInputItemStatus.searchResults.Clear();
			}
			else
			{
				blueprintInputItemStatus = new BlueprintInputItemStatus
				{
					searchResults = new List<PlayerInventorySearchResultV2>()
				};
			}
			blueprintInputItemStatus.totalAmount = 0;
			blueprintInputItemStatus.requiredAmountOverride = 0;
			blueprintInputItemStatus.isMissingRequiredAmount = false;
			return blueprintInputItemStatus;
		}

		// Token: 0x04001496 RID: 5270
		public Blueprint blueprint;

		// Token: 0x04001497 RID: 5271
		public List<BlueprintInputItemStatus> inputItems = new List<BlueprintInputItemStatus>();

		// Token: 0x04001498 RID: 5272
		public BlueprintInputItemStatus targetStatus;

		// Token: 0x04001499 RID: 5273
		public bool isMissingRequiredSkill;

		/// <summary>
		/// Total number of missing required nearby crafting tags.
		/// </summary>
		// Token: 0x0400149A RID: 5274
		public int missingCraftingTagsCount;

		// Token: 0x0400149B RID: 5275
		public bool isMissingAnyNpcConditions;

		// Token: 0x0400149C RID: 5276
		public bool isMissingTargetItem;

		/// <summary>
		/// Total required input item count minus available input item count.
		/// </summary>
		// Token: 0x0400149D RID: 5277
		public int totalMissingInputItemsCount;

		// Token: 0x0400149E RID: 5278
		public bool isMissingAnyCriticalInputItem;

		// Token: 0x0400149F RID: 5279
		public bool hasAnyInputItem;

		/// <summary>
		/// Used to sort blueprints from "most craftable" (1) to "least craftable" (0).
		/// </summary>
		// Token: 0x040014A0 RID: 5280
		public float normalizedCraftability;

		// Token: 0x040014A1 RID: 5281
		private static List<BlueprintInputItemStatus> inputItemsPool = new List<BlueprintInputItemStatus>();
	}
}
