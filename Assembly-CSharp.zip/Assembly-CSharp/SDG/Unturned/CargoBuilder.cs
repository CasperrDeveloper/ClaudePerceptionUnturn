﻿using System;
using System.Collections.Generic;
using Unturned.SystemEx;

namespace SDG.Unturned
{
	// Token: 0x020002AF RID: 687
	internal class CargoBuilder
	{
		/// <summary>
		/// Finds an existing "{{Cargo/name" (if any), otherwise adds a new one.
		/// </summary>
		// Token: 0x0600152A RID: 5418 RVA: 0x000523EC File Offset: 0x000505EC
		public CargoDeclaration GetOrAddDeclaration(string name)
		{
			List<CargoDeclaration> orAddNew = this.declarations.GetOrAddNew(name);
			if (orAddNew.IsEmpty<CargoDeclaration>())
			{
				CargoDeclaration item = new CargoDeclaration();
				orAddNew.Add(item);
			}
			return orAddNew[0];
		}

		/// <summary>
		/// Adds a new "{{Cargo/name" even if one already exists.
		/// </summary>
		// Token: 0x0600152B RID: 5419 RVA: 0x00052424 File Offset: 0x00050624
		public CargoDeclaration AddDeclaration(string name)
		{
			List<CargoDeclaration> orAddNew = this.declarations.GetOrAddNew(name);
			CargoDeclaration cargoDeclaration = new CargoDeclaration();
			orAddNew.Add(cargoDeclaration);
			return cargoDeclaration;
		}

		// Token: 0x0600152C RID: 5420 RVA: 0x0005244A File Offset: 0x0005064A
		public void Clear()
		{
			this.declarations.Clear();
		}

		// Token: 0x04000779 RID: 1913
		internal Dictionary<string, List<CargoDeclaration>> declarations = new Dictionary<string, List<CargoDeclaration>>();
	}
}
