﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020002AA RID: 682
	public class Bundle
	{
		// Token: 0x170002DC RID: 732
		// (get) Token: 0x060014C7 RID: 5319 RVA: 0x00051317 File Offset: 0x0004F517
		// (set) Token: 0x060014C8 RID: 5320 RVA: 0x0005131F File Offset: 0x0004F51F
		public AssetBundle asset { get; protected set; }

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x060014C9 RID: 5321 RVA: 0x00051328 File Offset: 0x0004F528
		// (set) Token: 0x060014CA RID: 5322 RVA: 0x00051330 File Offset: 0x0004F530
		public string resource { get; protected set; }

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x060014CB RID: 5323 RVA: 0x00051339 File Offset: 0x0004F539
		// (set) Token: 0x060014CC RID: 5324 RVA: 0x00051341 File Offset: 0x0004F541
		public string name { get; protected set; }

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x060014CD RID: 5325 RVA: 0x0005134A File Offset: 0x0004F54A
		[Obsolete]
		public bool hasResource
		{
			get
			{
				return this.asset == null;
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x060014CE RID: 5326 RVA: 0x00051358 File Offset: 0x0004F558
		protected virtual bool willBeUnloadedDuringUse
		{
			get
			{
				return true;
			}
		}

		// Token: 0x060014CF RID: 5327 RVA: 0x0005135C File Offset: 0x0004F55C
		protected void fixupMaterialForRenderer(Transform rootTransform, Renderer renderer, Material sharedMaterial)
		{
			Shader shader = sharedMaterial.shader;
			if (this.convertShadersToStandard || shader == null)
			{
				sharedMaterial.shader = Shader.Find("Standard");
			}
			else if (this.consolidateShaders)
			{
				Shader shader2 = ShaderConsolidator.findConsolidatedShader(shader);
				if (shader2 != null)
				{
					sharedMaterial.shader = shader2;
				}
				else
				{
					Transform transform = renderer.transform;
					string text = transform.name;
					while (transform != rootTransform)
					{
						transform = transform.parent;
						text = transform.name + "/" + text;
					}
					UnturnedLog.warn("Unable to find consolidated version of shader {0} for material {1} in {2} {3}", new object[]
					{
						shader.name,
						sharedMaterial.name,
						this.name,
						text
					});
				}
			}
			else
			{
				UnturnedLog.error("fixupMaterialForRenderer should not have been called for {0}", new object[]
				{
					this.name
				});
			}
			StandardShaderUtils.maybeFixupMaterial(sharedMaterial);
		}

		// Token: 0x060014D0 RID: 5328 RVA: 0x0005143C File Offset: 0x0004F63C
		internal static void FixupGameObjectAudio(GameObject gameObject)
		{
			if (!Dedicator.IsDedicatedServer)
			{
				Bundle.audioSources.Clear();
				gameObject.GetComponentsInChildren<AudioSource>(true, Bundle.audioSources);
				foreach (AudioSource audioSource in Bundle.audioSources)
				{
					if (audioSource.outputAudioMixerGroup == null)
					{
						audioSource.outputAudioMixerGroup = UnturnedAudioMixer.GetDefaultGroup();
					}
					if (audioSource.dopplerLevel > 0.0001f && audioSource.GetComponent<EnableDopplerEffect>() == null)
					{
						audioSource.dopplerLevel = 0f;
					}
				}
			}
		}

		// Token: 0x060014D1 RID: 5329 RVA: 0x000514E8 File Offset: 0x0004F6E8
		protected virtual void processLoadedGameObject(GameObject gameObject)
		{
			if (!Dedicator.IsDedicatedServer)
			{
				Bundle.FixupGameObjectAudio(gameObject);
			}
			if (!this.convertShadersToStandard && !this.consolidateShaders)
			{
				return;
			}
			if (Dedicator.IsDedicatedServer)
			{
				return;
			}
			Bundle.renderers.Clear();
			gameObject.GetComponentsInChildren<Renderer>(true, Bundle.renderers);
			foreach (Renderer renderer in Bundle.renderers)
			{
				foreach (Material material in renderer.sharedMaterials)
				{
					if (!(material == null))
					{
						this.fixupMaterialForRenderer(gameObject.transform, renderer, material);
					}
				}
			}
		}

		// Token: 0x060014D2 RID: 5330 RVA: 0x000515A4 File Offset: 0x0004F7A4
		protected virtual void processLoadedMaterial(Material material)
		{
			if (!this.convertShadersToStandard && !this.consolidateShaders)
			{
				return;
			}
			Shader shader = material.shader;
			if (this.convertShadersToStandard || shader == null)
			{
				material.shader = Shader.Find("Standard");
			}
			else if (this.consolidateShaders)
			{
				Shader shader2 = ShaderConsolidator.findConsolidatedShader(shader);
				if (shader2 != null)
				{
					material.shader = shader2;
				}
				else
				{
					UnturnedLog.warn("Unable to find consolidated version of shader {0} for material {1} in {2}", new object[]
					{
						shader.name,
						material.name,
						this.name
					});
				}
			}
			StandardShaderUtils.maybeFixupMaterial(material);
		}

		// Token: 0x060014D3 RID: 5331 RVA: 0x00051640 File Offset: 0x0004F840
		protected virtual void processLoadedObject<T>(T loadedObject) where T : UnityEngine.Object
		{
			if (typeof(T) == typeof(GameObject))
			{
				this.processLoadedGameObject(loadedObject as GameObject);
				return;
			}
			if (typeof(T) == typeof(AudioClip))
			{
				if (this.willBeUnloadedDuringUse && !Dedicator.IsDedicatedServer)
				{
					AudioClip audioClip = loadedObject as AudioClip;
					if (audioClip && !audioClip.preloadAudioData)
					{
						audioClip.LoadAudioData();
						return;
					}
				}
			}
			else if (typeof(T) == typeof(Material))
			{
				if (Dedicator.IsDedicatedServer)
				{
					return;
				}
				this.processLoadedMaterial(loadedObject as Material);
			}
		}

		/// <summary>
		/// Save a reference to an object in the asset bundle, but defer loading it until requested by game code.
		/// </summary>
		// Token: 0x060014D4 RID: 5332 RVA: 0x000516FC File Offset: 0x0004F8FC
		public virtual void loadDeferred<T>(string name, out IDeferredAsset<T> asset, LoadedAssetDeferredCallback<T> callback = null) where T : UnityEngine.Object
		{
			T t = this.load<T>(name);
			NonDeferredAsset<T> nonDeferredAsset;
			nonDeferredAsset.loadedObject = t;
			asset = nonDeferredAsset;
			if (callback != null)
			{
				callback(t);
			}
		}

		// Token: 0x060014D5 RID: 5333 RVA: 0x0005172C File Offset: 0x0004F92C
		public virtual T load<T>(string name) where T : UnityEngine.Object
		{
			if (this.asset == null)
			{
				return Resources.Load<T>(this.resource + "/" + name);
			}
			if (this.asset.Contains(name))
			{
				T t = this.asset.LoadAsset<T>(name);
				this.processLoadedObject<T>(t);
				return t;
			}
			return default(T);
		}

		// Token: 0x060014D6 RID: 5334 RVA: 0x0005178B File Offset: 0x0004F98B
		public virtual string WhereLoadLookedToString(string name)
		{
			if (this.asset == null)
			{
				return this.resource + "/" + name + " in built-in resources";
			}
			return name + " in .unity3d asset bundle";
		}

		// Token: 0x060014D7 RID: 5335 RVA: 0x000517BD File Offset: 0x0004F9BD
		public T[] loadAll<T>() where T : UnityEngine.Object
		{
			if (!(this.asset != null))
			{
				return null;
			}
			return this.asset.LoadAllAssets<T>();
		}

		// Token: 0x060014D8 RID: 5336 RVA: 0x000517DA File Offset: 0x0004F9DA
		public void unload()
		{
			if (this.asset != null)
			{
				this.asset.Unload(false);
			}
		}

		// Token: 0x060014D9 RID: 5337 RVA: 0x000517F6 File Offset: 0x0004F9F6
		protected Bundle(string name)
		{
			this.asset = null;
			this.resource = null;
			this.name = name;
		}

		// Token: 0x060014DA RID: 5338 RVA: 0x0005181C File Offset: 0x0004FA1C
		public Bundle(string path, bool usePath, string nameOverride = null)
		{
			if (ReadWrite.fileExists(path, false, usePath))
			{
				if (this.asset == null)
				{
					this.asset = AssetBundle.LoadFromFile(usePath ? (ReadWrite.PATH + path) : path);
				}
			}
			else
			{
				this.asset = null;
			}
			this.name = ((nameOverride != null) ? nameOverride : ReadWrite.fileName(path));
			if (this.asset == null)
			{
				this.resource = ReadWrite.folderPath(path).Substring(1);
			}
		}

		// Token: 0x060014DB RID: 5339 RVA: 0x000518A5 File Offset: 0x0004FAA5
		[Obsolete]
		public Bundle()
		{
			this.asset = null;
			this.name = "#NAME";
		}

		// Token: 0x060014DC RID: 5340 RVA: 0x000518C6 File Offset: 0x0004FAC6
		[Obsolete]
		public UnityEngine.Object[] load()
		{
			if (this.asset != null)
			{
				return this.asset.LoadAllAssets();
			}
			return null;
		}

		// Token: 0x060014DD RID: 5341 RVA: 0x000518E3 File Offset: 0x0004FAE3
		[Obsolete]
		public UnityEngine.Object[] load(Type type)
		{
			if (this.asset != null)
			{
				return this.asset.LoadAllAssets(type);
			}
			return null;
		}

		// Token: 0x04000768 RID: 1896
		private static List<AudioSource> audioSources = new List<AudioSource>();

		// Token: 0x04000769 RID: 1897
		private static List<Renderer> renderers = new List<Renderer>();

		// Token: 0x0400076D RID: 1901
		public bool convertShadersToStandard;

		// Token: 0x0400076E RID: 1902
		public bool consolidateShaders = true;
	}
}
