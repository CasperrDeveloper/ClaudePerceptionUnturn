﻿using System;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020005A5 RID: 1445
	// (Invoke) Token: 0x06003064 RID: 12388
	public delegate void Chatted(SteamPlayer player, EChatMode mode, ref Color chatted, ref bool isRich, string text, ref bool isVisible);
}
