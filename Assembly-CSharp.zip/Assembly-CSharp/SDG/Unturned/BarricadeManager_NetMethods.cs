﻿using System;
using SDG.NetPak;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x020001E0 RID: 480
	[NetInvokableGeneratedClass(typeof(BarricadeManager))]
	public static class BarricadeManager_NetMethods
	{
		// Token: 0x06000E94 RID: 3732 RVA: 0x0003648C File Offset: 0x0003468C
		[NetInvokableGeneratedMethod("ReceiveDestroyBarricade", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveDestroyBarricade_Read(in ClientInvocationContext context)
		{
			NetId netId;
			context.reader.ReadNetId(out netId);
			BarricadeManager.ReceiveDestroyBarricade(context, netId);
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x000364AE File Offset: 0x000346AE
		[NetInvokableGeneratedMethod("ReceiveDestroyBarricade", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveDestroyBarricade_Write(NetPakWriter writer, NetId netId)
		{
			writer.WriteNetId(netId);
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x000364B8 File Offset: 0x000346B8
		[NetInvokableGeneratedMethod("ReceiveClearRegionBarricades", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveClearRegionBarricades_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			byte x;
			reader.ReadUInt8(out x);
			byte y;
			reader.ReadUInt8(out y);
			BarricadeManager.ReceiveClearRegionBarricades(x, y);
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x000364E3 File Offset: 0x000346E3
		[NetInvokableGeneratedMethod("ReceiveClearRegionBarricades", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveClearRegionBarricades_Write(NetPakWriter writer, byte x, byte y)
		{
			writer.WriteUInt8(x);
			writer.WriteUInt8(y);
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x000364F8 File Offset: 0x000346F8
		[NetInvokableGeneratedMethod("ReceiveSingleBarricade", ENetInvokableGeneratedMethodPurpose.Read)]
		public static void ReceiveSingleBarricade_Read(in ClientInvocationContext context)
		{
			NetPakReader reader = context.reader;
			NetId parentNetId;
			reader.ReadNetId(out parentNetId);
			Guid assetId;
			reader.ReadGuid(out assetId);
			byte b;
			reader.ReadUInt8(out b);
			byte[] array = new byte[(int)b];
			reader.ReadBytes(array);
			Vector3 point;
			reader.ReadClampedVector3(out point, 13, 11);
			Quaternion rotation;
			reader.ReadSpecialYawOrQuaternion(out rotation, 23, 9);
			ulong owner;
			reader.ReadUInt64(out owner);
			ulong group;
			reader.ReadUInt64(out group);
			NetId netId;
			reader.ReadNetId(out netId);
			BarricadeManager.ReceiveSingleBarricade(context, parentNetId, assetId, array, point, rotation, owner, group, netId);
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0003657C File Offset: 0x0003477C
		[NetInvokableGeneratedMethod("ReceiveSingleBarricade", ENetInvokableGeneratedMethodPurpose.Write)]
		public static void ReceiveSingleBarricade_Write(NetPakWriter writer, NetId parentNetId, Guid assetId, byte[] state, Vector3 point, Quaternion rotation, ulong owner, ulong group, NetId netId)
		{
			writer.WriteNetId(parentNetId);
			writer.WriteGuid(assetId);
			byte b = (byte)state.Length;
			writer.WriteUInt8(b);
			writer.WriteBytes(state, (int)b);
			writer.WriteClampedVector3(point, 13, 11);
			writer.WriteSpecialYawOrQuaternion(rotation, 23, 9);
			writer.WriteUInt64(owner);
			writer.WriteUInt64(group);
			writer.WriteNetId(netId);
		}
	}
}
