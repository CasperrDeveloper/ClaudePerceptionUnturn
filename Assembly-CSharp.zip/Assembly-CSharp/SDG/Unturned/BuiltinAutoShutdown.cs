﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace SDG.Unturned
{
	/// <summary>
	/// Manages scheduled restart for dedicated server.
	/// </summary>
	// Token: 0x020006E2 RID: 1762
	internal class BuiltinAutoShutdown : MonoBehaviour
	{
		// Token: 0x06003D55 RID: 15701 RVA: 0x00131820 File Offset: 0x0012FA20
		private void InitScheduledShutdown()
		{
			if (!Provider.configData.Server.Enable_Scheduled_Shutdown)
			{
				return;
			}
			DateTime dateTime;
			if (!DateTime.TryParse(Provider.configData.Server.Scheduled_Shutdown_Time, out dateTime))
			{
				CommandWindow.LogWarning("Unable to parse scheduled shutdown time \"" + Provider.configData.Server.Scheduled_Shutdown_Time + "\"");
				return;
			}
			this.isScheduledShutdownEnabled = true;
			DateTime utcNow = DateTime.UtcNow;
			this.scheduledShutdownTime = utcNow.Date + dateTime.ToUniversalTime().TimeOfDay;
			if (this.scheduledShutdownTime < utcNow)
			{
				this.scheduledShutdownTime = this.scheduledShutdownTime.AddDays(1.0);
			}
			TimeSpan timeSpan = this.scheduledShutdownTime - DateTime.UtcNow;
			CommandWindow.LogFormat(string.Format("Shutdown is scheduled for {0} ({1:g} from now)", this.scheduledShutdownTime.ToLocalTime(), timeSpan), Array.Empty<object>());
			this.scheduledShutdownRealtime = Time.realtimeSinceStartupAsDouble + timeSpan.TotalSeconds;
			this.scheduledShutdownWarnings = new List<double>(Provider.configData.Server.Scheduled_Shutdown_Warnings.Length);
			foreach (string text in Provider.configData.Server.Scheduled_Shutdown_Warnings)
			{
				TimeSpan timeSpan2;
				if (TimeSpan.TryParse(text, out timeSpan2))
				{
					this.scheduledShutdownWarnings.Add(timeSpan2.TotalSeconds);
				}
				else
				{
					CommandWindow.LogWarning("Unable to parse scheduled shutdown warning time \"" + text + "\"");
				}
			}
			this.scheduledShutdownWarnings.Sort();
			if (this.scheduledShutdownWarnings.Count > 0)
			{
				double num = this.scheduledShutdownRealtime - Time.realtimeSinceStartupAsDouble;
				this.scheduledShutdownWarningIndex = this.scheduledShutdownWarnings.Count - 1;
				while (this.scheduledShutdownWarningIndex >= 0)
				{
					if (num > this.scheduledShutdownWarnings[this.scheduledShutdownWarningIndex])
					{
						return;
					}
					this.scheduledShutdownWarningIndex--;
				}
				return;
			}
			this.scheduledShutdownWarningIndex = -1;
		}

		// Token: 0x06003D56 RID: 15702 RVA: 0x00131A0C File Offset: 0x0012FC0C
		private void InitUpdateShutdown()
		{
			if (!Provider.configData.Server.Enable_Update_Shutdown)
			{
				return;
			}
			if (Dedicator.offlineOnly)
			{
				CommandWindow.LogWarning("Disabling check for game updates because Offline-Only mode is enabled");
				return;
			}
			string update_Steam_Beta_Name = Provider.configData.Server.Update_Steam_Beta_Name;
			if (string.IsNullOrEmpty(update_Steam_Beta_Name))
			{
				CommandWindow.LogWarning("Unable to check for game updates with empty Steam beta name (default is \"public\")");
				return;
			}
			this.updateShutdownWarnings = new List<double>(Provider.configData.Server.Update_Shutdown_Warnings.Length);
			foreach (string text in Provider.configData.Server.Update_Shutdown_Warnings)
			{
				TimeSpan timeSpan;
				if (TimeSpan.TryParse(text, out timeSpan))
				{
					this.updateShutdownWarnings.Add(timeSpan.TotalSeconds);
				}
				else
				{
					CommandWindow.LogWarning("Unable to parse update shutdown warning time \"" + text + "\"");
				}
			}
			this.updateShutdownWarnings.Sort();
			CommandWindow.LogFormat("Monitoring for game updates on Steam beta branch \"" + update_Steam_Beta_Name + "\"", Array.Empty<object>());
			string url = "https://smartlydressedgames.com/unturned-steam-versions/" + update_Steam_Beta_Name + ".txt";
			base.StartCoroutine(this.CheckVersion(url));
		}

		// Token: 0x06003D57 RID: 15703 RVA: 0x00131B1D File Offset: 0x0012FD1D
		private void OnEnable()
		{
			this.InitScheduledShutdown();
			this.InitUpdateShutdown();
		}

		// Token: 0x06003D58 RID: 15704 RVA: 0x00131B2C File Offset: 0x0012FD2C
		private void Update()
		{
			if (this.isShuttingDownForUpdate)
			{
				double num = this.updateShutdownRealtime - Time.realtimeSinceStartupAsDouble;
				if (num < 0.0)
				{
					this.isShuttingDownForUpdate = false;
					string key = this.isUpdateRollback ? "RollbackShutdown_KickExplanation" : "UpdateShutdown_KickExplanation";
					Provider.shutdown(0, Provider.localization.format(key, this.updateVersionString));
					return;
				}
				if (this.updateShutdownWarnings.Count > 0 && this.updateShutdownWarningIndex >= 0 && num < this.updateShutdownWarnings[this.updateShutdownWarningIndex])
				{
					TimeSpan timeSpan = new TimeSpan(0, 0, (int)this.updateShutdownWarnings[this.updateShutdownWarningIndex]);
					string key2 = this.isUpdateRollback ? "RollbackShutdown_Timer" : "UpdateShutdown_Timer";
					string text = Provider.localization.format(key2, this.updateVersionString, timeSpan.ToString("g"));
					CommandWindow.Log(text);
					ChatManager.say(text, ChatManager.welcomeColor, false);
					this.updateShutdownWarningIndex--;
					return;
				}
			}
			else if (this.isScheduledShutdownEnabled)
			{
				double num2 = this.scheduledShutdownRealtime - Time.realtimeSinceStartupAsDouble;
				if (num2 < 0.0)
				{
					this.isScheduledShutdownEnabled = false;
					Provider.shutdown(0, Provider.localization.format("ScheduledMaintenance_KickExplanation"));
					return;
				}
				if (this.scheduledShutdownWarnings.Count > 0 && this.scheduledShutdownWarningIndex >= 0 && num2 < this.scheduledShutdownWarnings[this.scheduledShutdownWarningIndex])
				{
					TimeSpan timeSpan2 = new TimeSpan(0, 0, (int)this.scheduledShutdownWarnings[this.scheduledShutdownWarningIndex]);
					string text2 = Provider.localization.format("ScheduledMaintenance_Timer", timeSpan2.ToString("g"));
					CommandWindow.Log(text2);
					ChatManager.say(text2, ChatManager.welcomeColor, false);
					this.scheduledShutdownWarningIndex--;
				}
			}
		}

		// Token: 0x06003D59 RID: 15705 RVA: 0x00131CF6 File Offset: 0x0012FEF6
		private IEnumerator CheckVersion(string url)
		{
			yield return new WaitForSecondsRealtime(300f);
			for (;;)
			{
				UnturnedLog.info("Checking for game updates...");
				using (UnityWebRequest request = UnityWebRequest.Get(url))
				{
					request.timeout = 30;
					yield return request.SendWebRequest();
					if (request.result == UnityWebRequest.Result.Success)
					{
						string text = request.downloadHandler.text;
						uint num;
						if (Parser.TryGetUInt32FromIP(text, out num))
						{
							if (num != Provider.APP_VERSION_PACKED)
							{
								if (num > Provider.APP_VERSION_PACKED)
								{
									CommandWindow.Log("Detected newer game version: " + text);
								}
								else
								{
									CommandWindow.Log("Detected rollback to older game version: " + text);
								}
								bool flag = true;
								GameUpdateMonitor.NotifyGameUpdateDetected(text, ref flag);
								if (flag)
								{
									this.isShuttingDownForUpdate = true;
									this.isUpdateRollback = (num < Provider.APP_VERSION_PACKED);
									this.updateVersionString = text;
									this.updateShutdownWarningIndex = this.updateShutdownWarnings.Count - 1;
									this.updateShutdownRealtime = Time.realtimeSinceStartupAsDouble + ((this.updateShutdownWarningIndex >= 0) ? this.updateShutdownWarnings[this.updateShutdownWarningIndex] : 0.0);
								}
								yield break;
							}
							UnturnedLog.info("Game version is up-to-date");
						}
						else
						{
							UnturnedLog.info("Unable to parse newest game version \"" + text + "\"");
						}
					}
					else
					{
						UnturnedLog.info("Network error checking for game updates: \"" + request.error + "\"");
					}
					yield return new WaitForSecondsRealtime(600f);
				}
				UnityWebRequest request = null;
			}
			yield break;
			yield break;
		}

		// Token: 0x0400233F RID: 9023
		public bool isScheduledShutdownEnabled;

		// Token: 0x04002340 RID: 9024
		public DateTime scheduledShutdownTime;

		// Token: 0x04002341 RID: 9025
		private double scheduledShutdownRealtime;

		/// <summary>
		/// Sorted from low to high.
		/// </summary>
		// Token: 0x04002342 RID: 9026
		private List<double> scheduledShutdownWarnings;

		// Token: 0x04002343 RID: 9027
		private int scheduledShutdownWarningIndex = -1;

		// Token: 0x04002344 RID: 9028
		private bool isShuttingDownForUpdate;

		// Token: 0x04002345 RID: 9029
		private bool isUpdateRollback;

		// Token: 0x04002346 RID: 9030
		private double updateShutdownRealtime;

		// Token: 0x04002347 RID: 9031
		private string updateVersionString;

		/// <summary>
		/// Sorted from low to high.
		/// </summary>
		// Token: 0x04002348 RID: 9032
		private List<double> updateShutdownWarnings;

		// Token: 0x04002349 RID: 9033
		private int updateShutdownWarningIndex = -1;
	}
}
