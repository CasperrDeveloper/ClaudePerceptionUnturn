﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020005A2 RID: 1442
	// (Invoke) Token: 0x06003058 RID: 12376
	public delegate void ChatMessageReceivedHandler();
}
