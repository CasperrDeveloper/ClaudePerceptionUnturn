﻿using System;
using System.Collections.Generic;
using SDG.NetPak;
using SDG.NetTransport;

namespace SDG.Unturned
{
	// Token: 0x0200022D RID: 557
	public sealed class ClientInstanceMethod<T> : ClientInstanceMethodBase
	{
		// Token: 0x0600115C RID: 4444 RVA: 0x0003F7AF File Offset: 0x0003D9AF
		public static ClientInstanceMethod<T> Get(Type declaringType, string methodName)
		{
			return ClientMethodHandle.GetInternal<ClientInstanceMethod<T>, ClientInstanceMethod<T>.WriteDelegate>(declaringType, methodName, (ClientMethodInfo clientMethodInfo, ClientInstanceMethod<T>.WriteDelegate generatedWrite) => new ClientInstanceMethod<T>(clientMethodInfo, generatedWrite));
		}

		// Token: 0x0600115D RID: 4445 RVA: 0x0003F7D8 File Offset: 0x0003D9D8
		public void Invoke(NetId netId, ENetReliability reliability, ITransportConnection transportConnection, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg);
			base.SendAndLoopbackIfLocal(reliability, transportConnection, writerWithInstanceHeader);
		}

		// Token: 0x0600115E RID: 4446 RVA: 0x0003F804 File Offset: 0x0003DA04
		public void Invoke(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg);
			base.SendAndLoopbackIfAnyAreLocal(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x0600115F RID: 4447 RVA: 0x0003F830 File Offset: 0x0003DA30
		[Obsolete("Replaced by List overload")]
		public void Invoke(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, T arg)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.Invoke(netId, reliability, list, arg);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001160 RID: 4448 RVA: 0x0003F864 File Offset: 0x0003DA64
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, List<ITransportConnection> transportConnections, T arg)
		{
			NetPakWriter writerWithInstanceHeader = base.GetWriterWithInstanceHeader(netId);
			this.generatedWrite(writerWithInstanceHeader, arg);
			base.SendAndLoopback(reliability, transportConnections, writerWithInstanceHeader);
		}

		// Token: 0x06001161 RID: 4449 RVA: 0x0003F890 File Offset: 0x0003DA90
		[Obsolete("Replaced by List overload")]
		public void InvokeAndLoopback(NetId netId, ENetReliability reliability, IEnumerable<ITransportConnection> transportConnections, T arg)
		{
			List<ITransportConnection> list = transportConnections as List<ITransportConnection>;
			if (list != null)
			{
				this.InvokeAndLoopback(netId, reliability, list, arg);
				return;
			}
			throw new ArgumentException("should be list", "transportConnections");
		}

		// Token: 0x06001162 RID: 4450 RVA: 0x0003F8C2 File Offset: 0x0003DAC2
		private ClientInstanceMethod(ClientMethodInfo clientMethodInfo, ClientInstanceMethod<T>.WriteDelegate generatedWrite) : base(clientMethodInfo)
		{
			this.generatedWrite = generatedWrite;
		}

		// Token: 0x040005C9 RID: 1481
		private ClientInstanceMethod<T>.WriteDelegate generatedWrite;

		// Token: 0x0200092C RID: 2348
		// (Invoke) Token: 0x06005137 RID: 20791
		private delegate void WriteDelegate(NetPakWriter writer, T arg);
	}
}
