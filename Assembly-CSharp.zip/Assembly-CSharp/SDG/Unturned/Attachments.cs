﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x02000291 RID: 657
	public class Attachments : MonoBehaviour
	{
		// Token: 0x1700026F RID: 623
		// (get) Token: 0x06001373 RID: 4979 RVA: 0x0004A53D File Offset: 0x0004873D
		public ItemGunAsset gunAsset
		{
			get
			{
				return this._gunAsset;
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06001374 RID: 4980 RVA: 0x0004A545 File Offset: 0x00048745
		public SkinAsset skinAsset
		{
			get
			{
				return this._skinAsset;
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06001375 RID: 4981 RVA: 0x0004A54D File Offset: 0x0004874D
		public ushort sightID
		{
			get
			{
				return this._sightID;
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06001376 RID: 4982 RVA: 0x0004A555 File Offset: 0x00048755
		public ushort tacticalID
		{
			get
			{
				return this._tacticalID;
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06001377 RID: 4983 RVA: 0x0004A55D File Offset: 0x0004875D
		public ushort gripID
		{
			get
			{
				return this._gripID;
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06001378 RID: 4984 RVA: 0x0004A565 File Offset: 0x00048765
		public ushort barrelID
		{
			get
			{
				return this._barrelID;
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06001379 RID: 4985 RVA: 0x0004A56D File Offset: 0x0004876D
		public ushort magazineID
		{
			get
			{
				return this._magazineID;
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x0600137A RID: 4986 RVA: 0x0004A575 File Offset: 0x00048775
		public ItemSightAsset sightAsset
		{
			get
			{
				return this._sightAsset;
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x0600137B RID: 4987 RVA: 0x0004A57D File Offset: 0x0004877D
		public ItemTacticalAsset tacticalAsset
		{
			get
			{
				return this._tacticalAsset;
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x0600137C RID: 4988 RVA: 0x0004A585 File Offset: 0x00048785
		public ItemGripAsset gripAsset
		{
			get
			{
				return this._gripAsset;
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x0600137D RID: 4989 RVA: 0x0004A58D File Offset: 0x0004878D
		public ItemBarrelAsset barrelAsset
		{
			get
			{
				return this._barrelAsset;
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x0600137E RID: 4990 RVA: 0x0004A595 File Offset: 0x00048795
		public ItemMagazineAsset magazineAsset
		{
			get
			{
				return this._magazineAsset;
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x0600137F RID: 4991 RVA: 0x0004A59D File Offset: 0x0004879D
		public Transform sightModel
		{
			get
			{
				return this._sightModel;
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06001380 RID: 4992 RVA: 0x0004A5A5 File Offset: 0x000487A5
		public Transform tacticalModel
		{
			get
			{
				return this._tacticalModel;
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06001381 RID: 4993 RVA: 0x0004A5AD File Offset: 0x000487AD
		public Transform gripModel
		{
			get
			{
				return this._gripModel;
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06001382 RID: 4994 RVA: 0x0004A5B5 File Offset: 0x000487B5
		public Transform barrelModel
		{
			get
			{
				return this._barrelModel;
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06001383 RID: 4995 RVA: 0x0004A5BD File Offset: 0x000487BD
		public Transform magazineModel
		{
			get
			{
				return this._magazineModel;
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06001384 RID: 4996 RVA: 0x0004A5C5 File Offset: 0x000487C5
		public Transform sightHook
		{
			get
			{
				return this._sightHook;
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06001385 RID: 4997 RVA: 0x0004A5CD File Offset: 0x000487CD
		public Transform viewHook
		{
			get
			{
				return this._viewHook;
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06001386 RID: 4998 RVA: 0x0004A5D5 File Offset: 0x000487D5
		public Transform tacticalHook
		{
			get
			{
				return this._tacticalHook;
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06001387 RID: 4999 RVA: 0x0004A5DD File Offset: 0x000487DD
		public Transform gripHook
		{
			get
			{
				return this._gripHook;
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06001388 RID: 5000 RVA: 0x0004A5E5 File Offset: 0x000487E5
		public Transform barrelHook
		{
			get
			{
				return this._barrelHook;
			}
		}

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06001389 RID: 5001 RVA: 0x0004A5ED File Offset: 0x000487ED
		public Transform magazineHook
		{
			get
			{
				return this._magazineHook;
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x0600138A RID: 5002 RVA: 0x0004A5F5 File Offset: 0x000487F5
		public Transform ejectHook
		{
			get
			{
				return this._ejectHook;
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x0600138B RID: 5003 RVA: 0x0004A5FD File Offset: 0x000487FD
		public Transform lightHook
		{
			get
			{
				return this._lightHook;
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x0600138C RID: 5004 RVA: 0x0004A605 File Offset: 0x00048805
		public Transform light2Hook
		{
			get
			{
				return this._light2Hook;
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x0600138D RID: 5005 RVA: 0x0004A60D File Offset: 0x0004880D
		public Transform aimHook
		{
			get
			{
				return this._aimHook;
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x0600138E RID: 5006 RVA: 0x0004A615 File Offset: 0x00048815
		public Transform scopeHook
		{
			get
			{
				return this._scopeHook;
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x0600138F RID: 5007 RVA: 0x0004A61D File Offset: 0x0004881D
		public Transform reticuleHook
		{
			get
			{
				return this._reticuleHook;
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06001390 RID: 5008 RVA: 0x0004A625 File Offset: 0x00048825
		public Transform leftHook
		{
			get
			{
				return this._leftHook;
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06001391 RID: 5009 RVA: 0x0004A62D File Offset: 0x0004882D
		public Transform rightHook
		{
			get
			{
				return this._rightHook;
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06001392 RID: 5010 RVA: 0x0004A635 File Offset: 0x00048835
		public Transform nockHook
		{
			get
			{
				return this._nockHook;
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06001393 RID: 5011 RVA: 0x0004A63D File Offset: 0x0004883D
		public Transform restHook
		{
			get
			{
				return this._restHook;
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06001394 RID: 5012 RVA: 0x0004A645 File Offset: 0x00048845
		public LineRenderer rope
		{
			get
			{
				return this._rope;
			}
		}

		// Token: 0x06001395 RID: 5013 RVA: 0x0004A650 File Offset: 0x00048850
		public void applyVisual()
		{
			if (this.isSkinned != this.wasSkinned)
			{
				this.wasSkinned = this.isSkinned;
				if (this.tempSightMaterial != null)
				{
					HighlighterTool.rematerialize(this.sightModel, this.tempSightMaterial, out this.tempSightMaterial);
				}
				if (this.tempTacticalMaterial != null)
				{
					HighlighterTool.rematerialize(this.tacticalModel, this.tempTacticalMaterial, out this.tempTacticalMaterial);
				}
				if (this.tempGripMaterial != null)
				{
					HighlighterTool.rematerialize(this.gripModel, this.tempGripMaterial, out this.tempGripMaterial);
				}
				if (this.tempBarrelMaterial != null)
				{
					HighlighterTool.rematerialize(this.barrelModel, this.tempBarrelMaterial, out this.tempBarrelMaterial);
				}
				if (this.tempMagazineMaterial != null)
				{
					HighlighterTool.rematerialize(this.magazineModel, this.tempMagazineMaterial, out this.tempMagazineMaterial);
				}
				if (this.magazineHook != null)
				{
					this.ApplyMagazineHiddenBySkin();
				}
			}
		}

		// Token: 0x06001396 RID: 5014 RVA: 0x0004A747 File Offset: 0x00048947
		public void updateGun(ItemGunAsset newGunAsset, SkinAsset newSkinAsset)
		{
			this._gunAsset = newGunAsset;
			this._skinAsset = newSkinAsset;
		}

		// Token: 0x06001397 RID: 5015 RVA: 0x0004A758 File Offset: 0x00048958
		public static void parseFromItemState(byte[] state, out ushort sight, out ushort tactical, out ushort grip, out ushort barrel, out ushort magazine)
		{
			if (state == null || state.Length < 10)
			{
				sight = 0;
				tactical = 0;
				grip = 0;
				barrel = 0;
				magazine = 0;
				return;
			}
			sight = BitConverter.ToUInt16(state, 0);
			tactical = BitConverter.ToUInt16(state, 2);
			grip = BitConverter.ToUInt16(state, 4);
			barrel = BitConverter.ToUInt16(state, 6);
			magazine = BitConverter.ToUInt16(state, 8);
		}

		// Token: 0x06001398 RID: 5016 RVA: 0x0004A7B0 File Offset: 0x000489B0
		public void updateAttachments(byte[] state, bool viewmodel)
		{
			if (state == null || state.Length < 18)
			{
				return;
			}
			base.transform.localScale = Vector3.one;
			Attachments.parseFromItemState(state, out this._sightID, out this._tacticalID, out this._gripID, out this._barrelID, out this._magazineID);
			this.DestroySkinMaterials();
			if (this.sightModel != null)
			{
				UnityEngine.Object.Destroy(this.sightModel.gameObject);
				this._sightModel = null;
			}
			try
			{
				this._sightAsset = (Assets.find(EAssetType.ITEM, this.sightID) as ItemSightAsset);
			}
			catch
			{
				this._sightAsset = null;
			}
			this.tempSightMaterial = null;
			if (this.sightAsset != null && this.sightHook != null && this.sightAsset.sight != null)
			{
				InstantiateParameters parameters = new InstantiateParameters
				{
					parent = this.SelectAttachmentParent(this.sightHook, this.sightAsset),
					worldSpace = false
				};
				this._sightModel = UnityEngine.Object.Instantiate<GameObject>(this.sightAsset.sight, Vector3.zero, Quaternion.identity, parameters).transform;
				this.sightModel.name = this.sightAsset.instantiatedAttachmentName;
				this.sightModel.localScale = Vector3.one;
				if (this.shouldDestroyColliders && this.sightAsset.shouldDestroyAttachmentColliders)
				{
					PrefabUtil.DestroyCollidersInChildren(this.sightModel.gameObject, true);
				}
				this.sightModel.DestroyRigidbody();
				if (viewmodel)
				{
					Layerer.viewmodel(this.sightModel);
				}
				if (this.gunAsset != null && this.skinAsset != null && this.skinAsset.secondarySkins != null)
				{
					Material material = null;
					if (!this.skinAsset.secondarySkins.TryGetValue(this.sightID, out material) && this.skinAsset.hasSight && this.sightAsset.isPaintable)
					{
						if (this.sightAsset.albedoBase != null && this.skinAsset.attachmentSkin != null)
						{
							this.instantiatedSightSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.attachmentSkin);
							this.sightAsset.applySkinBaseTextures(this.instantiatedSightSkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedSightSkin);
							material = this.instantiatedSightSkin;
						}
						else if (this.skinAsset.tertiarySkin != null)
						{
							this.instantiatedSightSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.tertiarySkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedSightSkin);
							material = this.instantiatedSightSkin;
						}
					}
					if (material != null)
					{
						HighlighterTool.rematerialize(this.sightModel, material, out this.tempSightMaterial);
					}
				}
			}
			if (this.tacticalModel != null)
			{
				UnityEngine.Object.Destroy(this.tacticalModel.gameObject);
				this._tacticalModel = null;
			}
			try
			{
				this._tacticalAsset = (Assets.find(EAssetType.ITEM, this.tacticalID) as ItemTacticalAsset);
			}
			catch
			{
				this._tacticalAsset = null;
			}
			this.tempTacticalMaterial = null;
			if (this.tacticalAsset != null && this.tacticalHook != null && this.tacticalAsset.tactical != null)
			{
				InstantiateParameters parameters2 = new InstantiateParameters
				{
					parent = this.SelectAttachmentParent(this.tacticalHook, this.tacticalAsset),
					worldSpace = false
				};
				this._tacticalModel = UnityEngine.Object.Instantiate<GameObject>(this.tacticalAsset.tactical, Vector3.zero, Quaternion.identity, parameters2).transform;
				this.tacticalModel.name = this.tacticalAsset.instantiatedAttachmentName;
				this.tacticalModel.localScale = Vector3.one;
				if (this.shouldDestroyColliders && this.tacticalAsset.shouldDestroyAttachmentColliders)
				{
					PrefabUtil.DestroyCollidersInChildren(this.tacticalModel.gameObject, true);
				}
				this.tacticalModel.DestroyRigidbody();
				if (viewmodel)
				{
					Layerer.viewmodel(this.tacticalModel);
				}
				if (this.gunAsset != null && this.skinAsset != null && this.skinAsset.secondarySkins != null)
				{
					Material material2 = null;
					if (!this.skinAsset.secondarySkins.TryGetValue(this.tacticalID, out material2) && this.skinAsset.hasTactical && this.tacticalAsset.isPaintable)
					{
						if (this.tacticalAsset.albedoBase != null && this.skinAsset.attachmentSkin != null)
						{
							this.instantiatedTacticalSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.attachmentSkin);
							this.tacticalAsset.applySkinBaseTextures(this.instantiatedTacticalSkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedTacticalSkin);
							material2 = this.instantiatedTacticalSkin;
						}
						else if (this.skinAsset.tertiarySkin != null)
						{
							this.instantiatedTacticalSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.tertiarySkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedTacticalSkin);
							material2 = this.instantiatedTacticalSkin;
						}
					}
					if (material2 != null)
					{
						HighlighterTool.rematerialize(this.tacticalModel, material2, out this.tempTacticalMaterial);
					}
				}
			}
			if (this.gripModel != null)
			{
				UnityEngine.Object.Destroy(this.gripModel.gameObject);
				this._gripModel = null;
			}
			try
			{
				this._gripAsset = (Assets.find(EAssetType.ITEM, this.gripID) as ItemGripAsset);
			}
			catch
			{
				this._gripAsset = null;
			}
			this.tempGripMaterial = null;
			if (this.gripAsset != null && this.gripHook != null && this.gripAsset.grip != null)
			{
				InstantiateParameters parameters3 = new InstantiateParameters
				{
					parent = this.SelectAttachmentParent(this.gripHook, this.gripAsset),
					worldSpace = false
				};
				this._gripModel = UnityEngine.Object.Instantiate<GameObject>(this.gripAsset.grip, Vector3.zero, Quaternion.identity, parameters3).transform;
				this.gripModel.name = this.gripAsset.instantiatedAttachmentName;
				this.gripModel.localScale = Vector3.one;
				if (this.shouldDestroyColliders && this.gripAsset.shouldDestroyAttachmentColliders)
				{
					PrefabUtil.DestroyCollidersInChildren(this.gripModel.gameObject, true);
				}
				this.gripModel.DestroyRigidbody();
				if (viewmodel)
				{
					Layerer.viewmodel(this.gripModel);
				}
				if (this.gunAsset != null && this.skinAsset != null && this.skinAsset.secondarySkins != null)
				{
					Material material3 = null;
					if (!this.skinAsset.secondarySkins.TryGetValue(this.gripID, out material3) && this.skinAsset.hasGrip && this.gripAsset.isPaintable)
					{
						if (this.gripAsset.albedoBase != null && this.skinAsset.attachmentSkin != null)
						{
							this.instantiatedGripSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.attachmentSkin);
							this.gripAsset.applySkinBaseTextures(this.instantiatedGripSkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedGripSkin);
							material3 = this.instantiatedGripSkin;
						}
						else if (this.skinAsset.tertiarySkin != null)
						{
							this.instantiatedGripSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.tertiarySkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedGripSkin);
							material3 = this.instantiatedGripSkin;
						}
					}
					if (material3 != null)
					{
						HighlighterTool.rematerialize(this.gripModel, material3, out this.tempGripMaterial);
					}
				}
			}
			if (this.barrelModel != null)
			{
				UnityEngine.Object.Destroy(this.barrelModel.gameObject);
				this._barrelModel = null;
			}
			try
			{
				this._barrelAsset = (Assets.find(EAssetType.ITEM, this.barrelID) as ItemBarrelAsset);
			}
			catch
			{
				this._barrelAsset = null;
			}
			this.tempBarrelMaterial = null;
			if (this.barrelAsset != null && this.barrelHook != null && this.barrelAsset.barrel != null)
			{
				InstantiateParameters parameters4 = new InstantiateParameters
				{
					parent = this.SelectAttachmentParent(this.barrelHook, this.barrelAsset),
					worldSpace = false
				};
				this._barrelModel = UnityEngine.Object.Instantiate<GameObject>(this.barrelAsset.barrel, Vector3.zero, Quaternion.identity, parameters4).transform;
				this.barrelModel.name = this.barrelAsset.instantiatedAttachmentName;
				this.barrelModel.localScale = Vector3.one;
				if (this.shouldDestroyColliders && this.barrelAsset.shouldDestroyAttachmentColliders)
				{
					PrefabUtil.DestroyCollidersInChildren(this.barrelModel.gameObject, true);
				}
				this.barrelModel.DestroyRigidbody();
				if (viewmodel)
				{
					Layerer.viewmodel(this.barrelModel);
				}
				if (this.gunAsset != null && this.skinAsset != null && this.skinAsset.secondarySkins != null)
				{
					Material material4 = null;
					if (!this.skinAsset.secondarySkins.TryGetValue(this.barrelID, out material4) && this.skinAsset.hasBarrel && this.barrelAsset.isPaintable)
					{
						if (this.barrelAsset.albedoBase != null && this.skinAsset.attachmentSkin != null)
						{
							this.instantiatedBarrelSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.attachmentSkin);
							this.barrelAsset.applySkinBaseTextures(this.instantiatedBarrelSkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedBarrelSkin);
							material4 = this.instantiatedBarrelSkin;
						}
						else if (this.skinAsset.tertiarySkin != null)
						{
							this.instantiatedBarrelSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.tertiarySkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedBarrelSkin);
							material4 = this.instantiatedBarrelSkin;
						}
					}
					if (material4 != null)
					{
						HighlighterTool.rematerialize(this.barrelModel, material4, out this.tempBarrelMaterial);
					}
				}
			}
			if (this.magazineModel != null)
			{
				UnityEngine.Object.Destroy(this.magazineModel.gameObject);
				this._magazineModel = null;
			}
			try
			{
				this._magazineAsset = (Assets.find(EAssetType.ITEM, this.magazineID) as ItemMagazineAsset);
			}
			catch
			{
				this._magazineAsset = null;
			}
			this.tempMagazineMaterial = null;
			if (this.magazineHook != null)
			{
				this.ApplyMagazineHiddenBySkin();
			}
			if (this.magazineAsset != null && this.magazineHook != null && this.magazineAsset.magazine != null)
			{
				InstantiateParameters parameters5 = new InstantiateParameters
				{
					parent = this.SelectAttachmentParent(this.magazineHook, this.magazineAsset),
					worldSpace = false
				};
				this._magazineModel = UnityEngine.Object.Instantiate<GameObject>(this.magazineAsset.magazine, Vector3.zero, Quaternion.identity, parameters5).transform;
				this.magazineModel.name = this.magazineAsset.instantiatedAttachmentName;
				this.magazineModel.localScale = Vector3.one;
				if (this.shouldDestroyColliders && this.magazineAsset.shouldDestroyAttachmentColliders)
				{
					PrefabUtil.DestroyCollidersInChildren(this.magazineModel.gameObject, true);
				}
				this.magazineModel.DestroyRigidbody();
				if (viewmodel)
				{
					Layerer.viewmodel(this.magazineModel);
				}
				if (this.gunAsset != null && this.skinAsset != null && this.skinAsset.secondarySkins != null)
				{
					Material material5 = null;
					if (!this.skinAsset.secondarySkins.TryGetValue(this.magazineID, out material5) && this.skinAsset.hasMagazine && this.magazineAsset.isPaintable)
					{
						if (this.magazineAsset.albedoBase != null && this.skinAsset.attachmentSkin != null)
						{
							this.instantiatedMagazineSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.attachmentSkin);
							this.magazineAsset.applySkinBaseTextures(this.instantiatedMagazineSkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedMagazineSkin);
							material5 = this.instantiatedMagazineSkin;
						}
						else if (this.skinAsset.tertiarySkin != null)
						{
							this.instantiatedMagazineSkin = UnityEngine.Object.Instantiate<Material>(this.skinAsset.tertiarySkin);
							this.skinAsset.SetMaterialProperties(this.instantiatedMagazineSkin);
							material5 = this.instantiatedMagazineSkin;
						}
					}
					if (material5 != null)
					{
						HighlighterTool.rematerialize(this.magazineModel, material5, out this.tempMagazineMaterial);
					}
				}
			}
			if (this.tacticalModel != null && this.tacticalModel.childCount > 0)
			{
				Transform transform = this.tacticalModel.Find("Model_0");
				this._lightHook = ((transform != null) ? transform.Find("Light") : null);
				this._light2Hook = ((transform != null) ? transform.Find("Light2") : null);
				if (viewmodel)
				{
					if (this.lightHook != null)
					{
						this.lightHook.tag = "Viewmodel";
						this.lightHook.gameObject.layer = 11;
						Transform transform2 = this.lightHook.Find("Light");
						if (transform2 != null)
						{
							transform2.tag = "Viewmodel";
							transform2.gameObject.layer = 11;
						}
					}
					if (this.light2Hook != null)
					{
						this.light2Hook.tag = "Viewmodel";
						this.light2Hook.gameObject.layer = 11;
						Transform transform3 = this.light2Hook.Find("Light");
						if (transform3 != null)
						{
							transform3.tag = "Viewmodel";
							transform3.gameObject.layer = 11;
						}
					}
				}
				else
				{
					LightLODTool.applyLightLOD(this.lightHook);
					LightLODTool.applyLightLOD(this.light2Hook);
				}
			}
			else
			{
				this._lightHook = null;
				this._light2Hook = null;
			}
			if (this.sightModel != null)
			{
				Transform transform4 = this.sightModel.Find("Model_0");
				Transform transform5 = (transform4 != null) ? transform4.Find("Aim") : null;
				if (transform5 != null)
				{
					Transform transform6 = transform5.parent.Find("Reticule");
					if (transform6 != null)
					{
						Renderer component = transform6.GetComponent<Renderer>();
						if (component != null)
						{
							this.reticuleMaterial = component.material;
							if (this.reticuleMaterial != null)
							{
								Color criticalHitmarkerColor = OptionsSettings.criticalHitmarkerColor;
								criticalHitmarkerColor.a = 1f;
								this.reticuleMaterial.SetColor("_Color", criticalHitmarkerColor);
								this.reticuleMaterial.SetColor("_EmissionColor", criticalHitmarkerColor);
							}
						}
					}
				}
				if (string.IsNullOrEmpty(this.sightAsset.AimAlignmentTransformPath))
				{
					this._aimHook = transform5;
				}
				else
				{
					Transform transform7 = this.sightModel;
					if (this.sightAsset.AimAlignmentTransformOwner == EAimAlignmentTransformOwner.Gun)
					{
						transform7 = base.transform;
					}
					this._aimHook = transform7.Find(this.sightAsset.AimAlignmentTransformPath);
				}
				this._reticuleHook = ((transform4 != null) ? transform4.Find("Reticule") : null);
			}
			else
			{
				this._aimHook = null;
				this._reticuleHook = null;
			}
			if (this.aimHook != null)
			{
				this._scopeHook = this.aimHook.Find("Scope");
			}
			else
			{
				this._scopeHook = null;
			}
			if (this.rope != null && viewmodel)
			{
				this.rope.tag = "Viewmodel";
				this.rope.gameObject.layer = 11;
			}
			this.wasSkinned = true;
			this.applyVisual();
			if (this.gunAttachmentEventHooks != null)
			{
				foreach (GunAttachmentEventHook gunAttachmentEventHook in this.gunAttachmentEventHooks)
				{
					gunAttachmentEventHook.UpdateEventHook(this);
				}
			}
		}

		// Token: 0x06001399 RID: 5017 RVA: 0x0004B7AC File Offset: 0x000499AC
		private void Awake()
		{
			this._sightHook = base.transform.Find("Sight");
			this._viewHook = base.transform.Find("View");
			this._tacticalHook = base.transform.Find("Tactical");
			this._gripHook = base.transform.Find("Grip");
			this._barrelHook = base.transform.Find("Barrel");
			this._magazineHook = base.transform.Find("Magazine");
			this._ejectHook = base.transform.Find("Eject");
			this._leftHook = base.transform.Find("Left");
			this._rightHook = base.transform.Find("Right");
			this._nockHook = base.transform.Find("Nock");
			this._restHook = base.transform.Find("Rest");
			Transform transform = base.transform.Find("Rope");
			if (transform != null)
			{
				this._rope = (LineRenderer)transform.GetComponent<Renderer>();
			}
		}

		// Token: 0x0600139A RID: 5018 RVA: 0x0004B8D8 File Offset: 0x00049AD8
		private void DestroySkinMaterials()
		{
			if (this.instantiatedSightSkin != null)
			{
				UnityEngine.Object.Destroy(this.instantiatedSightSkin);
				this.instantiatedSightSkin = null;
			}
			if (this.instantiatedTacticalSkin != null)
			{
				UnityEngine.Object.Destroy(this.instantiatedTacticalSkin);
				this.instantiatedTacticalSkin = null;
			}
			if (this.instantiatedGripSkin != null)
			{
				UnityEngine.Object.Destroy(this.instantiatedGripSkin);
				this.instantiatedGripSkin = null;
			}
			if (this.instantiatedBarrelSkin != null)
			{
				UnityEngine.Object.Destroy(this.instantiatedBarrelSkin);
				this.instantiatedBarrelSkin = null;
			}
			if (this.instantiatedMagazineSkin != null)
			{
				UnityEngine.Object.Destroy(this.instantiatedMagazineSkin);
				this.instantiatedMagazineSkin = null;
			}
			if (this.reticuleMaterial != null)
			{
				UnityEngine.Object.Destroy(this.reticuleMaterial);
				this.reticuleMaterial = null;
			}
		}

		/// <summary>
		/// Nelson 2024-11-15: By default, attachments use their corresponding "hook" transform. For example, magazines
		/// use the "Magazine" transform as their parent. If a child of the hook transform matches a caliber in the
		/// attachment's caliber list that is used instead.
		/// </summary>
		// Token: 0x0600139B RID: 5019 RVA: 0x0004B9A8 File Offset: 0x00049BA8
		private Transform SelectAttachmentParent(Transform hook, ItemCaliberAsset attachmentAsset)
		{
			if (attachmentAsset.calibers != null && attachmentAsset.calibers.Length != 0)
			{
				foreach (ushort num in attachmentAsset.calibers)
				{
					string n = string.Format("Caliber_{0}", num);
					Transform transform = hook.Find(n);
					if (transform != null)
					{
						return transform;
					}
				}
			}
			return hook;
		}

		// Token: 0x0600139C RID: 5020 RVA: 0x0004BA08 File Offset: 0x00049C08
		private void ApplyMagazineHiddenBySkin()
		{
			if (this.skinAsset != null && this.skinAsset.ShouldHideMagazine && this.isSkinned)
			{
				this.magazineHook.gameObject.SetActive(false);
				this.wasMagazineHookHiddenBySkin = true;
				return;
			}
			if (this.wasMagazineHookHiddenBySkin)
			{
				this.magazineHook.gameObject.SetActive(true);
				this.wasMagazineHookHiddenBySkin = false;
			}
		}

		// Token: 0x0600139D RID: 5021 RVA: 0x0004BA6B File Offset: 0x00049C6B
		private void OnDestroy()
		{
			this.DestroySkinMaterials();
		}

		// Token: 0x0600139E RID: 5022 RVA: 0x0004BA74 File Offset: 0x00049C74
		internal void InitializeGunAttachmentEventHooks(int count)
		{
			this.gunAttachmentEventHooks = new List<GunAttachmentEventHook>(count);
			base.GetComponentsInChildren<GunAttachmentEventHook>(true, this.gunAttachmentEventHooks);
			foreach (GunAttachmentEventHook gunAttachmentEventHook in this.gunAttachmentEventHooks)
			{
				gunAttachmentEventHook.InitializeEventHook(this);
			}
		}

		// Token: 0x04000698 RID: 1688
		private ItemGunAsset _gunAsset;

		// Token: 0x04000699 RID: 1689
		private SkinAsset _skinAsset;

		// Token: 0x0400069A RID: 1690
		private ushort _sightID;

		// Token: 0x0400069B RID: 1691
		private ushort _tacticalID;

		// Token: 0x0400069C RID: 1692
		private ushort _gripID;

		// Token: 0x0400069D RID: 1693
		private ushort _barrelID;

		// Token: 0x0400069E RID: 1694
		private ushort _magazineID;

		// Token: 0x0400069F RID: 1695
		private ItemSightAsset _sightAsset;

		// Token: 0x040006A0 RID: 1696
		private ItemTacticalAsset _tacticalAsset;

		// Token: 0x040006A1 RID: 1697
		private ItemGripAsset _gripAsset;

		// Token: 0x040006A2 RID: 1698
		private ItemBarrelAsset _barrelAsset;

		// Token: 0x040006A3 RID: 1699
		private ItemMagazineAsset _magazineAsset;

		// Token: 0x040006A4 RID: 1700
		private Transform _sightModel;

		// Token: 0x040006A5 RID: 1701
		private Transform _tacticalModel;

		// Token: 0x040006A6 RID: 1702
		private Transform _gripModel;

		// Token: 0x040006A7 RID: 1703
		private Transform _barrelModel;

		// Token: 0x040006A8 RID: 1704
		private Transform _magazineModel;

		// Token: 0x040006A9 RID: 1705
		private Transform _sightHook;

		// Token: 0x040006AA RID: 1706
		private Transform _viewHook;

		// Token: 0x040006AB RID: 1707
		private Transform _tacticalHook;

		// Token: 0x040006AC RID: 1708
		private Transform _gripHook;

		// Token: 0x040006AD RID: 1709
		private Transform _barrelHook;

		// Token: 0x040006AE RID: 1710
		private Transform _magazineHook;

		// Token: 0x040006AF RID: 1711
		private Transform _ejectHook;

		// Token: 0x040006B0 RID: 1712
		private Transform _lightHook;

		// Token: 0x040006B1 RID: 1713
		private Transform _light2Hook;

		// Token: 0x040006B2 RID: 1714
		private Transform _aimHook;

		// Token: 0x040006B3 RID: 1715
		private Transform _scopeHook;

		// Token: 0x040006B4 RID: 1716
		private Transform _reticuleHook;

		// Token: 0x040006B5 RID: 1717
		private Transform _leftHook;

		// Token: 0x040006B6 RID: 1718
		private Transform _rightHook;

		// Token: 0x040006B7 RID: 1719
		private Transform _nockHook;

		// Token: 0x040006B8 RID: 1720
		private Transform _restHook;

		// Token: 0x040006B9 RID: 1721
		private LineRenderer _rope;

		// Token: 0x040006BA RID: 1722
		public bool isSkinned;

		// Token: 0x040006BB RID: 1723
		public bool shouldDestroyColliders;

		// Token: 0x040006BC RID: 1724
		private bool wasSkinned;

		/// <summary>
		/// Nelson 2025-03-10: This aims to avoid messing with Magazine transform IsActive unless skin already did.
		/// </summary>
		// Token: 0x040006BD RID: 1725
		private bool wasMagazineHookHiddenBySkin;

		// Token: 0x040006BE RID: 1726
		private Material tempSightMaterial;

		// Token: 0x040006BF RID: 1727
		private Material tempTacticalMaterial;

		// Token: 0x040006C0 RID: 1728
		private Material tempGripMaterial;

		// Token: 0x040006C1 RID: 1729
		private Material tempBarrelMaterial;

		// Token: 0x040006C2 RID: 1730
		private Material tempMagazineMaterial;

		// Token: 0x040006C3 RID: 1731
		private Material instantiatedSightSkin;

		// Token: 0x040006C4 RID: 1732
		private Material instantiatedTacticalSkin;

		// Token: 0x040006C5 RID: 1733
		private Material instantiatedGripSkin;

		// Token: 0x040006C6 RID: 1734
		private Material instantiatedBarrelSkin;

		// Token: 0x040006C7 RID: 1735
		private Material instantiatedMagazineSkin;

		// Token: 0x040006C8 RID: 1736
		private Material reticuleMaterial;

		// Token: 0x040006C9 RID: 1737
		private List<GunAttachmentEventHook> gunAttachmentEventHooks;
	}
}
