﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020007B6 RID: 1974
	// (Invoke) Token: 0x060043EE RID: 17390
	public delegate void ClickedItem(SleekItem item);
}
