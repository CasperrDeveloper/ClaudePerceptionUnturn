﻿using System;
using SDG.NetPak;
using UnityEngine;

namespace SDG.Unturned
{
	// Token: 0x0200027C RID: 636
	internal static class ClientMessageHandler_PingResponse
	{
		// Token: 0x06001301 RID: 4865 RVA: 0x000451E8 File Offset: 0x000433E8
		internal static void ReadMessage(NetPakReader reader)
		{
			if (Provider.timeLastPingRequestWasSentToServer > 0f)
			{
				float deltaTime = Time.deltaTime;
				Provider.lag(Time.realtimeSinceStartup - Provider.timeLastPingRequestWasSentToServer - deltaTime);
				Provider.timeLastPingRequestWasSentToServer = -1f;
			}
		}
	}
}
