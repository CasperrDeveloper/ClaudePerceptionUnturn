﻿using System;

namespace SDG.Unturned
{
	// Token: 0x020006B4 RID: 1716
	// (Invoke) Token: 0x06003A19 RID: 14873
	public delegate void BrokenUpdated(bool newBroken);
}
