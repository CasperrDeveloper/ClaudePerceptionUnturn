﻿using System;

namespace SDG.Unturned
{
	// Token: 0x0200078C RID: 1932
	public class AutoSubscribeMap
	{
		/// <summary>
		/// Published steam id to subscribe to.
		/// </summary>
		// Token: 0x0400293F RID: 10559
		public ulong Workshop_File_Id;

		/// <summary>
		/// If logging in after this point, subscribe.
		/// </summary>
		// Token: 0x04002940 RID: 10560
		public DateTime Start;

		/// <summary>
		/// If logging in before this point, subscribe. 
		/// </summary>
		// Token: 0x04002941 RID: 10561
		public DateTime End;
	}
}
