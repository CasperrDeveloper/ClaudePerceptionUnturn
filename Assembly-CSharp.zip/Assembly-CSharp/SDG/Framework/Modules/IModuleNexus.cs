﻿using System;

namespace SDG.Framework.Modules
{
	/// <summary>
	/// ModuleHook looks for module entry/exit points, then calls <see cref="M:SDG.Framework.Modules.IModuleNexus.initialize" /> when enabled and <see cref="M:SDG.Framework.Modules.IModuleNexus.shutdown" /> when disabled.
	/// </summary>
	// Token: 0x0200008F RID: 143
	public interface IModuleNexus
	{
		/// <summary>
		/// Register components of this module.
		/// </summary>
		// Token: 0x06000387 RID: 903
		void initialize();

		/// <summary>
		/// Cleanup after this module.
		/// </summary>
		// Token: 0x06000388 RID: 904
		void shutdown();
	}
}
