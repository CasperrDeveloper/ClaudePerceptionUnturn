﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x02000092 RID: 146
	// (Invoke) Token: 0x06000392 RID: 914
	public delegate void ModuleShutdown(Module module);
}
