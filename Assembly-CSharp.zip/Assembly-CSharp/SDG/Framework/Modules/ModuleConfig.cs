﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace SDG.Framework.Modules
{
	/// <summary>
	/// Holds module configuration.
	/// </summary>
	// Token: 0x02000096 RID: 150
	public class ModuleConfig
	{
		// Token: 0x060003AD RID: 941 RVA: 0x0000ED4C File Offset: 0x0000CF4C
		public ModuleConfig()
		{
			this.IsEnabled = true;
			this.Name = string.Empty;
			this.Version = "1.0.0.0";
			this.Dependencies = new List<ModuleDependency>(0);
			this.Assemblies = new List<ModuleAssembly>(0);
		}

		/// <summary>
		/// Whether to load assemblies.
		/// </summary>
		// Token: 0x040001A6 RID: 422
		public bool IsEnabled;

		/// <summary>
		/// Directory containing Module file, set when loading.
		/// </summary>
		// Token: 0x040001A7 RID: 423
		[JsonIgnore]
		public string DirectoryPath;

		/// <summary>
		/// Path to the Module file, set when loading.
		/// </summary>
		// Token: 0x040001A8 RID: 424
		[JsonIgnore]
		public string FilePath;

		/// <summary>
		/// Used for module dependencies.
		/// </summary>
		// Token: 0x040001A9 RID: 425
		public string Name;

		/// <summary>
		/// Nicely formatted version, converted into <see cref="F:SDG.Framework.Modules.ModuleConfig.Version_Internal" />.
		/// </summary>
		// Token: 0x040001AA RID: 426
		public string Version;

		/// <summary>
		/// Used for module dependencies.
		/// </summary>
		// Token: 0x040001AB RID: 427
		[JsonIgnore]
		public uint Version_Internal;

		/// <summary>
		/// Modules that must be loaded before this module.
		/// </summary>
		// Token: 0x040001AC RID: 428
		public List<ModuleDependency> Dependencies;

		/// <summary>
		/// Relative file paths of .dlls to load.
		/// </summary>
		// Token: 0x040001AD RID: 429
		public List<ModuleAssembly> Assemblies;
	}
}
