﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x02000090 RID: 144
	// (Invoke) Token: 0x0600038A RID: 906
	public delegate void ModuleLoaded(Module module);
}
