﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x0200008E RID: 142
	public enum EModuleStatus
	{
		// Token: 0x04000197 RID: 407
		None,
		// Token: 0x04000198 RID: 408
		Initialized,
		// Token: 0x04000199 RID: 409
		Shutdown
	}
}
