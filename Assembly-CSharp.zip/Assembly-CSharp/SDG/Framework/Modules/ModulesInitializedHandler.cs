﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x02000098 RID: 152
	// (Invoke) Token: 0x060003B0 RID: 944
	public delegate void ModulesInitializedHandler();
}
