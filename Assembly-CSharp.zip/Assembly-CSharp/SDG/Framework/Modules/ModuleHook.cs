﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using SDG.Framework.IO;
using SDG.NetTransport;
using SDG.Unturned;
using Steamworks;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Modules
{
	/// <summary>
	/// Runs before everything else to find and load modules.
	/// </summary>
	// Token: 0x0200009A RID: 154
	public class ModuleHook : MonoBehaviour
	{
		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060003B7 RID: 951 RVA: 0x0000EDA7 File Offset: 0x0000CFA7
		// (set) Token: 0x060003B8 RID: 952 RVA: 0x0000EDAE File Offset: 0x0000CFAE
		public static List<Module> modules { get; protected set; }

		/// <summary>
		/// Temporarily contains Unturned's code untils it's moved into modules.
		/// </summary>
		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060003B9 RID: 953 RVA: 0x0000EDB6 File Offset: 0x0000CFB6
		// (set) Token: 0x060003BA RID: 954 RVA: 0x0000EDBD File Offset: 0x0000CFBD
		public static Assembly coreAssembly { get; protected set; }

		/// <summary>
		/// Temporarily contains <see cref="P:SDG.Framework.Modules.ModuleHook.coreAssembly" /> types.
		/// </summary>
		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060003BB RID: 955 RVA: 0x0000EDC5 File Offset: 0x0000CFC5
		// (set) Token: 0x060003BC RID: 956 RVA: 0x0000EDCC File Offset: 0x0000CFCC
		public static Type[] coreTypes { get; protected set; }

		/// <summary>
		/// Should module assemblies be loaded?
		/// </summary>
		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060003BD RID: 957 RVA: 0x0000EDD4 File Offset: 0x0000CFD4
		private static bool shouldLoadModules
		{
			get
			{
				return Dedicator.IsDedicatedServer || !Dedicator.hasBattlEye;
			}
		}

		/// <summary>
		/// Called once after all startup enabled modules are loaded. Not called when modules are initialized due to enabling/disabling.
		/// </summary>
		// Token: 0x14000014 RID: 20
		// (add) Token: 0x060003BE RID: 958 RVA: 0x0000EDE8 File Offset: 0x0000CFE8
		// (remove) Token: 0x060003BF RID: 959 RVA: 0x0000EE1C File Offset: 0x0000D01C
		public static event ModulesInitializedHandler onModulesInitialized;

		/// <summary>
		/// Called once after all modules are shutdown. Not called when modules are shutdown due to enabling/disabling.
		/// </summary>
		// Token: 0x14000015 RID: 21
		// (add) Token: 0x060003C0 RID: 960 RVA: 0x0000EE50 File Offset: 0x0000D050
		// (remove) Token: 0x060003C1 RID: 961 RVA: 0x0000EE84 File Offset: 0x0000D084
		public static event ModulesShutdownHandler onModulesShutdown;

		/// <summary>
		/// Find modules containing an assembly with the Both_Required role.
		/// </summary>
		/// <param name="result">Modules to append to.</param>
		// Token: 0x060003C2 RID: 962 RVA: 0x0000EEB8 File Offset: 0x0000D0B8
		public static void getRequiredModules(List<Module> result)
		{
			if (ModuleHook.modules == null || result == null)
			{
				return;
			}
			for (int i = 0; i < ModuleHook.modules.Count; i++)
			{
				Module module = ModuleHook.modules[i];
				if (module != null)
				{
					ModuleConfig config = module.config;
					if (config != null)
					{
						for (int j = 0; j < config.Assemblies.Count; j++)
						{
							ModuleAssembly moduleAssembly = config.Assemblies[j];
							if (moduleAssembly != null && moduleAssembly.Role == EModuleRole.Both_Required)
							{
								result.Add(module);
								break;
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Find module using dependency name.
		/// </summary>
		/// <returns></returns>
		// Token: 0x060003C3 RID: 963 RVA: 0x0000EF3C File Offset: 0x0000D13C
		public static Module getModuleByName(string name)
		{
			if (ModuleHook.modules == null)
			{
				return null;
			}
			for (int i = 0; i < ModuleHook.modules.Count; i++)
			{
				Module module = ModuleHook.modules[i];
				if (module != null && module.config != null && module.config.Name == name)
				{
					return module;
				}
			}
			return null;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0000EF94 File Offset: 0x0000D194
		public static void toggleModuleEnabled(int index)
		{
			if (index < 0 || index >= ModuleHook.modules.Count)
			{
				return;
			}
			Module module = ModuleHook.modules[index];
			ModuleConfig config = module.config;
			config.IsEnabled = !config.IsEnabled;
			IOUtility.jsonSerializer.serialize<ModuleConfig>(module.config, config.FilePath, true);
			ModuleHook.updateModuleEnabled(index, config.IsEnabled);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0000EFF8 File Offset: 0x0000D1F8
		public static void registerAssemblyPath(string path)
		{
			ModuleHook.registerAssemblyPath(path, false);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0000F004 File Offset: 0x0000D204
		public static void registerAssemblyPath(string path, bool loadAsByteArray)
		{
			AssemblyName assemblyName = AssemblyName.GetAssemblyName(path);
			if (!ModuleHook.nameToPath.ContainsKey(assemblyName.FullName))
			{
				ModuleHook.AssemblyFileSettings assemblyFileSettings = new ModuleHook.AssemblyFileSettings();
				assemblyFileSettings.absolutePath = path;
				assemblyFileSettings.loadAsByteArray = loadAsByteArray;
				ModuleHook.nameToPath.Add(assemblyName.FullName, assemblyFileSettings);
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0000F050 File Offset: 0x0000D250
		public static Assembly resolveAssemblyName(string name)
		{
			Assembly assembly;
			if (ModuleHook.nameToAssembly.TryGetValue(name, out assembly))
			{
				return assembly;
			}
			ModuleHook.AssemblyFileSettings assemblyFileSettings;
			if (ModuleHook.nameToPath.TryGetValue(name, out assemblyFileSettings))
			{
				if (assemblyFileSettings.loadAsByteArray)
				{
					assembly = Assembly.Load(File.ReadAllBytes(assemblyFileSettings.absolutePath));
				}
				else
				{
					assembly = Assembly.LoadFile(assemblyFileSettings.absolutePath);
				}
				ModuleHook.nameToAssembly.Add(name, assembly);
				return assembly;
			}
			return null;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0000F0B4 File Offset: 0x0000D2B4
		private static Assembly LoadAssemblyFromDiscoveredPaths(AssemblyName loadAssemblyName)
		{
			Assembly assembly = null;
			try
			{
				foreach (KeyValuePair<AssemblyName, string> keyValuePair in ModuleHook.discoveredNameToPath)
				{
					AssemblyName key = keyValuePair.Key;
					string value = keyValuePair.Value;
					if (string.Equals(key.Name, loadAssemblyName.Name) && (loadAssemblyName.Version == null || key.Version >= loadAssemblyName.Version))
					{
						if (ModuleHook.shouldLogAssemblyResolve)
						{
							UnturnedLog.info(string.Format("Using discovered assembly for \"{0}\" at \"{1}\"", loadAssemblyName, value));
						}
						if (ModuleHook.nameToAssembly.TryGetValue(key.Name, out assembly))
						{
							break;
						}
						assembly = Assembly.Load(File.ReadAllBytes(value));
						if (assembly != null)
						{
							ModuleHook.nameToAssembly.Add(key.Name, assembly);
							break;
						}
						break;
					}
				}
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, string.Format("Caught exception loading assembly for \"{0}\" from discovered paths:", loadAssemblyName));
			}
			return assembly;
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0000F1C8 File Offset: 0x0000D3C8
		public static Assembly resolveAssemblyPath(string path)
		{
			return ModuleHook.resolveAssemblyName(AssemblyName.GetAssemblyName(path).FullName);
		}

		/// <summary>
		/// Event for plugin frameworks (e.g., Rocket) to override AssemblyResolve handling.
		/// </summary>
		// Token: 0x14000016 RID: 22
		// (add) Token: 0x060003CA RID: 970 RVA: 0x0000F1DC File Offset: 0x0000D3DC
		// (remove) Token: 0x060003CB RID: 971 RVA: 0x0000F210 File Offset: 0x0000D410
		public static event ResolveEventHandler PreVanillaAssemblyResolve;

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x060003CC RID: 972 RVA: 0x0000F244 File Offset: 0x0000D444
		// (remove) Token: 0x060003CD RID: 973 RVA: 0x0000F278 File Offset: 0x0000D478
		public static event ResolveEventHandler PreVanillaAssemblyResolvePostRedirects;

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x060003CE RID: 974 RVA: 0x0000F2AC File Offset: 0x0000D4AC
		// (remove) Token: 0x060003CF RID: 975 RVA: 0x0000F2E0 File Offset: 0x0000D4E0
		public static event ResolveEventHandler PostVanillaAssemblyResolve;

		// Token: 0x060003D0 RID: 976 RVA: 0x0000F314 File Offset: 0x0000D514
		protected Assembly handleAssemblyResolve(object sender, ResolveEventArgs args)
		{
			if (ModuleHook.PreVanillaAssemblyResolve != null)
			{
				Assembly assembly = ModuleHook.PreVanillaAssemblyResolve(sender, args);
				if (ModuleHook.shouldLogAssemblyResolve)
				{
					if (assembly != null)
					{
						UnturnedLog.info(string.Format("PreVanillaAssemblyResolve found \"{0}\" for \"{1}\"", assembly.FullName, args.RequestingAssembly));
					}
					else
					{
						UnturnedLog.info(string.Format("PreVanillaAssemblyResolve is bound but unable to find \"{0}\" for \"{1}\"", args.Name, args.RequestingAssembly));
					}
				}
				if (assembly != null)
				{
					return assembly;
				}
			}
			if (string.Equals(args.Name, "Assembly-CSharp-firstpass, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null"))
			{
				if (ModuleHook.shouldLogAssemblyResolve)
				{
					UnturnedLog.info("Redirecting Assembly-CSharp-firstpass to com.rlabrecque.steamworks.net for {0}", new object[]
					{
						args.RequestingAssembly
					});
				}
				return typeof(SteamAPI).Assembly;
			}
			if (string.Equals(args.Name, "Steamworks.NET, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null"))
			{
				if (ModuleHook.shouldLogAssemblyResolve)
				{
					UnturnedLog.info("Redirecting Steamworks.NET to com.rlabrecque.steamworks.net for {0}", new object[]
					{
						args.RequestingAssembly
					});
				}
				return typeof(SteamAPI).Assembly;
			}
			if (ModuleHook.PreVanillaAssemblyResolvePostRedirects != null)
			{
				Assembly assembly2 = ModuleHook.PreVanillaAssemblyResolvePostRedirects(sender, args);
				if (ModuleHook.shouldLogAssemblyResolve)
				{
					if (assembly2 != null)
					{
						UnturnedLog.info(string.Format("PreVanillaAssemblyResolvePostRedirects found \"{0}\" for \"{1}\"", assembly2.FullName, args.RequestingAssembly));
					}
					else
					{
						UnturnedLog.info(string.Format("PreVanillaAssemblyResolvePostRedirects is bound but unable to find \"{0}\" for \"{1}\"", args.Name, args.RequestingAssembly));
					}
				}
				if (assembly2 != null)
				{
					return assembly2;
				}
			}
			Assembly assembly3 = ModuleHook.resolveAssemblyName(args.Name);
			if (assembly3 != null)
			{
				return assembly3;
			}
			if (ModuleHook.shouldSearchModulesForDLLs)
			{
				assembly3 = ModuleHook.LoadAssemblyFromDiscoveredPaths(new AssemblyName(args.Name));
				if (assembly3 != null)
				{
					return assembly3;
				}
			}
			if (ModuleHook.shouldLogAssemblyResolve)
			{
				UnturnedLog.error("Vanilla unable to resolve dependency \"" + args.Name + "\"! Please include it in one of your module assembly lists.");
			}
			if (ModuleHook.PostVanillaAssemblyResolve != null)
			{
				Assembly assembly4 = ModuleHook.PostVanillaAssemblyResolve(sender, args);
				if (ModuleHook.shouldLogAssemblyResolve)
				{
					if (assembly4 != null)
					{
						UnturnedLog.info(string.Format("PostVanillaAssemblyResolve found \"{0}\" for \"{1}\"", assembly4.FullName, args.RequestingAssembly));
					}
					else
					{
						UnturnedLog.info(string.Format("PostVanillaAssemblyResolve is bound but unable to find \"{0}\" for \"{1}\"", args.Name, args.RequestingAssembly));
					}
				}
				if (assembly4 != null)
				{
					return assembly4;
				}
			}
			return null;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0000F55C File Offset: 0x0000D75C
		protected Assembly OnTypeResolve(object sender, ResolveEventArgs args)
		{
			if (args.Name.StartsWith("SDG.NetTransport."))
			{
				UnturnedLog.info("Redirecting type \"{0}\" assembly for {1}", new object[]
				{
					args.Name,
					args.RequestingAssembly
				});
				return typeof(ITransportConnection).Assembly;
			}
			UnturnedLog.info("Unable to resolve type \"{0}\" for {1}", new object[]
			{
				args.Name,
				args.RequestingAssembly
			});
			return null;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0000F5D0 File Offset: 0x0000D7D0
		private static bool areModuleDependenciesEnabled(int moduleIndex)
		{
			ModuleConfig config = ModuleHook.modules[moduleIndex].config;
			for (int i = 0; i < config.Dependencies.Count; i++)
			{
				ModuleDependency moduleDependency = config.Dependencies[i];
				int index = moduleIndex - 1;
				while (moduleIndex >= 0)
				{
					if (ModuleHook.modules[index].config.Name == moduleDependency.Name && !ModuleHook.modules[index].isEnabled)
					{
						return false;
					}
					moduleIndex--;
				}
			}
			return true;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0000F658 File Offset: 0x0000D858
		private static void updateModuleEnabled(int index, bool enable)
		{
			if (enable)
			{
				if (ModuleHook.modules[index].config.IsEnabled && ModuleHook.areModuleDependenciesEnabled(index) && !ModuleHook.isModuleDisabledByCommandLine(ModuleHook.modules[index].config.Name))
				{
					ModuleHook.modules[index].isEnabled = true;
					for (int i = index + 1; i < ModuleHook.modules.Count; i++)
					{
						for (int j = 0; j < ModuleHook.modules[i].config.Dependencies.Count; j++)
						{
							if (ModuleHook.modules[i].config.Dependencies[j].Name == ModuleHook.modules[index].config.Name)
							{
								ModuleHook.updateModuleEnabled(i, true);
								break;
							}
						}
					}
					return;
				}
			}
			else
			{
				for (int k = ModuleHook.modules.Count - 1; k > index; k--)
				{
					for (int l = 0; l < ModuleHook.modules[k].config.Dependencies.Count; l++)
					{
						if (ModuleHook.modules[k].config.Dependencies[l].Name == ModuleHook.modules[index].config.Name)
						{
							ModuleHook.updateModuleEnabled(k, false);
							break;
						}
					}
				}
				ModuleHook.modules[index].isEnabled = false;
			}
		}

		/// <summary>
		/// Depending on the platform, assemblies are found in different directories.
		/// </summary>
		/// <returns>Root folder for modules.</returns>
		// Token: 0x060003D4 RID: 980 RVA: 0x0000F7D4 File Offset: 0x0000D9D4
		private string getModulesRootPath()
		{
			if (ModuleHook.modulesPathOverride.hasValue)
			{
				return ModuleHook.modulesPathOverride.value;
			}
			string text = Path.Join(ReadWrite.PATH, "Modules");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			return text;
		}

		/// <summary>
		/// Search Modules directory for .dll files and save their AssemblyName to discoveredNameToPath.
		/// </summary>
		// Token: 0x060003D5 RID: 981 RVA: 0x0000F824 File Offset: 0x0000DA24
		private void DiscoverAssemblies()
		{
			try
			{
				foreach (string text in Directory.GetFiles(this.getModulesRootPath(), "*.dll", SearchOption.AllDirectories))
				{
					try
					{
						AssemblyName assemblyName = AssemblyName.GetAssemblyName(text);
						UnturnedLog.info(string.Format("Discovered assembly \"{0}\" at \"{1}\"", assemblyName, text));
						string arg;
						if (!ModuleHook.discoveredNameToPath.TryGetValue(assemblyName, out arg))
						{
							ModuleHook.discoveredNameToPath.Add(assemblyName, text);
							UnturnedLog.info(string.Format("Discovered assembly \"{0}\" at \"{1}\"", assemblyName, text));
						}
						else
						{
							UnturnedLog.info(string.Format("Discovered duplicate of assembly \"{0}\" at \"{1}\" (first found at \"{2}\")", assemblyName, text, arg));
						}
					}
					catch (Exception ex)
					{
						UnturnedLog.info(string.Concat(new string[]
						{
							"Caught exception trying to determine AssemblyName for dll \"",
							text,
							"\": \"",
							ex.Message,
							"\""
						}));
					}
				}
			}
			catch (Exception e)
			{
				UnturnedLog.exception(e, "Caught exception discovering assemblies in Modules folder:");
			}
		}

		/// <summary>
		/// Search Modules directory for .module files and load them.
		/// </summary>
		// Token: 0x060003D6 RID: 982 RVA: 0x0000F91C File Offset: 0x0000DB1C
		private List<ModuleConfig> findModules()
		{
			List<ModuleConfig> list = new List<ModuleConfig>();
			string modulesRootPath = this.getModulesRootPath();
			UnturnedLog.info("Looking for module files in: " + modulesRootPath);
			this.findModules(modulesRootPath, list);
			return list;
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0000F950 File Offset: 0x0000DB50
		private void findModules(string path, List<ModuleConfig> configs)
		{
			foreach (string text in Directory.GetFiles(path, "*.module"))
			{
				try
				{
					ModuleConfig moduleConfig = IOUtility.jsonDeserializer.deserialize<ModuleConfig>(text);
					if (moduleConfig == null)
					{
						UnturnedLog.warn("Unable to parse module config file: " + text);
					}
					else
					{
						moduleConfig.DirectoryPath = path;
						moduleConfig.FilePath = text;
						moduleConfig.Version_Internal = Parser.getUInt32FromIP(moduleConfig.Version);
						for (int j = moduleConfig.Dependencies.Count - 1; j >= 0; j--)
						{
							ModuleDependency moduleDependency = moduleConfig.Dependencies[j];
							if (moduleDependency.Name == "Framework" || moduleDependency.Name == "Unturned")
							{
								moduleConfig.Dependencies.RemoveAtFast(j);
							}
							else
							{
								moduleDependency.Version_Internal = Parser.getUInt32FromIP(moduleDependency.Version);
							}
						}
						configs.Add(moduleConfig);
					}
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e, "Caught exception parsing .module file: " + text);
				}
			}
			foreach (string path2 in Directory.GetDirectories(path))
			{
				this.findModules(path2, configs);
			}
		}

		/// <summary>
		/// Orders configs by dependency and removes those that are missing files.
		/// </summary>
		// Token: 0x060003D8 RID: 984 RVA: 0x0000FA94 File Offset: 0x0000DC94
		private void sortModules(List<ModuleConfig> configs)
		{
			ModuleComparer comparer = new ModuleComparer();
			configs.Sort(comparer);
			for (int i = 0; i < configs.Count; i++)
			{
				ModuleConfig moduleConfig = configs[i];
				bool flag = true;
				for (int j = moduleConfig.Assemblies.Count - 1; j >= 0; j--)
				{
					ModuleAssembly moduleAssembly = moduleConfig.Assemblies[j];
					if (moduleAssembly.Role == EModuleRole.Client && Dedicator.IsDedicatedServer)
					{
						moduleConfig.Assemblies.RemoveAt(j);
					}
					else if (moduleAssembly.Role == EModuleRole.Server && !Dedicator.IsDedicatedServer)
					{
						moduleConfig.Assemblies.RemoveAt(j);
					}
					else
					{
						bool flag2 = false;
						for (int k = 1; k < moduleAssembly.Path.Length; k++)
						{
							if (moduleAssembly.Path[k] == '.' && moduleAssembly.Path[k - 1] == '.')
							{
								flag2 = true;
								break;
							}
						}
						if (flag2)
						{
							flag = false;
							break;
						}
						string text = moduleConfig.DirectoryPath + moduleAssembly.Path;
						if (!File.Exists(text))
						{
							flag = false;
							UnturnedLog.warn("Module \"" + moduleConfig.Name + "\" missing assembly: " + text);
							break;
						}
					}
				}
				if (!flag || moduleConfig.Assemblies.Count == 0)
				{
					configs.RemoveAt(i);
					i--;
					UnturnedLog.info("Discard module \"" + moduleConfig.Name + "\" because it has no assemblies");
				}
				else
				{
					for (int l = 0; l < moduleConfig.Dependencies.Count; l++)
					{
						ModuleDependency moduleDependency = moduleConfig.Dependencies[l];
						bool flag3 = false;
						int m = i - 1;
						while (m >= 0)
						{
							if (configs[m].Name == moduleDependency.Name)
							{
								if (configs[m].Version_Internal >= moduleDependency.Version_Internal)
								{
									flag3 = true;
									break;
								}
								break;
							}
							else
							{
								m--;
							}
						}
						if (!flag3)
						{
							configs.RemoveAtFast(i);
							i--;
							UnturnedLog.warn(string.Concat(new string[]
							{
								"Discard module \"",
								moduleConfig.Name,
								"\" because dependency \"",
								moduleDependency.Name,
								"\" wasn't met"
							}));
							break;
						}
					}
				}
			}
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0000FCD4 File Offset: 0x0000DED4
		private void loadModules()
		{
			ModuleHook.modules = new List<Module>();
			ModuleHook.nameToPath = new Dictionary<string, ModuleHook.AssemblyFileSettings>();
			ModuleHook.discoveredNameToPath = new Dictionary<AssemblyName, string>();
			ModuleHook.nameToAssembly = new Dictionary<string, Assembly>();
			if (ModuleHook.shouldLoadModules)
			{
				if (ModuleHook.shouldSearchModulesForDLLs)
				{
					this.DiscoverAssemblies();
				}
				List<ModuleConfig> list = this.findModules();
				this.sortModules(list);
				if (list.Count > 0)
				{
					UnturnedLog.info(string.Format("Found {0} module(s):", list.Count));
				}
				for (int i = 0; i < list.Count; i++)
				{
					ModuleConfig moduleConfig = list[i];
					if (moduleConfig != null)
					{
						UnturnedLog.info(string.Format("{0}: \"{1}\"", i, moduleConfig.Name));
						Module item = new Module(moduleConfig);
						ModuleHook.modules.Add(item);
					}
				}
				return;
			}
			UnturnedLog.info("Disabling module loading because BattlEye is enabled");
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000FDAC File Offset: 0x0000DFAC
		private static bool isModuleDisabledByCommandLine(string moduleName)
		{
			string text = CommandLine.Get();
			int num = text.IndexOf(moduleName, StringComparison.OrdinalIgnoreCase);
			if (num == -1)
			{
				return false;
			}
			string text2 = "-disableModule/";
			int num2 = num - text2.Length;
			return num2 >= 0 && text.Substring(num2, text2.Length) == text2;
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0000FDFC File Offset: 0x0000DFFC
		private void initializeModules()
		{
			if (ModuleHook.modules == null)
			{
				return;
			}
			for (int i = 0; i < ModuleHook.modules.Count; i++)
			{
				Module module = ModuleHook.modules[i];
				ModuleConfig config = module.config;
				bool isEnabled;
				if (!config.IsEnabled)
				{
					isEnabled = false;
					UnturnedLog.info("Disabling module \"" + config.Name + "\" as requested by config");
				}
				else if (!ModuleHook.areModuleDependenciesEnabled(i))
				{
					isEnabled = false;
					UnturnedLog.info("Disabling module \"" + config.Name + "\" because dependencies are disabled");
				}
				else if (ModuleHook.isModuleDisabledByCommandLine(config.Name))
				{
					isEnabled = false;
					UnturnedLog.info("Disabling module \"" + config.Name + "\" as requested by command-line");
				}
				else
				{
					isEnabled = true;
				}
				module.isEnabled = isEnabled;
			}
			ModulesInitializedHandler modulesInitializedHandler = ModuleHook.onModulesInitialized;
			if (modulesInitializedHandler == null)
			{
				return;
			}
			modulesInitializedHandler();
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0000FECC File Offset: 0x0000E0CC
		private void shutdownModules()
		{
			if (ModuleHook.modules == null)
			{
				return;
			}
			for (int i = ModuleHook.modules.Count - 1; i >= 0; i--)
			{
				Module module = ModuleHook.modules[i];
				if (module != null)
				{
					module.isEnabled = false;
				}
			}
			ModulesShutdownHandler modulesShutdownHandler = ModuleHook.onModulesShutdown;
			if (modulesShutdownHandler == null)
			{
				return;
			}
			modulesShutdownHandler();
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0000FF20 File Offset: 0x0000E120
		public void awake()
		{
			AppDomain.CurrentDomain.AssemblyResolve += this.handleAssemblyResolve;
			AppDomain.CurrentDomain.TypeResolve += this.OnTypeResolve;
			ModuleHook.coreAssembly = Assembly.GetExecutingAssembly();
			try
			{
				ModuleHook.coreTypes = ModuleHook.coreAssembly.GetTypes();
			}
			catch (ReflectionTypeLoadException ex)
			{
				ModuleHook.coreTypes = ex.Types;
			}
			this.loadModules();
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0000FF98 File Offset: 0x0000E198
		public void start()
		{
			ModuleHook.coreNexii = new List<IModuleNexus>();
			ModuleHook.coreNexii.Clear();
			Type typeFromHandle = typeof(IModuleNexus);
			for (int i = 0; i < ModuleHook.coreTypes.Length; i++)
			{
				Type type = ModuleHook.coreTypes[i];
				if (!type.IsAbstract && typeFromHandle.TryIsAssignableFrom(type))
				{
					IModuleNexus moduleNexus = Activator.CreateInstance(type) as IModuleNexus;
					try
					{
						moduleNexus.initialize();
					}
					catch (Exception e)
					{
						UnturnedLog.error("Failed to initialize nexus!");
						UnturnedLog.exception(e);
					}
					ModuleHook.coreNexii.Add(moduleNexus);
				}
			}
			this.initializeModules();
		}

		// Token: 0x060003DF RID: 991 RVA: 0x00010038 File Offset: 0x0000E238
		private void OnDestroy()
		{
			this.shutdownModules();
			for (int i = 0; i < ModuleHook.coreNexii.Count; i++)
			{
				try
				{
					ModuleHook.coreNexii[i].shutdown();
				}
				catch (Exception e)
				{
					UnturnedLog.error("Failed to shutdown nexus!");
					UnturnedLog.exception(e);
				}
			}
			ModuleHook.coreNexii.Clear();
			AppDomain.CurrentDomain.AssemblyResolve -= this.handleAssemblyResolve;
			AppDomain.CurrentDomain.TypeResolve -= this.OnTypeResolve;
		}

		// Token: 0x040001B4 RID: 436
		private static List<IModuleNexus> coreNexii;

		// Token: 0x040001B7 RID: 439
		protected static Dictionary<string, ModuleHook.AssemblyFileSettings> nameToPath;

		/// <summary>
		/// These are *.dll files discovered in the modules folder.
		/// </summary>
		// Token: 0x040001B8 RID: 440
		protected static Dictionary<AssemblyName, string> discoveredNameToPath;

		// Token: 0x040001B9 RID: 441
		protected static Dictionary<string, Assembly> nameToAssembly;

		/// <summary>
		/// Should missing DLLs be logged?
		/// Opt-in because RocketMod has its own handler.
		/// </summary>
		// Token: 0x040001BA RID: 442
		private static CommandLineFlag shouldLogAssemblyResolve = new CommandLineFlag(false, "-LogAssemblyResolve");

		/// <summary>
		/// Should vanilla search for *.dll files?
		/// Can be turned off in case it conflicts with third-party search mechanism.
		/// </summary>
		// Token: 0x040001BB RID: 443
		private static CommandLineFlag shouldSearchModulesForDLLs = new CommandLineFlag(true, "-NoVanillaAssemblySearch");

		/// <summary>
		/// If set, search for .dll and .module files in this directory instead of in Unturned/Modules.
		/// </summary>
		// Token: 0x040001BC RID: 444
		private static CommandLineString modulesPathOverride = new CommandLineString("-ModulesPath");

		// Token: 0x02000900 RID: 2304
		protected class AssemblyFileSettings
		{
			// Token: 0x040036BF RID: 14015
			public string absolutePath;

			// Token: 0x040036C0 RID: 14016
			public bool loadAsByteArray;
		}
	}
}
