﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SDG.Framework.Modules
{
	// Token: 0x02000094 RID: 148
	public class ModuleAssembly
	{
		// Token: 0x060003AA RID: 938 RVA: 0x0000EC92 File Offset: 0x0000CE92
		public ModuleAssembly()
		{
			this.Path = string.Empty;
			this.Role = EModuleRole.None;
			this.Load_As_Byte_Array = false;
		}

		// Token: 0x040001A3 RID: 419
		public string Path;

		// Token: 0x040001A4 RID: 420
		[JsonConverter(typeof(StringEnumConverter))]
		public EModuleRole Role;

		/// <summary>
		/// Useful as a workaround enabling plugin frameworks to self-update, otherwise LoadFile locks the file while in use.
		/// </summary>
		// Token: 0x040001A5 RID: 421
		public bool Load_As_Byte_Array;
	}
}
