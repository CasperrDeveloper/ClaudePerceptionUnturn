﻿using System;
using System.Collections.Generic;
using System.Reflection;
using SDG.Unturned;
using Unturned.SystemEx;

namespace SDG.Framework.Modules
{
	/// <summary>
	/// Wraps module assembly and handles initialization.
	/// </summary>
	// Token: 0x02000093 RID: 147
	public class Module
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000395 RID: 917 RVA: 0x0000E6C8 File Offset: 0x0000C8C8
		// (set) Token: 0x06000396 RID: 918 RVA: 0x0000E6D0 File Offset: 0x0000C8D0
		public bool isEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				if (this.isEnabled == value)
				{
					return;
				}
				this._isEnabled = value;
				if (this.isEnabled)
				{
					this.load();
					this.initialize();
					return;
				}
				this.shutdown();
			}
		}

		/// <summary>
		/// Metadata.
		/// </summary>
		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000397 RID: 919 RVA: 0x0000E6FE File Offset: 0x0000C8FE
		// (set) Token: 0x06000398 RID: 920 RVA: 0x0000E706 File Offset: 0x0000C906
		public ModuleConfig config { get; protected set; }

		/// <summary>
		/// Assembly files loaded.
		/// </summary>
		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000399 RID: 921 RVA: 0x0000E70F File Offset: 0x0000C90F
		// (set) Token: 0x0600039A RID: 922 RVA: 0x0000E717 File Offset: 0x0000C917
		public Assembly[] assemblies { get; protected set; }

		/// <summary>
		/// Types in the assemblies of this module. Refer to this for types rather than the assemblies to avoid exception and garbage.
		/// </summary>
		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600039B RID: 923 RVA: 0x0000E720 File Offset: 0x0000C920
		// (set) Token: 0x0600039C RID: 924 RVA: 0x0000E728 File Offset: 0x0000C928
		public Type[] types { get; protected set; }

		/// <summary>
		/// How far along the initialization to shutdown lifecycle this module is.
		/// </summary>
		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600039D RID: 925 RVA: 0x0000E731 File Offset: 0x0000C931
		// (set) Token: 0x0600039E RID: 926 RVA: 0x0000E739 File Offset: 0x0000C939
		public EModuleStatus status { get; protected set; }

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x0600039F RID: 927 RVA: 0x0000E744 File Offset: 0x0000C944
		// (remove) Token: 0x060003A0 RID: 928 RVA: 0x0000E77C File Offset: 0x0000C97C
		public event ModuleLoaded onModuleLoaded;

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x060003A1 RID: 929 RVA: 0x0000E7B4 File Offset: 0x0000C9B4
		// (remove) Token: 0x060003A2 RID: 930 RVA: 0x0000E7EC File Offset: 0x0000C9EC
		public event ModuleInitialized onModuleInitialized;

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x060003A3 RID: 931 RVA: 0x0000E824 File Offset: 0x0000CA24
		// (remove) Token: 0x060003A4 RID: 932 RVA: 0x0000E85C File Offset: 0x0000CA5C
		public event ModuleShutdown onModuleShutdown;

		// Token: 0x060003A5 RID: 933 RVA: 0x0000E894 File Offset: 0x0000CA94
		protected void register()
		{
			if (this.config == null)
			{
				return;
			}
			foreach (ModuleAssembly moduleAssembly in this.config.Assemblies)
			{
				ModuleHook.registerAssemblyPath(this.config.DirectoryPath + moduleAssembly.Path, moduleAssembly.Load_As_Byte_Array);
			}
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0000E910 File Offset: 0x0000CB10
		protected void load()
		{
			if (this.config == null || this.assemblies != null)
			{
				return;
			}
			if (!this.config.IsEnabled)
			{
				return;
			}
			List<Type> list = new List<Type>();
			this.assemblies = new Assembly[this.config.Assemblies.Count];
			for (int i = 0; i < this.config.Assemblies.Count; i++)
			{
				Assembly assembly = ModuleHook.resolveAssemblyPath(this.config.DirectoryPath + this.config.Assemblies[i].Path);
				this.assemblies[i] = assembly;
				Type[] types;
				try
				{
					types = assembly.GetTypes();
				}
				catch (ReflectionTypeLoadException ex)
				{
					types = ex.Types;
				}
				if (types != null)
				{
					for (int j = 0; j < types.Length; j++)
					{
						if (!(types[j] == null))
						{
							list.Add(types[j]);
						}
					}
				}
			}
			this.types = list.ToArray();
			ModuleLoaded moduleLoaded = this.onModuleLoaded;
			if (moduleLoaded == null)
			{
				return;
			}
			moduleLoaded(this);
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0000EA1C File Offset: 0x0000CC1C
		protected void initialize()
		{
			if (this.config == null || this.assemblies == null)
			{
				return;
			}
			if (this.status != EModuleStatus.None && this.status != EModuleStatus.Shutdown)
			{
				return;
			}
			this.nexii.Clear();
			Type typeFromHandle = typeof(IModuleNexus);
			for (int i = 0; i < this.types.Length; i++)
			{
				Type type = this.types[i];
				try
				{
					if (!type.IsAbstract && typeFromHandle.TryIsAssignableFrom(type))
					{
						IModuleNexus moduleNexus = Activator.CreateInstance(type) as IModuleNexus;
						try
						{
							moduleNexus.initialize();
						}
						catch (Exception e)
						{
							UnturnedLog.error(string.Concat(new string[]
							{
								"Caught exception while initializing module \"",
								this.config.Name,
								"\" entry point \"",
								type.Name,
								"\":"
							}));
							UnturnedLog.exception(e);
						}
						this.nexii.Add(moduleNexus);
					}
				}
				catch (Exception e2)
				{
					UnturnedLog.exception(e2, string.Concat(new string[]
					{
						"Caught exception while searching for entry points in module \"",
						this.config.Name,
						"\" type \"",
						type.Name,
						"\""
					}));
				}
			}
			this.status = EModuleStatus.Initialized;
			UnturnedLog.info("Initialized module \"" + this.config.Name + "\"");
			ModuleInitialized moduleInitialized = this.onModuleInitialized;
			if (moduleInitialized == null)
			{
				return;
			}
			moduleInitialized(this);
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0000EB98 File Offset: 0x0000CD98
		protected void shutdown()
		{
			if (this.config == null || this.assemblies == null)
			{
				return;
			}
			if (this.status != EModuleStatus.Initialized)
			{
				return;
			}
			for (int i = 0; i < this.nexii.Count; i++)
			{
				try
				{
					this.nexii[i].shutdown();
				}
				catch (Exception e)
				{
					UnturnedLog.error("Caught exception while shutting down module \"" + this.config.Name + "\":");
					UnturnedLog.exception(e);
				}
			}
			this.nexii.Clear();
			this.status = EModuleStatus.Shutdown;
			UnturnedLog.info("Shutdown module \"" + this.config.Name + "\"");
			ModuleShutdown moduleShutdown = this.onModuleShutdown;
			if (moduleShutdown == null)
			{
				return;
			}
			moduleShutdown(this);
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x0000EC64 File Offset: 0x0000CE64
		public Module(ModuleConfig newConfig)
		{
			this.config = newConfig;
			this.isEnabled = false;
			this.status = EModuleStatus.None;
			this.nexii = new List<IModuleNexus>();
			this.register();
		}

		/// <summary>
		/// True when config is enabled and dependencies are enabled.
		/// </summary>
		// Token: 0x0400019A RID: 410
		protected bool _isEnabled;

		// Token: 0x0400019F RID: 415
		private List<IModuleNexus> nexii;
	}
}
