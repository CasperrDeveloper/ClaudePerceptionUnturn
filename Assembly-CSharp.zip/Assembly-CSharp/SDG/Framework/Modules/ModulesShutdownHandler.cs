﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x02000099 RID: 153
	// (Invoke) Token: 0x060003B4 RID: 948
	public delegate void ModulesShutdownHandler();
}
