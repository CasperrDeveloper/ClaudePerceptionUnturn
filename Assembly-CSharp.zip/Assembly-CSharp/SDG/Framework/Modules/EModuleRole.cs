﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x0200008D RID: 141
	public enum EModuleRole
	{
		// Token: 0x04000191 RID: 401
		None,
		// Token: 0x04000192 RID: 402
		Client,
		// Token: 0x04000193 RID: 403
		Server,
		// Token: 0x04000194 RID: 404
		Both_Optional,
		// Token: 0x04000195 RID: 405
		Both_Required
	}
}
