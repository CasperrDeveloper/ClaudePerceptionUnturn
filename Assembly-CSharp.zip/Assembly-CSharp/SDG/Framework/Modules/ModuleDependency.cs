﻿using System;
using Newtonsoft.Json;

namespace SDG.Framework.Modules
{
	// Token: 0x02000097 RID: 151
	public class ModuleDependency
	{
		// Token: 0x060003AE RID: 942 RVA: 0x0000ED89 File Offset: 0x0000CF89
		public ModuleDependency()
		{
			this.Name = string.Empty;
			this.Version = "1.0.0.0";
		}

		// Token: 0x040001AE RID: 430
		public string Name;

		/// <summary>
		/// Nicely formatted version, converted into <see cref="F:SDG.Framework.Modules.ModuleDependency.Version_Internal" />.
		/// </summary>
		// Token: 0x040001AF RID: 431
		public string Version;

		/// <summary>
		/// Used for module dependencies.
		/// </summary>
		// Token: 0x040001B0 RID: 432
		[JsonIgnore]
		public uint Version_Internal;
	}
}
