﻿using System;

namespace SDG.Framework.Modules
{
	// Token: 0x02000091 RID: 145
	// (Invoke) Token: 0x0600038E RID: 910
	public delegate void ModuleInitialized(Module module);
}
