﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000154 RID: 340
	// (Invoke) Token: 0x06000896 RID: 2198
	public delegate void InspectableListRemovedHandler(IInspectableList list, object instance);
}
