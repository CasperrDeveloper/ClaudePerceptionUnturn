﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000153 RID: 339
	// (Invoke) Token: 0x06000892 RID: 2194
	public delegate void InspectableListAddedHandler(IInspectableList list, object instance);
}
