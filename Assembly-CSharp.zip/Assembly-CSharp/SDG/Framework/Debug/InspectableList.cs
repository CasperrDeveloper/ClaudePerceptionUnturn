﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Debug
{
	// Token: 0x0200015A RID: 346
	public class InspectableList<T> : List<T>, IInspectableList
	{
		// Token: 0x1400002D RID: 45
		// (add) Token: 0x060008B7 RID: 2231 RVA: 0x00021288 File Offset: 0x0001F488
		// (remove) Token: 0x060008B8 RID: 2232 RVA: 0x000212C0 File Offset: 0x0001F4C0
		public event InspectableListAddedHandler inspectorAdded;

		// Token: 0x1400002E RID: 46
		// (add) Token: 0x060008B9 RID: 2233 RVA: 0x000212F8 File Offset: 0x0001F4F8
		// (remove) Token: 0x060008BA RID: 2234 RVA: 0x00021330 File Offset: 0x0001F530
		public event InspectableListRemovedHandler inspectorRemoved;

		// Token: 0x1400002F RID: 47
		// (add) Token: 0x060008BB RID: 2235 RVA: 0x00021368 File Offset: 0x0001F568
		// (remove) Token: 0x060008BC RID: 2236 RVA: 0x000213A0 File Offset: 0x0001F5A0
		public event InspectableListChangedHandler inspectorChanged;

		// Token: 0x060008BD RID: 2237 RVA: 0x000213D5 File Offset: 0x0001F5D5
		public new void Add(T item)
		{
			base.Add(item);
			this.triggerChanged();
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x000213E4 File Offset: 0x0001F5E4
		public new bool Remove(T item)
		{
			bool result = base.Remove(item);
			this.triggerChanged();
			return result;
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x000213F3 File Offset: 0x0001F5F3
		public new void RemoveAt(int index)
		{
			base.RemoveAt(index);
			this.triggerChanged();
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x00021402 File Offset: 0x0001F602
		public virtual void inspectorAdd(object instance)
		{
			this.triggerAdded(instance);
			this.triggerChanged();
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x00021411 File Offset: 0x0001F611
		public virtual void inspectorRemove(object instance)
		{
			this.triggerRemoved(instance);
			this.triggerChanged();
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00021420 File Offset: 0x0001F620
		public virtual void inspectorSet(int index)
		{
			this.triggerChanged();
		}

		/// <summary>
		/// Whether add can be called from the inspector.
		/// </summary>
		// Token: 0x1700011B RID: 283
		// (get) Token: 0x060008C3 RID: 2243 RVA: 0x00021428 File Offset: 0x0001F628
		// (set) Token: 0x060008C4 RID: 2244 RVA: 0x00021430 File Offset: 0x0001F630
		public virtual bool canInspectorAdd { get; set; }

		/// <summary>
		/// Whether remove can be called from the inspector.
		/// </summary>
		// Token: 0x1700011C RID: 284
		// (get) Token: 0x060008C5 RID: 2245 RVA: 0x00021439 File Offset: 0x0001F639
		// (set) Token: 0x060008C6 RID: 2246 RVA: 0x00021441 File Offset: 0x0001F641
		public virtual bool canInspectorRemove { get; set; }

		// Token: 0x060008C7 RID: 2247 RVA: 0x0002144A File Offset: 0x0001F64A
		protected virtual void triggerAdded(object instance)
		{
			InspectableListAddedHandler inspectableListAddedHandler = this.inspectorAdded;
			if (inspectableListAddedHandler == null)
			{
				return;
			}
			inspectableListAddedHandler(this, instance);
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x0002145E File Offset: 0x0001F65E
		protected virtual void triggerRemoved(object instance)
		{
			InspectableListRemovedHandler inspectableListRemovedHandler = this.inspectorRemoved;
			if (inspectableListRemovedHandler == null)
			{
				return;
			}
			inspectableListRemovedHandler(this, instance);
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x00021472 File Offset: 0x0001F672
		protected virtual void triggerChanged()
		{
			InspectableListChangedHandler inspectableListChangedHandler = this.inspectorChanged;
			if (inspectableListChangedHandler == null)
			{
				return;
			}
			inspectableListChangedHandler(this);
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x00021485 File Offset: 0x0001F685
		public InspectableList()
		{
			this.canInspectorAdd = true;
			this.canInspectorRemove = true;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0002149B File Offset: 0x0001F69B
		public InspectableList(int capacity) : base(capacity)
		{
			this.canInspectorAdd = false;
			this.canInspectorRemove = false;
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x000214B2 File Offset: 0x0001F6B2
		public InspectableList(IEnumerable<T> collection) : base(collection)
		{
			this.canInspectorAdd = true;
			this.canInspectorRemove = true;
		}
	}
}
