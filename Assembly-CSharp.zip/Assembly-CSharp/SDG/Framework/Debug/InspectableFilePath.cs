﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000159 RID: 345
	public struct InspectableFilePath : IInspectablePath
	{
		// Token: 0x17000118 RID: 280
		// (get) Token: 0x060008B0 RID: 2224 RVA: 0x00021237 File Offset: 0x0001F437
		// (set) Token: 0x060008B1 RID: 2225 RVA: 0x0002123F File Offset: 0x0001F43F
		public string absolutePath { readonly get; set; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x060008B2 RID: 2226 RVA: 0x00021248 File Offset: 0x0001F448
		// (set) Token: 0x060008B3 RID: 2227 RVA: 0x00021250 File Offset: 0x0001F450
		public string extension { readonly get; private set; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x060008B4 RID: 2228 RVA: 0x00021259 File Offset: 0x0001F459
		public bool isValid
		{
			get
			{
				return !string.IsNullOrEmpty(this.absolutePath);
			}
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00021269 File Offset: 0x0001F469
		public override string ToString()
		{
			return this.absolutePath;
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00021271 File Offset: 0x0001F471
		public InspectableFilePath(string newExtension)
		{
			this.absolutePath = string.Empty;
			this.extension = newExtension;
		}
	}
}
