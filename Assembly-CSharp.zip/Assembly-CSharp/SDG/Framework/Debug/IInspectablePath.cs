﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000157 RID: 343
	public interface IInspectablePath
	{
		// Token: 0x17000115 RID: 277
		// (get) Token: 0x060008AA RID: 2218
		// (set) Token: 0x060008AB RID: 2219
		string absolutePath { get; set; }
	}
}
