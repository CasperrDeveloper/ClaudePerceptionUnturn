﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000158 RID: 344
	public struct InspectableDirectoryPath : IInspectablePath
	{
		// Token: 0x17000116 RID: 278
		// (get) Token: 0x060008AC RID: 2220 RVA: 0x0002120E File Offset: 0x0001F40E
		// (set) Token: 0x060008AD RID: 2221 RVA: 0x00021216 File Offset: 0x0001F416
		public string absolutePath { readonly get; set; }

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x060008AE RID: 2222 RVA: 0x0002121F File Offset: 0x0001F41F
		public bool isValid
		{
			get
			{
				return !string.IsNullOrEmpty(this.absolutePath);
			}
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x0002122F File Offset: 0x0001F42F
		public override string ToString()
		{
			return this.absolutePath;
		}
	}
}
