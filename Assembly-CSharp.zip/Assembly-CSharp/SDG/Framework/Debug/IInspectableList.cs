﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000156 RID: 342
	public interface IInspectableList
	{
		// Token: 0x1400002A RID: 42
		// (add) Token: 0x0600089D RID: 2205
		// (remove) Token: 0x0600089E RID: 2206
		event InspectableListAddedHandler inspectorAdded;

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x0600089F RID: 2207
		// (remove) Token: 0x060008A0 RID: 2208
		event InspectableListRemovedHandler inspectorRemoved;

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x060008A1 RID: 2209
		// (remove) Token: 0x060008A2 RID: 2210
		event InspectableListChangedHandler inspectorChanged;

		/// <summary>
		/// Called when the inspector adds an element.
		/// </summary>
		// Token: 0x060008A3 RID: 2211
		void inspectorAdd(object instance);

		/// <summary>
		/// Called when the inspector removes an element.
		/// </summary>
		// Token: 0x060008A4 RID: 2212
		void inspectorRemove(object instance);

		/// <summary>
		/// Called when the inspector sets an element to a different value.
		/// </summary>
		// Token: 0x060008A5 RID: 2213
		void inspectorSet(int index);

		/// <summary>
		/// Whether add can be called from the inspector.
		/// </summary>
		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060008A6 RID: 2214
		// (set) Token: 0x060008A7 RID: 2215
		bool canInspectorAdd { get; set; }

		/// <summary>
		/// Whether remove can be called from the inspector.
		/// </summary>
		// Token: 0x17000114 RID: 276
		// (get) Token: 0x060008A8 RID: 2216
		// (set) Token: 0x060008A9 RID: 2217
		bool canInspectorRemove { get; set; }
	}
}
