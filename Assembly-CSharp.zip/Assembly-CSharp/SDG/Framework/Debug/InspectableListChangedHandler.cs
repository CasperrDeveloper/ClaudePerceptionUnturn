﻿using System;

namespace SDG.Framework.Debug
{
	// Token: 0x02000155 RID: 341
	// (Invoke) Token: 0x0600089A RID: 2202
	public delegate void InspectableListChangedHandler(IInspectableList list);
}
