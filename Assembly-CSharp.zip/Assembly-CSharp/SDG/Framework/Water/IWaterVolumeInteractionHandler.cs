﻿using System;

namespace SDG.Framework.Water
{
	// Token: 0x02000079 RID: 121
	public interface IWaterVolumeInteractionHandler
	{
		// Token: 0x060002FA RID: 762
		void waterBeginCollision(WaterVolume volume);

		// Token: 0x060002FB RID: 763
		void waterEndCollision(WaterVolume volume);
	}
}
