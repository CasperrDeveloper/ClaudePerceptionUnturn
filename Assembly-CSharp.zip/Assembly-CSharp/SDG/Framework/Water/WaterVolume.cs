﻿using System;
using SDG.Framework.Devkit;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Water
{
	// Token: 0x0200007B RID: 123
	public class WaterVolume : LevelVolume<WaterVolume, WaterVolumeManager>
	{
		// Token: 0x06000305 RID: 773 RVA: 0x0000C9E4 File Offset: 0x0000ABE4
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new WaterVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000306 RID: 774 RVA: 0x0000CA00 File Offset: 0x0000AC00
		// (set) Token: 0x06000307 RID: 775 RVA: 0x0000CA08 File Offset: 0x0000AC08
		public override ELevelVolumeShape Shape
		{
			get
			{
				return base.Shape;
			}
			set
			{
				base.Shape = value;
				this.SyncWaterPlaneActive();
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0000CA17 File Offset: 0x0000AC17
		// (set) Token: 0x06000309 RID: 777 RVA: 0x0000CA1F File Offset: 0x0000AC1F
		public bool isSurfaceVisible
		{
			get
			{
				return this._isSurfaceVisible;
			}
			set
			{
				this._isSurfaceVisible = value;
				this.SyncWaterPlaneActive();
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600030A RID: 778 RVA: 0x0000CA2E File Offset: 0x0000AC2E
		// (set) Token: 0x0600030B RID: 779 RVA: 0x0000CA36 File Offset: 0x0000AC36
		public bool isReflectionVisible
		{
			get
			{
				return this._isReflectionVisible;
			}
			set
			{
				this._isReflectionVisible = value;
				this.SyncPlanarReflectionEnabled();
			}
		}

		/// <summary>
		/// If true rain will be occluded below the surface on the Y axis.
		/// </summary>
		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600030C RID: 780 RVA: 0x0000CA45 File Offset: 0x0000AC45
		// (set) Token: 0x0600030D RID: 781 RVA: 0x0000CA4D File Offset: 0x0000AC4D
		public bool isSeaLevel
		{
			get
			{
				return this._isSeaLevel;
			}
			set
			{
				this._isSeaLevel = value;
				if (this.isSeaLevel)
				{
					WaterVolumeManager.seaLevelVolume = this;
				}
			}
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0000CA64 File Offset: 0x0000AC64
		public override void UpdateEditorVisibility(ELevelVolumeVisibility visibility)
		{
			base.UpdateEditorVisibility(visibility);
			this._editorIsSufaceVisible = (visibility != ELevelVolumeVisibility.Solid && LevelLighting.EditorWantsWaterSurface);
			this.SyncWaterPlaneActive();
		}

		// Token: 0x0600030F RID: 783 RVA: 0x0000CA88 File Offset: 0x0000AC88
		internal void SyncWaterQuality()
		{
			if (this.sharedMaterial == null)
			{
				return;
			}
			EGraphicQuality waterQuality = GraphicsSettings.waterQuality;
			if (waterQuality == EGraphicQuality.LOW)
			{
				this.sharedMaterial.shader.maximumLOD = 201;
				return;
			}
			if (waterQuality == EGraphicQuality.MEDIUM)
			{
				this.sharedMaterial.shader.maximumLOD = 301;
				return;
			}
			if (waterQuality == EGraphicQuality.HIGH || waterQuality == EGraphicQuality.ULTRA)
			{
				this.sharedMaterial.shader.maximumLOD = 501;
			}
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0000CAFC File Offset: 0x0000ACFC
		internal void SyncPlanarReflectionEnabled()
		{
			if (this.planarReflection != null)
			{
				this.planarReflection.enabled = (this.isReflectionVisible && GraphicsSettings.waterQuality == EGraphicQuality.ULTRA);
				if (this.sharedMaterial != null && !this.planarReflection.enabled)
				{
					this.sharedMaterial.DisableKeyword("WATER_REFLECTIVE");
					this.sharedMaterial.EnableKeyword("WATER_SIMPLE");
					this.sharedMaterial.SetTexture(this.planarReflection.reflectionSampler, null);
				}
			}
		}

		// Token: 0x06000311 RID: 785 RVA: 0x0000CB87 File Offset: 0x0000AD87
		private void SyncWaterPlaneActive()
		{
			if (this.waterPlane != null)
			{
				this.waterPlane.SetActive(this.isSurfaceVisible && this._editorIsSufaceVisible && this.Shape == ELevelVolumeShape.Box);
			}
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0000CBC0 File Offset: 0x0000ADC0
		protected void createWaterPlanes()
		{
			if (!Dedicator.IsDedicatedServer && this.waterPlane == null)
			{
				InstantiateParameters parameters = new InstantiateParameters
				{
					parent = base.transform,
					worldSpace = false
				};
				this.waterPlane = UnityEngine.Object.Instantiate<GameObject>(Resources.Load<GameObject>("Level/Water_Plane"), new Vector3(0f, 0.5f, 0f), Quaternion.identity, parameters);
				this.waterPlane.name = "Plane";
				this.waterPlane.transform.localScale = Vector3.one;
				this.planarReflection = this.waterPlane.GetComponent<PlanarReflection>();
				int num = Mathf.Max(1, Mathf.FloorToInt(base.transform.localScale.x / (float)WaterVolume.WATER_SURFACE_TILE_SIZE));
				int num2 = Mathf.Max(1, Mathf.FloorToInt(base.transform.localScale.z / (float)WaterVolume.WATER_SURFACE_TILE_SIZE));
				float num3 = 1f / (float)num;
				float num4 = 1f / (float)num2;
				for (int i = 0; i < num; i++)
				{
					for (int j = 0; j < num2; j++)
					{
						GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(Resources.Load<GameObject>("Level/Water_Tile"));
						gameObject.name = "Tile_" + i.ToString() + "_" + j.ToString();
						gameObject.transform.parent = this.waterPlane.transform;
						gameObject.transform.localPosition = new Vector3(-0.5f + num3 / 2f + (float)i * num3, 0f, -0.5f + num4 / 2f + (float)j * num4);
						gameObject.transform.localRotation = Quaternion.identity;
						gameObject.transform.localScale = new Vector3(0.01f * num3, 1f, 0.01f * num4);
						if (this.sharedMaterial == null)
						{
							this.sharedMaterial = gameObject.GetComponent<Renderer>().material;
						}
						else
						{
							gameObject.GetComponent<Renderer>().material = this.sharedMaterial;
						}
						gameObject.GetComponent<WaterTile>().reflection = this.planarReflection;
					}
				}
				this.planarReflection.sharedMaterial = this.sharedMaterial;
				this.SyncWaterQuality();
				this.SyncPlanarReflectionEnabled();
				this.SyncWaterPlaneActive();
				LevelLighting.updateLighting();
			}
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0000CE20 File Offset: 0x0000B020
		public void beginCollision(Collider collider)
		{
			if (collider == null)
			{
				return;
			}
			IWaterVolumeInteractionHandler component = collider.gameObject.GetComponent<IWaterVolumeInteractionHandler>();
			if (component != null)
			{
				component.waterBeginCollision(this);
			}
		}

		// Token: 0x06000314 RID: 788 RVA: 0x0000CE50 File Offset: 0x0000B050
		public void endCollision(Collider collider)
		{
			if (collider == null)
			{
				return;
			}
			IWaterVolumeInteractionHandler component = collider.gameObject.GetComponent<IWaterVolumeInteractionHandler>();
			if (component != null)
			{
				component.waterEndCollision(this);
			}
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0000CE80 File Offset: 0x0000B080
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.isSurfaceVisible = reader.readValue<bool>("Is_Surface_Visible");
			this.isReflectionVisible = reader.readValue<bool>("Is_Reflection_Visible");
			this.isSeaLevel = reader.readValue<bool>("Is_Sea_Level");
			this.waterType = reader.readValue<ERefillWaterType>("Water_Type");
			this.createWaterPlanes();
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0000CEE0 File Offset: 0x0000B0E0
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<bool>("Is_Surface_Visible", this.isSurfaceVisible);
			writer.writeValue<bool>("Is_Reflection_Visible", this.isReflectionVisible);
			writer.writeValue<bool>("Is_Sea_Level", this.isSeaLevel);
			writer.writeValue<ERefillWaterType>("Water_Type", this.waterType);
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000317 RID: 791 RVA: 0x0000CF38 File Offset: 0x0000B138
		public override bool ShouldSave
		{
			get
			{
				return !this.isManagedByLighting;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000318 RID: 792 RVA: 0x0000CF43 File Offset: 0x0000B143
		public override bool CanBeSelected
		{
			get
			{
				return !this.isManagedByLighting;
			}
		}

		// Token: 0x06000319 RID: 793 RVA: 0x0000CF4E File Offset: 0x0000B14E
		public void OnTriggerEnter(Collider other)
		{
			this.beginCollision(other);
		}

		// Token: 0x0600031A RID: 794 RVA: 0x0000CF57 File Offset: 0x0000B157
		public void OnTriggerExit(Collider other)
		{
			this.endCollision(other);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0000CF60 File Offset: 0x0000B160
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0000CF6F File Offset: 0x0000B16F
		protected override void Start()
		{
			base.Start();
			this.createWaterPlanes();
		}

		// Token: 0x04000167 RID: 359
		public static readonly int WATER_SURFACE_TILE_SIZE = 1024;

		// Token: 0x04000168 RID: 360
		public GameObject waterPlane;

		/// <summary>
		/// All water tiles and the planar reflection component reference this material.
		/// </summary>
		// Token: 0x04000169 RID: 361
		public Material sharedMaterial;

		// Token: 0x0400016A RID: 362
		public PlanarReflection planarReflection;

		// Token: 0x0400016B RID: 363
		[SerializeField]
		protected bool _isSurfaceVisible = true;

		// Token: 0x0400016C RID: 364
		protected bool _editorIsSufaceVisible = true;

		// Token: 0x0400016D RID: 365
		[SerializeField]
		protected bool _isReflectionVisible;

		// Token: 0x0400016E RID: 366
		[SerializeField]
		protected bool _isSeaLevel;

		/// <summary>
		/// Flag for legacy sea level.
		/// </summary>
		// Token: 0x0400016F RID: 367
		internal bool isManagedByLighting;

		// Token: 0x04000170 RID: 368
		public ERefillWaterType waterType = ERefillWaterType.SALTY;

		// Token: 0x020008FA RID: 2298
		private class Menu : SleekWrapper
		{
			// Token: 0x06005083 RID: 20611 RVA: 0x001F3768 File Offset: 0x001F1968
			public Menu(WaterVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 150f;
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.isSurfaceVisible;
				sleekToggle.AddLabel("Surface Visible", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnIsSurfaceVisibleToggled;
				base.AddChild(sleekToggle);
				ISleekToggle sleekToggle2 = Glazier.Get().CreateToggle();
				sleekToggle2.PositionOffset_Y = 40f;
				sleekToggle2.SizeOffset_X = 40f;
				sleekToggle2.SizeOffset_Y = 40f;
				sleekToggle2.Value = volume.isReflectionVisible;
				sleekToggle2.AddLabel("Reflection Visible", ESleekSide.RIGHT);
				sleekToggle2.OnValueChanged += this.OnIsReflectionVisibleToggled;
				base.AddChild(sleekToggle2);
				ISleekToggle sleekToggle3 = Glazier.Get().CreateToggle();
				sleekToggle3.PositionOffset_Y = 80f;
				sleekToggle3.SizeOffset_X = 40f;
				sleekToggle3.SizeOffset_Y = 40f;
				sleekToggle3.Value = volume.isSeaLevel;
				sleekToggle3.AddLabel("Sea Level", ESleekSide.RIGHT);
				sleekToggle3.OnValueChanged += this.OnIsSeaLevelToggled;
				base.AddChild(sleekToggle3);
				SleekButtonState sleekButtonState = new SleekButtonState(new GUIContent[]
				{
					new GUIContent("Clean"),
					new GUIContent("Salty"),
					new GUIContent("Dirty")
				});
				sleekButtonState.PositionOffset_Y = 120f;
				sleekButtonState.SizeOffset_X = 200f;
				sleekButtonState.SizeOffset_Y = 30f;
				sleekButtonState.AddLabel("Refill Type", ESleekSide.RIGHT);
				sleekButtonState.state = volume.waterType - ERefillWaterType.CLEAN;
				SleekButtonState sleekButtonState2 = sleekButtonState;
				sleekButtonState2.onSwappedState = (SwappedState)Delegate.Combine(sleekButtonState2.onSwappedState, new SwappedState(this.OnSwappedWaterType));
				base.AddChild(sleekButtonState);
			}

			// Token: 0x06005084 RID: 20612 RVA: 0x001F393B File Offset: 0x001F1B3B
			private void OnIsSurfaceVisibleToggled(ISleekToggle toggle, bool state)
			{
				this.volume.isSurfaceVisible = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x06005085 RID: 20613 RVA: 0x001F394E File Offset: 0x001F1B4E
			private void OnIsReflectionVisibleToggled(ISleekToggle toggle, bool state)
			{
				this.volume.isReflectionVisible = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x06005086 RID: 20614 RVA: 0x001F3961 File Offset: 0x001F1B61
			private void OnIsSeaLevelToggled(ISleekToggle toggle, bool state)
			{
				this.volume.isSeaLevel = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x06005087 RID: 20615 RVA: 0x001F3974 File Offset: 0x001F1B74
			private void OnSwappedWaterType(SleekButtonState button, int state)
			{
				this.volume.waterType = state + ERefillWaterType.CLEAN;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036BA RID: 14010
			private WaterVolume volume;
		}
	}
}
