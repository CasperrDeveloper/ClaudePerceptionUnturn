﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Water
{
	// Token: 0x0200007C RID: 124
	public class WaterVolumeManager : VolumeManager<WaterVolume, WaterVolumeManager>
	{
		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600031F RID: 799 RVA: 0x0000CFA6 File Offset: 0x0000B1A6
		public static float worldSeaLevel
		{
			get
			{
				if (WaterVolumeManager.seaLevelVolume != null)
				{
					return WaterVolumeManager.seaLevelVolume.transform.TransformPoint(0f, 0.5f, 0f).y;
				}
				return -1024f;
			}
		}

		// Token: 0x06000320 RID: 800 RVA: 0x0000CFE0 File Offset: 0x0000B1E0
		public WaterVolumeManager()
		{
			base.FriendlyName = "Water";
			base.SetDebugColor(new Color32(50, 200, 200, byte.MaxValue));
			if (!Dedicator.IsDedicatedServer)
			{
				this.oldWaterQuality = GraphicsSettings.waterQuality;
				this.wasPlanarReflectionEnabled = (this.oldWaterQuality == EGraphicQuality.ULTRA);
				GraphicsSettings.graphicsSettingsApplied += this.OnGraphicsSettingsApplied;
			}
		}

		// Token: 0x06000321 RID: 801 RVA: 0x0000D054 File Offset: 0x0000B254
		private void OnGraphicsSettingsApplied()
		{
			EGraphicQuality waterQuality = GraphicsSettings.waterQuality;
			if (this.oldWaterQuality != waterQuality)
			{
				this.oldWaterQuality = waterQuality;
				foreach (WaterVolume waterVolume in this.allVolumes)
				{
					waterVolume.SyncWaterQuality();
				}
				bool flag = waterQuality == EGraphicQuality.ULTRA;
				if (this.wasPlanarReflectionEnabled != flag)
				{
					this.wasPlanarReflectionEnabled = flag;
					foreach (WaterVolume waterVolume2 in this.allVolumes)
					{
						waterVolume2.SyncPlanarReflectionEnabled();
					}
				}
			}
		}

		/// <summary>
		/// Water volume marked as being sea level.
		/// </summary>
		// Token: 0x04000171 RID: 369
		public static WaterVolume seaLevelVolume;

		// Token: 0x04000172 RID: 370
		private EGraphicQuality oldWaterQuality;

		// Token: 0x04000173 RID: 371
		private bool wasPlanarReflectionEnabled;
	}
}
