﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Water
{
	// Token: 0x0200007A RID: 122
	public class WaterUtility
	{
		// Token: 0x060002FC RID: 764 RVA: 0x0000C820 File Offset: 0x0000AA20
		[Obsolete]
		public static bool isPointInsideVolume(Vector3 point)
		{
			return VolumeManager<WaterVolume, WaterVolumeManager>.Get().IsPositionInsideAnyVolume(point);
		}

		// Token: 0x060002FD RID: 765 RVA: 0x0000C82D File Offset: 0x0000AA2D
		[Obsolete]
		public static bool isPointInsideVolume(Vector3 point, out WaterVolume volume)
		{
			volume = VolumeManager<WaterVolume, WaterVolumeManager>.Get().GetFirstOverlappingVolume(point);
			return volume != null;
		}

		// Token: 0x060002FE RID: 766 RVA: 0x0000C844 File Offset: 0x0000AA44
		public static float getWaterSurfaceElevation(WaterVolume volume, Vector3 point)
		{
			point.y += 1024f;
			Ray ray = new Ray(point, new Vector3(0f, -1f, 0f));
			RaycastHit raycastHit;
			if (volume.volumeCollider.Raycast(ray, out raycastHit, 2048f))
			{
				return raycastHit.point.y;
			}
			return 0f;
		}

		// Token: 0x060002FF RID: 767 RVA: 0x0000C8A4 File Offset: 0x0000AAA4
		[Obsolete]
		public static bool isPointInsideVolume(WaterVolume volume, Vector3 point)
		{
			return volume.IsPositionInsideVolume(point);
		}

		// Token: 0x06000300 RID: 768 RVA: 0x0000C8AD File Offset: 0x0000AAAD
		public static bool isPointUnderwater(Vector3 point)
		{
			return VolumeManager<WaterVolume, WaterVolumeManager>.Get().IsPositionInsideAnyVolume(point);
		}

		/// <param name="volume">Null if under old water level, otherwise the volume.</param>
		// Token: 0x06000301 RID: 769 RVA: 0x0000C8BA File Offset: 0x0000AABA
		public static bool isPointUnderwater(Vector3 point, out WaterVolume volume)
		{
			volume = VolumeManager<WaterVolume, WaterVolumeManager>.Get().GetFirstOverlappingVolume(point);
			return volume != null;
		}

		/// <summary>
		/// Find the water elevation underneath point, or above point if underwater.
		/// </summary>
		// Token: 0x06000302 RID: 770 RVA: 0x0000C8D4 File Offset: 0x0000AAD4
		public static float getWaterSurfaceElevation(Vector3 point)
		{
			bool flag = false;
			float num = -1024f;
			foreach (WaterVolume waterVolume in VolumeManager<WaterVolume, WaterVolumeManager>.Get().InternalGetAllVolumes())
			{
				if (waterVolume.IsPositionInsideVolume(point))
				{
					return WaterUtility.getWaterSurfaceElevation(waterVolume, point);
				}
				Ray ray = new Ray(point, new Vector3(0f, -1f, 0f));
				RaycastHit raycastHit;
				if (waterVolume.volumeCollider.Raycast(ray, out raycastHit, 2048f) && raycastHit.point.y > num)
				{
					num = raycastHit.point.y;
					flag = true;
				}
			}
			if (flag)
			{
				return num;
			}
			return -1024f;
		}

		// Token: 0x06000303 RID: 771 RVA: 0x0000C9A0 File Offset: 0x0000ABA0
		public static void getUnderwaterInfo(Vector3 point, out bool isUnderwater, out float surfaceElevation)
		{
			WaterVolume firstOverlappingVolume = VolumeManager<WaterVolume, WaterVolumeManager>.Get().GetFirstOverlappingVolume(point);
			if (firstOverlappingVolume != null)
			{
				isUnderwater = true;
				surfaceElevation = WaterUtility.getWaterSurfaceElevation(firstOverlappingVolume, point);
				return;
			}
			isUnderwater = false;
			surfaceElevation = -1024f;
		}
	}
}
