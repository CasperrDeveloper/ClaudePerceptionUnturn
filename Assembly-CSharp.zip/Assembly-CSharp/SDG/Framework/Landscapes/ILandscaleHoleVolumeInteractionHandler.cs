﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x0200009D RID: 157
	[Obsolete]
	public interface ILandscaleHoleVolumeInteractionHandler
	{
		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060003ED RID: 1005
		bool landscapeHoleAutoIgnoreTerrainCollision { get; }

		// Token: 0x060003EE RID: 1006
		void landscapeHoleBeginCollision(LandscapeHoleVolume volume, List<TerrainCollider> terrainColliders);

		// Token: 0x060003EF RID: 1007
		void landscapeHoleEndCollision(LandscapeHoleVolume volume, List<TerrainCollider> terrainColliders);
	}
}
