﻿using System;

namespace SDG.Framework.Landscapes
{
	// Token: 0x0200009E RID: 158
	// (Invoke) Token: 0x060003F1 RID: 1009
	public delegate void LandscapeLoadedHandler();
}
