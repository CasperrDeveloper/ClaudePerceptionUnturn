﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A0 RID: 160
	public struct LandscapeBounds
	{
		// Token: 0x06000434 RID: 1076 RVA: 0x000120B0 File Offset: 0x000102B0
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"[",
				this.min.ToString(),
				", ",
				this.max.ToString(),
				"]"
			});
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x00012108 File Offset: 0x00010308
		public LandscapeBounds(LandscapeCoord newMin, LandscapeCoord newMax)
		{
			this.min = newMin;
			this.max = newMax;
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x00012118 File Offset: 0x00010318
		public LandscapeBounds(Bounds worldBounds)
		{
			this.min = new LandscapeCoord(worldBounds.min);
			this.max = new LandscapeCoord(worldBounds.max);
		}

		// Token: 0x040001E2 RID: 482
		public LandscapeCoord min;

		// Token: 0x040001E3 RID: 483
		public LandscapeCoord max;
	}
}
