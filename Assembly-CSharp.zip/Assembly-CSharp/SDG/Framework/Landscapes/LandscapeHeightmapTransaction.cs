﻿using System;
using SDG.Framework.Devkit.Transactions;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A3 RID: 163
	public class LandscapeHeightmapTransaction : IDevkitTransaction
	{
		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000449 RID: 1097 RVA: 0x00012347 File Offset: 0x00010547
		public bool delta
		{
			get
			{
				return true;
			}
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0001234C File Offset: 0x0001054C
		public void undo()
		{
			if (this.tile == null)
			{
				return;
			}
			float[,] heightmap = this.tile.heightmap;
			this.tile.heightmap = this.heightmapCopy;
			this.heightmapCopy = heightmap;
			this.tile.SetHeightsDelayLOD();
			this.tile.SyncDelayedLOD();
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0001239C File Offset: 0x0001059C
		public void redo()
		{
			this.undo();
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x000123A4 File Offset: 0x000105A4
		public void begin()
		{
			this.heightmapCopy = LandscapeHeightmapCopyPool.claim();
			for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
				{
					this.heightmapCopy[i, j] = this.tile.heightmap[i, j];
				}
			}
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x000123FB File Offset: 0x000105FB
		public void end()
		{
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x000123FD File Offset: 0x000105FD
		public void forget()
		{
			LandscapeHeightmapCopyPool.release(this.heightmapCopy);
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0001240A File Offset: 0x0001060A
		public LandscapeHeightmapTransaction(LandscapeTile newTile)
		{
			this.tile = newTile;
		}

		// Token: 0x040001E8 RID: 488
		protected LandscapeTile tile;

		// Token: 0x040001E9 RID: 489
		protected float[,] heightmapCopy;
	}
}
