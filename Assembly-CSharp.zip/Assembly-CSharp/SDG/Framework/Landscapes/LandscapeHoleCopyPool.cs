﻿using System;
using SDG.Framework.Utilities;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A4 RID: 164
	public static class LandscapeHoleCopyPool
	{
		// Token: 0x06000450 RID: 1104 RVA: 0x00012419 File Offset: 0x00010619
		public static void empty()
		{
			LandscapeHoleCopyPool.pool.empty();
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00012425 File Offset: 0x00010625
		public static void warmup(uint count)
		{
			LandscapeHoleCopyPool.pool.warmup(count, new Pool<bool[,]>.PoolClaimHandler(LandscapeHoleCopyPool.handlePoolClaim));
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0001243E File Offset: 0x0001063E
		public static bool[,] claim()
		{
			return LandscapeHoleCopyPool.pool.claim(new Pool<bool[,]>.PoolClaimHandler(LandscapeHoleCopyPool.handlePoolClaim));
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00012456 File Offset: 0x00010656
		public static void release(bool[,] copy)
		{
			LandscapeHoleCopyPool.pool.release(copy, new Pool<bool[,]>.PoolReleasedHandler(LandscapeHoleCopyPool.handlePoolRelease));
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0001246F File Offset: 0x0001066F
		private static bool[,] handlePoolClaim(Pool<bool[,]> pool)
		{
			return new bool[256, 256];
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00012480 File Offset: 0x00010680
		private static void handlePoolRelease(Pool<bool[,]> pool, bool[,] copy)
		{
		}

		// Token: 0x040001EA RID: 490
		private static Pool<bool[,]> pool = new Pool<bool[,]>();
	}
}
