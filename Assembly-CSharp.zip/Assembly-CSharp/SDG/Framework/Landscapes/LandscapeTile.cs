﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using SDG.Framework.Debug;
using SDG.Framework.Foliage;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;
using UnityEngine.Rendering;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000AC RID: 172
	public class LandscapeTile : IFormattedFileReadable, IFormattedFileWritable, IFoliageSurface
	{
		// Token: 0x1700009E RID: 158
		// (get) Token: 0x0600047E RID: 1150 RVA: 0x00012D6B File Offset: 0x00010F6B
		// (set) Token: 0x0600047F RID: 1151 RVA: 0x00012D73 File Offset: 0x00010F73
		public GameObject gameObject { get; protected set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000480 RID: 1152 RVA: 0x00012D7C File Offset: 0x00010F7C
		// (set) Token: 0x06000481 RID: 1153 RVA: 0x00012D84 File Offset: 0x00010F84
		public LandscapeCoord coord
		{
			get
			{
				return this._coord;
			}
			protected set
			{
				this._coord = value;
				this.updateTransform();
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000482 RID: 1154 RVA: 0x00012D93 File Offset: 0x00010F93
		public Bounds localBounds
		{
			get
			{
				return new Bounds(new Vector3(Landscape.TILE_SIZE / 2f, 0f, Landscape.TILE_SIZE / 2f), new Vector3(Landscape.TILE_SIZE, Landscape.TILE_HEIGHT, Landscape.TILE_SIZE));
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000483 RID: 1155 RVA: 0x00012DD0 File Offset: 0x00010FD0
		public Bounds worldBounds
		{
			get
			{
				Bounds localBounds = this.localBounds;
				localBounds.center += new Vector3((float)this.coord.x * Landscape.TILE_SIZE, 0f, (float)this.coord.y * Landscape.TILE_SIZE);
				return localBounds;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000484 RID: 1156 RVA: 0x00012E25 File Offset: 0x00011025
		// (set) Token: 0x06000485 RID: 1157 RVA: 0x00012E2D File Offset: 0x0001102D
		public InspectableList<AssetReference<LandscapeMaterialAsset>> materials { get; protected set; }

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x00012E36 File Offset: 0x00011036
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x00012E3E File Offset: 0x0001103E
		public TerrainData data { get; protected set; }

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x00012E47 File Offset: 0x00011047
		// (set) Token: 0x06000489 RID: 1161 RVA: 0x00012E4F File Offset: 0x0001104F
		public Terrain terrain { get; protected set; }

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x00012E58 File Offset: 0x00011058
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x00012E60 File Offset: 0x00011060
		public TerrainCollider collider { get; protected set; }

		// Token: 0x0600048C RID: 1164 RVA: 0x00012E69 File Offset: 0x00011069
		public void SetHeightsDelayLOD()
		{
			this.data.SetHeightsDelayLOD(0, 0, this.heightmap);
			if (this.dataWithoutHoles != null)
			{
				this.dataWithoutHoles.SetHeightsDelayLOD(0, 0, this.heightmap);
			}
			this.isHeightsLodDataDirty = true;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x00012EA8 File Offset: 0x000110A8
		public void SyncDelayedLOD()
		{
			if (this.isHeightsLodDataDirty)
			{
				this.isHeightsLodDataDirty = false;
				this.data.SyncHeightmap();
				if (this.dataWithoutHoles != null)
				{
					this.dataWithoutHoles.SyncHeightmap();
				}
			}
			if (this.isHolesLodDataDirty)
			{
				this.isHolesLodDataDirty = false;
				this.data.SyncTexture(TerrainData.HolesTextureName);
			}
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x00012F07 File Offset: 0x00011107
		public void SetHoles()
		{
			if (Landscape.ShouldUseSetHolesDelayLOD)
			{
				this.data.SetHolesDelayLOD(0, 0, this.holes);
				this.isHolesLodDataDirty = true;
				return;
			}
			this.data.SetHoles(0, 0, this.holes);
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x00012F40 File Offset: 0x00011140
		public virtual void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			this.coord = reader.readValue<LandscapeCoord>("Coord");
			bool flag = Level.isEditor && EditorAssetRedirector.HasRedirects;
			int num = reader.readArrayLength("Materials");
			for (int i = 0; i < num; i++)
			{
				AssetReference<LandscapeMaterialAsset> value = reader.readValue<AssetReference<LandscapeMaterialAsset>>(i);
				if (value.isValid)
				{
					if (Level.shouldUseHolidayRedirects)
					{
						LandscapeMaterialAsset landscapeMaterialAsset = value.Find();
						if (landscapeMaterialAsset != null)
						{
							AssetReference<LandscapeMaterialAsset> holidayRedirect = landscapeMaterialAsset.getHolidayRedirect();
							if (holidayRedirect.isValid)
							{
								value = holidayRedirect;
							}
						}
					}
					else if (flag)
					{
						LandscapeMaterialAsset landscapeMaterialAsset2 = EditorAssetRedirector.Redirect<LandscapeMaterialAsset>(value.GUID);
						if (landscapeMaterialAsset2 != null)
						{
							value = landscapeMaterialAsset2.getReferenceTo<LandscapeMaterialAsset>();
						}
					}
					if (value.Find() == null)
					{
						ClientAssetIntegrity.ServerAddKnownMissingAsset(value.GUID, string.Format("Landscape tile (x: {0} y: {1} layer: {2})", this.coord.x, this.coord.y, i));
					}
				}
				this.materials[i] = value;
			}
			this.updatePrototypes();
			this.readHeightmaps();
			this.readSplatmaps();
			this.ReadHoles();
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x0001305A File Offset: 0x0001125A
		public virtual void readHeightmaps()
		{
			this.readHeightmap("_Source", this.heightmap);
			this.SetHeightsDelayLOD();
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x00013074 File Offset: 0x00011274
		protected virtual void readHeightmap(string suffix, float[,] heightmap)
		{
			string[] array = new string[6];
			array[0] = "Tile_";
			int num = 1;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[2] = "_";
			int num2 = 3;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[4] = suffix;
			array[5] = ".heightmap";
			string text = string.Concat(array);
			string text2 = Level.info.path + "/Landscape/Heightmaps/" + text;
			if (!File.Exists(text2))
			{
				UnturnedLog.warn("LandscapeTile missing heightmap file: {0}", new object[]
				{
					text2
				});
				return;
			}
			using (FileStream fileStream = new FileStream(text2, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				using (SHA1Stream sha1Stream = new SHA1Stream(fileStream))
				{
					for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
					{
						for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
						{
							float num3 = (float)((ushort)(sha1Stream.ReadByte() << 8 | sha1Stream.ReadByte())) / 65535f;
							heightmap[i, j] = num3;
						}
					}
					Level.includeHash(text, sha1Stream.Hash);
				}
			}
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x000131B4 File Offset: 0x000113B4
		public virtual void readSplatmaps()
		{
			this.readSplatmap("_Source", this.splatmap);
			if (!Dedicator.IsDedicatedServer)
			{
				this.data.SetAlphamaps(0, 0, this.splatmap);
			}
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x000131E4 File Offset: 0x000113E4
		protected virtual void readSplatmap(string suffix, float[,,] splatmap)
		{
			string[] array = new string[6];
			array[0] = "Tile_";
			int num = 1;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[2] = "_";
			int num2 = 3;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[4] = suffix;
			array[5] = ".splatmap";
			string text = string.Concat(array);
			string text2 = Level.info.path + "/Landscape/Splatmaps/" + text;
			if (!File.Exists(text2))
			{
				UnturnedLog.warn("LandscapeTile missing splatmap file: {0}", new object[]
				{
					text2
				});
				return;
			}
			using (FileStream fileStream = new FileStream(text2, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				using (SHA1Stream sha1Stream = new SHA1Stream(fileStream))
				{
					for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
					{
						for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
						{
							for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
							{
								float num3 = (float)((byte)sha1Stream.ReadByte()) / 255f;
								splatmap[i, j, k] = num3;
							}
						}
					}
					Level.includeHash(text, sha1Stream.Hash);
				}
			}
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x00013330 File Offset: 0x00011530
		private void ReadHoles()
		{
			string[] array = new string[5];
			array[0] = "Tile_";
			int num = 1;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[2] = "_";
			int num2 = 3;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[4] = ".bin";
			string text = string.Concat(array);
			string path = Level.info.path + "/Landscape/Holes/" + text;
			if (!File.Exists(path))
			{
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				using (SHA1Stream sha1Stream = new SHA1Stream(fileStream))
				{
					sha1Stream.ReadByte();
					for (int i = 0; i < 256; i++)
					{
						for (int j = 0; j < 256; j += 8)
						{
							byte b = (byte)sha1Stream.ReadByte();
							for (int k = 0; k < 8; k++)
							{
								this.holes[i, j + k] = (((int)b & 1 << k) > 0);
							}
						}
					}
					Level.includeHash(text, sha1Stream.Hash);
				}
			}
			this.SetHoles();
			this.hasAnyHolesData = true;
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x00013480 File Offset: 0x00011680
		public virtual void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.writeValue<LandscapeCoord>("Coord", this.coord);
			writer.beginArray("Materials");
			for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
			{
				writer.writeValue<AssetReference<LandscapeMaterialAsset>>(this.materials[i]);
			}
			writer.endArray();
			writer.endObject();
			this.writeHeightmaps();
			this.writeSplatmaps();
			if (this.hasAnyHolesData)
			{
				this.WriteHoles();
			}
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x000134F7 File Offset: 0x000116F7
		public virtual void writeHeightmaps()
		{
			this.writeHeightmap("_Source", this.heightmap);
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x0001350C File Offset: 0x0001170C
		protected virtual void writeHeightmap(string suffix, float[,] heightmap)
		{
			string[] array = new string[7];
			array[0] = Level.info.path;
			array[1] = "/Landscape/Heightmaps/Tile_";
			int num = 2;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[3] = "_";
			int num2 = 4;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[5] = suffix;
			array[6] = ".heightmap";
			string path = string.Concat(array);
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
			{
				for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
				{
					for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
					{
						ushort num3 = (ushort)Mathf.RoundToInt(heightmap[i, j] * 65535f);
						fileStream.WriteByte((byte)(num3 >> 8 & 255));
						fileStream.WriteByte((byte)(num3 & 255));
					}
				}
			}
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0001361C File Offset: 0x0001181C
		public virtual void writeSplatmaps()
		{
			this.writeSplatmap("_Source", this.splatmap);
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x00013630 File Offset: 0x00011830
		protected virtual void writeSplatmap(string suffix, float[,,] splatmap)
		{
			string[] array = new string[7];
			array[0] = Level.info.path;
			array[1] = "/Landscape/Splatmaps/Tile_";
			int num = 2;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[3] = "_";
			int num2 = 4;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[5] = suffix;
			array[6] = ".splatmap";
			string path = string.Concat(array);
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
			{
				for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
				{
					for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
					{
						for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
						{
							byte value = (byte)Mathf.RoundToInt(splatmap[i, j, k] * 255f);
							fileStream.WriteByte(value);
						}
					}
				}
			}
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0001373C File Offset: 0x0001193C
		private void WriteHoles()
		{
			string[] array = new string[6];
			array[0] = Level.info.path;
			array[1] = "/Landscape/Holes/Tile_";
			int num = 2;
			LandscapeCoord coord = this.coord;
			array[num] = coord.x.ToString(CultureInfo.InvariantCulture);
			array[3] = "_";
			int num2 = 4;
			coord = this.coord;
			array[num2] = coord.y.ToString(CultureInfo.InvariantCulture);
			array[5] = ".bin";
			string path = string.Concat(array);
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
			{
				fileStream.WriteByte(1);
				for (int i = 0; i < 256; i++)
				{
					for (int j = 0; j < 256; j += 8)
					{
						byte b = this.holes[i, j] ? 1 : 0;
						for (int k = 1; k < 8; k++)
						{
							b |= (this.holes[i, j + k] ? ((byte)(1 << k)) : 0);
						}
						fileStream.WriteByte(b);
					}
				}
			}
		}

		/// <summary>
		/// Call this when done changing material references to grab their textures and pass them to the terrain renderer.
		/// </summary>
		// Token: 0x0600049B RID: 1179 RVA: 0x00013868 File Offset: 0x00011A68
		public void updatePrototypes()
		{
			if (Dedicator.IsDedicatedServer)
			{
				return;
			}
			for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
			{
				AssetReference<LandscapeMaterialAsset> assetReference = this.materials[i];
				LandscapeMaterialAsset landscapeMaterialAsset = assetReference.Find();
				if (assetReference.isValid)
				{
					ClientAssetIntegrity.QueueRequest(assetReference.GUID, landscapeMaterialAsset, string.Format("Landscape tile (x: {0} y: {1} layer: {2})", this.coord.x, this.coord.y, i));
				}
				if (landscapeMaterialAsset == null)
				{
					this.terrainLayers[i] = null;
				}
				else
				{
					this.terrainLayers[i] = landscapeMaterialAsset.getOrCreateLayer();
				}
			}
			this.data.terrainLayers = this.terrainLayers;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00013918 File Offset: 0x00011B18
		protected void updateTransform()
		{
			this.gameObject.transform.position = new Vector3((float)this.coord.x * Landscape.TILE_SIZE, -Landscape.TILE_HEIGHT / 2f, (float)this.coord.y * Landscape.TILE_SIZE);
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0001396C File Offset: 0x00011B6C
		public void convertLegacyHeightmap()
		{
			for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
				{
					HeightmapCoord heightmapCoord = new HeightmapCoord(i, j);
					float num = LevelGround.getConversionHeight(Landscape.getWorldPosition(this.coord, heightmapCoord, this.heightmap[i, j]));
					num /= Landscape.TILE_HEIGHT;
					num += 0.5f;
					this.heightmap[i, j] = num;
				}
			}
			this.data.SetHeights(0, 0, this.heightmap);
			if (this.dataWithoutHoles != null)
			{
				this.dataWithoutHoles.SetHeights(0, 0, this.heightmap);
			}
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x00013A14 File Offset: 0x00011C14
		public void convertLegacySplatmap()
		{
			for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
				{
					SplatmapCoord splatmapCoord = new SplatmapCoord(i, j);
					Vector3 worldPosition = Landscape.getWorldPosition(this.coord, splatmapCoord);
					for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
					{
						float conversionWeight = LevelGround.getConversionWeight(worldPosition, k);
						this.splatmap[i, j, k] = conversionWeight;
					}
				}
			}
			if (!Dedicator.IsDedicatedServer)
			{
				this.data.SetAlphamaps(0, 0, this.splatmap);
			}
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x00013AA0 File Offset: 0x00011CA0
		public void resetHeightmap()
		{
			for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
				{
					this.heightmap[i, j] = 0.5f;
				}
			}
			Landscape.reconcileNeighbors(this);
			this.SyncDelayedLOD();
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00013AEC File Offset: 0x00011CEC
		public void resetSplatmap()
		{
			for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
				{
					this.splatmap[i, j, 0] = 1f;
					for (int k = 1; k < Landscape.SPLATMAP_LAYERS; k++)
					{
						this.splatmap[i, j, k] = 0f;
					}
				}
			}
			this.data.SetAlphamaps(0, 0, this.splatmap);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00013B64 File Offset: 0x00011D64
		public void normalizeSplatmap()
		{
			for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
				{
					float num = 0f;
					for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
					{
						num += this.splatmap[i, j, k];
					}
					for (int l = 0; l < Landscape.SPLATMAP_LAYERS; l++)
					{
						this.splatmap[i, j, l] /= num;
					}
				}
			}
			this.data.SetAlphamaps(0, 0, this.splatmap);
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00013BF4 File Offset: 0x00011DF4
		public void applyGraphicsSettings()
		{
			if (Dedicator.IsDedicatedServer)
			{
				return;
			}
			if (SDG.Unturned.GraphicsSettings.blend)
			{
				ERenderMode renderMode = SDG.Unturned.GraphicsSettings.renderMode;
				if (renderMode != ERenderMode.DEFERRED)
				{
					if (renderMode == ERenderMode.FORWARD)
					{
						this.terrain.materialTemplate = Resources.Load<Material>("Materials/Landscapes/Landscape_Forward");
					}
					else
					{
						this.terrain.materialTemplate = null;
						UnturnedLog.error("Unknown render mode: " + SDG.Unturned.GraphicsSettings.renderMode.ToString());
					}
				}
				else
				{
					this.terrain.materialTemplate = Resources.Load<Material>("Materials/Landscapes/Landscape_Deferred");
				}
			}
			else
			{
				this.terrain.materialTemplate = Resources.Load<Material>("Materials/Landscapes/Landscape_Classic");
			}
			this.terrain.basemapDistance = SDG.Unturned.GraphicsSettings.terrainBasemapDistance;
			if (this.terrain.materialTemplate == null)
			{
				UnturnedLog.warn("LandscapeTile unable to load materialTemplate");
			}
			this.terrain.heightmapPixelError = SDG.Unturned.GraphicsSettings.terrainHeightmapPixelError;
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060004A3 RID: 1187 RVA: 0x00013CCD File Offset: 0x00011ECD
		public bool IsValidFoliageSurface
		{
			get
			{
				return true;
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00013CD0 File Offset: 0x00011ED0
		public FoliageBounds getFoliageSurfaceBounds()
		{
			return new FoliageBounds(new FoliageCoord(this.coord.x * Landscape.TILE_SIZE_INT / FoliageSystem.TILE_SIZE_INT, this.coord.y * Landscape.TILE_SIZE_INT / FoliageSystem.TILE_SIZE_INT), new FoliageCoord((this.coord.x + 1) * Landscape.TILE_SIZE_INT / FoliageSystem.TILE_SIZE_INT - 1, (this.coord.y + 1) * Landscape.TILE_SIZE_INT / FoliageSystem.TILE_SIZE_INT - 1));
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x00013D50 File Offset: 0x00011F50
		public bool getFoliageSurfaceInfo(Vector3 position, out Vector3 surfacePosition, out Vector3 surfaceNormal)
		{
			surfacePosition = position;
			surfacePosition.y = this.terrain.SampleHeight(position) - Landscape.TILE_HEIGHT / 2f;
			surfaceNormal = this.data.GetInterpolatedNormal((position.x - (float)this.coord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE, (position.z - (float)this.coord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE);
			return !Landscape.IsPointInsideHole(surfacePosition);
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00013DE0 File Offset: 0x00011FE0
		public void bakeFoliageSurface(FoliageBakeSettings bakeSettings, FoliageTile foliageTile)
		{
			int num = (foliageTile.coord.y * FoliageSystem.TILE_SIZE_INT - this.coord.y * Landscape.TILE_SIZE_INT) / FoliageSystem.TILE_SIZE_INT * FoliageSystem.SPLATMAP_RESOLUTION_PER_TILE;
			int num2 = num + FoliageSystem.SPLATMAP_RESOLUTION_PER_TILE;
			int num3 = (foliageTile.coord.x * FoliageSystem.TILE_SIZE_INT - this.coord.x * Landscape.TILE_SIZE_INT) / FoliageSystem.TILE_SIZE_INT * FoliageSystem.SPLATMAP_RESOLUTION_PER_TILE;
			int num4 = num3 + FoliageSystem.SPLATMAP_RESOLUTION_PER_TILE;
			for (int i = num; i < num2; i++)
			{
				for (int j = num3; j < num4; j++)
				{
					SplatmapCoord splatmapCoord = new SplatmapCoord(i, j);
					float num5 = (float)this.coord.x * Landscape.TILE_SIZE + (float)splatmapCoord.y * Landscape.SPLATMAP_WORLD_UNIT;
					float num6 = (float)this.coord.y * Landscape.TILE_SIZE + (float)splatmapCoord.x * Landscape.SPLATMAP_WORLD_UNIT;
					Bounds bounds = default(Bounds);
					bounds.min = new Vector3(num5, 0f, num6);
					bounds.max = new Vector3(num5 + Landscape.SPLATMAP_WORLD_UNIT, 0f, num6 + Landscape.SPLATMAP_WORLD_UNIT);
					for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
					{
						float num7 = this.splatmap[i, j, k];
						if (num7 >= 0.01f)
						{
							LandscapeMaterialAsset landscapeMaterialAsset = Assets.find<LandscapeMaterialAsset>(this.materials[k]);
							if (landscapeMaterialAsset != null)
							{
								FoliageInfoCollectionAsset foliageInfoCollectionAsset = Assets.find<FoliageInfoCollectionAsset>(landscapeMaterialAsset.foliage);
								if (foliageInfoCollectionAsset != null)
								{
									foliageInfoCollectionAsset.bakeFoliage(bakeSettings, this, bounds, num7);
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x00013F77 File Offset: 0x00012177
		protected virtual void handleMaterialsInspectorChanged(IInspectableList list)
		{
			this.updatePrototypes();
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00013F7F File Offset: 0x0001217F
		public virtual void enable()
		{
			FoliageSystem.addSurface(this);
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x00013F87 File Offset: 0x00012187
		public virtual void disable()
		{
			FoliageSystem.removeSurface(this);
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00013F90 File Offset: 0x00012190
		public LandscapeTile(LandscapeCoord newCoord)
		{
			this.gameObject = new GameObject();
			this.gameObject.tag = "Ground";
			this.gameObject.layer = 20;
			this.gameObject.transform.rotation = MathUtility.IDENTITY_QUATERNION;
			this.gameObject.transform.localScale = Vector3.one;
			this.coord = newCoord;
			this.heightmap = new float[Landscape.HEIGHTMAP_RESOLUTION, Landscape.HEIGHTMAP_RESOLUTION];
			this.splatmap = new float[Landscape.SPLATMAP_RESOLUTION, Landscape.SPLATMAP_RESOLUTION, Landscape.SPLATMAP_LAYERS];
			this.holes = new bool[256, 256];
			for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
				{
					this.heightmap[i, j] = 0.5f;
				}
			}
			for (int k = 0; k < Landscape.SPLATMAP_RESOLUTION; k++)
			{
				for (int l = 0; l < Landscape.SPLATMAP_RESOLUTION; l++)
				{
					this.splatmap[k, l, 0] = 1f;
				}
			}
			for (int m = 0; m < 256; m++)
			{
				for (int n = 0; n < 256; n++)
				{
					this.holes[m, n] = true;
				}
			}
			this.materials = new InspectableList<AssetReference<LandscapeMaterialAsset>>(Landscape.SPLATMAP_LAYERS);
			this.materials.Add(LandscapeTile.DEFAULT_MATERIAL);
			for (int num = 1; num < Landscape.SPLATMAP_LAYERS; num++)
			{
				this.materials.Add(AssetReference<LandscapeMaterialAsset>.invalid);
			}
			this.materials.canInspectorAdd = false;
			this.materials.canInspectorRemove = false;
			this.materials.inspectorChanged += this.handleMaterialsInspectorChanged;
			this.data = new TerrainData();
			if (!Dedicator.IsDedicatedServer)
			{
				this.terrainLayers = new TerrainLayer[Landscape.SPLATMAP_LAYERS];
				this.data.terrainLayers = this.terrainLayers;
			}
			this.data.heightmapResolution = Landscape.HEIGHTMAP_RESOLUTION;
			this.data.alphamapResolution = Landscape.SPLATMAP_RESOLUTION;
			this.data.baseMapResolution = Landscape.BASEMAP_RESOLUTION;
			this.data.size = new Vector3(Landscape.TILE_SIZE, Landscape.TILE_HEIGHT, Landscape.TILE_SIZE);
			this.data.SetHeightsDelayLOD(0, 0, this.heightmap);
			if (Landscape.ShouldUseSetHolesDelayLOD)
			{
				this.data.enableHolesTextureCompression = false;
			}
			this.isHeightsLodDataDirty = true;
			if (!Dedicator.IsDedicatedServer)
			{
				this.data.SetAlphamaps(0, 0, this.splatmap);
			}
			this.data.wavingGrassTint = Color.white;
			this.terrain = this.gameObject.AddComponent<Terrain>();
			this.terrain.drawInstanced = SystemInfo.supportsInstancing;
			this.terrain.terrainData = this.data;
			this.terrain.heightmapPixelError = 200f;
			this.terrain.reflectionProbeUsage = ReflectionProbeUsage.Off;
			this.terrain.shadowCastingMode = ShadowCastingMode.Off;
			this.terrain.drawHeightmap = !Dedicator.IsDedicatedServer;
			this.terrain.drawTreesAndFoliage = false;
			this.terrain.collectDetailPatches = false;
			this.terrain.allowAutoConnect = false;
			this.terrain.groupingID = 1;
			this.terrain.Flush();
			if (Level.isEditor)
			{
				this.dataWithoutHoles = new TerrainData();
				this.dataWithoutHoles.heightmapResolution = this.data.heightmapResolution;
				this.dataWithoutHoles.size = this.data.size;
				this.dataWithoutHoles.SetHeightsDelayLOD(0, 0, this.heightmap);
			}
			this.collider = this.gameObject.AddComponent<TerrainCollider>();
			this.collider.terrainData = ((Level.isEditor && Landscape.DisableHoleColliders) ? this.dataWithoutHoles : this.data);
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0001435C File Offset: 0x0001255C
		[Conditional("UNITY_EDITOR")]
		[Conditional("DEVELOPMENT_BUILD")]
		private void UpdateNames()
		{
			this.gameObject.name = string.Format("Terrain ({0}, {1})", this.coord.x, this.coord.y);
			this.data.name = string.Format("x: {0} y: {1}", this.coord.x, this.coord.y);
			if (this.dataWithoutHoles != null)
			{
				this.dataWithoutHoles.name = this.data.name + " (without holes)";
			}
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x00014401 File Offset: 0x00012601
		[Obsolete]
		public void SyncHeightmap()
		{
			this.SyncDelayedLOD();
		}

		// Token: 0x040001F7 RID: 503
		protected LandscapeCoord _coord;

		// Token: 0x040001F8 RID: 504
		public float[,] heightmap;

		// Token: 0x040001F9 RID: 505
		public float[,,] splatmap;

		/// <summary>
		/// True is solid and false is empty.
		/// </summary>
		// Token: 0x040001FA RID: 506
		public bool[,] holes;

		/// <summary>
		/// Marked true when level editor or legacy hole volumes modify hole data.
		/// Defaults to false in which case holes do not need to be saved.
		///
		/// Initially this was not going to be marked by hole volumes because they can re-generate the holes, but saving
		/// hole volume cuts is helpful when upgrading to remove hole volumes from a map.
		/// </summary>
		// Token: 0x040001FB RID: 507
		public bool hasAnyHolesData;

		/// <summary>
		/// If true, SetHeightsDelayLOD was called without calling SyncHeightmap yet.
		/// </summary>
		// Token: 0x040001FC RID: 508
		private bool isHeightsLodDataDirty;

		/// <summary>
		/// If true, SetHolesDelayLOD was called without calling SyncTexture yet.
		/// </summary>
		// Token: 0x040001FD RID: 509
		private bool isHolesLodDataDirty;

		// Token: 0x040001FF RID: 511
		private TerrainLayer[] terrainLayers;

		/// <summary>
		/// Heightmap-only data used in level editor. Refer to Landscape.DisableHoleColliders for explanation.
		/// </summary>
		// Token: 0x04000201 RID: 513
		public TerrainData dataWithoutHoles;

		// Token: 0x04000204 RID: 516
		private static AssetReference<LandscapeMaterialAsset> DEFAULT_MATERIAL = new AssetReference<LandscapeMaterialAsset>("498ca625072d443a876b2a4f11896018");
	}
}
