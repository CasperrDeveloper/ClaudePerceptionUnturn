﻿using System;
using SDG.Framework.Utilities;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A2 RID: 162
	public static class LandscapeHeightmapCopyPool
	{
		// Token: 0x06000442 RID: 1090 RVA: 0x000122D2 File Offset: 0x000104D2
		public static void empty()
		{
			LandscapeHeightmapCopyPool.pool.empty();
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x000122DE File Offset: 0x000104DE
		public static void warmup(uint count)
		{
			LandscapeHeightmapCopyPool.pool.warmup(count, new Pool<float[,]>.PoolClaimHandler(LandscapeHeightmapCopyPool.handlePoolClaim));
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x000122F7 File Offset: 0x000104F7
		public static float[,] claim()
		{
			return LandscapeHeightmapCopyPool.pool.claim(new Pool<float[,]>.PoolClaimHandler(LandscapeHeightmapCopyPool.handlePoolClaim));
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0001230F File Offset: 0x0001050F
		public static void release(float[,] copy)
		{
			LandscapeHeightmapCopyPool.pool.release(copy, new Pool<float[,]>.PoolReleasedHandler(LandscapeHeightmapCopyPool.handlePoolRelease));
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00012328 File Offset: 0x00010528
		private static float[,] handlePoolClaim(Pool<float[,]> pool)
		{
			return new float[Landscape.HEIGHTMAP_RESOLUTION, Landscape.HEIGHTMAP_RESOLUTION];
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x00012339 File Offset: 0x00010539
		private static void handlePoolRelease(Pool<float[,]> pool, float[,] copy)
		{
		}

		// Token: 0x040001E7 RID: 487
		private static Pool<float[,]> pool = new Pool<float[,]>();
	}
}
