﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A9 RID: 169
	public struct LandscapePreviewSample
	{
		// Token: 0x0600046F RID: 1135 RVA: 0x00012BF4 File Offset: 0x00010DF4
		public LandscapePreviewSample(Vector3 newPosition, float newWeight)
		{
			this.position = newPosition;
			this.weight = newWeight;
		}

		// Token: 0x040001F1 RID: 497
		public Vector3 position;

		// Token: 0x040001F2 RID: 498
		public float weight;
	}
}
