﻿using System;
using SDG.Framework.Utilities;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000AA RID: 170
	public static class LandscapeSplatmapCopyPool
	{
		// Token: 0x06000470 RID: 1136 RVA: 0x00012C04 File Offset: 0x00010E04
		public static void empty()
		{
			LandscapeSplatmapCopyPool.pool.empty();
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x00012C10 File Offset: 0x00010E10
		public static void warmup(uint count)
		{
			LandscapeSplatmapCopyPool.pool.warmup(count, new Pool<float[,,]>.PoolClaimHandler(LandscapeSplatmapCopyPool.handlePoolClaim));
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00012C29 File Offset: 0x00010E29
		public static float[,,] claim()
		{
			return LandscapeSplatmapCopyPool.pool.claim(new Pool<float[,,]>.PoolClaimHandler(LandscapeSplatmapCopyPool.handlePoolClaim));
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x00012C41 File Offset: 0x00010E41
		public static void release(float[,,] copy)
		{
			LandscapeSplatmapCopyPool.pool.release(copy, new Pool<float[,,]>.PoolReleasedHandler(LandscapeSplatmapCopyPool.handlePoolRelease));
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x00012C5A File Offset: 0x00010E5A
		private static float[,,] handlePoolClaim(Pool<float[,,]> pool)
		{
			return new float[Landscape.SPLATMAP_RESOLUTION, Landscape.SPLATMAP_RESOLUTION, Landscape.SPLATMAP_LAYERS];
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x00012C70 File Offset: 0x00010E70
		private static void handlePoolRelease(Pool<float[,,]> pool, float[,,] copy)
		{
		}

		// Token: 0x040001F3 RID: 499
		private static Pool<float[,,]> pool = new Pool<float[,,]>();
	}
}
