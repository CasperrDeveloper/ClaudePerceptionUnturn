﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x0200009C RID: 156
	public struct HeightmapCoord : IEquatable<HeightmapCoord>
	{
		// Token: 0x060003E5 RID: 997 RVA: 0x00010277 File Offset: 0x0000E477
		public static bool operator ==(HeightmapCoord a, HeightmapCoord b)
		{
			return a.x == b.x && a.y == b.y;
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00010297 File Offset: 0x0000E497
		public static bool operator !=(HeightmapCoord a, HeightmapCoord b)
		{
			return !(a == b);
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x000102A4 File Offset: 0x0000E4A4
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			HeightmapCoord heightmapCoord = (HeightmapCoord)obj;
			return this.x == heightmapCoord.x && this.y == heightmapCoord.y;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x000102DB File Offset: 0x0000E4DB
		public override int GetHashCode()
		{
			return this.x ^ this.y;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x000102EC File Offset: 0x0000E4EC
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"(",
				this.x.ToString(),
				", ",
				this.y.ToString(),
				")"
			});
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00010338 File Offset: 0x0000E538
		public bool Equals(HeightmapCoord other)
		{
			return this.x == other.x && this.y == other.y;
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00010358 File Offset: 0x0000E558
		public HeightmapCoord(int new_x, int new_y)
		{
			this.x = new_x;
			this.y = new_y;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x00010368 File Offset: 0x0000E568
		public HeightmapCoord(LandscapeCoord tileCoord, Vector3 worldPosition)
		{
			this.x = Mathf.Clamp(Mathf.RoundToInt((worldPosition.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
			this.y = Mathf.Clamp(Mathf.RoundToInt((worldPosition.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
		}

		// Token: 0x040001C2 RID: 450
		public int x;

		// Token: 0x040001C3 RID: 451
		public int y;
	}
}
