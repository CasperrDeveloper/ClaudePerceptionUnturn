﻿using System;
using SDG.Unturned;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A7 RID: 167
	public class LandscapeHoleVolume : LevelVolume<LandscapeHoleVolume, LandscapeHoleVolumeManager>
	{
		// Token: 0x06000468 RID: 1128 RVA: 0x000126BB File Offset: 0x000108BB
		protected override void Awake()
		{
			this.supportsSphereShape = false;
			base.Awake();
		}
	}
}
