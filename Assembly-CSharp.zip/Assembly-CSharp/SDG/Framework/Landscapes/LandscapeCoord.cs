﻿using System;
using SDG.Framework.IO.FormattedFiles;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A1 RID: 161
	public struct LandscapeCoord : IFormattedFileReadable, IFormattedFileWritable, IEquatable<LandscapeCoord>
	{
		// Token: 0x06000437 RID: 1079 RVA: 0x0001213E File Offset: 0x0001033E
		public void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			this.x = reader.readValue<int>("X");
			this.y = reader.readValue<int>("Y");
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0001216A File Offset: 0x0001036A
		public void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.writeValue<int>("X", this.x);
			writer.writeValue<int>("Y", this.y);
			writer.endObject();
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0001219A File Offset: 0x0001039A
		public static bool operator ==(LandscapeCoord a, LandscapeCoord b)
		{
			return a.x == b.x && a.y == b.y;
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x000121BA File Offset: 0x000103BA
		public static bool operator !=(LandscapeCoord a, LandscapeCoord b)
		{
			return !(a == b);
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x000121C8 File Offset: 0x000103C8
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			LandscapeCoord landscapeCoord = (LandscapeCoord)obj;
			return this.x.Equals(landscapeCoord.x) && this.y.Equals(landscapeCoord.y);
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x00012207 File Offset: 0x00010407
		public override int GetHashCode()
		{
			return this.x ^ this.y;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00012218 File Offset: 0x00010418
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"(",
				this.x.ToString(),
				", ",
				this.y.ToString(),
				")"
			});
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x00012264 File Offset: 0x00010464
		public bool Equals(LandscapeCoord other)
		{
			return this.x == other.x && this.y == other.y;
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00012284 File Offset: 0x00010484
		public LandscapeCoord(int new_x, int new_y)
		{
			this.x = new_x;
			this.y = new_y;
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x00012294 File Offset: 0x00010494
		public LandscapeCoord(Vector3 position)
		{
			this.x = Mathf.FloorToInt(position.x / Landscape.TILE_SIZE);
			this.y = Mathf.FloorToInt(position.z / Landscape.TILE_SIZE);
		}

		// Token: 0x040001E4 RID: 484
		public static LandscapeCoord ZERO = new LandscapeCoord(0, 0);

		// Token: 0x040001E5 RID: 485
		public int x;

		// Token: 0x040001E6 RID: 486
		public int y;
	}
}
