﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x0200009B RID: 155
	public struct HeightmapBounds
	{
		// Token: 0x060003E2 RID: 994 RVA: 0x00010108 File Offset: 0x0000E308
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"[",
				this.min.ToString(),
				", ",
				this.max.ToString(),
				"]"
			});
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x00010160 File Offset: 0x0000E360
		public HeightmapBounds(HeightmapCoord newMin, HeightmapCoord newMax)
		{
			this.min = newMin;
			this.max = newMax;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x00010170 File Offset: 0x0000E370
		public HeightmapBounds(LandscapeCoord tileCoord, Bounds worldBounds)
		{
			int new_x = Mathf.Clamp(Mathf.FloorToInt((worldBounds.min.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
			int new_x2 = Mathf.Clamp(Mathf.CeilToInt((worldBounds.max.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
			int new_y = Mathf.Clamp(Mathf.FloorToInt((worldBounds.min.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
			int new_y2 = Mathf.Clamp(Mathf.CeilToInt((worldBounds.max.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE), 0, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE);
			this.min = new HeightmapCoord(new_x, new_y);
			this.max = new HeightmapCoord(new_x2, new_y2);
		}

		// Token: 0x040001C0 RID: 448
		public HeightmapCoord min;

		// Token: 0x040001C1 RID: 449
		public HeightmapCoord max;
	}
}
