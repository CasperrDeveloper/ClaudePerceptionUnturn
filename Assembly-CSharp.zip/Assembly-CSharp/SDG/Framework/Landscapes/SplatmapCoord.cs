﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000AF RID: 175
	public struct SplatmapCoord : IEquatable<SplatmapCoord>
	{
		// Token: 0x060004B4 RID: 1204 RVA: 0x000146DB File Offset: 0x000128DB
		public static bool operator ==(SplatmapCoord a, SplatmapCoord b)
		{
			return a.x == b.x && a.y == b.y;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x000146FB File Offset: 0x000128FB
		public static bool operator !=(SplatmapCoord a, SplatmapCoord b)
		{
			return !(a == b);
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x00014708 File Offset: 0x00012908
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			SplatmapCoord splatmapCoord = (SplatmapCoord)obj;
			return this.x.Equals(splatmapCoord.x) && this.y.Equals(splatmapCoord.y);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x00014747 File Offset: 0x00012947
		public override int GetHashCode()
		{
			return this.x ^ this.y;
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00014758 File Offset: 0x00012958
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"(",
				this.x.ToString(),
				", ",
				this.y.ToString(),
				")"
			});
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x000147A4 File Offset: 0x000129A4
		public bool Equals(SplatmapCoord other)
		{
			return this.x == other.x && this.y == other.y;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x000147C4 File Offset: 0x000129C4
		public SplatmapCoord(int new_x, int new_y)
		{
			this.x = new_x;
			this.y = new_y;
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x000147D4 File Offset: 0x000129D4
		public SplatmapCoord(LandscapeCoord tileCoord, Vector3 worldPosition)
		{
			this.x = Mathf.Clamp(Mathf.FloorToInt((worldPosition.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
			this.y = Mathf.Clamp(Mathf.FloorToInt((worldPosition.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
		}

		// Token: 0x04000207 RID: 519
		public int x;

		// Token: 0x04000208 RID: 520
		public int y;
	}
}
