﻿using System;
using SDG.Framework.Devkit.Transactions;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000AB RID: 171
	public class LandscapeSplatmapTransaction : IDevkitTransaction
	{
		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000477 RID: 1143 RVA: 0x00012C7E File Offset: 0x00010E7E
		public bool delta
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00012C84 File Offset: 0x00010E84
		public void undo()
		{
			if (this.tile == null)
			{
				return;
			}
			float[,,] splatmap = this.tile.splatmap;
			this.tile.splatmap = this.splatmapCopy;
			this.splatmapCopy = splatmap;
			this.tile.data.SetAlphamaps(0, 0, this.tile.splatmap);
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x00012CDB File Offset: 0x00010EDB
		public void redo()
		{
			this.undo();
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x00012CE4 File Offset: 0x00010EE4
		public void begin()
		{
			this.splatmapCopy = LandscapeSplatmapCopyPool.claim();
			for (int i = 0; i < Landscape.SPLATMAP_RESOLUTION; i++)
			{
				for (int j = 0; j < Landscape.SPLATMAP_RESOLUTION; j++)
				{
					for (int k = 0; k < Landscape.SPLATMAP_LAYERS; k++)
					{
						this.splatmapCopy[i, j, k] = this.tile.splatmap[i, j, k];
					}
				}
			}
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x00012D4D File Offset: 0x00010F4D
		public void end()
		{
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x00012D4F File Offset: 0x00010F4F
		public void forget()
		{
			LandscapeSplatmapCopyPool.release(this.splatmapCopy);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00012D5C File Offset: 0x00010F5C
		public LandscapeSplatmapTransaction(LandscapeTile newTile)
		{
			this.tile = newTile;
		}

		// Token: 0x040001F4 RID: 500
		protected LandscapeTile tile;

		// Token: 0x040001F5 RID: 501
		protected float[,,] splatmapCopy;
	}
}
