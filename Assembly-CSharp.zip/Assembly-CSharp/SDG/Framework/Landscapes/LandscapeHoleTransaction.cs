﻿using System;
using SDG.Framework.Devkit.Transactions;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A5 RID: 165
	public class LandscapeHoleTransaction : IDevkitTransaction
	{
		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000457 RID: 1111 RVA: 0x0001248E File Offset: 0x0001068E
		public bool delta
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00012494 File Offset: 0x00010694
		public void undo()
		{
			if (this.tile == null)
			{
				return;
			}
			bool[,] holes = this.tile.holes;
			this.tile.holes = this.holesCopy;
			this.holesCopy = holes;
			this.tile.SetHoles();
			this.tile.SyncDelayedLOD();
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x000124E4 File Offset: 0x000106E4
		public void redo()
		{
			this.undo();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x000124EC File Offset: 0x000106EC
		public void begin()
		{
			this.holesCopy = LandscapeHoleCopyPool.claim();
			for (int i = 0; i < 256; i++)
			{
				for (int j = 0; j < 256; j++)
				{
					this.holesCopy[i, j] = this.tile.holes[i, j];
				}
			}
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00012543 File Offset: 0x00010743
		public void end()
		{
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00012545 File Offset: 0x00010745
		public void forget()
		{
			LandscapeHoleCopyPool.release(this.holesCopy);
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00012552 File Offset: 0x00010752
		public LandscapeHoleTransaction(LandscapeTile newTile)
		{
			this.tile = newTile;
		}

		// Token: 0x040001EB RID: 491
		protected LandscapeTile tile;

		// Token: 0x040001EC RID: 492
		protected bool[,] holesCopy;
	}
}
