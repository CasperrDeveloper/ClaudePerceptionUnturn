﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000A6 RID: 166
	public class LandscapeHoleUtility
	{
		// Token: 0x0600045E RID: 1118 RVA: 0x00012564 File Offset: 0x00010764
		[Obsolete("New code should probably be using Landscape.IsPointInsideHole")]
		public static bool isPointInsideHoleVolume(Vector3 point)
		{
			LandscapeHoleVolume landscapeHoleVolume;
			return LandscapeHoleUtility.isPointInsideHoleVolume(point, out landscapeHoleVolume);
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0001257C File Offset: 0x0001077C
		[Obsolete("New code should probably be using Landscape.IsPointInsideHole")]
		public static bool isPointInsideHoleVolume(Vector3 point, out LandscapeHoleVolume volume)
		{
			List<LandscapeHoleVolume> list = VolumeManager<LandscapeHoleVolume, LandscapeHoleVolumeManager>.Get().InternalGetAllVolumes();
			for (int i = 0; i < list.Count; i++)
			{
				volume = list[i];
				if (LandscapeHoleUtility.isPointInsideHoleVolume(volume, point))
				{
					return true;
				}
			}
			volume = null;
			return false;
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x000125BE File Offset: 0x000107BE
		[Obsolete]
		public static bool isPointInsideHoleVolume(LandscapeHoleVolume volume, Vector3 point)
		{
			return volume.IsPositionInsideVolume(point);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x000125C7 File Offset: 0x000107C7
		[Obsolete]
		public static bool doesRayIntersectHoleVolume(Ray ray, out RaycastHit hit, out LandscapeHoleVolume volume, float maxDistance)
		{
			return VolumeManager<LandscapeHoleVolume, LandscapeHoleVolumeManager>.Get().Raycast(ray, out hit, out volume, maxDistance);
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x000125D7 File Offset: 0x000107D7
		[Obsolete]
		public static bool doesRayIntersectHoleVolume(LandscapeHoleVolume volume, Ray ray, out RaycastHit hit, float maxDistance)
		{
			return volume.volumeCollider.Raycast(ray, out hit, maxDistance);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x000125E8 File Offset: 0x000107E8
		[Obsolete("Hole collision is handled by Unity now")]
		public static bool shouldRaycastIgnoreLandscape(Ray ray, float maxDistance)
		{
			RaycastHit raycastHit;
			LandscapeHoleVolume volume;
			RaycastHit raycastHit2;
			RaycastHit raycastHit3;
			return (LandscapeHoleUtility.doesRayIntersectHoleVolume(ray, out raycastHit, out volume, maxDistance) && Physics.Raycast(ray, out raycastHit2, maxDistance, 1048576) && LandscapeHoleUtility.isPointInsideHoleVolume(volume, raycastHit2.point)) || (LandscapeHoleUtility.isPointInsideHoleVolume(ray.origin, out volume) && Physics.Raycast(ray, out raycastHit3, maxDistance, 1048576) && LandscapeHoleUtility.isPointInsideHoleVolume(volume, raycastHit3.point));
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00012655 File Offset: 0x00010855
		[Obsolete("Hole collision is handled by Unity now")]
		public static bool shouldSpherecastIgnoreLandscape(Ray ray, float radius, float maxDistance)
		{
			ray.origin -= ray.direction * radius;
			maxDistance += radius * 2f;
			return LandscapeHoleUtility.shouldRaycastIgnoreLandscape(ray, maxDistance);
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00012688 File Offset: 0x00010888
		[Obsolete("Hole collision is handled by Unity now")]
		public static void raycastIgnoreLandscapeIfNecessary(Ray ray, float maxDistance, ref int layerMask)
		{
			if (LandscapeHoleUtility.shouldRaycastIgnoreLandscape(ray, maxDistance))
			{
				layerMask &= -1048577;
			}
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0001269D File Offset: 0x0001089D
		[Obsolete("Hole collision is handled by Unity now")]
		public static void spherecastIgnoreLandscapeIfNecessary(Ray ray, float radius, float maxDistance, ref int layerMask)
		{
			if (LandscapeHoleUtility.shouldSpherecastIgnoreLandscape(ray, radius, maxDistance))
			{
				layerMask &= -1048577;
			}
		}
	}
}
