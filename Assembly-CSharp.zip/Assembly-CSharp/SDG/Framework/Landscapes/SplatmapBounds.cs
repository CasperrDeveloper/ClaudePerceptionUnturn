﻿using System;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x020000AE RID: 174
	public struct SplatmapBounds
	{
		// Token: 0x060004B1 RID: 1201 RVA: 0x0001456C File Offset: 0x0001276C
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"[",
				this.min.ToString(),
				", ",
				this.max.ToString(),
				"]"
			});
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x000145C4 File Offset: 0x000127C4
		public SplatmapBounds(SplatmapCoord newMin, SplatmapCoord newMax)
		{
			this.min = newMin;
			this.max = newMax;
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x000145D4 File Offset: 0x000127D4
		public SplatmapBounds(LandscapeCoord tileCoord, Bounds worldBounds)
		{
			int new_x = Mathf.Clamp(Mathf.FloorToInt((worldBounds.min.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
			int new_x2 = Mathf.Clamp(Mathf.FloorToInt((worldBounds.max.z - (float)tileCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
			int new_y = Mathf.Clamp(Mathf.FloorToInt((worldBounds.min.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
			int new_y2 = Mathf.Clamp(Mathf.FloorToInt((worldBounds.max.x - (float)tileCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE * (float)Landscape.SPLATMAP_RESOLUTION), 0, Landscape.SPLATMAP_RESOLUTION_MINUS_ONE);
			this.min = new SplatmapCoord(new_x, new_y);
			this.max = new SplatmapCoord(new_x2, new_y2);
		}

		// Token: 0x04000205 RID: 517
		public SplatmapCoord min;

		// Token: 0x04000206 RID: 518
		public SplatmapCoord max;
	}
}
