﻿using System;
using System.Collections;
using System.Collections.Generic;
using SDG.Framework.Debug;
using SDG.Framework.Devkit;
using SDG.Framework.Devkit.Transactions;
using SDG.Framework.Foliage;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Landscapes
{
	// Token: 0x0200009F RID: 159
	public class Landscape : DevkitHierarchyItemBase
	{
		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x000103E3 File Offset: 0x0000E5E3
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x000103EA File Offset: 0x0000E5EA
		public static Landscape instance { get; protected set; }

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x060003F6 RID: 1014 RVA: 0x000103F4 File Offset: 0x0000E5F4
		// (remove) Token: 0x060003F7 RID: 1015 RVA: 0x00010428 File Offset: 0x0000E628
		public static event LandscapeLoadedHandler loaded;

		/// <summary>
		/// Hacky workaround for height and material brushes in editor. As far as I can tell in Unity 2019 LTS there is no method to ignore
		/// holes when raycasting against terrain (e.g. when painting holes), so we use a duplicate TerrainData without holes in the editor.
		/// </summary>
		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x0001045B File Offset: 0x0000E65B
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x00010464 File Offset: 0x0000E664
		public static bool DisableHoleColliders
		{
			get
			{
				return Landscape._disableHoleColliders;
			}
			set
			{
				if (Landscape._disableHoleColliders == value)
				{
					return;
				}
				Landscape._disableHoleColliders = value;
				foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
				{
					LandscapeTile value2 = keyValuePair.Value;
					if (value2.collider != null)
					{
						value2.collider.terrainData = (Landscape._disableHoleColliders ? value2.dataWithoutHoles : value2.data);
					}
				}
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x000104F4 File Offset: 0x0000E6F4
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x000104FB File Offset: 0x0000E6FB
		public static bool HighlightHoles
		{
			get
			{
				return Landscape._highlightHoles;
			}
			set
			{
				if (Landscape._highlightHoles == value)
				{
					return;
				}
				Landscape._highlightHoles = value;
				Shader.SetGlobalFloat("_TerrainHighlightHoles", Landscape._highlightHoles ? 1f : 0f);
			}
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0001052C File Offset: 0x0000E72C
		public static void GetUniqueMaterials(List<LandscapeMaterialAsset> materials)
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				foreach (AssetReference<LandscapeMaterialAsset> assetReference in keyValuePair.Value.materials)
				{
					LandscapeMaterialAsset landscapeMaterialAsset = assetReference.Find();
					if (landscapeMaterialAsset != null && !materials.Contains(landscapeMaterialAsset))
					{
						materials.Add(landscapeMaterialAsset);
					}
				}
			}
		}

		/// <summary>
		/// Is point (on XZ plane) inside a masked-out pixel?
		/// </summary>
		// Token: 0x060003FD RID: 1021 RVA: 0x000105D8 File Offset: 0x0000E7D8
		public static bool IsPointInsideHole(Vector3 worldPosition)
		{
			LandscapeCoord landscapeCoord = new LandscapeCoord(worldPosition);
			LandscapeTile tile = Landscape.getTile(landscapeCoord);
			if (tile != null)
			{
				SplatmapCoord splatmapCoord = new SplatmapCoord(landscapeCoord, worldPosition);
				return !tile.holes[splatmapCoord.x, splatmapCoord.y];
			}
			return false;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0001061C File Offset: 0x0000E81C
		public static bool getWorldHeight(Vector3 position, out float height)
		{
			LandscapeTile tile = Landscape.getTile(new LandscapeCoord(position));
			if (tile != null)
			{
				height = tile.terrain.SampleHeight(position) - Landscape.TILE_HEIGHT / 2f;
				return true;
			}
			height = 0f;
			return false;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0001065C File Offset: 0x0000E85C
		public static bool getWorldHeight(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, out float height)
		{
			LandscapeTile tile = Landscape.getTile(tileCoord);
			if (tile != null)
			{
				height = tile.heightmap[heightmapCoord.x, heightmapCoord.y] * Landscape.TILE_HEIGHT - Landscape.TILE_HEIGHT / 2f;
				return true;
			}
			height = 0f;
			return false;
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x000106A8 File Offset: 0x0000E8A8
		public static bool getHeight01(Vector3 position, out float height)
		{
			LandscapeTile tile = Landscape.getTile(new LandscapeCoord(position));
			if (tile != null)
			{
				height = tile.terrain.SampleHeight(position) / Landscape.TILE_HEIGHT;
				return true;
			}
			height = 0f;
			return false;
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x000106E4 File Offset: 0x0000E8E4
		public static bool getHeight01(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, out float height)
		{
			LandscapeTile tile = Landscape.getTile(tileCoord);
			if (tile != null)
			{
				height = tile.heightmap[heightmapCoord.x, heightmapCoord.y];
				return true;
			}
			height = 0f;
			return false;
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00010720 File Offset: 0x0000E920
		public static bool getNormal(Vector3 position, out Vector3 normal)
		{
			LandscapeCoord landscapeCoord = new LandscapeCoord(position);
			LandscapeTile tile = Landscape.getTile(landscapeCoord);
			if (tile != null)
			{
				normal = tile.data.GetInterpolatedNormal((position.x - (float)landscapeCoord.x * Landscape.TILE_SIZE) / Landscape.TILE_SIZE, (position.z - (float)landscapeCoord.y * Landscape.TILE_SIZE) / Landscape.TILE_SIZE);
				return true;
			}
			normal = Vector3.up;
			return false;
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00010794 File Offset: 0x0000E994
		public static bool getSplatmapMaterial(Vector3 position, out AssetReference<LandscapeMaterialAsset> materialAsset)
		{
			LandscapeCoord tileCoord = new LandscapeCoord(position);
			SplatmapCoord splatmapCoord = new SplatmapCoord(tileCoord, position);
			return Landscape.getSplatmapMaterial(tileCoord, splatmapCoord, out materialAsset);
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x000107BC File Offset: 0x0000E9BC
		public static bool getSplatmapMaterial(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord, out AssetReference<LandscapeMaterialAsset> materialAsset)
		{
			int index;
			if (Landscape.getSplatmapLayer(tileCoord, splatmapCoord, out index))
			{
				materialAsset = Landscape.getTile(tileCoord).materials[index];
				return true;
			}
			materialAsset = AssetReference<LandscapeMaterialAsset>.invalid;
			return false;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x000107FC File Offset: 0x0000E9FC
		public static bool getSplatmapLayer(Vector3 position, out int layer)
		{
			LandscapeCoord tileCoord = new LandscapeCoord(position);
			SplatmapCoord splatmapCoord = new SplatmapCoord(tileCoord, position);
			return Landscape.getSplatmapLayer(tileCoord, splatmapCoord, out layer);
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00010824 File Offset: 0x0000EA24
		public static bool getSplatmapLayer(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord, out int layer)
		{
			LandscapeTile tile = Landscape.getTile(tileCoord);
			if (tile != null)
			{
				layer = Landscape.getSplatmapHighestWeightLayerIndex(splatmapCoord, tile.splatmap, -1);
				return true;
			}
			layer = -1;
			return false;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00010850 File Offset: 0x0000EA50
		public static int getSplatmapHighestWeightLayerIndex(SplatmapCoord splatmapCoord, float[,,] currentWeights, int ignoreLayer = -1)
		{
			float num = -1f;
			int result = -1;
			for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
			{
				if (i != ignoreLayer && currentWeights[splatmapCoord.x, splatmapCoord.y, i] > num)
				{
					num = currentWeights[splatmapCoord.x, splatmapCoord.y, i];
					result = i;
				}
			}
			return result;
		}

		/// <param name="ignoreLayer">If the highest weight layer is ignoreLayer then the next highest will be returned.</param>
		// Token: 0x06000408 RID: 1032 RVA: 0x000108A8 File Offset: 0x0000EAA8
		public static int getSplatmapHighestWeightLayerIndex(float[] currentWeights, int ignoreLayer = -1)
		{
			float num = -1f;
			int result = -1;
			for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
			{
				if (i != ignoreLayer && currentWeights[i] > num)
				{
					num = currentWeights[i];
					result = i;
				}
			}
			return result;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x000108DE File Offset: 0x0000EADE
		public static void clearHeightmapTransactions()
		{
			Landscape.heightmapTransactions.Clear();
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x000108EA File Offset: 0x0000EAEA
		public static void clearSplatmapTransactions()
		{
			Landscape.splatmapTransactions.Clear();
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x000108F6 File Offset: 0x0000EAF6
		public static void clearHoleTransactions()
		{
			Landscape.holeTransactions.Clear();
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00010902 File Offset: 0x0000EB02
		public static bool isPointerInTile(Vector3 worldPosition)
		{
			return Landscape.getTile(worldPosition) != null;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00010910 File Offset: 0x0000EB10
		public static Vector3 getWorldPosition(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, float height)
		{
			float x = (float)Mathf.RoundToInt((float)tileCoord.x * Landscape.TILE_SIZE + (float)heightmapCoord.y / (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE * Landscape.TILE_SIZE);
			float y = -Landscape.TILE_HEIGHT / 2f + height * Landscape.TILE_HEIGHT;
			float num = (float)tileCoord.y * Landscape.TILE_SIZE + (float)heightmapCoord.x / (float)Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE * Landscape.TILE_SIZE;
			num = (float)Mathf.RoundToInt(num);
			return new Vector3(x, y, num);
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0001098C File Offset: 0x0000EB8C
		public static Vector3 getWorldPosition(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord)
		{
			float num = (float)tileCoord.x * Landscape.TILE_SIZE + (float)splatmapCoord.y / (float)Landscape.SPLATMAP_RESOLUTION * Landscape.TILE_SIZE;
			num = (float)Mathf.RoundToInt(num) + Landscape.HALF_SPLATMAP_WORLD_UNIT;
			float num2 = (float)tileCoord.y * Landscape.TILE_SIZE + (float)splatmapCoord.x / (float)Landscape.SPLATMAP_RESOLUTION * Landscape.TILE_SIZE;
			num2 = (float)Mathf.RoundToInt(num2) + Landscape.HALF_SPLATMAP_WORLD_UNIT;
			Vector3 vector = new Vector3(num, 0f, num2);
			float y;
			Landscape.getWorldHeight(vector, out y);
			vector.y = y;
			return vector;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00010A1C File Offset: 0x0000EC1C
		public static void readHeightmap(Bounds worldBounds, Landscape.LandscapeReadHeightmapHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						HeightmapBounds heightmapBounds = new HeightmapBounds(landscapeCoord, worldBounds);
						for (int k = heightmapBounds.min.x; k < heightmapBounds.max.x; k++)
						{
							for (int l = heightmapBounds.min.y; l < heightmapBounds.max.y; l++)
							{
								HeightmapCoord heightmapCoord = new HeightmapCoord(k, l);
								float num = tile.heightmap[k, l];
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, heightmapCoord, num);
								callback(landscapeCoord, heightmapCoord, worldPosition, num);
							}
						}
					}
				}
			}
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00010B24 File Offset: 0x0000ED24
		public static void readSplatmap(Bounds worldBounds, Landscape.LandscapeReadSplatmapHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						SplatmapBounds splatmapBounds = new SplatmapBounds(landscapeCoord, worldBounds);
						for (int k = splatmapBounds.min.x; k < splatmapBounds.max.x; k++)
						{
							for (int l = splatmapBounds.min.y; l < splatmapBounds.max.y; l++)
							{
								SplatmapCoord splatmapCoord = new SplatmapCoord(k, l);
								for (int m = 0; m < Landscape.SPLATMAP_LAYERS; m++)
								{
									Landscape.SPLATMAP_LAYER_BUFFER[m] = tile.splatmap[k, l, m];
								}
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, splatmapCoord);
								callback(landscapeCoord, splatmapCoord, worldPosition, Landscape.SPLATMAP_LAYER_BUFFER);
							}
						}
					}
				}
			}
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00010C4C File Offset: 0x0000EE4C
		public static void writeHeightmap(Bounds worldBounds, Landscape.LandscapeWriteHeightmapHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						if (!Landscape.heightmapTransactions.ContainsKey(landscapeCoord))
						{
							LandscapeHeightmapTransaction landscapeHeightmapTransaction = new LandscapeHeightmapTransaction(tile);
							DevkitTransactionManager.recordTransaction(landscapeHeightmapTransaction);
							Landscape.heightmapTransactions.Add(landscapeCoord, landscapeHeightmapTransaction);
						}
						HeightmapBounds heightmapBounds = new HeightmapBounds(landscapeCoord, worldBounds);
						for (int k = heightmapBounds.min.x; k <= heightmapBounds.max.x; k++)
						{
							for (int l = heightmapBounds.min.y; l <= heightmapBounds.max.y; l++)
							{
								HeightmapCoord heightmapCoord = new HeightmapCoord(k, l);
								float num = tile.heightmap[k, l];
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, heightmapCoord, num);
								tile.heightmap[k, l] = Mathf.Clamp01(callback(landscapeCoord, heightmapCoord, worldPosition, num));
							}
						}
					}
				}
			}
			for (int m = landscapeBounds.min.x; m <= landscapeBounds.max.x; m++)
			{
				for (int n = landscapeBounds.min.y; n <= landscapeBounds.max.y; n++)
				{
					LandscapeTile tile2 = Landscape.getTile(new LandscapeCoord(m, n));
					if (tile2 != null)
					{
						if (m < landscapeBounds.max.x)
						{
							LandscapeTile tile3 = Landscape.getTile(new LandscapeCoord(m + 1, n));
							if (tile3 != null)
							{
								for (int num2 = 0; num2 <= Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE; num2++)
								{
									tile2.heightmap[num2, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE] = tile3.heightmap[num2, 0];
								}
							}
						}
						if (n < landscapeBounds.max.y)
						{
							LandscapeTile tile4 = Landscape.getTile(new LandscapeCoord(m, n + 1));
							if (tile4 != null)
							{
								for (int num3 = 0; num3 <= Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE; num3++)
								{
									tile2.heightmap[Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE, num3] = tile4.heightmap[0, num3];
								}
							}
						}
						if (m < landscapeBounds.max.x && n < landscapeBounds.max.y)
						{
							LandscapeTile tile5 = Landscape.getTile(new LandscapeCoord(m + 1, n + 1));
							if (tile5 != null)
							{
								tile2.heightmap[Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE, Landscape.HEIGHTMAP_RESOLUTION_MINUS_ONE] = tile5.heightmap[0, 0];
							}
						}
					}
				}
			}
			for (int num4 = landscapeBounds.min.x; num4 <= landscapeBounds.max.x; num4++)
			{
				for (int num5 = landscapeBounds.min.y; num5 <= landscapeBounds.max.y; num5++)
				{
					LandscapeTile tile6 = Landscape.getTile(new LandscapeCoord(num4, num5));
					if (tile6 != null)
					{
						tile6.SetHeightsDelayLOD();
					}
				}
			}
			LevelHierarchy.MarkDirty();
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00010F7C File Offset: 0x0000F17C
		public static void writeSplatmap(Bounds worldBounds, Landscape.LandscapeWriteSplatmapHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						if (!Landscape.splatmapTransactions.ContainsKey(landscapeCoord))
						{
							LandscapeSplatmapTransaction landscapeSplatmapTransaction = new LandscapeSplatmapTransaction(tile);
							DevkitTransactionManager.recordTransaction(landscapeSplatmapTransaction);
							Landscape.splatmapTransactions.Add(landscapeCoord, landscapeSplatmapTransaction);
						}
						SplatmapBounds splatmapBounds = new SplatmapBounds(landscapeCoord, worldBounds);
						for (int k = splatmapBounds.min.x; k <= splatmapBounds.max.x; k++)
						{
							for (int l = splatmapBounds.min.y; l <= splatmapBounds.max.y; l++)
							{
								SplatmapCoord splatmapCoord = new SplatmapCoord(k, l);
								for (int m = 0; m < Landscape.SPLATMAP_LAYERS; m++)
								{
									Landscape.SPLATMAP_LAYER_BUFFER[m] = tile.splatmap[k, l, m];
								}
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, splatmapCoord);
								callback(landscapeCoord, splatmapCoord, worldPosition, Landscape.SPLATMAP_LAYER_BUFFER);
								for (int n = 0; n < Landscape.SPLATMAP_LAYERS; n++)
								{
									tile.splatmap[k, l, n] = Mathf.Clamp01(Landscape.SPLATMAP_LAYER_BUFFER[n]);
								}
							}
						}
						tile.data.SetAlphamaps(0, 0, tile.splatmap);
					}
				}
			}
			LevelHierarchy.MarkDirty();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00011124 File Offset: 0x0000F324
		public static void writeHoles(Bounds worldBounds, Landscape.LandscapeWriteHolesHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						if (!Landscape.holeTransactions.ContainsKey(landscapeCoord))
						{
							LandscapeHoleTransaction landscapeHoleTransaction = new LandscapeHoleTransaction(tile);
							DevkitTransactionManager.recordTransaction(landscapeHoleTransaction);
							Landscape.holeTransactions.Add(landscapeCoord, landscapeHoleTransaction);
						}
						SplatmapBounds splatmapBounds = new SplatmapBounds(landscapeCoord, worldBounds);
						for (int k = splatmapBounds.min.x; k <= splatmapBounds.max.x; k++)
						{
							for (int l = splatmapBounds.min.y; l <= splatmapBounds.max.y; l++)
							{
								SplatmapCoord splatmapCoord = new SplatmapCoord(k, l);
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, splatmapCoord);
								bool flag = tile.holes[k, l];
								bool flag2 = callback(worldPosition, flag);
								tile.holes[k, l] = flag2;
								tile.hasAnyHolesData |= (flag2 != flag);
							}
						}
						tile.SetHoles();
					}
				}
			}
			LevelHierarchy.MarkDirty();
		}

		/// <summary>
		/// Appends heightmap vertices to points list.
		/// </summary>
		// Token: 0x06000414 RID: 1044 RVA: 0x00011290 File Offset: 0x0000F490
		public static void getHeightmapVertices(Bounds worldBounds, Landscape.LandscapeGetHeightmapVerticesHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					LandscapeTile tile = Landscape.getTile(landscapeCoord);
					if (tile != null)
					{
						HeightmapBounds heightmapBounds = new HeightmapBounds(landscapeCoord, worldBounds);
						for (int k = heightmapBounds.min.x; k <= heightmapBounds.max.x; k++)
						{
							for (int l = heightmapBounds.min.y; l <= heightmapBounds.max.y; l++)
							{
								HeightmapCoord heightmapCoord = new HeightmapCoord(k, l);
								float height = tile.heightmap[k, l];
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, heightmapCoord, height);
								callback(landscapeCoord, heightmapCoord, worldPosition);
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Appends heightmap vertices to points list.
		/// </summary>
		// Token: 0x06000415 RID: 1045 RVA: 0x00011398 File Offset: 0x0000F598
		public static void getSplatmapVertices(Bounds worldBounds, Landscape.LandscapeGetSplatmapVerticesHandler callback)
		{
			if (callback == null)
			{
				return;
			}
			LandscapeBounds landscapeBounds = new LandscapeBounds(worldBounds);
			for (int i = landscapeBounds.min.x; i <= landscapeBounds.max.x; i++)
			{
				for (int j = landscapeBounds.min.y; j <= landscapeBounds.max.y; j++)
				{
					LandscapeCoord landscapeCoord = new LandscapeCoord(i, j);
					if (Landscape.getTile(landscapeCoord) != null)
					{
						SplatmapBounds splatmapBounds = new SplatmapBounds(landscapeCoord, worldBounds);
						for (int k = splatmapBounds.min.x; k <= splatmapBounds.max.x; k++)
						{
							for (int l = splatmapBounds.min.y; l <= splatmapBounds.max.y; l++)
							{
								SplatmapCoord splatmapCoord = new SplatmapCoord(k, l);
								Vector3 worldPosition = Landscape.getWorldPosition(landscapeCoord, splatmapCoord);
								callback(landscapeCoord, splatmapCoord, worldPosition);
							}
						}
					}
				}
			}
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00011484 File Offset: 0x0000F684
		public static void applyLOD()
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				keyValuePair.Value.SyncDelayedLOD();
			}
		}

		/// <summary>
		/// Call this after you're done adding new tiles.
		/// </summary>
		// Token: 0x06000417 RID: 1047 RVA: 0x000114DC File Offset: 0x0000F6DC
		public static void linkNeighbors()
		{
			if (Dedicator.IsDedicatedServer)
			{
				return;
			}
			bool supportsInstancing = SystemInfo.supportsInstancing;
			foreach (LandscapeTile landscapeTile in Landscape.tiles.Values)
			{
				landscapeTile.terrain.drawInstanced = supportsInstancing;
			}
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				LandscapeTile value = keyValuePair.Value;
				LandscapeTile tile = Landscape.getTile(new LandscapeCoord(value.coord.x - 1, value.coord.y));
				LandscapeTile tile2 = Landscape.getTile(new LandscapeCoord(value.coord.x, value.coord.y + 1));
				LandscapeTile tile3 = Landscape.getTile(new LandscapeCoord(value.coord.x + 1, value.coord.y));
				LandscapeTile tile4 = Landscape.getTile(new LandscapeCoord(value.coord.x, value.coord.y - 1));
				Terrain left = (tile == null) ? null : tile.terrain;
				Terrain top = (tile2 == null) ? null : tile2.terrain;
				Terrain right = (tile3 == null) ? null : tile3.terrain;
				Terrain bottom = (tile4 == null) ? null : tile4.terrain;
				value.terrain.SetNeighbors(left, top, right, bottom);
			}
			foreach (LandscapeTile landscapeTile2 in Landscape.tiles.Values)
			{
				landscapeTile2.terrain.Flush();
			}
		}

		/// <summary>
		/// Call this to sync a new tile up with nearby tiles.
		/// </summary>
		// Token: 0x06000418 RID: 1048 RVA: 0x000116E8 File Offset: 0x0000F8E8
		public static void reconcileNeighbors(LandscapeTile tile)
		{
			LandscapeTile tile2 = Landscape.getTile(new LandscapeCoord(tile.coord.x - 1, tile.coord.y));
			if (tile2 != null)
			{
				for (int i = 0; i < Landscape.HEIGHTMAP_RESOLUTION; i++)
				{
					tile.heightmap[i, 0] = tile2.heightmap[i, Landscape.HEIGHTMAP_RESOLUTION - 1];
				}
			}
			LandscapeTile tile3 = Landscape.getTile(new LandscapeCoord(tile.coord.x, tile.coord.y - 1));
			if (tile3 != null)
			{
				for (int j = 0; j < Landscape.HEIGHTMAP_RESOLUTION; j++)
				{
					tile.heightmap[0, j] = tile3.heightmap[Landscape.HEIGHTMAP_RESOLUTION - 1, j];
				}
			}
			LandscapeTile tile4 = Landscape.getTile(new LandscapeCoord(tile.coord.x + 1, tile.coord.y));
			if (tile4 != null)
			{
				for (int k = 0; k < Landscape.HEIGHTMAP_RESOLUTION; k++)
				{
					tile.heightmap[k, Landscape.HEIGHTMAP_RESOLUTION - 1] = tile4.heightmap[k, 0];
				}
			}
			LandscapeTile tile5 = Landscape.getTile(new LandscapeCoord(tile.coord.x, tile.coord.y + 1));
			if (tile5 != null)
			{
				for (int l = 0; l < Landscape.HEIGHTMAP_RESOLUTION; l++)
				{
					tile.heightmap[Landscape.HEIGHTMAP_RESOLUTION - 1, l] = tile5.heightmap[0, l];
				}
			}
			tile.SetHeightsDelayLOD();
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0001186C File Offset: 0x0000FA6C
		public static LandscapeTile addTile(LandscapeCoord coord)
		{
			if (Landscape.instance == null)
			{
				UnturnedLog.info("Adding default landscape to level");
				LevelHierarchy.AssignInstanceIdAndMarkDirty(new GameObject().AddComponent<Landscape>());
			}
			if (Landscape.tiles.ContainsKey(coord))
			{
				return null;
			}
			LandscapeTile landscapeTile = new LandscapeTile(coord);
			landscapeTile.enable();
			landscapeTile.applyGraphicsSettings();
			Landscape.tiles.Add(coord, landscapeTile);
			return landscapeTile;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x000118D0 File Offset: 0x0000FAD0
		protected static void clearTiles()
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				keyValuePair.Value.disable();
			}
			Landscape.tiles.Clear();
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00011934 File Offset: 0x0000FB34
		public static void CopyLayersToAllTiles(LandscapeTile source)
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				LandscapeTile value = keyValuePair.Value;
				if (value != source)
				{
					for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
					{
						value.materials[i] = source.materials[i];
					}
					value.updatePrototypes();
				}
			}
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x000119BC File Offset: 0x0000FBBC
		public static LandscapeTile getOrAddTile(Vector3 worldPosition)
		{
			return Landscape.getOrAddTile(new LandscapeCoord(worldPosition));
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x000119C9 File Offset: 0x0000FBC9
		public static LandscapeTile getTile(Vector3 worldPosition)
		{
			return Landscape.getTile(new LandscapeCoord(worldPosition));
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x000119D8 File Offset: 0x0000FBD8
		public static LandscapeTile getOrAddTile(LandscapeCoord coord)
		{
			LandscapeTile result;
			if (!Landscape.tiles.TryGetValue(coord, out result))
			{
				result = Landscape.addTile(coord);
			}
			return result;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x000119FC File Offset: 0x0000FBFC
		public static LandscapeTile getTile(LandscapeCoord coord)
		{
			LandscapeTile result;
			Landscape.tiles.TryGetValue(coord, out result);
			return result;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x00011A18 File Offset: 0x0000FC18
		public static bool removeTile(LandscapeCoord coord)
		{
			LandscapeTile landscapeTile;
			if (!Landscape.tiles.TryGetValue(coord, out landscapeTile))
			{
				return false;
			}
			landscapeTile.disable();
			UnityEngine.Object.Destroy(landscapeTile.gameObject);
			Landscape.tiles.Remove(coord);
			return true;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x00011A54 File Offset: 0x0000FC54
		public override void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			int num = reader.readArrayLength("Tiles");
			if (Landscape.instance != this)
			{
				UnturnedLog.warn("Level contains multiple Landscapes. Ignoring {0} tile(s) with instance ID: {1}", new object[]
				{
					num,
					this.instanceID
				});
				return;
			}
			UnturnedLog.info("Loading {0} landscape tiles", new object[]
			{
				num
			});
			for (int i = 0; i < num; i++)
			{
				reader.readArrayIndex(i);
				LandscapeTile landscapeTile = new LandscapeTile(LandscapeCoord.ZERO);
				landscapeTile.enable();
				landscapeTile.applyGraphicsSettings();
				landscapeTile.read(reader);
				if (Landscape.tiles.ContainsKey(landscapeTile.coord))
				{
					UnturnedLog.error("Duplicate landscape coord read: " + landscapeTile.coord.ToString());
				}
				else
				{
					Landscape.tiles.Add(landscapeTile.coord, landscapeTile);
				}
			}
			Landscape.linkNeighbors();
			Landscape.applyLOD();
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00011B48 File Offset: 0x0000FD48
		public override void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.beginArray("Tiles");
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				LandscapeTile value = keyValuePair.Value;
				writer.writeValue<LandscapeTile>(value);
			}
			writer.endArray();
			writer.endObject();
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x00011BC0 File Offset: 0x0000FDC0
		protected void triggerLandscapeLoaded()
		{
			LandscapeLoadedHandler landscapeLoadedHandler = Landscape.loaded;
			if (landscapeLoadedHandler == null)
			{
				return;
			}
			landscapeLoadedHandler();
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00011BD4 File Offset: 0x0000FDD4
		protected void handleGraphicsSettingsApplied()
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				keyValuePair.Value.applyGraphicsSettings();
			}
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00011C2C File Offset: 0x0000FE2C
		protected void handlePlanarReflectionPreRender()
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				keyValuePair.Value.terrain.basemapDistance = 0f;
			}
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x00011C90 File Offset: 0x0000FE90
		protected void handlePlanarReflectionPostRender()
		{
			float terrainBasemapDistance = GraphicsSettings.terrainBasemapDistance;
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				keyValuePair.Value.terrain.basemapDistance = terrainBasemapDistance;
			}
		}

		/// <summary>
		/// Capturing ortho view of map, so we raise the terrain to max quality.
		/// </summary>
		// Token: 0x06000427 RID: 1063 RVA: 0x00011CF4 File Offset: 0x0000FEF4
		protected void onSatellitePreCapture()
		{
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				LandscapeTile value = keyValuePair.Value;
				value.terrain.basemapDistance = 8192f;
				value.terrain.heightmapPixelError = 1f;
			}
		}

		/// <summary>
		/// Finished capturing ortho view of map, so we restore the terrain to preferred quality.
		/// </summary>
		// Token: 0x06000428 RID: 1064 RVA: 0x00011D68 File Offset: 0x0000FF68
		protected void onSatellitePostCapture()
		{
			float terrainBasemapDistance = GraphicsSettings.terrainBasemapDistance;
			float terrainHeightmapPixelError = GraphicsSettings.terrainHeightmapPixelError;
			foreach (KeyValuePair<LandscapeCoord, LandscapeTile> keyValuePair in Landscape.tiles)
			{
				LandscapeTile value = keyValuePair.Value;
				value.terrain.basemapDistance = terrainBasemapDistance;
				value.terrain.heightmapPixelError = terrainHeightmapPixelError;
			}
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x00011DE0 File Offset: 0x0000FFE0
		protected void OnEnable()
		{
			LevelHierarchy.addItem(this);
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x00011DE8 File Offset: 0x0000FFE8
		protected void OnDisable()
		{
			LevelHierarchy.removeItem(this);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x00011DF0 File Offset: 0x0000FFF0
		protected void Awake()
		{
			base.name = "Landscape";
			base.gameObject.layer = 20;
			if (Landscape.instance == null)
			{
				Landscape.instance = this;
				Landscape.clearTiles();
				Landscape._disableHoleColliders = false;
				Landscape.HighlightHoles = false;
				if (Level.isEditor)
				{
					LandscapeHeightmapCopyPool.warmup(DevkitTransactionManager.historyLength);
					LandscapeSplatmapCopyPool.warmup(DevkitTransactionManager.historyLength);
					LandscapeHoleCopyPool.warmup(DevkitTransactionManager.historyLength);
				}
				GraphicsSettings.graphicsSettingsApplied += this.handleGraphicsSettingsApplied;
				PlanarReflection.preRender += this.handlePlanarReflectionPreRender;
				PlanarReflection.postRender += this.handlePlanarReflectionPostRender;
				Level.bindSatelliteCaptureInEditor(new Level.SatelliteCaptureDelegate(this.onSatellitePreCapture), new Level.SatelliteCaptureDelegate(this.onSatellitePostCapture));
			}
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x00011EB1 File Offset: 0x000100B1
		protected void Start()
		{
			if (Landscape.instance == this && this.shouldTriggerLandscapeLoaded)
			{
				this.triggerLandscapeLoaded();
			}
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x00011ED0 File Offset: 0x000100D0
		protected void OnDestroy()
		{
			if (Landscape.instance == this)
			{
				GraphicsSettings.graphicsSettingsApplied -= this.handleGraphicsSettingsApplied;
				PlanarReflection.preRender -= this.handlePlanarReflectionPreRender;
				PlanarReflection.postRender -= this.handlePlanarReflectionPostRender;
				Level.unbindSatelliteCapture(new Level.SatelliteCaptureDelegate(this.onSatellitePreCapture), new Level.SatelliteCaptureDelegate(this.onSatellitePostCapture));
				Landscape.instance = null;
				Landscape.clearTiles();
				Landscape._disableHoleColliders = false;
				Landscape.HighlightHoles = false;
				LandscapeHeightmapCopyPool.empty();
				LandscapeSplatmapCopyPool.empty();
				LandscapeHoleCopyPool.empty();
			}
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x00011F60 File Offset: 0x00010160
		internal IEnumerator AutoConvertLegacyTerrain()
		{
			this.shouldTriggerLandscapeLoaded = false;
			int num = (int)Level.size / Landscape.TILE_SIZE_INT;
			int halfTiles = num / 2 + 1;
			int num2;
			for (int tile_x = -halfTiles; tile_x < halfTiles; tile_x = num2 + 1)
			{
				for (int tile_y = -halfTiles; tile_y < halfTiles; tile_y = num2 + 1)
				{
					LandscapeCoord coord = new LandscapeCoord(tile_x, tile_y);
					LandscapeTile tile = Landscape.getOrAddTile(coord);
					UnturnedLog.info("Auto convert heightmap {0}", new object[]
					{
						coord
					});
					tile.convertLegacyHeightmap();
					yield return null;
					if (LevelGround.doesLegacyDataIncludeSplatmapWeights)
					{
						UnturnedLog.info("Auto convert splatmap {0}", new object[]
						{
							coord
						});
						tile.convertLegacySplatmap();
						yield return null;
						for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
						{
							tile.materials[i] = LevelGround.legacyMaterialGuids[i];
						}
					}
					tile.updatePrototypes();
					yield return null;
					tile = null;
					num2 = tile_y;
				}
				num2 = tile_x;
			}
			FoliageSystem.CreateInLevelIfMissing();
			this.triggerLandscapeLoaded();
			yield break;
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x00011F6F File Offset: 0x0001016F
		private IEnumerator convertLegacyTerrainImpl(InspectableList<AssetReference<LandscapeMaterialAsset>> materials)
		{
			yield return null;
			int size = (int)Level.size;
			int tiles = size / Landscape.TILE_SIZE_INT;
			int num;
			for (int tile_x = -tiles; tile_x < tiles; tile_x = num + 1)
			{
				for (int tile_y = -tiles; tile_y < tiles; tile_y = num + 1)
				{
					LandscapeCoord coord = new LandscapeCoord(tile_x, tile_y);
					LandscapeTile tile = Landscape.getOrAddTile(coord);
					UnturnedLog.info("Convert heightmap {0}", new object[]
					{
						coord
					});
					tile.convertLegacyHeightmap();
					yield return null;
					UnturnedLog.info("Convert splatmap {0}", new object[]
					{
						coord
					});
					tile.convertLegacySplatmap();
					yield return null;
					for (int i = 0; i < Landscape.SPLATMAP_LAYERS; i++)
					{
						tile.materials[i] = materials[i];
					}
					UnturnedLog.info("Convert prototypes {0}", new object[]
					{
						coord
					});
					tile.updatePrototypes();
					yield return null;
					tile = null;
					num = tile_y;
				}
				num = tile_x;
			}
			new GameObject
			{
				transform = 
				{
					position = Vector3.zero,
					rotation = Quaternion.identity,
					localScale = new Vector3((float)size, Landscape.TILE_HEIGHT, (float)size)
				}
			}.AddComponent<FoliageVolume>().mode = FoliageVolume.EFoliageVolumeMode.ADDITIVE;
			yield break;
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x00011F7E File Offset: 0x0001017E
		public void convertLegacyTerrain(InspectableList<AssetReference<LandscapeMaterialAsset>> materials)
		{
			if (this.hasConverted)
			{
				return;
			}
			this.hasConverted = true;
			base.StartCoroutine(this.convertLegacyTerrainImpl(materials));
		}

		/// <summary>
		/// Nelson 2025-03-10: I want to experiment whether this fixes a strange terrain hole painting bug (public issue
		/// #4851) without potentially introducing crashes for other players. (Per an earlier, undated comment we'd
		/// run into a SetHolesDelayLOD-related crash in 2019 LTS.)
		/// </summary>
		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06000431 RID: 1073 RVA: 0x00011F9E File Offset: 0x0001019E
		internal static bool ShouldUseSetHolesDelayLOD
		{
			get
			{
				return !Landscape.clNoSetHolesDelayLod;
			}
		}

		// Token: 0x040001C4 RID: 452
		public static readonly float TILE_SIZE = 1024f;

		// Token: 0x040001C5 RID: 453
		public static readonly int TILE_SIZE_INT = 1024;

		// Token: 0x040001C6 RID: 454
		public static readonly float TILE_HEIGHT = 2048f;

		// Token: 0x040001C7 RID: 455
		public static readonly int TILE_HEIGHT_INT = 2048;

		// Token: 0x040001C8 RID: 456
		public static readonly int HEIGHTMAP_RESOLUTION = 257;

		// Token: 0x040001C9 RID: 457
		public static readonly int HEIGHTMAP_RESOLUTION_MINUS_ONE = 256;

		// Token: 0x040001CA RID: 458
		public static readonly float HEIGHTMAP_WORLD_UNIT = 4f;

		// Token: 0x040001CB RID: 459
		public static readonly float HALF_HEIGHTMAP_WORLD_UNIT = 2f;

		// Token: 0x040001CC RID: 460
		public static readonly int SPLATMAP_RESOLUTION = 256;

		// Token: 0x040001CD RID: 461
		public static readonly int SPLATMAP_RESOLUTION_MINUS_ONE = 255;

		// Token: 0x040001CE RID: 462
		public static readonly float SPLATMAP_WORLD_UNIT = 4f;

		// Token: 0x040001CF RID: 463
		public static readonly float HALF_SPLATMAP_WORLD_UNIT = 2f;

		// Token: 0x040001D0 RID: 464
		public static readonly int BASEMAP_RESOLUTION = 256;

		// Token: 0x040001D1 RID: 465
		public static readonly int SPLATMAP_COUNT = 2;

		// Token: 0x040001D2 RID: 466
		public static readonly int SPLATMAP_CHANNELS = 4;

		// Token: 0x040001D3 RID: 467
		public static readonly int SPLATMAP_LAYERS = Landscape.SPLATMAP_COUNT * Landscape.SPLATMAP_CHANNELS;

		// Token: 0x040001D4 RID: 468
		public const int HOLES_RESOLUTION = 256;

		// Token: 0x040001D5 RID: 469
		public const float HALF_DIAGONAL_SPLATMAP_WORLD_UNIT = 2.828427f;

		// Token: 0x040001D6 RID: 470
		protected static readonly float[] SPLATMAP_LAYER_BUFFER = new float[Landscape.SPLATMAP_LAYERS];

		// Token: 0x040001D9 RID: 473
		protected static Dictionary<LandscapeCoord, LandscapeTile> tiles = new Dictionary<LandscapeCoord, LandscapeTile>();

		// Token: 0x040001DA RID: 474
		protected static Dictionary<LandscapeCoord, LandscapeHeightmapTransaction> heightmapTransactions = new Dictionary<LandscapeCoord, LandscapeHeightmapTransaction>();

		// Token: 0x040001DB RID: 475
		protected static Dictionary<LandscapeCoord, LandscapeSplatmapTransaction> splatmapTransactions = new Dictionary<LandscapeCoord, LandscapeSplatmapTransaction>();

		// Token: 0x040001DC RID: 476
		protected static Dictionary<LandscapeCoord, LandscapeHoleTransaction> holeTransactions = new Dictionary<LandscapeCoord, LandscapeHoleTransaction>();

		// Token: 0x040001DD RID: 477
		private static bool _disableHoleColliders;

		// Token: 0x040001DE RID: 478
		private static bool _highlightHoles;

		// Token: 0x040001DF RID: 479
		private bool shouldTriggerLandscapeLoaded = true;

		// Token: 0x040001E0 RID: 480
		private bool hasConverted;

		// Token: 0x040001E1 RID: 481
		internal static CommandLineFlag clNoSetHolesDelayLod = new CommandLineFlag(false, "-NoSetHolesDelayLOD");

		// Token: 0x02000901 RID: 2305
		// (Invoke) Token: 0x060050A0 RID: 20640
		public delegate void LandscapeReadHeightmapHandler(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, Vector3 worldPosition, float currentHeight);

		// Token: 0x02000902 RID: 2306
		// (Invoke) Token: 0x060050A4 RID: 20644
		public delegate void LandscapeReadSplatmapHandler(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord, Vector3 worldPosition, float[] currentWeights);

		// Token: 0x02000903 RID: 2307
		// (Invoke) Token: 0x060050A8 RID: 20648
		public delegate float LandscapeWriteHeightmapHandler(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, Vector3 worldPosition, float currentHeight);

		// Token: 0x02000904 RID: 2308
		// (Invoke) Token: 0x060050AC RID: 20652
		public delegate void LandscapeWriteSplatmapHandler(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord, Vector3 worldPosition, float[] currentWeights);

		// Token: 0x02000905 RID: 2309
		// (Invoke) Token: 0x060050B0 RID: 20656
		public delegate bool LandscapeWriteHolesHandler(Vector3 worldPosition, bool currentlyVisible);

		// Token: 0x02000906 RID: 2310
		// (Invoke) Token: 0x060050B4 RID: 20660
		public delegate void LandscapeGetHeightmapVerticesHandler(LandscapeCoord tileCoord, HeightmapCoord heightmapCoord, Vector3 worldPosition);

		// Token: 0x02000907 RID: 2311
		// (Invoke) Token: 0x060050B8 RID: 20664
		public delegate void LandscapeGetSplatmapVerticesHandler(LandscapeCoord tileCoord, SplatmapCoord splatmapCoord, Vector3 worldPosition);
	}
}
