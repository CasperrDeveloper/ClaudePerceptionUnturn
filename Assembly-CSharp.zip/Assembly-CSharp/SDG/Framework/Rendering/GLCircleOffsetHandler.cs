﻿using System;
using UnityEngine;

namespace SDG.Framework.Rendering
{
	// Token: 0x0200008B RID: 139
	// (Invoke) Token: 0x06000375 RID: 885
	public delegate void GLCircleOffsetHandler(ref Vector3 point);
}
