﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Rendering
{
	// Token: 0x0200008A RID: 138
	public class GLRenderer : MonoBehaviour
	{
		// Token: 0x1400000F RID: 15
		// (add) Token: 0x0600036E RID: 878 RVA: 0x0000DAF4 File Offset: 0x0000BCF4
		// (remove) Token: 0x0600036F RID: 879 RVA: 0x0000DB28 File Offset: 0x0000BD28
		public static event GLRenderHandler render;

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000370 RID: 880 RVA: 0x0000DB5C File Offset: 0x0000BD5C
		// (remove) Token: 0x06000371 RID: 881 RVA: 0x0000DB90 File Offset: 0x0000BD90
		public static event GLRenderHandler OnGameRender;

		// Token: 0x06000372 RID: 882 RVA: 0x0000DBC4 File Offset: 0x0000BDC4
		private void OnRenderImage(RenderTexture source, RenderTexture destination)
		{
			Graphics.Blit(source, destination);
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			if (Level.isEditor)
			{
				flag2 = (GLRenderer.render != null);
				if (EditorUI.window == null || !EditorUI.window.isEnabled)
				{
					flag2 = false;
				}
				flag = (flag || flag2);
			}
			else
			{
				flag3 = (GLRenderer.OnGameRender != null);
				if (PlayerUI.window == null || !PlayerUI.window.isEnabled)
				{
					flag3 = false;
				}
				flag = (flag || flag3);
			}
			flag4 = RuntimeGizmos.Get().HasQueuedElements;
			flag = (flag || flag4);
			if (flag)
			{
				RenderTexture.active = destination;
				if (flag2)
				{
					GL.PushMatrix();
					try
					{
						GLRenderer.render();
					}
					catch (Exception e)
					{
						UnturnedLog.exception(e);
					}
					GL.PopMatrix();
				}
				if (flag3)
				{
					GL.PushMatrix();
					try
					{
						GLRenderer.OnGameRender();
					}
					catch (Exception e2)
					{
						UnturnedLog.exception(e2);
					}
					GL.PopMatrix();
				}
				if (flag4)
				{
					GL.PushMatrix();
					try
					{
						RuntimeGizmos.Get().Render();
					}
					catch (Exception e3)
					{
						UnturnedLog.exception(e3);
					}
					GL.PopMatrix();
				}
				RenderTexture.active = null;
			}
		}
	}
}
