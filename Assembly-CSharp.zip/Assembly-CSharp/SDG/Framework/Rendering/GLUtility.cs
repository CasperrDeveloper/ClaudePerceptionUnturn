﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Rendering
{
	// Token: 0x0200008C RID: 140
	public class GLUtility
	{
		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000378 RID: 888 RVA: 0x0000DCDC File Offset: 0x0000BEDC
		public static Material LINE_FLAT_COLOR
		{
			get
			{
				if (GLUtility._LINE_FLAT_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._LINE_FLAT_COLOR = new Material(Shader.Find("GL/LineFlatColor"));
				}
				return GLUtility._LINE_FLAT_COLOR;
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000379 RID: 889 RVA: 0x0000DD0B File Offset: 0x0000BF0B
		public static Material LINE_CHECKERED_COLOR
		{
			get
			{
				if (GLUtility._LINE_CHECKERED_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._LINE_CHECKERED_COLOR = new Material(Shader.Find("GL/LineCheckeredColor"));
				}
				return GLUtility._LINE_CHECKERED_COLOR;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x0600037A RID: 890 RVA: 0x0000DD3A File Offset: 0x0000BF3A
		public static Material LINE_DEPTH_CHECKERED_COLOR
		{
			get
			{
				if (GLUtility._LINE_DEPTH_CHECKERED_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._LINE_DEPTH_CHECKERED_COLOR = new Material(Shader.Find("GL/LineDepthCheckeredColor"));
				}
				return GLUtility._LINE_DEPTH_CHECKERED_COLOR;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600037B RID: 891 RVA: 0x0000DD69 File Offset: 0x0000BF69
		public static Material LINE_CHECKERED_DEPTH_CUTOFF_COLOR
		{
			get
			{
				if (GLUtility._LINE_CHECKERED_DEPTH_CUTOFF_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._LINE_CHECKERED_DEPTH_CUTOFF_COLOR = new Material(Shader.Find("GL/LineCheckeredDepthCutoffColor"));
				}
				return GLUtility._LINE_CHECKERED_DEPTH_CUTOFF_COLOR;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600037C RID: 892 RVA: 0x0000DD98 File Offset: 0x0000BF98
		public static Material LINE_DEPTH_CUTOFF_COLOR
		{
			get
			{
				if (GLUtility._LINE_DEPTH_CUTOFF_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._LINE_DEPTH_CUTOFF_COLOR = new Material(Shader.Find("GL/LineDepthCutoffColor"));
				}
				return GLUtility._LINE_DEPTH_CUTOFF_COLOR;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x0600037D RID: 893 RVA: 0x0000DDC7 File Offset: 0x0000BFC7
		public static Material TRI_FLAT_COLOR
		{
			get
			{
				if (GLUtility._TRI_FLAT_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._TRI_FLAT_COLOR = new Material(Shader.Find("GL/TriFlatColor"));
				}
				return GLUtility._TRI_FLAT_COLOR;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600037E RID: 894 RVA: 0x0000DDF6 File Offset: 0x0000BFF6
		public static Material TRI_CHECKERED_COLOR
		{
			get
			{
				if (GLUtility._TRI_CHECKERED_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._TRI_CHECKERED_COLOR = new Material(Shader.Find("GL/TriCheckeredColor"));
				}
				return GLUtility._TRI_CHECKERED_COLOR;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x0600037F RID: 895 RVA: 0x0000DE25 File Offset: 0x0000C025
		public static Material TRI_DEPTH_CHECKERED_COLOR
		{
			get
			{
				if (GLUtility._TRI_DEPTH_CHECKERED_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._TRI_DEPTH_CHECKERED_COLOR = new Material(Shader.Find("GL/TriDepthCheckeredColor"));
				}
				return GLUtility._TRI_DEPTH_CHECKERED_COLOR;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000380 RID: 896 RVA: 0x0000DE54 File Offset: 0x0000C054
		public static Material TRI_CHECKERED_DEPTH_CUTOFF_COLOR
		{
			get
			{
				if (GLUtility._TRI_CHECKERED_DEPTH_CUTOFF_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._TRI_CHECKERED_DEPTH_CUTOFF_COLOR = new Material(Shader.Find("GL/TriCheckeredDepthCutoffColor"));
				}
				return GLUtility._TRI_CHECKERED_DEPTH_CUTOFF_COLOR;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000381 RID: 897 RVA: 0x0000DE83 File Offset: 0x0000C083
		public static Material TRI_DEPTH_CUTOFF_COLOR
		{
			get
			{
				if (GLUtility._TRI_DEPTH_CUTOFF_COLOR == null && !Dedicator.IsDedicatedServer)
				{
					GLUtility._TRI_DEPTH_CUTOFF_COLOR = new Material(Shader.Find("GL/TriDepthCutoffColor"));
				}
				return GLUtility._TRI_DEPTH_CUTOFF_COLOR;
			}
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000DEB2 File Offset: 0x0000C0B2
		public static void line(Vector3 begin, Vector3 end)
		{
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(begin));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(end));
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0000DED4 File Offset: 0x0000C0D4
		public static void boxSolid(Vector3 center, Vector3 size)
		{
			Vector3 vector = size / 2f;
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, -vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(-vector.x, vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, -vector.y, vector.z)));
			GL.Vertex(GLUtility.matrix.MultiplyPoint3x4(center + new Vector3(vector.x, vector.y, vector.z)));
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000E554 File Offset: 0x0000C754
		public static void circle(Vector3 center, float radius, Vector3 horizontalAxis, Vector3 verticalAxis, float steps = 0f)
		{
			float num = 6.2831855f;
			float num2 = 0f;
			if (steps == 0f)
			{
				steps = Mathf.Clamp(4f * radius, 8f, 128f);
			}
			float num3 = num / steps;
			Vector3 v = GLUtility.matrix.MultiplyPoint3x4(center + horizontalAxis * radius);
			while (num2 < num)
			{
				num2 += num3;
				float f = Mathf.Min(num2, num);
				float d = Mathf.Cos(f) * radius;
				float d2 = Mathf.Sin(f) * radius;
				Vector3 vector = GLUtility.matrix.MultiplyPoint3x4(center + horizontalAxis * d + verticalAxis * d2);
				GL.Vertex(v);
				GL.Vertex(vector);
				v = vector;
			}
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000E604 File Offset: 0x0000C804
		public static void circle(Vector3 center, float radius, Vector3 horizontalAxis, Vector3 verticalAxis, GLCircleOffsetHandler handleGLCircleOffset)
		{
			if (handleGLCircleOffset == null)
			{
				return;
			}
			float num = 6.2831855f;
			float num2 = 0f;
			float num3 = num / Mathf.Clamp(4f * radius, 8f, 128f);
			Vector3 v = GLUtility.matrix.MultiplyPoint3x4(center + horizontalAxis * radius);
			handleGLCircleOffset(ref v);
			while (num2 < num)
			{
				num2 += num3;
				float f = Mathf.Min(num2, num);
				float d = Mathf.Cos(f) * radius;
				float d2 = Mathf.Sin(f) * radius;
				Vector3 vector = GLUtility.matrix.MultiplyPoint3x4(center + horizontalAxis * d + verticalAxis * d2);
				handleGLCircleOffset(ref vector);
				GL.Vertex(v);
				GL.Vertex(vector);
				v = vector;
			}
		}

		// Token: 0x04000185 RID: 389
		protected static Material _LINE_FLAT_COLOR;

		// Token: 0x04000186 RID: 390
		protected static Material _LINE_CHECKERED_COLOR;

		// Token: 0x04000187 RID: 391
		protected static Material _LINE_DEPTH_CHECKERED_COLOR;

		// Token: 0x04000188 RID: 392
		protected static Material _LINE_CHECKERED_DEPTH_CUTOFF_COLOR;

		// Token: 0x04000189 RID: 393
		protected static Material _LINE_DEPTH_CUTOFF_COLOR;

		// Token: 0x0400018A RID: 394
		protected static Material _TRI_FLAT_COLOR;

		// Token: 0x0400018B RID: 395
		protected static Material _TRI_CHECKERED_COLOR;

		// Token: 0x0400018C RID: 396
		protected static Material _TRI_DEPTH_CHECKERED_COLOR;

		// Token: 0x0400018D RID: 397
		protected static Material _TRI_CHECKERED_DEPTH_CUTOFF_COLOR;

		// Token: 0x0400018E RID: 398
		protected static Material _TRI_DEPTH_CUTOFF_COLOR;

		// Token: 0x0400018F RID: 399
		public static Matrix4x4 matrix;
	}
}
