﻿using System;

namespace SDG.Framework.Rendering
{
	// Token: 0x02000089 RID: 137
	// (Invoke) Token: 0x0600036B RID: 875
	public delegate void GLRenderHandler();
}
