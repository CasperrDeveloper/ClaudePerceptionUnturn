﻿using System;
using SDG.Framework.Modules;

namespace SDG.Framework
{
	// Token: 0x02000078 RID: 120
	public class FrameworkNexus : IModuleNexus
	{
		// Token: 0x060002F7 RID: 759 RVA: 0x0000C814 File Offset: 0x0000AA14
		public void initialize()
		{
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x0000C816 File Offset: 0x0000AA16
		public void shutdown()
		{
		}
	}
}
