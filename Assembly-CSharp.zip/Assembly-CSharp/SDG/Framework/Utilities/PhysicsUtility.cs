﻿using System;
using SDG.Framework.Landscapes;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000083 RID: 131
	public class PhysicsUtility
	{
		// Token: 0x0600033A RID: 826 RVA: 0x0000D57F File Offset: 0x0000B77F
		[Obsolete("Hole collision is handled by Unity now")]
		public static bool raycast(Ray ray, out RaycastHit hit, float maxDistance, int layerMask, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.UseGlobal)
		{
			if ((layerMask & 1048576) == 1048576)
			{
				LandscapeHoleUtility.raycastIgnoreLandscapeIfNecessary(ray, maxDistance, ref layerMask);
			}
			return Physics.Raycast(ray, out hit, maxDistance, layerMask, queryTriggerInteraction);
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0000D5A3 File Offset: 0x0000B7A3
		[Obsolete("Hole collision is handled by Unity now")]
		public static RaycastHit[] raycastAll(Ray ray, float maxDistance, int layerMask, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.UseGlobal)
		{
			if ((layerMask & 1048576) == 1048576)
			{
				LandscapeHoleUtility.raycastIgnoreLandscapeIfNecessary(ray, maxDistance, ref layerMask);
			}
			return Physics.RaycastAll(ray, maxDistance, layerMask, queryTriggerInteraction);
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0000D5C5 File Offset: 0x0000B7C5
		[Obsolete("Hole collision is handled by Unity now")]
		public static int sphereCastNonAlloc(Ray ray, float radius, RaycastHit[] results, float maxDistance, int layerMask, QueryTriggerInteraction queryTriggerInteraction = QueryTriggerInteraction.UseGlobal)
		{
			if ((layerMask & 1048576) == 1048576)
			{
				LandscapeHoleUtility.spherecastIgnoreLandscapeIfNecessary(ray, radius, maxDistance, ref layerMask);
			}
			return Physics.SphereCastNonAlloc(ray, radius, results, maxDistance, layerMask, queryTriggerInteraction);
		}
	}
}
