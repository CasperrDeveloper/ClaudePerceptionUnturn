﻿using System;
using System.Collections;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000088 RID: 136
	public class TimeUtility : MonoBehaviour
	{
		/// <summary>
		/// Equivalent to MonoBehaviour.Update
		/// </summary>
		// Token: 0x1400000D RID: 13
		// (add) Token: 0x0600035E RID: 862 RVA: 0x0000D998 File Offset: 0x0000BB98
		// (remove) Token: 0x0600035F RID: 863 RVA: 0x0000D9CC File Offset: 0x0000BBCC
		public static event UpdateHandler updated;

		/// <summary>
		/// Equivalent to MonoBehaviour.FixedUpdate
		/// </summary>
		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000360 RID: 864 RVA: 0x0000DA00 File Offset: 0x0000BC00
		// (remove) Token: 0x06000361 RID: 865 RVA: 0x0000DA34 File Offset: 0x0000BC34
		public static event UpdateHandler physicsUpdated;

		/// <summary>
		/// Useful when caller is not a MonoBehaviour, or coroutine should not be owned by a component which might get
		/// deactivated. For example attached effects destroy timer should happen regardless of parent deactivation.
		/// </summary>
		// Token: 0x06000362 RID: 866 RVA: 0x0000DA67 File Offset: 0x0000BC67
		public static Coroutine InvokeAfterDelay(Action callback, float timeSeconds)
		{
			return TimeUtility.singleton.StartCoroutine(TimeUtility.singleton.InternalInvokeAfterDelay(callback, timeSeconds));
		}

		/// <summary>
		/// Stop a coroutine started by InvokeAfterDelay.
		/// </summary>
		// Token: 0x06000363 RID: 867 RVA: 0x0000DA7F File Offset: 0x0000BC7F
		public static void StaticStopCoroutine(Coroutine routine)
		{
			if (TimeUtility.singleton != null)
			{
				TimeUtility.singleton.StopCoroutine(routine);
			}
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0000DA99 File Offset: 0x0000BC99
		protected virtual void triggerUpdated()
		{
			UpdateHandler updateHandler = TimeUtility.updated;
			if (updateHandler == null)
			{
				return;
			}
			updateHandler();
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0000DAAA File Offset: 0x0000BCAA
		protected virtual void Update()
		{
			UpdateHandler updateHandler = TimeUtility.updated;
			if (updateHandler == null)
			{
				return;
			}
			updateHandler();
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0000DABB File Offset: 0x0000BCBB
		protected virtual void FixedUpdate()
		{
			UpdateHandler updateHandler = TimeUtility.physicsUpdated;
			if (updateHandler == null)
			{
				return;
			}
			updateHandler();
		}

		// Token: 0x06000367 RID: 871 RVA: 0x0000DACC File Offset: 0x0000BCCC
		private IEnumerator InternalInvokeAfterDelay(Action callback, float timeSeconds)
		{
			yield return new WaitForSeconds(timeSeconds);
			callback();
			yield break;
		}

		// Token: 0x06000368 RID: 872 RVA: 0x0000DAE2 File Offset: 0x0000BCE2
		private void Awake()
		{
			TimeUtility.singleton = this;
		}

		// Token: 0x04000182 RID: 386
		private static TimeUtility singleton;
	}
}
