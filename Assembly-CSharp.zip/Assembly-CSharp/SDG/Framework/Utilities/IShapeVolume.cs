﻿using System;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x0200007F RID: 127
	public interface IShapeVolume
	{
		// Token: 0x06000329 RID: 809
		bool containsPoint(Vector3 point);

		/// <summary>
		/// Not necessarily cheap to calculate - probably best to cache.
		/// </summary>
		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600032A RID: 810
		Bounds worldBounds { get; }

		/// <summary>
		/// Internal cubic meter volume.
		/// </summary>
		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600032B RID: 811
		float internalVolume { get; }

		/// <summary>
		/// Surface square meters area.
		/// </summary>
		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600032C RID: 812
		float surfaceArea { get; }
	}
}
