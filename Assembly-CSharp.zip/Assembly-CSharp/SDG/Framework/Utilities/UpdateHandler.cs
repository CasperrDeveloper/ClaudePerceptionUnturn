﻿using System;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000087 RID: 135
	// (Invoke) Token: 0x0600035B RID: 859
	public delegate void UpdateHandler();
}
