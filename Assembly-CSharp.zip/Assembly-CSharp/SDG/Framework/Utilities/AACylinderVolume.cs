﻿using System;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x0200007D RID: 125
	public struct AACylinderVolume : IShapeVolume
	{
		// Token: 0x06000322 RID: 802 RVA: 0x0000D114 File Offset: 0x0000B314
		public bool containsPoint(Vector3 point)
		{
			float num = this.height / 2f;
			if (point.y > this.center.y - num && point.y < this.center.y + num)
			{
				float num2 = this.radius * this.radius;
				return (new Vector2(point.x, point.z) - new Vector2(this.center.x, this.center.z)).sqrMagnitude < num2;
			}
			return false;
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000323 RID: 803 RVA: 0x0000D1A4 File Offset: 0x0000B3A4
		public Bounds worldBounds
		{
			get
			{
				float num = this.radius * 2f;
				return new Bounds(this.center, new Vector3(num, this.height, num));
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000324 RID: 804 RVA: 0x0000D1D6 File Offset: 0x0000B3D6
		public float internalVolume
		{
			get
			{
				return this.height * 3.1415927f * this.radius * this.radius;
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000325 RID: 805 RVA: 0x0000D1F2 File Offset: 0x0000B3F2
		public float surfaceArea
		{
			get
			{
				return 3.1415927f * this.radius * this.radius;
			}
		}

		// Token: 0x06000326 RID: 806 RVA: 0x0000D207 File Offset: 0x0000B407
		public AACylinderVolume(Vector3 newCenter, float newRadius, float newHeight)
		{
			this.center = newCenter;
			this.radius = newRadius;
			this.height = newHeight;
		}

		// Token: 0x04000174 RID: 372
		public Vector3 center;

		// Token: 0x04000175 RID: 373
		public float radius;

		// Token: 0x04000176 RID: 374
		public float height;
	}
}
