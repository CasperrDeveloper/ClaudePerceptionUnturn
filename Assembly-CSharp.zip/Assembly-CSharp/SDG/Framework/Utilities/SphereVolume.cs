﻿using System;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000086 RID: 134
	public struct SphereVolume : IShapeVolume
	{
		// Token: 0x06000355 RID: 853 RVA: 0x0000D890 File Offset: 0x0000BA90
		public bool containsPoint(Vector3 point)
		{
			if (Mathf.Abs(point.x - this.center.x) >= this.radius)
			{
				return false;
			}
			if (Mathf.Abs(point.y - this.center.y) >= this.radius)
			{
				return false;
			}
			if (Mathf.Abs(point.z - this.center.z) >= this.radius)
			{
				return false;
			}
			float num = this.radius * this.radius;
			return (point - this.center).sqrMagnitude < num;
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000356 RID: 854 RVA: 0x0000D928 File Offset: 0x0000BB28
		public Bounds worldBounds
		{
			get
			{
				float num = this.radius * 2f;
				return new Bounds(this.center, new Vector3(num, num, num));
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000357 RID: 855 RVA: 0x0000D955 File Offset: 0x0000BB55
		public float internalVolume
		{
			get
			{
				return 4.1887903f * this.radius * this.radius * this.radius;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000358 RID: 856 RVA: 0x0000D971 File Offset: 0x0000BB71
		public float surfaceArea
		{
			get
			{
				return 12.566371f * this.radius * this.radius;
			}
		}

		// Token: 0x06000359 RID: 857 RVA: 0x0000D986 File Offset: 0x0000BB86
		public SphereVolume(Vector3 newCenter, float newRadius)
		{
			this.center = newCenter;
			this.radius = newRadius;
		}

		// Token: 0x0400017E RID: 382
		public Vector3 center;

		// Token: 0x0400017F RID: 383
		public float radius;
	}
}
