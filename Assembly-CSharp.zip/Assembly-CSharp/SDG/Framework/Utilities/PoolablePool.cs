﻿using System;

namespace SDG.Framework.Utilities
{
	/// <summary>
	/// Pool of objects that implement the IPoolable interface.
	///
	/// Useful for types that do not need special construction,
	/// and want notification when claimed and released.
	/// </summary>
	// Token: 0x02000085 RID: 133
	public static class PoolablePool<T> where T : IPoolable
	{
		// Token: 0x0600034E RID: 846 RVA: 0x0000D7FB File Offset: 0x0000B9FB
		public static void empty()
		{
			PoolablePool<T>.pool.empty();
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0000D807 File Offset: 0x0000BA07
		public static void warmup(uint count)
		{
			PoolablePool<T>.pool.warmup(count, new Pool<T>.PoolClaimHandler(PoolablePool<T>.handlePoolClaim));
		}

		// Token: 0x06000350 RID: 848 RVA: 0x0000D820 File Offset: 0x0000BA20
		public static T claim()
		{
			T result = PoolablePool<T>.pool.claim(new Pool<T>.PoolClaimHandler(PoolablePool<T>.handlePoolClaim));
			result.poolClaim();
			return result;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0000D852 File Offset: 0x0000BA52
		public static void release(T poolable)
		{
			PoolablePool<T>.pool.release(poolable, new Pool<T>.PoolReleasedHandler(PoolablePool<T>.handlePoolRelease));
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0000D86B File Offset: 0x0000BA6B
		private static T handlePoolClaim(Pool<T> pool)
		{
			return Activator.CreateInstance<T>();
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0000D872 File Offset: 0x0000BA72
		private static void handlePoolRelease(Pool<T> pool, T poolable)
		{
			poolable.poolRelease();
		}

		// Token: 0x0400017D RID: 381
		private static Pool<T> pool = new Pool<T>();
	}
}
