﻿using System;

namespace SDG.Framework.Utilities
{
	/// <summary>
	/// For use with PoolablePool when no special construction is required.
	/// </summary>
	// Token: 0x0200007E RID: 126
	public interface IPoolable
	{
		/// <summary>
		/// Called when this instance is getting claimed.
		/// </summary>
		// Token: 0x06000327 RID: 807
		void poolClaim();

		/// <summary>
		/// Called when this instance is returned to the pool.
		/// </summary>
		// Token: 0x06000328 RID: 808
		void poolRelease();
	}
}
