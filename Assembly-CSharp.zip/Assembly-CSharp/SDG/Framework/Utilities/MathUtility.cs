﻿using System;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000081 RID: 129
	public class MathUtility
	{
		// Token: 0x06000334 RID: 820 RVA: 0x0000D28F File Offset: 0x0000B48F
		public static void getPitchYawFromDirection(Vector3 direction, out float pitch, out float yaw)
		{
			pitch = 57.29578f * -Mathf.Sin(direction.y / direction.magnitude);
			yaw = 57.29578f * -Mathf.Atan2(direction.z, direction.x) + 90f;
		}

		// Token: 0x04000178 RID: 376
		public static readonly Quaternion IDENTITY_QUATERNION = Quaternion.identity;

		// Token: 0x04000179 RID: 377
		public static readonly Matrix4x4 IDENTITY_MATRIX = Matrix4x4.identity;
	}
}
