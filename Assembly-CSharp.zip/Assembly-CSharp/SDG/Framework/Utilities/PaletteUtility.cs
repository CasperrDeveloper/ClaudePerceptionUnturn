﻿using System;
using System.Globalization;
using UnityEngine;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000082 RID: 130
	public static class PaletteUtility
	{
		// Token: 0x06000337 RID: 823 RVA: 0x0000D2EC File Offset: 0x0000B4EC
		public static string toRGB(Color color)
		{
			Color32 color2 = color;
			return "#" + color2.r.ToString("X2") + color2.g.ToString("X2") + color2.b.ToString("X2");
		}

		// Token: 0x06000338 RID: 824 RVA: 0x0000D340 File Offset: 0x0000B540
		public static string toRGBA(Color color)
		{
			Color32 color2 = color;
			return string.Concat(new string[]
			{
				"#",
				color2.r.ToString("X2"),
				color2.g.ToString("X2"),
				color2.b.ToString("X2"),
				color2.a.ToString("X2")
			});
		}

		// Token: 0x06000339 RID: 825 RVA: 0x0000D3B8 File Offset: 0x0000B5B8
		public static bool tryParse(string value, out Color color)
		{
			color = Color.white;
			if (!string.IsNullOrEmpty(value))
			{
				switch (value.Length)
				{
				case 6:
				{
					uint num;
					if (uint.TryParse(value, NumberStyles.HexNumber, CultureInfo.CurrentCulture, out num))
					{
						color.r = (float)((byte)(num >> 16 & 255U));
						color.g = (float)((byte)(num >> 8 & 255U));
						color.b = (float)((byte)(num & 255U));
						color.a = 255f;
						return true;
					}
					break;
				}
				case 7:
				{
					uint num;
					if (uint.TryParse(value.Substring(1, value.Length - 1), NumberStyles.HexNumber, CultureInfo.CurrentCulture, out num))
					{
						color.r = (float)((byte)(num >> 16 & 255U));
						color.g = (float)((byte)(num >> 8 & 255U));
						color.b = (float)((byte)(num & 255U));
						color.a = 255f;
						return true;
					}
					break;
				}
				case 8:
				{
					uint num;
					if (uint.TryParse(value, NumberStyles.HexNumber, CultureInfo.CurrentCulture, out num))
					{
						color.r = (float)((byte)(num >> 24 & 255U));
						color.g = (float)((byte)(num >> 16 & 255U));
						color.b = (float)((byte)(num >> 8 & 255U));
						color.a = (float)((byte)(num & 255U));
						return true;
					}
					break;
				}
				case 9:
				{
					uint num;
					if (uint.TryParse(value.Substring(1, value.Length - 1), NumberStyles.HexNumber, CultureInfo.CurrentCulture, out num))
					{
						color.r = (float)((byte)(num >> 24 & 255U));
						color.g = (float)((byte)(num >> 16 & 255U));
						color.b = (float)((byte)(num >> 8 & 255U));
						color.a = (float)((byte)(num & 255U));
						return true;
					}
					break;
				}
				}
			}
			return false;
		}
	}
}
