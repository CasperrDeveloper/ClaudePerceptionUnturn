﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000084 RID: 132
	public class Pool<T>
	{
		// Token: 0x1400000B RID: 11
		// (add) Token: 0x0600033E RID: 830 RVA: 0x0000D5F8 File Offset: 0x0000B7F8
		// (remove) Token: 0x0600033F RID: 831 RVA: 0x0000D630 File Offset: 0x0000B830
		public event Pool<T>.PoolClaimedHandler claimed;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000340 RID: 832 RVA: 0x0000D668 File Offset: 0x0000B868
		// (remove) Token: 0x06000341 RID: 833 RVA: 0x0000D6A0 File Offset: 0x0000B8A0
		public event Pool<T>.PoolReleasedHandler released;

		/// <summary>
		/// Number of items in underlying queue.
		/// </summary>
		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000342 RID: 834 RVA: 0x0000D6D5 File Offset: 0x0000B8D5
		public int count
		{
			get
			{
				return this.pool.Count;
			}
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0000D6E2 File Offset: 0x0000B8E2
		public void empty()
		{
			this.pool.Clear();
		}

		// Token: 0x06000344 RID: 836 RVA: 0x0000D6EF File Offset: 0x0000B8EF
		public void warmup(uint count)
		{
			this.warmup(count, null);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x0000D6FC File Offset: 0x0000B8FC
		public void warmup(uint count, Pool<T>.PoolClaimHandler callback)
		{
			if (callback == null)
			{
				callback = new Pool<T>.PoolClaimHandler(this.handleClaim);
			}
			for (uint num = 0U; num < count; num += 1U)
			{
				T item = callback(this);
				this.release(item);
			}
		}

		// Token: 0x06000346 RID: 838 RVA: 0x0000D735 File Offset: 0x0000B935
		public T claim()
		{
			return this.claim(null);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0000D740 File Offset: 0x0000B940
		public T claim(Pool<T>.PoolClaimHandler callback)
		{
			T t;
			if (this.pool.Count > 0)
			{
				t = this.pool.Dequeue();
			}
			else if (callback != null)
			{
				t = callback(this);
			}
			else
			{
				t = this.handleClaim(this);
			}
			this.triggerClaimed(t);
			return t;
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0000D786 File Offset: 0x0000B986
		public void release(T item)
		{
			this.release(item, null);
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0000D790 File Offset: 0x0000B990
		public void release(T item, Pool<T>.PoolReleasedHandler callback)
		{
			if (item == null)
			{
				return;
			}
			if (callback != null)
			{
				callback(this, item);
			}
			this.triggerReleased(item);
			this.pool.Enqueue(item);
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0000D7B9 File Offset: 0x0000B9B9
		protected T handleClaim(Pool<T> pool)
		{
			return Activator.CreateInstance<T>();
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0000D7C0 File Offset: 0x0000B9C0
		protected void triggerClaimed(T item)
		{
			Pool<T>.PoolClaimedHandler poolClaimedHandler = this.claimed;
			if (poolClaimedHandler == null)
			{
				return;
			}
			poolClaimedHandler(this, item);
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0000D7D4 File Offset: 0x0000B9D4
		protected void triggerReleased(T item)
		{
			Pool<T>.PoolReleasedHandler poolReleasedHandler = this.released;
			if (poolReleasedHandler == null)
			{
				return;
			}
			poolReleasedHandler(this, item);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0000D7E8 File Offset: 0x0000B9E8
		public Pool()
		{
			this.pool = new Queue<T>();
		}

		// Token: 0x0400017C RID: 380
		protected Queue<T> pool;

		// Token: 0x020008FB RID: 2299
		// (Invoke) Token: 0x06005089 RID: 20617
		public delegate T PoolClaimHandler(Pool<T> pool);

		// Token: 0x020008FC RID: 2300
		// (Invoke) Token: 0x0600508D RID: 20621
		public delegate void PoolReleaseHandler(Pool<T> pool, T item);

		// Token: 0x020008FD RID: 2301
		// (Invoke) Token: 0x06005091 RID: 20625
		public delegate void PoolClaimedHandler(Pool<T> pool, T item);

		// Token: 0x020008FE RID: 2302
		// (Invoke) Token: 0x06005095 RID: 20629
		public delegate void PoolReleasedHandler(Pool<T> pool, T item);
	}
}
