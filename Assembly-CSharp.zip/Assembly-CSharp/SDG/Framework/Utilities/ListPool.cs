﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Utilities
{
	// Token: 0x02000080 RID: 128
	public static class ListPool<T>
	{
		// Token: 0x0600032D RID: 813 RVA: 0x0000D21E File Offset: 0x0000B41E
		public static void empty()
		{
			ListPool<T>.pool.empty();
		}

		// Token: 0x0600032E RID: 814 RVA: 0x0000D22A File Offset: 0x0000B42A
		public static void warmup(uint count)
		{
			ListPool<T>.pool.warmup(count, new Pool<List<T>>.PoolClaimHandler(ListPool<T>.handlePoolClaim));
		}

		// Token: 0x0600032F RID: 815 RVA: 0x0000D243 File Offset: 0x0000B443
		public static List<T> claim()
		{
			return ListPool<T>.pool.claim(new Pool<List<T>>.PoolClaimHandler(ListPool<T>.handlePoolClaim));
		}

		// Token: 0x06000330 RID: 816 RVA: 0x0000D25B File Offset: 0x0000B45B
		public static void release(List<T> list)
		{
			ListPool<T>.pool.release(list, new Pool<List<T>>.PoolReleasedHandler(ListPool<T>.handlePoolRelease));
		}

		// Token: 0x06000331 RID: 817 RVA: 0x0000D274 File Offset: 0x0000B474
		private static List<T> handlePoolClaim(Pool<List<T>> pool)
		{
			return new List<T>();
		}

		// Token: 0x06000332 RID: 818 RVA: 0x0000D27B File Offset: 0x0000B47B
		private static void handlePoolRelease(Pool<List<T>> pool, List<T> list)
		{
			list.Clear();
		}

		// Token: 0x04000177 RID: 375
		private static Pool<List<T>> pool = new Pool<List<T>>();
	}
}
