﻿using System;
using System.IO;

namespace SDG.Framework.IO.Deserialization
{
	// Token: 0x020000E6 RID: 230
	public interface IDeserializer
	{
		// Token: 0x060005C2 RID: 1474
		T deserialize<T>(byte[] data, int offset);

		// Token: 0x060005C3 RID: 1475
		T deserialize<T>(MemoryStream memoryStream);

		// Token: 0x060005C4 RID: 1476
		T deserialize<T>(string path);
	}
}
