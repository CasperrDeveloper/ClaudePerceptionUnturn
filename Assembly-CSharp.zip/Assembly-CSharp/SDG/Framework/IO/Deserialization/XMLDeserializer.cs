﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace SDG.Framework.IO.Deserialization
{
	// Token: 0x020000E8 RID: 232
	public class XMLDeserializer : IDeserializer
	{
		// Token: 0x060005C9 RID: 1481 RVA: 0x00016C90 File Offset: 0x00014E90
		public T deserialize<T>(byte[] data, int offset)
		{
			MemoryStream memoryStream = new MemoryStream(data, offset, data.Length - offset);
			T result = this.deserialize<T>(memoryStream);
			memoryStream.Close();
			memoryStream.Dispose();
			return result;
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x00016CBD File Offset: 0x00014EBD
		public T deserialize<T>(MemoryStream memoryStream)
		{
			return (T)((object)new XmlSerializer(typeof(T)).Deserialize(memoryStream));
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00016CDC File Offset: 0x00014EDC
		public T deserialize<T>(string path)
		{
			T result = default(T);
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
			StreamReader streamReader = new StreamReader(path);
			try
			{
				result = (T)((object)xmlSerializer.Deserialize(streamReader));
			}
			finally
			{
				streamReader.Close();
				streamReader.Dispose();
			}
			return result;
		}
	}
}
