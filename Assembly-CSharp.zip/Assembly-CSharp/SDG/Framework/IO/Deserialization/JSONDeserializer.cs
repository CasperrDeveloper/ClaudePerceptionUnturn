﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace SDG.Framework.IO.Deserialization
{
	// Token: 0x020000E7 RID: 231
	public class JSONDeserializer : IDeserializer
	{
		// Token: 0x060005C5 RID: 1477 RVA: 0x00016BA8 File Offset: 0x00014DA8
		public T deserialize<T>(byte[] data, int offset)
		{
			MemoryStream memoryStream = new MemoryStream(data, offset, data.Length - offset);
			T result = this.deserialize<T>(memoryStream);
			memoryStream.Close();
			memoryStream.Dispose();
			return result;
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x00016BD8 File Offset: 0x00014DD8
		public T deserialize<T>(MemoryStream memoryStream)
		{
			T result = default(T);
			StreamReader streamReader = new StreamReader(memoryStream);
			JsonReader jsonReader = new JsonTextReader(streamReader);
			JsonSerializer jsonSerializer = new JsonSerializer();
			try
			{
				result = jsonSerializer.Deserialize<T>(jsonReader);
			}
			finally
			{
				jsonReader.Close();
				streamReader.Close();
				streamReader.Dispose();
			}
			return result;
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x00016C30 File Offset: 0x00014E30
		public T deserialize<T>(string path)
		{
			T result = default(T);
			StreamReader streamReader = new StreamReader(path);
			JsonReader jsonReader = new JsonTextReader(streamReader);
			JsonSerializer jsonSerializer = new JsonSerializer();
			try
			{
				result = jsonSerializer.Deserialize<T>(jsonReader);
			}
			finally
			{
				jsonReader.Close();
				streamReader.Close();
				streamReader.Dispose();
			}
			return result;
		}
	}
}
