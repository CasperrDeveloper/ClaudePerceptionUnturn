﻿using System;
using System.IO;

namespace SDG.Framework.IO.Streams
{
	// Token: 0x020000B3 RID: 179
	public class NetworkStream
	{
		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060004C4 RID: 1220 RVA: 0x00014A6B File Offset: 0x00012C6B
		// (set) Token: 0x060004C5 RID: 1221 RVA: 0x00014A73 File Offset: 0x00012C73
		private Stream stream { get; set; }

		// Token: 0x060004C6 RID: 1222 RVA: 0x00014A7C File Offset: 0x00012C7C
		public sbyte readSByte()
		{
			return (sbyte)this.stream.ReadByte();
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x00014A8A File Offset: 0x00012C8A
		public byte readByte()
		{
			return (byte)this.stream.ReadByte();
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x00014A98 File Offset: 0x00012C98
		public short readInt16()
		{
			byte b = this.readByte();
			byte b2 = this.readByte();
			return (short)(b << 8 | b2);
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x00014AB8 File Offset: 0x00012CB8
		public ushort readUInt16()
		{
			byte b = this.readByte();
			byte b2 = this.readByte();
			return (ushort)(b << 8 | b2);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x00014AD8 File Offset: 0x00012CD8
		public int readInt32()
		{
			int num = (int)this.readByte();
			byte b = this.readByte();
			byte b2 = this.readByte();
			byte b3 = this.readByte();
			return num << 24 | (int)b << 16 | (int)b2 << 8 | (int)b3;
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x00014B10 File Offset: 0x00012D10
		public uint readUInt32()
		{
			uint num = (uint)this.readByte();
			byte b = this.readByte();
			byte b2 = this.readByte();
			byte b3 = this.readByte();
			return num << 24 | (uint)((uint)b << 16) | (uint)((uint)b2 << 8) | (uint)b3;
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00014B48 File Offset: 0x00012D48
		public long readInt64()
		{
			int num = (int)this.readByte();
			byte b = this.readByte();
			byte b2 = this.readByte();
			byte b3 = this.readByte();
			byte b4 = this.readByte();
			byte b5 = this.readByte();
			byte b6 = this.readByte();
			byte b7 = this.readByte();
			return (long)(num << 24 | (int)b << 16 | (int)b2 << 8 | (int)b3 | (int)b4 << 24 | (int)b5 << 16 | (int)b6 << 8 | (int)b7);
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x00014BB4 File Offset: 0x00012DB4
		public ulong readUInt64()
		{
			int num = (int)this.readByte();
			byte b = this.readByte();
			byte b2 = this.readByte();
			byte b3 = this.readByte();
			byte b4 = this.readByte();
			byte b5 = this.readByte();
			byte b6 = this.readByte();
			byte b7 = this.readByte();
			return (ulong)((long)(num << 24 | (int)b << 16 | (int)b2 << 8 | (int)b3 | (int)b4 << 24 | (int)b5 << 16 | (int)b6 << 8 | (int)b7));
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x00014C1D File Offset: 0x00012E1D
		public char readChar()
		{
			return (char)this.readUInt16();
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x00014C28 File Offset: 0x00012E28
		public string readString()
		{
			ushort num = this.readUInt16();
			char[] array = new char[(int)num];
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				char c = this.readChar();
				array[(int)num2] = c;
			}
			return new string(array);
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00014C61 File Offset: 0x00012E61
		public void readBytes(byte[] data, ulong offset, ulong length)
		{
			this.stream.Read(data, (int)offset, (int)length);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00014C74 File Offset: 0x00012E74
		public void writeSByte(sbyte data)
		{
			this.stream.WriteByte((byte)data);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00014C83 File Offset: 0x00012E83
		public void writeByte(byte data)
		{
			this.stream.WriteByte(data);
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x00014C91 File Offset: 0x00012E91
		public void writeInt16(short data)
		{
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x00014CA5 File Offset: 0x00012EA5
		public void writeUInt16(ushort data)
		{
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x00014CB9 File Offset: 0x00012EB9
		public void writeInt32(int data)
		{
			this.writeByte((byte)(data >> 24));
			this.writeByte((byte)(data >> 16));
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00014CE3 File Offset: 0x00012EE3
		public void writeUInt32(uint data)
		{
			this.writeByte((byte)(data >> 24));
			this.writeByte((byte)(data >> 16));
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00014D10 File Offset: 0x00012F10
		public void writeInt64(long data)
		{
			this.writeByte((byte)(data >> 56));
			this.writeByte((byte)(data >> 48));
			this.writeByte((byte)(data >> 40));
			this.writeByte((byte)(data >> 32));
			this.writeByte((byte)(data >> 24));
			this.writeByte((byte)(data >> 16));
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x00014D74 File Offset: 0x00012F74
		public void writeUInt64(ulong data)
		{
			this.writeByte((byte)(data >> 56));
			this.writeByte((byte)(data >> 48));
			this.writeByte((byte)(data >> 40));
			this.writeByte((byte)(data >> 32));
			this.writeByte((byte)(data >> 24));
			this.writeByte((byte)(data >> 16));
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x00014DD5 File Offset: 0x00012FD5
		public void writeChar(char data)
		{
			this.writeUInt16((ushort)data);
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x00014DE0 File Offset: 0x00012FE0
		public void writeString(string data)
		{
			ushort num = (ushort)data.Length;
			char[] array = data.ToCharArray();
			this.writeUInt16(num);
			for (ushort num2 = 0; num2 < num; num2 += 1)
			{
				char data2 = array[(int)num2];
				this.writeChar(data2);
			}
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x00014E1B File Offset: 0x0001301B
		public void writeBytes(byte[] data, ulong offset, ulong length)
		{
			this.stream.Write(data, (int)offset, (int)length);
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x00014E2D File Offset: 0x0001302D
		public NetworkStream(Stream newStream)
		{
			this.stream = newStream;
		}
	}
}
