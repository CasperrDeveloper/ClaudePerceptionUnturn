﻿using System;

namespace SDG.Framework.IO.Streams
{
	// Token: 0x020000B2 RID: 178
	public interface INetworkStreamable
	{
		// Token: 0x060004C2 RID: 1218
		void readFromStream(NetworkStream networkStream);

		// Token: 0x060004C3 RID: 1219
		void writeToStream(NetworkStream networkStream);
	}
}
