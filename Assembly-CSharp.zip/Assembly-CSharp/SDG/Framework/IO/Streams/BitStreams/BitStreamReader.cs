﻿using System;
using System.IO;

namespace SDG.Framework.IO.Streams.BitStreams
{
	// Token: 0x020000B4 RID: 180
	public class BitStreamReader
	{
		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x00014E3C File Offset: 0x0001303C
		// (set) Token: 0x060004DE RID: 1246 RVA: 0x00014E44 File Offset: 0x00013044
		public Stream stream { get; protected set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060004DF RID: 1247 RVA: 0x00014E4D File Offset: 0x0001304D
		// (set) Token: 0x060004E0 RID: 1248 RVA: 0x00014E55 File Offset: 0x00013055
		private byte buffer { get; set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060004E1 RID: 1249 RVA: 0x00014E5E File Offset: 0x0001305E
		// (set) Token: 0x060004E2 RID: 1250 RVA: 0x00014E66 File Offset: 0x00013066
		private byte bitIndex { get; set; }

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060004E3 RID: 1251 RVA: 0x00014E6F File Offset: 0x0001306F
		// (set) Token: 0x060004E4 RID: 1252 RVA: 0x00014E77 File Offset: 0x00013077
		private byte bitsAvailable { get; set; }

		// Token: 0x060004E5 RID: 1253 RVA: 0x00014E80 File Offset: 0x00013080
		public void readBit(ref byte data)
		{
			this.readBits(ref data, 1);
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00014E8C File Offset: 0x0001308C
		public void readBits(ref byte data, byte length)
		{
			if (this.bitIndex == 8 && this.bitsAvailable == 0)
			{
				this.fillBuffer();
			}
			if (length > this.bitsAvailable)
			{
				byte b = length - this.bitsAvailable;
				this.readBits(ref data, this.bitsAvailable);
				data = (byte)(data << (int)b);
				this.readBits(ref data, b);
				return;
			}
			byte b2 = 8 - length - this.bitIndex;
			byte b3 = (byte)(255 >> (int)(8 - length));
			data |= (byte)(this.buffer >> (int)b2 & (int)b3);
			this.bitIndex += length;
			this.bitsAvailable -= length;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00014F2F File Offset: 0x0001312F
		private void fillBuffer()
		{
			this.buffer = (byte)this.stream.ReadByte();
			this.bitIndex = 0;
			this.bitsAvailable = 8;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00014F51 File Offset: 0x00013151
		public void reset()
		{
			this.buffer = 0;
			this.bitIndex = 8;
			this.bitsAvailable = 0;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x00014F68 File Offset: 0x00013168
		public BitStreamReader(Stream newStream)
		{
			this.stream = newStream;
			this.reset();
		}
	}
}
