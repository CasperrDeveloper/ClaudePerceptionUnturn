﻿using System;
using System.IO;

namespace SDG.Framework.IO.Streams.BitStreams
{
	// Token: 0x020000B7 RID: 183
	public class PrimitiveBitStreamWriter : BitStreamWriter
	{
		// Token: 0x06000500 RID: 1280 RVA: 0x00015377 File Offset: 0x00013577
		public void writeByte(byte data)
		{
			base.writeBits(data, 8);
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x00015381 File Offset: 0x00013581
		public void writeInt16(short data)
		{
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x00015395 File Offset: 0x00013595
		public void writeInt16(short data, byte length)
		{
			if (length == 16)
			{
				this.writeInt16(data);
				return;
			}
			if (length > 8)
			{
				base.writeBits((byte)(data >> 8), length - 8);
				this.writeByte((byte)data);
				return;
			}
			if (length == 8)
			{
				this.writeByte((byte)data);
				return;
			}
			base.writeBits((byte)data, length);
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x000153D5 File Offset: 0x000135D5
		public void writeUInt16(ushort data)
		{
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x000153E9 File Offset: 0x000135E9
		public void writeUInt16(ushort data, byte length)
		{
			if (length == 16)
			{
				this.writeUInt16(data);
				return;
			}
			if (length > 8)
			{
				base.writeBits((byte)(data >> 8), length - 8);
				this.writeByte((byte)data);
				return;
			}
			if (length == 8)
			{
				this.writeByte((byte)data);
				return;
			}
			base.writeBits((byte)data, length);
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x00015429 File Offset: 0x00013629
		public void writeInt32(int data)
		{
			this.writeByte((byte)(data >> 24));
			this.writeByte((byte)(data >> 16));
			this.writeByte((byte)(data >> 8));
			this.writeByte((byte)data);
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00015454 File Offset: 0x00013654
		public void writeInt32(int data, byte length)
		{
			if (length == 32)
			{
				this.writeInt32(data);
				return;
			}
			if (length > 24)
			{
				base.writeBits((byte)(data >> 24), length - 8);
				this.writeByte((byte)(data >> 16));
				this.writeByte((byte)(data >> 8));
				this.writeByte((byte)data);
				return;
			}
			if (length == 24)
			{
				this.writeByte((byte)(data >> 16));
				this.writeByte((byte)(data >> 8));
				this.writeByte((byte)data);
				return;
			}
			if (length > 16)
			{
				base.writeBits((byte)(data >> 16), length - 8);
				this.writeByte((byte)(data >> 8));
				this.writeByte((byte)data);
				return;
			}
			if (length == 16)
			{
				this.writeByte((byte)(data >> 8));
				this.writeByte((byte)data);
				return;
			}
			if (length > 8)
			{
				base.writeBits((byte)(data >> 8), length - 8);
				this.writeByte((byte)data);
				return;
			}
			if (length == 8)
			{
				this.writeByte((byte)data);
				return;
			}
			base.writeBits((byte)data, length);
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00015533 File Offset: 0x00013733
		public PrimitiveBitStreamWriter(Stream newStream) : base(newStream)
		{
		}
	}
}
