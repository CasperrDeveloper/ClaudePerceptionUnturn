﻿using System;
using System.IO;

namespace SDG.Framework.IO.Streams.BitStreams
{
	// Token: 0x020000B5 RID: 181
	public class BitStreamWriter
	{
		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060004EA RID: 1258 RVA: 0x00014F7D File Offset: 0x0001317D
		// (set) Token: 0x060004EB RID: 1259 RVA: 0x00014F85 File Offset: 0x00013185
		public Stream stream { get; protected set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060004EC RID: 1260 RVA: 0x00014F8E File Offset: 0x0001318E
		// (set) Token: 0x060004ED RID: 1261 RVA: 0x00014F96 File Offset: 0x00013196
		private byte buffer { get; set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060004EE RID: 1262 RVA: 0x00014F9F File Offset: 0x0001319F
		// (set) Token: 0x060004EF RID: 1263 RVA: 0x00014FA7 File Offset: 0x000131A7
		private byte bitIndex { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x060004F0 RID: 1264 RVA: 0x00014FB0 File Offset: 0x000131B0
		// (set) Token: 0x060004F1 RID: 1265 RVA: 0x00014FB8 File Offset: 0x000131B8
		private byte bitsAvailable { get; set; }

		// Token: 0x060004F2 RID: 1266 RVA: 0x00014FC1 File Offset: 0x000131C1
		public void writeBit(byte data)
		{
			this.writeBits(data, 1);
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x00014FCC File Offset: 0x000131CC
		public void writeBits(byte data, byte length)
		{
			if (length > this.bitsAvailable)
			{
				byte b = length - this.bitsAvailable;
				this.writeBits((byte)(data >> (int)b), this.bitsAvailable);
				this.writeBits(data, b);
				return;
			}
			byte b2 = 8 - length - this.bitIndex;
			byte b3 = (byte)(255 >> (int)(8 - length));
			this.buffer |= (byte)((data & b3) << (int)b2);
			this.bitIndex += length;
			this.bitsAvailable -= length;
			if (this.bitIndex == 8 && this.bitsAvailable == 0)
			{
				this.emptyBuffer();
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0001506E File Offset: 0x0001326E
		private void emptyBuffer()
		{
			this.stream.WriteByte(this.buffer);
			this.reset();
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00015087 File Offset: 0x00013287
		public void flush()
		{
			if (this.bitsAvailable == 8)
			{
				return;
			}
			this.emptyBuffer();
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00015099 File Offset: 0x00013299
		public void reset()
		{
			this.buffer = 0;
			this.bitIndex = 0;
			this.bitsAvailable = 8;
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x000150B0 File Offset: 0x000132B0
		public BitStreamWriter(Stream newStream)
		{
			this.stream = newStream;
			this.reset();
		}
	}
}
