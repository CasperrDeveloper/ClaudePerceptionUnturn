﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace SDG.Framework.IO.Serialization
{
	// Token: 0x020000BA RID: 186
	public class JsonTextWriterFormatted : JsonTextWriter
	{
		// Token: 0x0600050F RID: 1295 RVA: 0x0001564C File Offset: 0x0001384C
		public override void WriteStartArray()
		{
			base.Formatting = Formatting.None;
			base.WriteIndent();
			base.WriteStartArray();
			base.Formatting = Formatting.Indented;
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00015668 File Offset: 0x00013868
		public JsonTextWriterFormatted(TextWriter textWriter) : base(textWriter)
		{
			base.IndentChar = '\t';
			base.Indentation = 1;
		}
	}
}
