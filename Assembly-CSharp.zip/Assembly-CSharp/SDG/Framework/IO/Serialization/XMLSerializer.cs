﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace SDG.Framework.IO.Serialization
{
	// Token: 0x020000BB RID: 187
	public class XMLSerializer : ISerializer
	{
		// Token: 0x06000511 RID: 1297 RVA: 0x00015680 File Offset: 0x00013880
		public void serialize<T>(T instance, byte[] data, int index, out int size, bool isFormatted)
		{
			MemoryStream memoryStream = new MemoryStream(data, index, data.Length - index);
			this.serialize<T>(instance, memoryStream, isFormatted);
			size = (int)memoryStream.Position;
			memoryStream.Close();
			memoryStream.Dispose();
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x000156BC File Offset: 0x000138BC
		public void serialize<T>(T instance, MemoryStream memoryStream, bool isFormatted)
		{
			XmlWriter xmlWriter = XmlWriter.Create(memoryStream, isFormatted ? XMLSerializer.XML_WRITER_SETTINGS_FORMATTED : XMLSerializer.XML_WRITER_SETTINGS_UNFORMATTED);
			new XmlSerializer(typeof(T)).Serialize(xmlWriter, instance, XMLSerializer.XML_SERIALIZER_NAMESPACES);
			xmlWriter.Flush();
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00015708 File Offset: 0x00013908
		public void serialize<T>(T instance, string path, bool isFormatted)
		{
			StreamWriter streamWriter = new StreamWriter(path);
			XmlWriter xmlWriter = XmlWriter.Create(streamWriter, isFormatted ? XMLSerializer.XML_WRITER_SETTINGS_FORMATTED : XMLSerializer.XML_WRITER_SETTINGS_UNFORMATTED);
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
			try
			{
				xmlSerializer.Serialize(xmlWriter, instance, XMLSerializer.XML_SERIALIZER_NAMESPACES);
				xmlWriter.Flush();
			}
			finally
			{
				streamWriter.Close();
				streamWriter.Dispose();
			}
		}

		// Token: 0x04000216 RID: 534
		private static readonly XmlSerializerNamespaces XML_SERIALIZER_NAMESPACES = new XmlSerializerNamespaces(new XmlQualifiedName[]
		{
			XmlQualifiedName.Empty
		});

		// Token: 0x04000217 RID: 535
		private static readonly XmlWriterSettings XML_WRITER_SETTINGS_FORMATTED = new XmlWriterSettings
		{
			Indent = true,
			OmitXmlDeclaration = true,
			Encoding = new UTF8Encoding()
		};

		// Token: 0x04000218 RID: 536
		private static readonly XmlWriterSettings XML_WRITER_SETTINGS_UNFORMATTED = new XmlWriterSettings
		{
			Indent = false,
			OmitXmlDeclaration = true,
			Encoding = new UTF8Encoding()
		};
	}
}
