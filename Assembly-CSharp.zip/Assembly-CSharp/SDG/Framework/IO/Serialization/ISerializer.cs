﻿using System;
using System.IO;

namespace SDG.Framework.IO.Serialization
{
	// Token: 0x020000B8 RID: 184
	public interface ISerializer
	{
		// Token: 0x06000508 RID: 1288
		void serialize<T>(T instance, byte[] data, int offset, out int size, bool isFormatted);

		// Token: 0x06000509 RID: 1289
		void serialize<T>(T instance, MemoryStream memoryStream, bool isFormatted);

		// Token: 0x0600050A RID: 1290
		void serialize<T>(T instance, string path, bool isFormatted);
	}
}
