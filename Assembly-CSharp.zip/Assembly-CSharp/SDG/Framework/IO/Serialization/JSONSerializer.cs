﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace SDG.Framework.IO.Serialization
{
	// Token: 0x020000B9 RID: 185
	public class JSONSerializer : ISerializer
	{
		// Token: 0x0600050B RID: 1291 RVA: 0x0001553C File Offset: 0x0001373C
		public void serialize<T>(T instance, byte[] data, int index, out int size, bool isFormatted)
		{
			MemoryStream memoryStream = new MemoryStream(data, index, data.Length - index);
			this.serialize<T>(instance, memoryStream, isFormatted);
			size = (int)memoryStream.Position;
			memoryStream.Close();
			memoryStream.Dispose();
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00015578 File Offset: 0x00013778
		public void serialize<T>(T instance, MemoryStream memoryStream, bool isFormatted)
		{
			StreamWriter streamWriter = new StreamWriter(memoryStream);
			JsonWriter jsonWriter = isFormatted ? new JsonTextWriter(streamWriter) : new JsonTextWriterFormatted(streamWriter);
			JsonSerializer jsonSerializer = new JsonSerializer();
			try
			{
				jsonSerializer.Serialize(jsonWriter, instance);
				jsonWriter.Flush();
			}
			finally
			{
				jsonWriter.Close();
				streamWriter.Close();
				streamWriter.Dispose();
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x000155DC File Offset: 0x000137DC
		public void serialize<T>(T instance, string path, bool isFormatted)
		{
			StreamWriter streamWriter = new StreamWriter(path);
			JsonWriter jsonWriter = new JsonTextWriterFormatted(streamWriter);
			JsonSerializer jsonSerializer = new JsonSerializer();
			jsonSerializer.Formatting = (isFormatted ? Formatting.Indented : Formatting.None);
			try
			{
				jsonSerializer.Serialize(jsonWriter, instance);
				jsonWriter.Flush();
			}
			finally
			{
				jsonWriter.Close();
				streamWriter.Close();
				streamWriter.Dispose();
			}
		}
	}
}
