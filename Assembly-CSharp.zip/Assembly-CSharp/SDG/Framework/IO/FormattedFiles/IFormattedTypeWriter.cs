﻿using System;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000C1 RID: 193
	public interface IFormattedTypeWriter
	{
		// Token: 0x0600053D RID: 1341
		void write(IFormattedFileWriter writer, object value);
	}
}
