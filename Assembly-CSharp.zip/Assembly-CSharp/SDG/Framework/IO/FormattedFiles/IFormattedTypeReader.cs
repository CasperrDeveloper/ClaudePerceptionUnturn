﻿using System;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000C0 RID: 192
	public interface IFormattedTypeReader
	{
		// Token: 0x0600053C RID: 1340
		object read(IFormattedFileReader reader);
	}
}
