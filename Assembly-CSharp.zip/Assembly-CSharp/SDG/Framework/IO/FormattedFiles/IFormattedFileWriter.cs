﻿using System;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000BF RID: 191
	public interface IFormattedFileWriter
	{
		// Token: 0x0600052F RID: 1327
		void writeKey(string key);

		// Token: 0x06000530 RID: 1328
		void writeValue(string key, string value);

		// Token: 0x06000531 RID: 1329
		void writeValue(string value);

		// Token: 0x06000532 RID: 1330
		void writeValue(string key, object value);

		// Token: 0x06000533 RID: 1331
		void writeValue(object value);

		// Token: 0x06000534 RID: 1332
		void writeValue<T>(string key, T value);

		// Token: 0x06000535 RID: 1333
		void writeValue<T>(T value);

		// Token: 0x06000536 RID: 1334
		void beginObject();

		// Token: 0x06000537 RID: 1335
		void beginObject(string key);

		// Token: 0x06000538 RID: 1336
		void endObject();

		// Token: 0x06000539 RID: 1337
		void beginArray(string key);

		// Token: 0x0600053A RID: 1338
		void beginArray();

		// Token: 0x0600053B RID: 1339
		void endArray();
	}
}
