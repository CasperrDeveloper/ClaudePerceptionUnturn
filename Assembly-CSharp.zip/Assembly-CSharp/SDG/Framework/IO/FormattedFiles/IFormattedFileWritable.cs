﻿using System;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000BE RID: 190
	public interface IFormattedFileWritable
	{
		// Token: 0x0600052E RID: 1326
		void write(IFormattedFileWriter writer);
	}
}
