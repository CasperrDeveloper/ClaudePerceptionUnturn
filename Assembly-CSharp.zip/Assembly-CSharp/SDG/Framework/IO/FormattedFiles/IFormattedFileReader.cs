﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000BD RID: 189
	public interface IFormattedFileReader
	{
		// Token: 0x06000517 RID: 1303
		IEnumerable<string> getKeys();

		// Token: 0x06000518 RID: 1304
		bool containsKey(string key);

		// Token: 0x06000519 RID: 1305
		void readKey(string key);

		// Token: 0x0600051A RID: 1306
		int readArrayLength(string key);

		// Token: 0x0600051B RID: 1307
		int readArrayLength();

		// Token: 0x0600051C RID: 1308
		void readArrayIndex(string key, int index);

		// Token: 0x0600051D RID: 1309
		void readArrayIndex(int index);

		// Token: 0x0600051E RID: 1310
		string readValue(string key);

		// Token: 0x0600051F RID: 1311
		string readValue(int index);

		// Token: 0x06000520 RID: 1312
		string readValue(string key, int index);

		// Token: 0x06000521 RID: 1313
		string readValue();

		// Token: 0x06000522 RID: 1314
		object readValue(Type type, string key);

		// Token: 0x06000523 RID: 1315
		object readValue(Type type, int index);

		// Token: 0x06000524 RID: 1316
		object readValue(Type type, string key, int index);

		// Token: 0x06000525 RID: 1317
		object readValue(Type type);

		// Token: 0x06000526 RID: 1318
		T readValue<T>(string key);

		// Token: 0x06000527 RID: 1319
		T readValue<T>(int index);

		// Token: 0x06000528 RID: 1320
		T readValue<T>(string key, int index);

		// Token: 0x06000529 RID: 1321
		T readValue<T>();

		// Token: 0x0600052A RID: 1322
		IFormattedFileReader readObject(string key);

		// Token: 0x0600052B RID: 1323
		IFormattedFileReader readObject(int index);

		// Token: 0x0600052C RID: 1324
		IFormattedFileReader readObject(string key, int index);

		// Token: 0x0600052D RID: 1325
		IFormattedFileReader readObject();
	}
}
