﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E0 RID: 224
	public class KeyValueTableSByteReader : IFormattedTypeReader
	{
		// Token: 0x060005B6 RID: 1462 RVA: 0x00016A94 File Offset: 0x00014C94
		public object read(IFormattedFileReader reader)
		{
			sbyte b;
			sbyte.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out b);
			return b;
		}
	}
}
