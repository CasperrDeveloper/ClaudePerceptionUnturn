﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D5 RID: 213
	public class KeyValueTableQuaternionReader : IFormattedTypeReader
	{
		// Token: 0x060005A0 RID: 1440 RVA: 0x00016738 File Offset: 0x00014938
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Quaternion(reader.readValue<float>("X"), reader.readValue<float>("Y"), reader.readValue<float>("Z"), reader.readValue<float>("W"));
		}
	}
}
