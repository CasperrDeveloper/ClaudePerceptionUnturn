﻿using System;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E2 RID: 226
	public class KeyValueTableStringReader : IFormattedTypeReader
	{
		// Token: 0x060005BA RID: 1466 RVA: 0x00016AFB File Offset: 0x00014CFB
		public object read(IFormattedFileReader reader)
		{
			return reader.readValue();
		}
	}
}
