﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D8 RID: 216
	public class KeyValueTableVector4Reader : IFormattedTypeReader
	{
		// Token: 0x060005A6 RID: 1446 RVA: 0x0001680C File Offset: 0x00014A0C
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Vector4(reader.readValue<float>("X"), reader.readValue<float>("Y"), reader.readValue<float>("Z"), reader.readValue<float>("W"));
		}
	}
}
