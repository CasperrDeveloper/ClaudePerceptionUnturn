﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000DF RID: 223
	public class KeyValueTableLongReader : IFormattedTypeReader
	{
		// Token: 0x060005B4 RID: 1460 RVA: 0x00016A60 File Offset: 0x00014C60
		public object read(IFormattedFileReader reader)
		{
			long num;
			long.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
