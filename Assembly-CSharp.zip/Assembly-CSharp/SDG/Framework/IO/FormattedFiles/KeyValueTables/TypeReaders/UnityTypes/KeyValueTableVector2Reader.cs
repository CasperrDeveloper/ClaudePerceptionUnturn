﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D6 RID: 214
	public class KeyValueTableVector2Reader : IFormattedTypeReader
	{
		// Token: 0x060005A2 RID: 1442 RVA: 0x00016790 File Offset: 0x00014990
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Vector2(reader.readValue<float>("X"), reader.readValue<float>("Y"));
		}
	}
}
