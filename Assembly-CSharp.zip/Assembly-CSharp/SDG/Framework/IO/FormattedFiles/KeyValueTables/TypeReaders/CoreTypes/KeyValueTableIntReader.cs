﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000DE RID: 222
	public class KeyValueTableIntReader : IFormattedTypeReader
	{
		// Token: 0x060005B2 RID: 1458 RVA: 0x00016A2C File Offset: 0x00014C2C
		public object read(IFormattedFileReader reader)
		{
			int num;
			int.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
