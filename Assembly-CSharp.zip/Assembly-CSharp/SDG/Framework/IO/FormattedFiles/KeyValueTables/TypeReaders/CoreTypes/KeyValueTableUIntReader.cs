﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E3 RID: 227
	public class KeyValueTableUIntReader : IFormattedTypeReader
	{
		// Token: 0x060005BC RID: 1468 RVA: 0x00016B0C File Offset: 0x00014D0C
		public object read(IFormattedFileReader reader)
		{
			uint num;
			uint.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
