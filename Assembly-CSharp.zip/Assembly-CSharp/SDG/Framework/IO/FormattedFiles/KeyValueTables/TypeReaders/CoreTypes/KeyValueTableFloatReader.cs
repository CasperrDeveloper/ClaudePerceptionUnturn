﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000DD RID: 221
	public class KeyValueTableFloatReader : IFormattedTypeReader
	{
		// Token: 0x060005B0 RID: 1456 RVA: 0x000169F8 File Offset: 0x00014BF8
		public object read(IFormattedFileReader reader)
		{
			float num;
			float.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
