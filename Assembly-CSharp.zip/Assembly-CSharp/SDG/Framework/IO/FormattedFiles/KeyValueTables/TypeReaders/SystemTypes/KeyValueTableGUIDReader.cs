﻿using System;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.SystemTypes
{
	// Token: 0x020000D9 RID: 217
	public class KeyValueTableGUIDReader : IFormattedTypeReader
	{
		// Token: 0x060005A8 RID: 1448 RVA: 0x00016864 File Offset: 0x00014A64
		public object read(IFormattedFileReader reader)
		{
			string text = reader.readValue();
			if (string.IsNullOrEmpty(text) || text.Equals("0"))
			{
				return Guid.Empty;
			}
			return new Guid(text);
		}
	}
}
