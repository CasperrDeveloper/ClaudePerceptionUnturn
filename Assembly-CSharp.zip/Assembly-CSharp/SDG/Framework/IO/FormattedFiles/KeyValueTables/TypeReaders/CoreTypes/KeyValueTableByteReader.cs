﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000DC RID: 220
	public class KeyValueTableByteReader : IFormattedTypeReader
	{
		// Token: 0x060005AE RID: 1454 RVA: 0x000169C4 File Offset: 0x00014BC4
		public object read(IFormattedFileReader reader)
		{
			byte b;
			byte.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out b);
			return b;
		}
	}
}
