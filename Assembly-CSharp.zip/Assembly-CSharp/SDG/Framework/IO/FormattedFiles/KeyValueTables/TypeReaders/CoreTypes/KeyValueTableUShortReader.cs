﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E5 RID: 229
	public class KeyValueTableUShortReader : IFormattedTypeReader
	{
		// Token: 0x060005C0 RID: 1472 RVA: 0x00016B74 File Offset: 0x00014D74
		public object read(IFormattedFileReader reader)
		{
			ushort num;
			ushort.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
