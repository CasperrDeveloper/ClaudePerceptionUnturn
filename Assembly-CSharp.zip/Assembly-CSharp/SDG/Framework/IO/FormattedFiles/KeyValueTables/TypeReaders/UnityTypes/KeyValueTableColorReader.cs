﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D4 RID: 212
	public class KeyValueTableColorReader : IFormattedTypeReader
	{
		// Token: 0x0600059E RID: 1438 RVA: 0x000166D8 File Offset: 0x000148D8
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Color32(reader.readValue<byte>("R"), reader.readValue<byte>("G"), reader.readValue<byte>("B"), reader.readValue<byte>("A"));
		}
	}
}
