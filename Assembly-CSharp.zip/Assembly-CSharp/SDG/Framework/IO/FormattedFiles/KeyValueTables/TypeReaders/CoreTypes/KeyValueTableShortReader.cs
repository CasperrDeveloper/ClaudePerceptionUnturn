﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E1 RID: 225
	public class KeyValueTableShortReader : IFormattedTypeReader
	{
		// Token: 0x060005B8 RID: 1464 RVA: 0x00016AC8 File Offset: 0x00014CC8
		public object read(IFormattedFileReader reader)
		{
			short num;
			short.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
