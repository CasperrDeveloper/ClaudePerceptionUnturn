﻿using System;
using SDG.Unturned;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.SystemTypes
{
	// Token: 0x020000DA RID: 218
	public class KeyValueTableTypeReader : IFormattedTypeReader
	{
		// Token: 0x060005AA RID: 1450 RVA: 0x000168AC File Offset: 0x00014AAC
		public object read(IFormattedFileReader reader)
		{
			string text = reader.readValue();
			if (string.IsNullOrEmpty(text))
			{
				return null;
			}
			text = KeyValueTableTypeRedirectorRegistry.chase(text);
			if (text.IndexOfAny(DatValue.INVALID_TYPE_CHARS) >= 0)
			{
				return null;
			}
			return Type.GetType(text);
		}
	}
}
