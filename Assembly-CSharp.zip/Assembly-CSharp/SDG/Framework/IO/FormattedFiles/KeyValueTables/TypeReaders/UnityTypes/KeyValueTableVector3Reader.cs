﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D7 RID: 215
	public class KeyValueTableVector3Reader : IFormattedTypeReader
	{
		// Token: 0x060005A4 RID: 1444 RVA: 0x000167C7 File Offset: 0x000149C7
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Vector3(reader.readValue<float>("X"), reader.readValue<float>("Y"), reader.readValue<float>("Z"));
		}
	}
}
