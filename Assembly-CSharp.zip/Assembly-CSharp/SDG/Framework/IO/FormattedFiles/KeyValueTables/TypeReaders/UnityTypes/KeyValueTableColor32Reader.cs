﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.UnityTypes
{
	// Token: 0x020000D3 RID: 211
	public class KeyValueTableColor32Reader : IFormattedTypeReader
	{
		// Token: 0x0600059C RID: 1436 RVA: 0x00016680 File Offset: 0x00014880
		public object read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return null;
			}
			return new Color32(reader.readValue<byte>("R"), reader.readValue<byte>("G"), reader.readValue<byte>("B"), reader.readValue<byte>("A"));
		}
	}
}
