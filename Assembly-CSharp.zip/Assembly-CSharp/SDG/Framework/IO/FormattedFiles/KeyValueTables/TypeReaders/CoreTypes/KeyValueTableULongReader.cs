﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeReaders.CoreTypes
{
	// Token: 0x020000E4 RID: 228
	public class KeyValueTableULongReader : IFormattedTypeReader
	{
		// Token: 0x060005BE RID: 1470 RVA: 0x00016B40 File Offset: 0x00014D40
		public object read(IFormattedFileReader reader)
		{
			ulong num;
			ulong.TryParse(reader.readValue(), NumberStyles.Any, CultureInfo.InvariantCulture, out num);
			return num;
		}
	}
}
