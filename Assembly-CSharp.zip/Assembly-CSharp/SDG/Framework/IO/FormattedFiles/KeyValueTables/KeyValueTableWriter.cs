﻿using System;
using System.IO;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C6 RID: 198
	public class KeyValueTableWriter : IFormattedFileWriter
	{
		// Token: 0x06000571 RID: 1393 RVA: 0x00016024 File Offset: 0x00014224
		public virtual void writeKey(string key)
		{
			if (this.hasWritten)
			{
				this.writer.WriteLine();
			}
			this.writeIndents();
			this.writer.Write('"');
			this.writer.Write(key);
			this.writer.Write('"');
			this.hasWritten = true;
			this.wroteKey = true;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0001607E File Offset: 0x0001427E
		public virtual void writeValue(string key, string value)
		{
			this.writeKey(key);
			this.writeValue(value);
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x00016090 File Offset: 0x00014290
		public virtual void writeValue(string value)
		{
			if (this.wroteKey)
			{
				this.writer.Write(' ');
			}
			else
			{
				if (this.hasWritten)
				{
					this.writer.WriteLine();
				}
				this.writeIndents();
			}
			this.writer.Write('"');
			this.writer.Write(value);
			this.writer.Write('"');
			this.wroteKey = false;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x000160FA File Offset: 0x000142FA
		public virtual void writeValue(string key, object value)
		{
			this.writeKey(key);
			this.writeValue(value);
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0001610A File Offset: 0x0001430A
		public virtual void writeValue(object value)
		{
			if (value is IFormattedFileWritable)
			{
				(value as IFormattedFileWritable).write(this);
				return;
			}
			KeyValueTableTypeWriterRegistry.write(this, value);
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x00016128 File Offset: 0x00014328
		public virtual void writeValue<T>(string key, T value)
		{
			this.writeKey(key);
			this.writeValue<T>(value);
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x00016138 File Offset: 0x00014338
		public virtual void writeValue<T>(T value)
		{
			if (value is IFormattedFileWritable)
			{
				(value as IFormattedFileWritable).write(this);
				return;
			}
			KeyValueTableTypeWriterRegistry.write<T>(this, value);
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00016160 File Offset: 0x00014360
		public virtual void beginObject(string key)
		{
			this.writeKey(key);
			this.beginObject();
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00016170 File Offset: 0x00014370
		public virtual void beginObject()
		{
			if (this.hasWritten)
			{
				this.writer.WriteLine();
			}
			this.writeIndents();
			this.writer.Write('{');
			this.indentationCount++;
			this.hasWritten = true;
			this.wroteKey = false;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x000161BF File Offset: 0x000143BF
		public virtual void endObject()
		{
			if (this.hasWritten)
			{
				this.writer.WriteLine();
			}
			this.indentationCount--;
			this.writeIndents();
			this.writer.Write('}');
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x000161F5 File Offset: 0x000143F5
		public virtual void beginArray(string key)
		{
			this.writeKey(key);
			this.beginArray();
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00016204 File Offset: 0x00014404
		public virtual void beginArray()
		{
			if (this.hasWritten)
			{
				this.writer.WriteLine();
			}
			this.writeIndents();
			this.writer.Write('[');
			this.indentationCount++;
			this.hasWritten = true;
			this.wroteKey = false;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x00016253 File Offset: 0x00014453
		public virtual void endArray()
		{
			if (this.hasWritten)
			{
				this.writer.WriteLine();
			}
			this.indentationCount--;
			this.writeIndents();
			this.writer.Write(']');
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x0001628C File Offset: 0x0001448C
		protected virtual void writeIndents()
		{
			for (int i = 0; i < this.indentationCount; i++)
			{
				this.writer.Write('\t');
			}
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x000162B7 File Offset: 0x000144B7
		public KeyValueTableWriter(StreamWriter writer)
		{
			this.writer = writer;
			this.indentationCount = 0;
			this.hasWritten = false;
			this.wroteKey = false;
		}

		// Token: 0x04000225 RID: 549
		protected StreamWriter writer;

		// Token: 0x04000226 RID: 550
		protected int indentationCount;

		// Token: 0x04000227 RID: 551
		protected bool hasWritten;

		// Token: 0x04000228 RID: 552
		protected bool wroteKey;
	}
}
