﻿using System;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.CoreTypes
{
	// Token: 0x020000D0 RID: 208
	public class KeyValueTableBoolWriter : IFormattedTypeWriter
	{
		// Token: 0x06000596 RID: 1430 RVA: 0x000165EC File Offset: 0x000147EC
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.writeValue(((bool)value) ? "true" : "false");
		}
	}
}
