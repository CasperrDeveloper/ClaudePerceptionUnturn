﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.UnityTypes
{
	// Token: 0x020000C8 RID: 200
	public class KeyValueTableColor32Writer : IFormattedTypeWriter
	{
		// Token: 0x06000586 RID: 1414 RVA: 0x00016334 File Offset: 0x00014534
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.beginObject();
			Color32 color = (Color32)value;
			writer.writeValue<byte>("R", color.r);
			writer.writeValue<byte>("G", color.g);
			writer.writeValue<byte>("B", color.b);
			writer.writeValue<byte>("A", color.a);
			writer.endObject();
		}
	}
}
