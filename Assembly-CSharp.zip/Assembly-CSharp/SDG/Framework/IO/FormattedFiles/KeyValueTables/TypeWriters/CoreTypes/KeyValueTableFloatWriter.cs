﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.CoreTypes
{
	// Token: 0x020000D2 RID: 210
	public class KeyValueTableFloatWriter : IFormattedTypeWriter
	{
		// Token: 0x0600059A RID: 1434 RVA: 0x00016650 File Offset: 0x00014850
		public void write(IFormattedFileWriter writer, object value)
		{
			string value2 = ((float)value).ToString(CultureInfo.InvariantCulture);
			writer.writeValue(value2);
		}
	}
}
