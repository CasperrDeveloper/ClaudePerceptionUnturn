﻿using System;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.SystemTypes
{
	// Token: 0x020000CE RID: 206
	public class KeyValueTableGUIDWriter : IFormattedTypeWriter
	{
		// Token: 0x06000592 RID: 1426 RVA: 0x00016594 File Offset: 0x00014794
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.writeValue(((Guid)value).ToString("N"));
		}
	}
}
