﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.UnityTypes
{
	// Token: 0x020000CC RID: 204
	public class KeyValueTableVector3Writer : IFormattedTypeWriter
	{
		// Token: 0x0600058E RID: 1422 RVA: 0x000164CC File Offset: 0x000146CC
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.beginObject();
			Vector3 vector = (Vector3)value;
			writer.writeValue<float>("X", vector.x);
			writer.writeValue<float>("Y", vector.y);
			writer.writeValue<float>("Z", vector.z);
			writer.endObject();
		}
	}
}
