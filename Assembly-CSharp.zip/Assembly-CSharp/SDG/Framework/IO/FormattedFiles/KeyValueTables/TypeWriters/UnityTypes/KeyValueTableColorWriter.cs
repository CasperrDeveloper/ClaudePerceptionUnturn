﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.UnityTypes
{
	// Token: 0x020000C9 RID: 201
	public class KeyValueTableColorWriter : IFormattedTypeWriter
	{
		// Token: 0x06000588 RID: 1416 RVA: 0x000163A0 File Offset: 0x000145A0
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.beginObject();
			Color32 color = (Color)value;
			writer.writeValue<byte>("R", color.r);
			writer.writeValue<byte>("G", color.g);
			writer.writeValue<byte>("B", color.b);
			writer.writeValue<byte>("A", color.a);
			writer.endObject();
		}
	}
}
