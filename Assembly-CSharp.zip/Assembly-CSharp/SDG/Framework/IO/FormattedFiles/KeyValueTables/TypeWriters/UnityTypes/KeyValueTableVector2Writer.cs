﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.UnityTypes
{
	// Token: 0x020000CB RID: 203
	public class KeyValueTableVector2Writer : IFormattedTypeWriter
	{
		// Token: 0x0600058C RID: 1420 RVA: 0x00016480 File Offset: 0x00014680
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.beginObject();
			Vector2 vector = (Vector2)value;
			writer.writeValue<float>("X", vector.x);
			writer.writeValue<float>("Y", vector.y);
			writer.endObject();
		}
	}
}
