﻿using System;
using System.Globalization;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.CoreTypes
{
	// Token: 0x020000D1 RID: 209
	public class KeyValueTableDoubleWriter : IFormattedTypeWriter
	{
		// Token: 0x06000598 RID: 1432 RVA: 0x00016620 File Offset: 0x00014820
		public void write(IFormattedFileWriter writer, object value)
		{
			string value2 = ((double)value).ToString(CultureInfo.InvariantCulture);
			writer.writeValue(value2);
		}
	}
}
