﻿using System;
using UnityEngine;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.UnityTypes
{
	// Token: 0x020000CA RID: 202
	public class KeyValueTableQuaternionWriter : IFormattedTypeWriter
	{
		// Token: 0x0600058A RID: 1418 RVA: 0x00016414 File Offset: 0x00014614
		public void write(IFormattedFileWriter writer, object value)
		{
			writer.beginObject();
			Quaternion quaternion = (Quaternion)value;
			writer.writeValue<float>("X", quaternion.x);
			writer.writeValue<float>("Y", quaternion.y);
			writer.writeValue<float>("Z", quaternion.z);
			writer.writeValue<float>("W", quaternion.w);
			writer.endObject();
		}
	}
}
