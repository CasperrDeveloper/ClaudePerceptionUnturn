﻿using System;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables.TypeWriters.SystemTypes
{
	// Token: 0x020000CF RID: 207
	public class KeyValueTableTypeWriter : IFormattedTypeWriter
	{
		// Token: 0x06000594 RID: 1428 RVA: 0x000165C4 File Offset: 0x000147C4
		public void write(IFormattedFileWriter writer, object value)
		{
			Type type = value as Type;
			writer.writeValue(type.AssemblyQualifiedName);
		}
	}
}
