﻿using System;
using System.Collections.Generic;
using SDG.Framework.Devkit;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C4 RID: 196
	public static class KeyValueTableTypeRedirectorRegistry
	{
		/// <summary>
		/// If the type name has been redirected this method will be called recursively until the most recent name is found and returned.
		/// </summary>
		// Token: 0x06000565 RID: 1381 RVA: 0x00015ED0 File Offset: 0x000140D0
		public static string chase(string assemblyQualifiedName)
		{
			string assemblyQualifiedName2;
			if (KeyValueTableTypeRedirectorRegistry.redirects.TryGetValue(assemblyQualifiedName, out assemblyQualifiedName2))
			{
				return KeyValueTableTypeRedirectorRegistry.chase(assemblyQualifiedName2);
			}
			return assemblyQualifiedName;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x00015EF4 File Offset: 0x000140F4
		public static void add(string oldAssemblyQualifiedName, string newAssemblyQualifiedName)
		{
			KeyValueTableTypeRedirectorRegistry.redirects.Add(oldAssemblyQualifiedName, newAssemblyQualifiedName);
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x00015F02 File Offset: 0x00014102
		public static void remove(string oldAssemblyQualifiedName)
		{
			KeyValueTableTypeRedirectorRegistry.redirects.Remove(oldAssemblyQualifiedName);
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x00015F10 File Offset: 0x00014110
		static KeyValueTableTypeRedirectorRegistry()
		{
			KeyValueTableTypeRedirectorRegistry.add("SDG.Framework.Landscapes.PlayerClipVolume, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null", typeof(PlayerClipVolume).AssemblyQualifiedName);
			KeyValueTableTypeRedirectorRegistry.add("SDG.Framework.Foliage.KillVolume, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null", typeof(KillVolume).AssemblyQualifiedName);
		}

		// Token: 0x04000223 RID: 547
		private static Dictionary<string, string> redirects = new Dictionary<string, string>();
	}
}
