﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C7 RID: 199
	public class LimitedKeyValueTableReader : KeyValueTableReader
	{
		/// <summary>
		/// After the key "limit" is loaded we stop reading.
		/// </summary>
		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x000162DB File Offset: 0x000144DB
		// (set) Token: 0x06000581 RID: 1409 RVA: 0x000162E3 File Offset: 0x000144E3
		public string limit { get; protected set; }

		// Token: 0x06000582 RID: 1410 RVA: 0x000162EC File Offset: 0x000144EC
		protected override bool canContinueReadDictionary(StreamReader input, Dictionary<string, object> scope)
		{
			return !(this.dictionaryKey == this.limit) && base.canContinueReadDictionary(input, scope);
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x0001630B File Offset: 0x0001450B
		public LimitedKeyValueTableReader()
		{
			this.limit = null;
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x0001631A File Offset: 0x0001451A
		public LimitedKeyValueTableReader(StreamReader input) : this(null, input)
		{
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00016324 File Offset: 0x00014524
		public LimitedKeyValueTableReader(string newLimit, StreamReader input) : base(input)
		{
			this.limit = newLimit;
		}
	}
}
