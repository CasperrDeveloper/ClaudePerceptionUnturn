﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C2 RID: 194
	public class KeyValueTableReader : IFormattedFileReader
	{
		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x0600053E RID: 1342 RVA: 0x000157EF File Offset: 0x000139EF
		// (set) Token: 0x0600053F RID: 1343 RVA: 0x000157F7 File Offset: 0x000139F7
		public Dictionary<string, object> table { get; protected set; }

		// Token: 0x06000540 RID: 1344 RVA: 0x00015800 File Offset: 0x00013A00
		public virtual IEnumerable<string> getKeys()
		{
			return this.table.Keys;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x0001580D File Offset: 0x00013A0D
		public virtual bool containsKey(string key)
		{
			return this.table.ContainsKey(key);
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0001581B File Offset: 0x00013A1B
		public virtual void readKey(string key)
		{
			this.key = key;
			this.index = -1;
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x0001582B File Offset: 0x00013A2B
		public virtual int readArrayLength(string key)
		{
			this.readKey(key);
			return this.readArrayLength();
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x0001583C File Offset: 0x00013A3C
		public virtual int readArrayLength()
		{
			object obj;
			if (this.table.TryGetValue(this.key, out obj))
			{
				return (obj as List<object>).Count;
			}
			return 0;
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x0001586B File Offset: 0x00013A6B
		public virtual void readArrayIndex(string key, int index)
		{
			this.readKey(key);
			this.readArrayIndex(index);
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0001587B File Offset: 0x00013A7B
		public virtual void readArrayIndex(int index)
		{
			this.index = index;
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00015884 File Offset: 0x00013A84
		public virtual string readValue(string key)
		{
			this.readKey(key);
			return this.readValue();
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x00015893 File Offset: 0x00013A93
		public virtual string readValue(int index)
		{
			this.readArrayIndex(index);
			return this.readValue();
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x000158A2 File Offset: 0x00013AA2
		public virtual string readValue(string key, int index)
		{
			this.readKey(key);
			this.readArrayIndex(index);
			return this.readValue();
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x000158B8 File Offset: 0x00013AB8
		public virtual string readValue()
		{
			if (this.index == -1)
			{
				object obj;
				if (!this.table.TryGetValue(this.key, out obj))
				{
					return null;
				}
				return (string)obj;
			}
			else
			{
				object obj2;
				if (this.table.TryGetValue(this.key, out obj2))
				{
					return (string)(obj2 as List<object>)[this.index];
				}
				return null;
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x00015919 File Offset: 0x00013B19
		public virtual object readValue(Type type, string key)
		{
			this.readKey(key);
			return this.readValue(type);
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x00015929 File Offset: 0x00013B29
		public virtual object readValue(Type type, int index)
		{
			this.readArrayIndex(index);
			return this.readValue(type);
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00015939 File Offset: 0x00013B39
		public virtual object readValue(Type type, string key, int index)
		{
			this.readKey(key);
			this.readArrayIndex(index);
			return this.readValue(type);
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x00015950 File Offset: 0x00013B50
		public virtual object readValue(Type type)
		{
			if (typeof(IFormattedFileReadable).IsAssignableFrom(type))
			{
				IFormattedFileReadable formattedFileReadable = Activator.CreateInstance(type) as IFormattedFileReadable;
				formattedFileReadable.read(this);
				return formattedFileReadable;
			}
			return KeyValueTableTypeReaderRegistry.read(this, type);
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x0001597E File Offset: 0x00013B7E
		public virtual T readValue<T>(string key)
		{
			this.readKey(key);
			return this.readValue<T>();
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x0001598D File Offset: 0x00013B8D
		public virtual T readValue<T>(int index)
		{
			this.readArrayIndex(index);
			return this.readValue<T>();
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x0001599C File Offset: 0x00013B9C
		public virtual T readValue<T>(string key, int index)
		{
			this.readKey(key);
			this.readArrayIndex(index);
			return this.readValue<T>();
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x000159B2 File Offset: 0x00013BB2
		public virtual T readValue<T>()
		{
			if (typeof(IFormattedFileReadable).IsAssignableFrom(typeof(T)))
			{
				IFormattedFileReadable formattedFileReadable = Activator.CreateInstance<T>() as IFormattedFileReadable;
				formattedFileReadable.read(this);
				return (T)((object)formattedFileReadable);
			}
			return KeyValueTableTypeReaderRegistry.read<T>(this);
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x000159F1 File Offset: 0x00013BF1
		public virtual IFormattedFileReader readObject(string key)
		{
			this.readKey(key);
			return this.readObject();
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x00015A00 File Offset: 0x00013C00
		public virtual IFormattedFileReader readObject(int index)
		{
			this.readArrayIndex(index);
			return this.readObject();
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x00015A0F File Offset: 0x00013C0F
		public virtual IFormattedFileReader readObject(string key, int index)
		{
			this.readKey(key);
			this.readArrayIndex(index);
			return this.readObject();
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x00015A28 File Offset: 0x00013C28
		public virtual IFormattedFileReader readObject()
		{
			if (this.index == -1)
			{
				object obj;
				if (this.table.TryGetValue(this.key, out obj))
				{
					return obj as IFormattedFileReader;
				}
				return null;
			}
			else
			{
				object obj2;
				if (this.table.TryGetValue(this.key, out obj2))
				{
					return (obj2 as List<object>)[this.index] as IFormattedFileReader;
				}
				return null;
			}
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00015A89 File Offset: 0x00013C89
		protected virtual bool canContinueReadDictionary(StreamReader input, Dictionary<string, object> scope)
		{
			return true;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x00015A8C File Offset: 0x00013C8C
		public virtual void readDictionary(StreamReader input, Dictionary<string, object> scope)
		{
			this.dictionaryKey = null;
			this.dictionaryInQuotes = false;
			this.dictionaryIgnoreNextChar = false;
			while (!input.EndOfStream)
			{
				char c = (char)input.Read();
				if (this.dictionaryIgnoreNextChar)
				{
					KeyValueTableReader.builder.Append(c);
					this.dictionaryIgnoreNextChar = false;
				}
				else if (c == '\\')
				{
					this.dictionaryIgnoreNextChar = true;
				}
				else if (c == '"')
				{
					if (this.dictionaryInQuotes)
					{
						this.dictionaryInQuotes = false;
						if (string.IsNullOrEmpty(this.dictionaryKey))
						{
							this.dictionaryKey = KeyValueTableReader.builder.ToString();
						}
						else
						{
							string value = KeyValueTableReader.builder.ToString();
							if (!scope.ContainsKey(this.dictionaryKey))
							{
								scope.Add(this.dictionaryKey, value);
							}
							if (!this.canContinueReadDictionary(input, scope))
							{
								return;
							}
							this.dictionaryKey = null;
						}
					}
					else
					{
						this.dictionaryInQuotes = true;
						KeyValueTableReader.builder.Length = 0;
					}
				}
				else if (this.dictionaryInQuotes)
				{
					KeyValueTableReader.builder.Append(c);
				}
				else if (c == '{')
				{
					object obj;
					if (scope.TryGetValue(this.dictionaryKey, out obj))
					{
						KeyValueTableReader keyValueTableReader = (KeyValueTableReader)obj;
						keyValueTableReader.readDictionary(input, keyValueTableReader.table);
					}
					else
					{
						KeyValueTableReader keyValueTableReader2 = new KeyValueTableReader(input);
						obj = keyValueTableReader2;
						scope.Add(this.dictionaryKey, keyValueTableReader2);
					}
					if (!this.canContinueReadDictionary(input, scope))
					{
						return;
					}
					this.dictionaryKey = null;
				}
				else
				{
					if (c == '}')
					{
						return;
					}
					if (c == '[')
					{
						object obj2;
						if (!scope.TryGetValue(this.dictionaryKey, out obj2))
						{
							obj2 = new List<object>();
							scope.Add(this.dictionaryKey, obj2);
						}
						this.readList(input, (List<object>)obj2);
						if (!this.canContinueReadDictionary(input, scope))
						{
							return;
						}
						this.dictionaryKey = null;
					}
				}
			}
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00015C48 File Offset: 0x00013E48
		public virtual void readList(StreamReader input, List<object> scope)
		{
			this.listInQuotes = false;
			this.listIgnoreNextChar = false;
			while (!input.EndOfStream)
			{
				char c = (char)input.Read();
				if (this.listIgnoreNextChar)
				{
					KeyValueTableReader.builder.Append(c);
					this.listIgnoreNextChar = false;
				}
				else if (c == '\\')
				{
					this.listIgnoreNextChar = true;
				}
				else if (c == '"')
				{
					if (this.listInQuotes)
					{
						this.listInQuotes = false;
						string item = KeyValueTableReader.builder.ToString();
						scope.Add(item);
					}
					else
					{
						this.listInQuotes = true;
						KeyValueTableReader.builder.Length = 0;
					}
				}
				else if (this.listInQuotes)
				{
					KeyValueTableReader.builder.Append(c);
				}
				else if (c == '{')
				{
					KeyValueTableReader item2 = new KeyValueTableReader(input);
					scope.Add(item2);
				}
				else if (c == ']')
				{
					return;
				}
			}
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x00015D13 File Offset: 0x00013F13
		public KeyValueTableReader()
		{
			this.table = new Dictionary<string, object>();
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x00015D26 File Offset: 0x00013F26
		public KeyValueTableReader(StreamReader input)
		{
			this.table = new Dictionary<string, object>();
			this.readDictionary(input, this.table);
		}

		// Token: 0x04000219 RID: 537
		protected static StringBuilder builder = new StringBuilder();

		// Token: 0x0400021B RID: 539
		protected string key;

		// Token: 0x0400021C RID: 540
		protected int index;

		// Token: 0x0400021D RID: 541
		protected string dictionaryKey;

		// Token: 0x0400021E RID: 542
		protected bool dictionaryInQuotes;

		// Token: 0x0400021F RID: 543
		protected bool dictionaryIgnoreNextChar;

		// Token: 0x04000220 RID: 544
		protected bool listInQuotes;

		// Token: 0x04000221 RID: 545
		protected bool listIgnoreNextChar;
	}
}
