﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C5 RID: 197
	public class KeyValueTableTypeWriterRegistry
	{
		// Token: 0x06000569 RID: 1385 RVA: 0x00015F50 File Offset: 0x00014150
		public static void write<T>(IFormattedFileWriter output, T value)
		{
			IFormattedTypeWriter formattedTypeWriter;
			if (KeyValueTableTypeWriterRegistry.writers.TryGetValue(typeof(T), out formattedTypeWriter))
			{
				formattedTypeWriter.write(output, value);
				return;
			}
			output.writeValue(value.ToString());
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x00015F98 File Offset: 0x00014198
		public static void write(IFormattedFileWriter output, object value)
		{
			IFormattedTypeWriter formattedTypeWriter;
			if (KeyValueTableTypeWriterRegistry.writers.TryGetValue(value.GetType(), out formattedTypeWriter))
			{
				formattedTypeWriter.write(output, value);
				return;
			}
			output.writeValue(value.ToString());
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x00015FCE File Offset: 0x000141CE
		public static void add<T>(IFormattedTypeWriter writer)
		{
			KeyValueTableTypeWriterRegistry.add(typeof(T), writer);
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x00015FE0 File Offset: 0x000141E0
		public static void add(Type type, IFormattedTypeWriter writer)
		{
			KeyValueTableTypeWriterRegistry.writers.Add(type, writer);
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x00015FEE File Offset: 0x000141EE
		public static void remove<T>()
		{
			KeyValueTableTypeWriterRegistry.remove(typeof(T));
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x00015FFF File Offset: 0x000141FF
		public static void remove(Type type)
		{
			KeyValueTableTypeWriterRegistry.writers.Remove(type);
		}

		// Token: 0x04000224 RID: 548
		private static Dictionary<Type, IFormattedTypeWriter> writers = new Dictionary<Type, IFormattedTypeWriter>();
	}
}
