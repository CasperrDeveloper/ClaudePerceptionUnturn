﻿using System;
using System.Collections.Generic;
using SDG.Unturned;

namespace SDG.Framework.IO.FormattedFiles.KeyValueTables
{
	// Token: 0x020000C3 RID: 195
	public class KeyValueTableTypeReaderRegistry
	{
		// Token: 0x0600055D RID: 1373 RVA: 0x00015D54 File Offset: 0x00013F54
		public static T read<T>(IFormattedFileReader input)
		{
			IFormattedTypeReader formattedTypeReader;
			if (KeyValueTableTypeReaderRegistry.readers.TryGetValue(typeof(T), out formattedTypeReader))
			{
				object obj = formattedTypeReader.read(input);
				if (obj == null)
				{
					return default(T);
				}
				return (T)((object)obj);
			}
			else
			{
				if (!typeof(T).IsEnum)
				{
					string str = "Failed to find reader for: ";
					Type typeFromHandle = typeof(T);
					UnturnedLog.error(str + ((typeFromHandle != null) ? typeFromHandle.ToString() : null));
					return default(T);
				}
				string value = input.readValue();
				if (string.IsNullOrEmpty(value))
				{
					return default(T);
				}
				return (T)((object)Enum.Parse(typeof(T), value, true));
			}
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x00015E04 File Offset: 0x00014004
		public static object read(IFormattedFileReader input, Type type)
		{
			IFormattedTypeReader formattedTypeReader;
			if (KeyValueTableTypeReaderRegistry.readers.TryGetValue(type, out formattedTypeReader))
			{
				object obj = formattedTypeReader.read(input);
				if (obj == null)
				{
					return type.getDefaultValue();
				}
				return obj;
			}
			else
			{
				if (!type.IsEnum)
				{
					UnturnedLog.error("Failed to find reader for: " + ((type != null) ? type.ToString() : null));
					return type.getDefaultValue();
				}
				string value = input.readValue();
				if (string.IsNullOrEmpty(value))
				{
					return type.getDefaultValue();
				}
				return Enum.Parse(type, value, true);
			}
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x00015E7D File Offset: 0x0001407D
		public static void add<T>(IFormattedTypeReader reader)
		{
			KeyValueTableTypeReaderRegistry.add(typeof(T), reader);
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x00015E8F File Offset: 0x0001408F
		public static void add(Type type, IFormattedTypeReader reader)
		{
			KeyValueTableTypeReaderRegistry.readers.Add(type, reader);
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x00015E9D File Offset: 0x0001409D
		public static void remove<T>()
		{
			KeyValueTableTypeReaderRegistry.remove(typeof(T));
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x00015EAE File Offset: 0x000140AE
		public static void remove(Type type)
		{
			KeyValueTableTypeReaderRegistry.readers.Remove(type);
		}

		// Token: 0x04000222 RID: 546
		private static Dictionary<Type, IFormattedTypeReader> readers = new Dictionary<Type, IFormattedTypeReader>();
	}
}
