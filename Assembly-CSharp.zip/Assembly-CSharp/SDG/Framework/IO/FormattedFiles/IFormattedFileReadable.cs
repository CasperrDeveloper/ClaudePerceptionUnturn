﻿using System;

namespace SDG.Framework.IO.FormattedFiles
{
	// Token: 0x020000BC RID: 188
	public interface IFormattedFileReadable
	{
		// Token: 0x06000516 RID: 1302
		void read(IFormattedFileReader reader);
	}
}
