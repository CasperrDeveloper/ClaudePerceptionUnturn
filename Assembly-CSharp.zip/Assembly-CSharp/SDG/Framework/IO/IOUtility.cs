﻿using System;
using SDG.Framework.IO.Deserialization;
using SDG.Framework.IO.Serialization;
using SDG.Unturned;

namespace SDG.Framework.IO
{
	// Token: 0x020000B1 RID: 177
	public class IOUtility
	{
		/// <summary>
		/// Path to the folder which contains the Unity player executable.
		/// </summary>
		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060004BF RID: 1215 RVA: 0x00014A2D File Offset: 0x00012C2D
		[Obsolete("Replaced by UnturnedPaths.RootDirectory")]
		public static string rootPath
		{
			get
			{
				return UnturnedPaths.RootDirectory.FullName;
			}
		}

		// Token: 0x04000209 RID: 521
		public static IDeserializer jsonDeserializer = new JSONDeserializer();

		// Token: 0x0400020A RID: 522
		public static ISerializer jsonSerializer = new JSONSerializer();

		// Token: 0x0400020B RID: 523
		public static IDeserializer xmlDeserializer = new XMLDeserializer();

		// Token: 0x0400020C RID: 524
		public static ISerializer xmlSerializer = new XMLSerializer();
	}
}
