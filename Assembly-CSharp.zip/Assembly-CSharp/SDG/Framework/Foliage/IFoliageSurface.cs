﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000108 RID: 264
	public interface IFoliageSurface
	{
		/// <returns>True if other IFoliageSurface methods can be called.</returns>
		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060006D8 RID: 1752
		bool IsValidFoliageSurface { get; }

		// Token: 0x060006D9 RID: 1753
		FoliageBounds getFoliageSurfaceBounds();

		// Token: 0x060006DA RID: 1754
		bool getFoliageSurfaceInfo(Vector3 position, out Vector3 surfacePosition, out Vector3 surfaceNormal);

		// Token: 0x060006DB RID: 1755
		void bakeFoliageSurface(FoliageBakeSettings bakeSettings, FoliageTile foliageTile);
	}
}
