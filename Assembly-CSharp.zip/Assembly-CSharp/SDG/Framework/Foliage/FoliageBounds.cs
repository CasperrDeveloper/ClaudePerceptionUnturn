﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000EA RID: 234
	public struct FoliageBounds
	{
		// Token: 0x060005CD RID: 1485 RVA: 0x00016D40 File Offset: 0x00014F40
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"[",
				this.min.ToString(),
				", ",
				this.max.ToString(),
				"]"
			});
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00016D98 File Offset: 0x00014F98
		public FoliageBounds(FoliageCoord newMin, FoliageCoord newMax)
		{
			this.min = newMin;
			this.max = newMax;
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00016DA8 File Offset: 0x00014FA8
		public FoliageBounds(Bounds worldBounds)
		{
			this.min = new FoliageCoord(worldBounds.min);
			this.max = new FoliageCoord(worldBounds.max);
		}

		// Token: 0x0400022F RID: 559
		public FoliageCoord min;

		// Token: 0x04000230 RID: 560
		public FoliageCoord max;
	}
}
