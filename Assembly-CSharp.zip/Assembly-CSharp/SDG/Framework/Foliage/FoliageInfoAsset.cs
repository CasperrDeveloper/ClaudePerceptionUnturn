﻿using System;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000ED RID: 237
	public abstract class FoliageInfoAsset : Asset
	{
		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060005DD RID: 1501 RVA: 0x00017038 File Offset: 0x00015238
		public virtual float randomNormalPositionOffset
		{
			get
			{
				return UnityEngine.Random.Range(this.minNormalPositionOffset, this.maxNormalPositionOffset);
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x0001704C File Offset: 0x0001524C
		public virtual Quaternion randomRotation
		{
			get
			{
				return Quaternion.Euler(new Vector3(UnityEngine.Random.Range(this.minRotation.x, this.maxRotation.x), UnityEngine.Random.Range(this.minRotation.y, this.maxRotation.y), UnityEngine.Random.Range(this.minRotation.z, this.maxRotation.z)));
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060005DF RID: 1503 RVA: 0x000170B4 File Offset: 0x000152B4
		// (set) Token: 0x060005E0 RID: 1504 RVA: 0x000170BC File Offset: 0x000152BC
		public bool UniformScale { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060005E1 RID: 1505 RVA: 0x000170C8 File Offset: 0x000152C8
		public virtual Vector3 randomScale
		{
			get
			{
				return new Vector3(UnityEngine.Random.Range(this.minScale.x, this.maxScale.x), UnityEngine.Random.Range(this.minScale.y, this.maxScale.y), UnityEngine.Random.Range(this.minScale.z, this.maxScale.z));
			}
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0001712B File Offset: 0x0001532B
		public virtual void bakeFoliage(FoliageBakeSettings bakeSettings, IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight)
		{
			if (!this.isSurfaceWeightValid(surfaceWeight))
			{
				return;
			}
			this.bakeFoliageSteps(surface, bounds, surfaceWeight, collectionWeight, new FoliageInfoAsset.BakeFoliageStepHandler(this.handleBakeFoliageStep));
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x00017151 File Offset: 0x00015351
		public void addFoliageToSurface(Vector3 surfacePosition, Vector3 surfaceNormal, bool clearWhenBaked, bool followRules)
		{
			this.addFoliageToSurface(surfacePosition, surfaceNormal, clearWhenBaked, followRules, true);
		}

		/// <param name="followRules">Should angle limits and subtractive volumes be respected? Disabled when manually placing individually.</param>
		/// <param name="doCollisionChecks">If true, trees do a sphere overlap to prevent placement inside objects.</param>
		// Token: 0x060005E4 RID: 1508 RVA: 0x00017160 File Offset: 0x00015360
		public virtual void addFoliageToSurface(Vector3 surfacePosition, Vector3 surfaceNormal, bool clearWhenBaked, bool followRules, bool doCollisionChecks)
		{
			if (followRules && !this.isAngleValid(surfaceNormal))
			{
				return;
			}
			Vector3 position = surfacePosition + surfaceNormal * this.randomNormalPositionOffset;
			if (followRules && !this.isPositionValid(position, doCollisionChecks))
			{
				return;
			}
			Quaternion quaternion = Quaternion.Lerp(MathUtility.IDENTITY_QUATERNION, Quaternion.FromToRotation(Vector3.up, surfaceNormal), this.normalRotationAlignment);
			quaternion *= Quaternion.Euler(this.normalRotationOffset);
			quaternion *= this.randomRotation;
			Vector3 randomScale = this.randomScale;
			this.addFoliage(position, quaternion, randomScale, clearWhenBaked);
		}

		// Token: 0x060005E5 RID: 1509
		public abstract int getInstanceCountInVolume<T>(T volume) where T : IShapeVolume;

		// Token: 0x060005E6 RID: 1510
		protected abstract void addFoliage(Vector3 position, Quaternion rotation, Vector3 scale, bool clearWhenBaked);

		// Token: 0x060005E7 RID: 1511 RVA: 0x000171EC File Offset: 0x000153EC
		protected virtual void bakeFoliageSteps(IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight, FoliageInfoAsset.BakeFoliageStepHandler callback)
		{
			float num = surfaceWeight * collectionWeight;
			float num2 = bounds.size.x * bounds.size.z / this.density * num;
			int num3 = Mathf.FloorToInt(num2);
			if (UnityEngine.Random.value < num2 - (float)num3)
			{
				num3++;
			}
			for (int i = 0; i < num3; i++)
			{
				callback(surface, bounds, surfaceWeight, collectionWeight);
			}
		}

		/// <summary>
		/// Pick a point inside the bounds to test for foliage placement. The base implementation is completely random, but a blue noise implementation could be very nice.
		/// </summary>
		// Token: 0x060005E8 RID: 1512 RVA: 0x00017250 File Offset: 0x00015450
		protected virtual Vector3 getTestPosition(Bounds bounds)
		{
			float x = UnityEngine.Random.Range(-1f, 1f) * bounds.extents.x;
			float z = UnityEngine.Random.Range(-1f, 1f) * bounds.extents.z;
			return bounds.center + new Vector3(x, bounds.extents.y, z);
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x000172B8 File Offset: 0x000154B8
		protected virtual void handleBakeFoliageStep(IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight)
		{
			Vector3 testPosition = this.getTestPosition(bounds);
			Vector3 surfacePosition;
			Vector3 surfaceNormal;
			if (!surface.getFoliageSurfaceInfo(testPosition, out surfacePosition, out surfaceNormal))
			{
				return;
			}
			this.addFoliageToSurface(surfacePosition, surfaceNormal, true, true, true);
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x000172E8 File Offset: 0x000154E8
		protected virtual bool isAngleValid(Vector3 surfaceNormal)
		{
			float num = Vector3.Angle(Vector3.up, surfaceNormal);
			return num >= this.minSurfaceAngle && num <= this.maxSurfaceAngle;
		}

		// Token: 0x060005EB RID: 1515
		protected abstract bool isPositionValid(Vector3 position, bool doCollisionChecks);

		// Token: 0x060005EC RID: 1516 RVA: 0x00017318 File Offset: 0x00015518
		protected virtual bool isSurfaceWeightValid(float surfaceWeight)
		{
			return surfaceWeight >= this.minSurfaceWeight && surfaceWeight <= this.maxSurfaceWeight;
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00017334 File Offset: 0x00015534
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			this.density = p.data.ParseFloat("Density", 0f);
			this.minNormalPositionOffset = p.data.ParseFloat("Min_Normal_Position_Offset", 0f);
			this.maxNormalPositionOffset = p.data.ParseFloat("Max_Normal_Position_Offset", 0f);
			this.normalRotationOffset = p.data.ParseVector3("Normal_Rotation_Offset", default(Vector3));
			if (p.data.ContainsKey("Normal_Rotation_Alignment"))
			{
				this.normalRotationAlignment = p.data.ParseFloat("Normal_Rotation_Alignment", 0f);
			}
			else
			{
				this.normalRotationAlignment = 1f;
			}
			this.minSurfaceWeight = p.data.ParseFloat("Min_Weight", 0f);
			this.maxSurfaceWeight = p.data.ParseFloat("Max_Weight", 0f);
			this.minSurfaceAngle = p.data.ParseFloat("Min_Angle", 0f);
			this.maxSurfaceAngle = p.data.ParseFloat("Max_Angle", 0f);
			this.minRotation = p.data.ParseVector3("Min_Rotation", default(Vector3));
			this.maxRotation = p.data.ParseVector3("Max_Rotation", default(Vector3));
			this.UniformScale = p.data.ParseBool("Uniform_Scale", false);
			if (this.UniformScale)
			{
				float num = p.data.ParseFloat("Min_Scale", 0f);
				this.minScale = new Vector3(num, num, num);
				float num2 = p.data.ParseFloat("Max_Scale", 0f);
				this.maxScale = new Vector3(num2, num2, num2);
				return;
			}
			this.minScale = p.data.ParseVector3("Min_Scale", default(Vector3));
			this.maxScale = p.data.ParseVector3("Max_Scale", default(Vector3));
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00017542 File Offset: 0x00015742
		protected virtual void resetFoliageInfo()
		{
			this.normalRotationAlignment = 1f;
			this.maxSurfaceWeight = 1f;
			this.minScale = Vector3.one;
			this.maxScale = Vector3.one;
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x00017570 File Offset: 0x00015770
		public FoliageInfoAsset()
		{
			this.resetFoliageInfo();
		}

		// Token: 0x04000238 RID: 568
		public float density;

		// Token: 0x04000239 RID: 569
		public float minNormalPositionOffset;

		// Token: 0x0400023A RID: 570
		public float maxNormalPositionOffset;

		// Token: 0x0400023B RID: 571
		public Vector3 normalRotationOffset;

		// Token: 0x0400023C RID: 572
		public float normalRotationAlignment;

		// Token: 0x0400023D RID: 573
		public float minSurfaceWeight;

		// Token: 0x0400023E RID: 574
		public float maxSurfaceWeight;

		// Token: 0x0400023F RID: 575
		public float minSurfaceAngle;

		// Token: 0x04000240 RID: 576
		public float maxSurfaceAngle;

		// Token: 0x04000241 RID: 577
		public Vector3 minRotation;

		// Token: 0x04000242 RID: 578
		public Vector3 maxRotation;

		// Token: 0x04000243 RID: 579
		public Vector3 minScale;

		// Token: 0x04000244 RID: 580
		public Vector3 maxScale;

		// Token: 0x0200090B RID: 2315
		// (Invoke) Token: 0x060050C9 RID: 20681
		protected delegate void BakeFoliageStepHandler(IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight);
	}
}
