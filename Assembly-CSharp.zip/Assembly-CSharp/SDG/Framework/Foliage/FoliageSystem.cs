﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using SDG.Framework.Devkit;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.Landscapes;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;
using UnityEngine.Rendering;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000101 RID: 257
	public class FoliageSystem : DevkitHierarchyItemBase
	{
		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000671 RID: 1649 RVA: 0x00019D38 File Offset: 0x00017F38
		// (set) Token: 0x06000672 RID: 1650 RVA: 0x00019D3F File Offset: 0x00017F3F
		public static FoliageSystem instance { get; private set; }

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000673 RID: 1651 RVA: 0x00019D47 File Offset: 0x00017F47
		// (set) Token: 0x06000674 RID: 1652 RVA: 0x00019D4E File Offset: 0x00017F4E
		public static List<IFoliageSurface> surfaces { get; private set; } = new List<IFoliageSurface>();

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x06000675 RID: 1653 RVA: 0x00019D58 File Offset: 0x00017F58
		// (remove) Token: 0x06000676 RID: 1654 RVA: 0x00019D8C File Offset: 0x00017F8C
		public static event FoliageSystemPreBakeHandler preBake;

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x06000677 RID: 1655 RVA: 0x00019DC0 File Offset: 0x00017FC0
		// (remove) Token: 0x06000678 RID: 1656 RVA: 0x00019DF4 File Offset: 0x00017FF4
		public static event FoliageSystemPreBakeTileHandler preBakeTile;

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x06000679 RID: 1657 RVA: 0x00019E28 File Offset: 0x00018028
		// (remove) Token: 0x0600067A RID: 1658 RVA: 0x00019E5C File Offset: 0x0001805C
		public static event FoliageSystemPostBakeTileHandler postBakeTile;

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x0600067B RID: 1659 RVA: 0x00019E90 File Offset: 0x00018090
		// (remove) Token: 0x0600067C RID: 1660 RVA: 0x00019EC4 File Offset: 0x000180C4
		public static event FoliageSystemGlobalBakeHandler globalBake;

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x0600067D RID: 1661 RVA: 0x00019EF8 File Offset: 0x000180F8
		// (remove) Token: 0x0600067E RID: 1662 RVA: 0x00019F2C File Offset: 0x0001812C
		public static event FoliageSystemLocalBakeHandler localBake;

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x0600067F RID: 1663 RVA: 0x00019F60 File Offset: 0x00018160
		// (remove) Token: 0x06000680 RID: 1664 RVA: 0x00019F94 File Offset: 0x00018194
		public static event FoliageSystemPostBakeHandler postBake;

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000681 RID: 1665 RVA: 0x00019FC7 File Offset: 0x000181C7
		public static int bakeQueueProgress
		{
			get
			{
				return FoliageSystem.bakeQueueTotal - FoliageSystem.bakeQueue.Count;
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000682 RID: 1666 RVA: 0x00019FD9 File Offset: 0x000181D9
		// (set) Token: 0x06000683 RID: 1667 RVA: 0x00019FE0 File Offset: 0x000181E0
		public static int bakeQueueTotal { get; private set; }

		/// <summary>
		/// Settings configured when starting the bake.
		/// </summary>
		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000684 RID: 1668 RVA: 0x00019FE8 File Offset: 0x000181E8
		// (set) Token: 0x06000685 RID: 1669 RVA: 0x00019FEF File Offset: 0x000181EF
		public static FoliageBakeSettings bakeSettings { get; private set; }

		// Token: 0x06000686 RID: 1670 RVA: 0x00019FF8 File Offset: 0x000181F8
		public static void CreateInLevelIfMissing()
		{
			if (FoliageSystem.instance == null)
			{
				UnturnedLog.info("Adding default foliage system to level");
				LevelHierarchy.AssignInstanceIdAndMarkDirty(new GameObject().AddComponent<FoliageSystem>());
				if (VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().additiveVolumes.Count < 1)
				{
					UnturnedLog.info("Adding default additive foliage volume to level");
					FoliageVolume foliageVolume = new GameObject
					{
						transform = 
						{
							position = Vector3.zero,
							rotation = Quaternion.identity,
							localScale = new Vector3((float)Level.size, Landscape.TILE_HEIGHT, (float)Level.size)
						}
					}.AddComponent<FoliageVolume>();
					LevelHierarchy.AssignInstanceIdAndMarkDirty(foliageVolume);
					foliageVolume.mode = FoliageVolume.EFoliageVolumeMode.ADDITIVE;
				}
			}
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x0001A0A1 File Offset: 0x000182A1
		public static void addSurface(IFoliageSurface surface)
		{
			FoliageSystem.surfaces.Add(surface);
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0001A0AE File Offset: 0x000182AE
		public static void removeSurface(IFoliageSurface surface)
		{
			FoliageSystem.surfaces.Remove(surface);
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x0001A0BC File Offset: 0x000182BC
		[Obsolete]
		public static void addCut(IShapeVolume cut)
		{
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x0001A0C0 File Offset: 0x000182C0
		internal static void AddCut(FoliageCut cut)
		{
			for (int i = cut.foliageBounds.min.x; i <= cut.foliageBounds.max.x; i++)
			{
				for (int j = cut.foliageBounds.min.y; j <= cut.foliageBounds.max.y; j++)
				{
					FoliageSystem.getOrAddTile(new FoliageCoord(i, j)).AddCut(cut);
				}
			}
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x0001A134 File Offset: 0x00018334
		internal static void RemoveCut(FoliageCut cut)
		{
			for (int i = cut.foliageBounds.min.x; i <= cut.foliageBounds.max.x; i++)
			{
				for (int j = cut.foliageBounds.min.y; j <= cut.foliageBounds.max.y; j++)
				{
					FoliageSystem.getOrAddTile(new FoliageCoord(i, j)).RemoveCut(cut);
				}
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0001A1A8 File Offset: 0x000183A8
		private static Dictionary<FoliageTile, List<IFoliageSurface>> getTileSurfacePairs()
		{
			Dictionary<FoliageTile, List<IFoliageSurface>> dictionary = new Dictionary<FoliageTile, List<IFoliageSurface>>();
			foreach (KeyValuePair<FoliageCoord, FoliageTile> keyValuePair in FoliageSystem.tiles)
			{
				FoliageTile value = keyValuePair.Value;
				if (VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsTileBakeable(value))
				{
					dictionary.Add(value, new List<IFoliageSurface>());
				}
			}
			foreach (IFoliageSurface foliageSurface in FoliageSystem.surfaces)
			{
				if (foliageSurface.IsValidFoliageSurface)
				{
					FoliageBounds foliageSurfaceBounds = foliageSurface.getFoliageSurfaceBounds();
					for (int i = foliageSurfaceBounds.min.x; i <= foliageSurfaceBounds.max.x; i++)
					{
						for (int j = foliageSurfaceBounds.min.y; j <= foliageSurfaceBounds.max.y; j++)
						{
							FoliageTile orAddTile = FoliageSystem.getOrAddTile(new FoliageCoord(i, j));
							if (VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsTileBakeable(orAddTile))
							{
								List<IFoliageSurface> list;
								if (!dictionary.TryGetValue(orAddTile, out list))
								{
									list = new List<IFoliageSurface>();
									dictionary.Add(orAddTile, list);
								}
								list.Add(foliageSurface);
							}
						}
					}
				}
			}
			return dictionary;
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x0001A304 File Offset: 0x00018504
		private static void bakePre()
		{
			FoliageSystemPreBakeHandler foliageSystemPreBakeHandler = FoliageSystem.preBake;
			if (foliageSystemPreBakeHandler != null)
			{
				foliageSystemPreBakeHandler();
			}
			FoliageSystem.bakeQueue.Clear();
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0001A320 File Offset: 0x00018520
		public static void bakeGlobal(FoliageBakeSettings bakeSettings)
		{
			FoliageSystem.CreateInLevelIfMissing();
			FoliageSystem.bakeSettings = bakeSettings;
			FoliageSystem.bakePre();
			FoliageSystem.bakeGlobalBegin();
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0001A338 File Offset: 0x00018538
		private static void bakeGlobalBegin()
		{
			foreach (KeyValuePair<FoliageTile, List<IFoliageSurface>> item in FoliageSystem.getTileSurfacePairs())
			{
				FoliageSystem.bakeQueue.Enqueue(item);
			}
			FoliageSystem.bakeQueueTotal = FoliageSystem.bakeQueue.Count;
			FoliageSystem.bakeEnd = new FoliageSystemPostBakeHandler(FoliageSystem.bakeGlobalEnd);
			FoliageSystem.bakeEnd();
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0001A3B8 File Offset: 0x000185B8
		private static void bakeGlobalEnd()
		{
			FoliageSystemGlobalBakeHandler foliageSystemGlobalBakeHandler = FoliageSystem.globalBake;
			if (foliageSystemGlobalBakeHandler != null)
			{
				foliageSystemGlobalBakeHandler();
			}
			FoliageSystem.bakePost();
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x0001A3CF File Offset: 0x000185CF
		public static void bakeLocal(FoliageBakeSettings bakeSettings)
		{
			FoliageSystem.CreateInLevelIfMissing();
			FoliageSystem.bakeSettings = bakeSettings;
			FoliageSystem.bakePre();
			FoliageSystem.bakeLocalBegin();
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x0001A3E8 File Offset: 0x000185E8
		private static void bakeLocalBegin()
		{
			FoliageSystem.bakeLocalPosition = MainCamera.instance.transform.position;
			int num = 6;
			int num2 = num * num;
			FoliageCoord foliageCoord = new FoliageCoord(FoliageSystem.bakeLocalPosition);
			Dictionary<FoliageTile, List<IFoliageSurface>> tileSurfacePairs = FoliageSystem.getTileSurfacePairs();
			for (int i = -num; i <= num; i++)
			{
				for (int j = -num; j <= num; j++)
				{
					if (i * i + j * j <= num2)
					{
						FoliageTile tile = FoliageSystem.getTile(new FoliageCoord(foliageCoord.x + i, foliageCoord.y + j));
						List<IFoliageSurface> value;
						if (tile != null && tileSurfacePairs.TryGetValue(tile, out value))
						{
							KeyValuePair<FoliageTile, List<IFoliageSurface>> item = new KeyValuePair<FoliageTile, List<IFoliageSurface>>(tile, value);
							FoliageSystem.bakeQueue.Enqueue(item);
						}
					}
				}
			}
			FoliageSystem.bakeQueueTotal = FoliageSystem.bakeQueue.Count;
			FoliageSystem.bakeEnd = new FoliageSystemPostBakeHandler(FoliageSystem.bakeLocalEnd);
			FoliageSystem.bakeEnd();
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x0001A4C0 File Offset: 0x000186C0
		private static void bakeLocalEnd()
		{
			FoliageSystemLocalBakeHandler foliageSystemLocalBakeHandler = FoliageSystem.localBake;
			if (foliageSystemLocalBakeHandler != null)
			{
				foliageSystemLocalBakeHandler(FoliageSystem.bakeLocalPosition);
			}
			FoliageSystem.bakePost();
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x0001A4DC File Offset: 0x000186DC
		public static void bakeCancel()
		{
			if (FoliageSystem.bakeQueue.Count == 0)
			{
				return;
			}
			FoliageSystem.bakeQueue.Clear();
			FoliageSystem.bakeEnd();
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x0001A4FF File Offset: 0x000186FF
		private static void bakePreTile(FoliageBakeSettings bakeSettings, FoliageTile foliageTile)
		{
			if (!bakeSettings.bakeInstancesMeshes)
			{
				return;
			}
			if (bakeSettings.bakeApplyScale)
			{
				foliageTile.applyScale();
				return;
			}
			foliageTile.clearGeneratedInstances();
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x0001A520 File Offset: 0x00018720
		private static void bake(FoliageTile tile, List<IFoliageSurface> list)
		{
			FoliageSystem.bakePreTile(FoliageSystem.bakeSettings, tile);
			FoliageSystemPreBakeTileHandler foliageSystemPreBakeTileHandler = FoliageSystem.preBakeTile;
			if (foliageSystemPreBakeTileHandler != null)
			{
				foliageSystemPreBakeTileHandler(FoliageSystem.bakeSettings, tile);
			}
			if (!FoliageSystem.bakeSettings.bakeApplyScale)
			{
				foreach (IFoliageSurface foliageSurface in list)
				{
					if (foliageSurface.IsValidFoliageSurface)
					{
						foliageSurface.bakeFoliageSurface(FoliageSystem.bakeSettings, tile);
					}
				}
			}
			FoliageSystemPostBakeTileHandler foliageSystemPostBakeTileHandler = FoliageSystem.postBakeTile;
			if (foliageSystemPostBakeTileHandler == null)
			{
				return;
			}
			foliageSystemPostBakeTileHandler(FoliageSystem.bakeSettings, tile);
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x0001A5C0 File Offset: 0x000187C0
		private static void bakePost()
		{
			if (LevelHierarchy.instance != null)
			{
				LevelHierarchy.instance.isDirty = true;
			}
			FoliageSystemPostBakeHandler foliageSystemPostBakeHandler = FoliageSystem.postBake;
			if (foliageSystemPostBakeHandler == null)
			{
				return;
			}
			foliageSystemPostBakeHandler();
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0001A5E4 File Offset: 0x000187E4
		public static void addInstance(AssetReference<FoliageInstancedMeshInfoAsset> assetReference, Vector3 position, Quaternion rotation, Vector3 scale, bool clearWhenBaked)
		{
			FoliageTile orAddTile = FoliageSystem.getOrAddTile(position);
			Matrix4x4 newMatrix = Matrix4x4.TRS(position, rotation, scale);
			orAddTile.addInstance(new FoliageInstanceGroup(assetReference, newMatrix, clearWhenBaked));
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x0001A60E File Offset: 0x0001880E
		protected static void shutdownStorage()
		{
			if (FoliageSystem.storage != null)
			{
				FoliageSystem.storage.Shutdown();
				FoliageSystem.storage = null;
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x0001A628 File Offset: 0x00018828
		protected static void clearAndReleaseTiles()
		{
			foreach (KeyValuePair<FoliageCoord, FoliageTile> keyValuePair in FoliageSystem.tiles)
			{
				keyValuePair.Value.clearAndReleaseInstances();
			}
			FoliageSystem.tiles.Clear();
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x0001A68C File Offset: 0x0001888C
		private static void drawTiles(Vector3 position, int drawDistance, Camera camera, Plane[] frustumPlanes)
		{
			FoliageSystem.batches.Clear();
			Stack<Matrix4x4[]> stack = FoliageSystem.activeMatrixLists;
			FoliageSystem.activeMatrixLists = FoliageSystem.matrixListPool;
			FoliageSystem.matrixListPool = stack;
			FoliageCoord foliageCoord = new FoliageCoord(position);
			foreach (FoliageCoord foliageCoord2 in FoliageSystem.DRAW_OFFSETS[drawDistance])
			{
				FoliageCoord foliageCoord3 = new FoliageCoord(foliageCoord.x + foliageCoord2.x, foliageCoord.y + foliageCoord2.y);
				if (!FoliageSystem.relevantTiles.ContainsKey(foliageCoord3))
				{
					FoliageTile tile = FoliageSystem.getTile(foliageCoord3);
					if (tile != null)
					{
						FoliageSystem.relevantTiles.Add(foliageCoord3, tile);
						if (!tile.isRelevantToViewer)
						{
							tile.isRelevantToViewer = true;
							IFoliageStorage foliageStorage = FoliageSystem.storage;
							if (foliageStorage != null)
							{
								foliageStorage.TileBecameRelevantToViewer(tile);
							}
						}
						if (GeometryUtility.TestPlanesAABB(frustumPlanes, tile.worldBounds))
						{
							int sqrDistance = foliageCoord2.x * foliageCoord2.x + foliageCoord2.y * foliageCoord2.y;
							FoliageSystem.drawTile(tile, sqrDistance, camera);
						}
					}
				}
			}
			foreach (KeyValuePair<FoliageInstancingBatchConfig, FoliageInstancingBatchData> keyValuePair in FoliageSystem.batches)
			{
				FoliageInstancingBatchData value = keyValuePair.Value;
				if (value.count >= 1)
				{
					FoliageInstancingBatchConfig key = keyValuePair.Key;
					FoliageSystem.DrawInstances(key, value.list, value.count, camera);
				}
			}
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x0001A7F8 File Offset: 0x000189F8
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static void drawTile(FoliageTile tile, int sqrDistance, Camera camera)
		{
			foreach (FoliageInstanceList foliageInstanceList in tile.instances.Values)
			{
				int count = foliageInstanceList.matrices.Count;
				if (count >= 1 && foliageInstanceList.isLoadedAndRenderable && (foliageInstanceList.sqrDrawDistance == -1 || sqrDistance <= foliageInstanceList.sqrDrawDistance))
				{
					if (count > 1)
					{
						for (int i = 0; i < count - 1; i++)
						{
							List<Matrix4x4> list = foliageInstanceList.matrices[i];
							int matrixCount = Mathf.RoundToInt((float)list.Count * FoliageSettings._instanceDensity);
							FoliageSystem.DrawInstances(foliageInstanceList.batchConfig, list.GetInternalArray<Matrix4x4>(), matrixCount, camera);
						}
					}
					List<Matrix4x4> list2 = foliageInstanceList.matrices[count - 1];
					int num = Mathf.RoundToInt((float)list2.Count * FoliageSettings._instanceDensity);
					if (num >= 1)
					{
						FoliageInstancingBatchData foliageInstancingBatchData;
						if (!FoliageSystem.batches.TryGetValue(foliageInstanceList.batchConfig, out foliageInstancingBatchData))
						{
							Matrix4x4[] array;
							if (!FoliageSystem.matrixListPool.TryPop(out array))
							{
								array = new Matrix4x4[1023];
							}
							FoliageSystem.activeMatrixLists.Push(array);
							foliageInstancingBatchData = new FoliageInstancingBatchData
							{
								list = array,
								count = 0
							};
						}
						int num2 = foliageInstanceList.maxMatricesPerBatch - foliageInstancingBatchData.count;
						if (num < num2)
						{
							FoliageSystem.FastMatrixCopy(list2, 0, foliageInstancingBatchData.list, foliageInstancingBatchData.count, num);
							foliageInstancingBatchData.count += num;
						}
						else
						{
							FoliageSystem.FastMatrixCopy(list2, 0, foliageInstancingBatchData.list, foliageInstancingBatchData.count, num2);
							FoliageSystem.DrawInstances(foliageInstanceList.batchConfig, foliageInstancingBatchData.list, foliageInstanceList.maxMatricesPerBatch, camera);
							foliageInstancingBatchData.count = num - num2;
							if (foliageInstancingBatchData.count > 0)
							{
								FoliageSystem.FastMatrixCopy(list2, num2, foliageInstancingBatchData.list, 0, foliageInstancingBatchData.count);
							}
						}
						FoliageSystem.batches[foliageInstanceList.batchConfig] = foliageInstancingBatchData;
					}
				}
			}
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x0001AA0C File Offset: 0x00018C0C
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private unsafe static void FastMatrixCopy(List<Matrix4x4> source, int sourceIndex, Matrix4x4[] destination, int destinationIndex, int count)
		{
			Matrix4x4[] array;
			Matrix4x4* ptr;
			if ((array = source.GetInternalArray<Matrix4x4>()) == null || array.Length == 0)
			{
				ptr = null;
			}
			else
			{
				ptr = &array[0];
			}
			fixed (Matrix4x4[] array2 = destination)
			{
				Matrix4x4* ptr2;
				if (destination == null || array2.Length == 0)
				{
					ptr2 = null;
				}
				else
				{
					ptr2 = &array2[0];
				}
				void* source2 = (void*)(ptr + sourceIndex);
				Matrix4x4* destination2 = ptr2 + destinationIndex;
				long destinationSizeInBytes = (long)((1023 - destinationIndex) * sizeof(Matrix4x4));
				long sourceBytesToCopy = (long)(count * sizeof(Matrix4x4));
				Buffer.MemoryCopy(source2, (void*)destination2, destinationSizeInBytes, sourceBytesToCopy);
			}
			array = null;
		}

		/// <param name="matrixCount">Must be within [0, MAX_MATRICES_PER_BATCH] range.</param>
		// Token: 0x0600069E RID: 1694 RVA: 0x0001AA94 File Offset: 0x00018C94
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		private static void DrawInstances(in FoliageInstancingBatchConfig config, Matrix4x4[] matrices, int matrixCount, Camera camera)
		{
			if (FoliageSystem.shouldDrawWithoutInstancing)
			{
				for (int i = 0; i < matrixCount; i++)
				{
					Graphics.DrawMesh(config.mesh, matrices[i], config.material, 18, camera, 0, null, config.castShadows, true);
				}
				return;
			}
			ShadowCastingMode castShadows = config.castShadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
			Graphics.DrawMeshInstanced(config.mesh, 0, config.material, matrices, matrixCount, null, castShadows, true, 18, camera);
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0001AB00 File Offset: 0x00018D00
		public static FoliageTile getOrAddTile(Vector3 worldPosition)
		{
			return FoliageSystem.getOrAddTile(new FoliageCoord(worldPosition));
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0001AB0D File Offset: 0x00018D0D
		public static FoliageTile getTile(Vector3 worldPosition)
		{
			return FoliageSystem.getTile(new FoliageCoord(worldPosition));
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0001AB1C File Offset: 0x00018D1C
		public static FoliageTile getOrAddTile(FoliageCoord tileCoord)
		{
			FoliageTile foliageTile;
			if (!FoliageSystem.tiles.TryGetValue(tileCoord, out foliageTile))
			{
				foliageTile = new FoliageTile(tileCoord);
				FoliageSystem.tiles.Add(tileCoord, foliageTile);
			}
			return foliageTile;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0001AB4C File Offset: 0x00018D4C
		public static FoliageTile getTile(FoliageCoord tileCoord)
		{
			FoliageTile result;
			FoliageSystem.tiles.TryGetValue(tileCoord, out result);
			return result;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0001AB68 File Offset: 0x00018D68
		public override void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader.containsKey("Version"))
			{
				this.version = reader.readValue<uint>("Version");
			}
			else
			{
				this.version = 1U;
			}
			int num = reader.readArrayLength("Tiles");
			if (FoliageSystem.instance != this)
			{
				UnturnedLog.warn("Level contains multiple FoliageSystems. Ignoring {0} tile(s) with instance ID: {1}", new object[]
				{
					num,
					this.instanceID
				});
				return;
			}
			if (this.version == 2U)
			{
				FoliageSystem.storage = new FoliageStorageV2();
			}
			else
			{
				FoliageSystem.storage = new FoliageStorageV1();
			}
			FoliageSystem.storage.Initialize();
			if (Dedicator.IsDedicatedServer)
			{
				FoliageSystem.shutdownStorage();
				return;
			}
			for (int i = 0; i < num; i++)
			{
				reader.readArrayIndex(i);
				FoliageTile foliageTile = new FoliageTile(FoliageCoord.ZERO);
				foliageTile.read(reader);
				FoliageSystem.tiles.Add(foliageTile.coord, foliageTile);
			}
			if (Level.isEditor)
			{
				FoliageSystem.storage.EditorLoadAllTiles(FoliageSystem.tiles.Values);
				if (this.version < 2U)
				{
					LevelHierarchy.instance.isDirty = true;
				}
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0001AC80 File Offset: 0x00018E80
		public override void write(IFormattedFileWriter writer)
		{
			if (FoliageSystem.storage == null || this.version < 2U)
			{
				new FoliageStorageV2().EditorSaveAllTiles(FoliageSystem.tiles.Values);
				this.version = 2U;
			}
			else
			{
				FoliageSystem.storage.EditorSaveAllTiles(FoliageSystem.tiles.Values);
			}
			writer.beginObject();
			writer.writeValue<uint>("Version", this.version);
			writer.beginArray("Tiles");
			foreach (KeyValuePair<FoliageCoord, FoliageTile> keyValuePair in FoliageSystem.tiles)
			{
				FoliageTile value = keyValuePair.Value;
				writer.writeValue<FoliageTile>(value);
			}
			writer.endArray();
			writer.endObject();
		}

		/// <summary>
		/// Automatically placing foliage onto tiles in editor.
		/// </summary>
		// Token: 0x060006A5 RID: 1701 RVA: 0x0001AD4C File Offset: 0x00018F4C
		protected void tickBakeQueue()
		{
			KeyValuePair<FoliageTile, List<IFoliageSurface>> keyValuePair = FoliageSystem.bakeQueue.Dequeue();
			FoliageSystem.bake(keyValuePair.Key, keyValuePair.Value);
			if (FoliageSystem.bakeQueue.Count == 0)
			{
				FoliageSystem.bakeEnd();
			}
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0001AD90 File Offset: 0x00018F90
		protected void Update()
		{
			if (MainCamera.instance == null || this != FoliageSystem.instance)
			{
				return;
			}
			FoliageSystem.relevantTiles.Clear();
			if (FoliageSettings.enabled && !(this.hiddenByHeightEditor | this.hiddenByMaterialEditor))
			{
				FoliageSystem.shouldDrawWithoutInstancing = (FoliageSettings.forceInstancingOff || !SystemInfo.supportsInstancing);
				GeometryUtility.CalculateFrustumPlanes(MainCamera.instance, FoliageSystem.mainCameraFrustumPlanes);
				FoliageSystem.drawTiles(MainCamera.RenderingPosition, FoliageSettings.drawDistance, null, FoliageSystem.mainCameraFrustumPlanes);
				if (FoliageSettings.drawFocus && FoliageSystem.isFocused && FoliageSystem.focusCamera != null)
				{
					Plane[] frustumPlanes;
					if (MainCamera.instance == FoliageSystem.focusCamera)
					{
						frustumPlanes = FoliageSystem.mainCameraFrustumPlanes;
					}
					else
					{
						GeometryUtility.CalculateFrustumPlanes(FoliageSystem.focusCamera, FoliageSystem.focusCameraFrustumPlanes);
						frustumPlanes = FoliageSystem.focusCameraFrustumPlanes;
					}
					FoliageSystem.drawTiles(FoliageSystem.focusPosition, FoliageSettings.drawFocusDistance, FoliageSystem.focusCamera, frustumPlanes);
				}
			}
			foreach (KeyValuePair<FoliageCoord, FoliageTile> keyValuePair in FoliageSystem.previousFrameRelevantTiles)
			{
				if (!FoliageSystem.relevantTiles.ContainsKey(keyValuePair.Key) && keyValuePair.Value != null && keyValuePair.Value.isRelevantToViewer)
				{
					keyValuePair.Value.isRelevantToViewer = false;
					IFoliageStorage foliageStorage = FoliageSystem.storage;
					if (foliageStorage != null)
					{
						foliageStorage.TileNoLongerRelevantToViewer(keyValuePair.Value);
					}
				}
			}
			Dictionary<FoliageCoord, FoliageTile> dictionary = FoliageSystem.previousFrameRelevantTiles;
			FoliageSystem.previousFrameRelevantTiles = FoliageSystem.relevantTiles;
			FoliageSystem.relevantTiles = dictionary;
			if (Level.isEditor && FoliageSystem.bakeQueue.Count > 0)
			{
				this.tickBakeQueue();
			}
			if (FoliageSystem.storage != null)
			{
				FoliageSystem.storage.Update();
			}
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x0001AF44 File Offset: 0x00019144
		protected void OnEnable()
		{
			LevelHierarchy.addItem(this);
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x0001AF4C File Offset: 0x0001914C
		protected void OnDisable()
		{
			LevelHierarchy.removeItem(this);
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x0001AF54 File Offset: 0x00019154
		protected void Awake()
		{
			base.name = "Foliage_System";
			base.gameObject.layer = 20;
			if (FoliageSystem.instance == null)
			{
				FoliageSystem.instance = this;
				FoliageSystem.previousFrameRelevantTiles.Clear();
				FoliageSystem.relevantTiles.Clear();
				FoliageSystem.bakeQueue.Clear();
				FoliageSystem.batches.Clear();
				FoliageSystem.activeMatrixLists.Clear();
				FoliageSystem.matrixListPool.Clear();
				FoliageSystem.shutdownStorage();
				FoliageSystem.clearAndReleaseTiles();
			}
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x0001AFD4 File Offset: 0x000191D4
		protected void OnDestroy()
		{
			if (FoliageSystem.instance == this)
			{
				FoliageSystem.instance = null;
				FoliageSystem.previousFrameRelevantTiles.Clear();
				FoliageSystem.relevantTiles.Clear();
				FoliageSystem.bakeQueue.Clear();
				FoliageSystem.batches.Clear();
				FoliageSystem.activeMatrixLists.Clear();
				FoliageSystem.matrixListPool.Clear();
				FoliageSystem.shutdownStorage();
				FoliageSystem.clearAndReleaseTiles();
			}
		}

		// Token: 0x0400028D RID: 653
		public static float TILE_SIZE = 32f;

		// Token: 0x0400028E RID: 654
		public static int TILE_SIZE_INT = 32;

		// Token: 0x0400028F RID: 655
		public static int SPLATMAP_RESOLUTION_PER_TILE = 8;

		// Token: 0x0400029A RID: 666
		protected static Dictionary<FoliageCoord, FoliageTile> previousFrameRelevantTiles = new Dictionary<FoliageCoord, FoliageTile>();

		// Token: 0x0400029B RID: 667
		protected static Dictionary<FoliageCoord, FoliageTile> relevantTiles = new Dictionary<FoliageCoord, FoliageTile>();

		// Token: 0x0400029C RID: 668
		protected static Dictionary<FoliageCoord, FoliageTile> tiles = new Dictionary<FoliageCoord, FoliageTile>();

		/// <summary>
		/// Implementation of tile data storage.
		/// </summary>
		// Token: 0x0400029D RID: 669
		protected static IFoliageStorage storage = null;

		// Token: 0x0400029E RID: 670
		protected static Queue<KeyValuePair<FoliageTile, List<IFoliageSurface>>> bakeQueue = new Queue<KeyValuePair<FoliageTile, List<IFoliageSurface>>>();

		// Token: 0x0400029F RID: 671
		protected static FoliageSystemPostBakeHandler bakeEnd;

		// Token: 0x040002A0 RID: 672
		protected static Vector3 bakeLocalPosition;

		// Token: 0x040002A1 RID: 673
		private static Plane[] mainCameraFrustumPlanes = new Plane[6];

		// Token: 0x040002A2 RID: 674
		private static Plane[] focusCameraFrustumPlanes = new Plane[6];

		// Token: 0x040002A3 RID: 675
		public static Vector3 focusPosition;

		// Token: 0x040002A4 RID: 676
		public static bool isFocused;

		// Token: 0x040002A5 RID: 677
		public static Camera focusCamera;

		// Token: 0x040002A6 RID: 678
		public bool hiddenByHeightEditor;

		// Token: 0x040002A7 RID: 679
		public bool hiddenByMaterialEditor;

		/// <summary>
		/// Nelson 2025-04-22: instanced foliage rendering is a decent chunk of CPU time. In retrospect this seems like
		/// an obvious optimization: Graphics.DrawMeshInstanced accepts up to 1023* instances per call. Each tile
		/// groups instances in lists of up to 1023*, but often isn't that high. Now, we collect instances until we
		/// hit the 1023* limit. This is particularly useful for sparse variants like colored flowers.
		/// With a consistent camera transform ("/copycameratransform") on an upcoming map remaster I went from between
		/// 0.72-0.8 ms on my PC to 0.55-0.6 ms!
		/// *Nelson 2025-07-14: refer to NON_UNIFORM_SCALE_INSTANCES_PER_BATCH.
		/// </summary>
		// Token: 0x040002A8 RID: 680
		private static Dictionary<FoliageInstancingBatchConfig, FoliageInstancingBatchData> batches = new Dictionary<FoliageInstancingBatchConfig, FoliageInstancingBatchData>();

		// Token: 0x040002A9 RID: 681
		private static Stack<Matrix4x4[]> activeMatrixLists = new Stack<Matrix4x4[]>();

		// Token: 0x040002AA RID: 682
		private static Stack<Matrix4x4[]> matrixListPool = new Stack<Matrix4x4[]>();

		/// <summary>
		/// 2022-04-26: drawTiles previously looped over a square [-N, +N] from the upper-left to the bottom-right,
		/// and each tile checked radial distance. We can improve over this by pre-computing the radial offsets and
		/// starting from the center to improve responsiveness. N is [1, 5]
		/// </summary>
		// Token: 0x040002AB RID: 683
		private static readonly FoliageCoord[][] DRAW_OFFSETS = new FoliageCoord[][]
		{
			new FoliageCoord[0],
			new FoliageCoord[]
			{
				new FoliageCoord(0, 0),
				new FoliageCoord(1, 0),
				new FoliageCoord(1, 1),
				new FoliageCoord(0, 1),
				new FoliageCoord(-1, 1),
				new FoliageCoord(-1, 0),
				new FoliageCoord(-1, -1),
				new FoliageCoord(0, -1),
				new FoliageCoord(1, -1)
			},
			new FoliageCoord[]
			{
				new FoliageCoord(0, 0),
				new FoliageCoord(1, 0),
				new FoliageCoord(1, 1),
				new FoliageCoord(0, 1),
				new FoliageCoord(-1, 1),
				new FoliageCoord(-1, 0),
				new FoliageCoord(-1, -1),
				new FoliageCoord(0, -1),
				new FoliageCoord(1, -1),
				new FoliageCoord(2, -1),
				new FoliageCoord(2, 0),
				new FoliageCoord(2, 1),
				new FoliageCoord(1, 2),
				new FoliageCoord(0, 2),
				new FoliageCoord(-1, 2),
				new FoliageCoord(-2, 1),
				new FoliageCoord(-2, 0),
				new FoliageCoord(-2, -1),
				new FoliageCoord(-1, -2),
				new FoliageCoord(0, -2),
				new FoliageCoord(1, -2)
			},
			new FoliageCoord[]
			{
				new FoliageCoord(0, 0),
				new FoliageCoord(1, 0),
				new FoliageCoord(1, 1),
				new FoliageCoord(0, 1),
				new FoliageCoord(-1, 1),
				new FoliageCoord(-1, 0),
				new FoliageCoord(-1, -1),
				new FoliageCoord(0, -1),
				new FoliageCoord(1, -1),
				new FoliageCoord(2, -1),
				new FoliageCoord(2, 0),
				new FoliageCoord(2, 1),
				new FoliageCoord(2, 2),
				new FoliageCoord(1, 2),
				new FoliageCoord(0, 2),
				new FoliageCoord(-1, 2),
				new FoliageCoord(-2, 2),
				new FoliageCoord(-2, 1),
				new FoliageCoord(-2, 0),
				new FoliageCoord(-2, -1),
				new FoliageCoord(-2, -2),
				new FoliageCoord(-1, -2),
				new FoliageCoord(0, -2),
				new FoliageCoord(1, -2),
				new FoliageCoord(2, -2),
				new FoliageCoord(3, -2),
				new FoliageCoord(3, -1),
				new FoliageCoord(3, 0),
				new FoliageCoord(3, 1),
				new FoliageCoord(3, 2),
				new FoliageCoord(2, 3),
				new FoliageCoord(1, 3),
				new FoliageCoord(0, 3),
				new FoliageCoord(-1, 3),
				new FoliageCoord(-2, 3),
				new FoliageCoord(-3, 2),
				new FoliageCoord(-3, 1),
				new FoliageCoord(-3, 0),
				new FoliageCoord(-3, -1),
				new FoliageCoord(-3, -2),
				new FoliageCoord(-2, -3),
				new FoliageCoord(-1, -3),
				new FoliageCoord(0, -3),
				new FoliageCoord(1, -3),
				new FoliageCoord(2, -3)
			},
			new FoliageCoord[]
			{
				new FoliageCoord(0, 0),
				new FoliageCoord(1, 0),
				new FoliageCoord(1, 1),
				new FoliageCoord(0, 1),
				new FoliageCoord(-1, 1),
				new FoliageCoord(-1, 0),
				new FoliageCoord(-1, -1),
				new FoliageCoord(0, -1),
				new FoliageCoord(1, -1),
				new FoliageCoord(2, -1),
				new FoliageCoord(2, 0),
				new FoliageCoord(2, 1),
				new FoliageCoord(2, 2),
				new FoliageCoord(1, 2),
				new FoliageCoord(0, 2),
				new FoliageCoord(-1, 2),
				new FoliageCoord(-2, 2),
				new FoliageCoord(-2, 1),
				new FoliageCoord(-2, 0),
				new FoliageCoord(-2, -1),
				new FoliageCoord(-2, -2),
				new FoliageCoord(-1, -2),
				new FoliageCoord(0, -2),
				new FoliageCoord(1, -2),
				new FoliageCoord(2, -2),
				new FoliageCoord(3, -2),
				new FoliageCoord(3, -1),
				new FoliageCoord(3, 0),
				new FoliageCoord(3, 1),
				new FoliageCoord(3, 2),
				new FoliageCoord(3, 3),
				new FoliageCoord(2, 3),
				new FoliageCoord(1, 3),
				new FoliageCoord(0, 3),
				new FoliageCoord(-1, 3),
				new FoliageCoord(-2, 3),
				new FoliageCoord(-3, 3),
				new FoliageCoord(-3, 2),
				new FoliageCoord(-3, 1),
				new FoliageCoord(-3, 0),
				new FoliageCoord(-3, -1),
				new FoliageCoord(-3, -2),
				new FoliageCoord(-3, -3),
				new FoliageCoord(-2, -3),
				new FoliageCoord(-1, -3),
				new FoliageCoord(0, -3),
				new FoliageCoord(1, -3),
				new FoliageCoord(2, -3),
				new FoliageCoord(3, -3),
				new FoliageCoord(4, -2),
				new FoliageCoord(4, -1),
				new FoliageCoord(4, 0),
				new FoliageCoord(4, 1),
				new FoliageCoord(4, 2),
				new FoliageCoord(2, 4),
				new FoliageCoord(1, 4),
				new FoliageCoord(0, 4),
				new FoliageCoord(-1, 4),
				new FoliageCoord(-2, 4),
				new FoliageCoord(-4, 2),
				new FoliageCoord(-4, 1),
				new FoliageCoord(-4, 0),
				new FoliageCoord(-4, -1),
				new FoliageCoord(-4, -2),
				new FoliageCoord(-2, -4),
				new FoliageCoord(-1, -4),
				new FoliageCoord(0, -4),
				new FoliageCoord(1, -4),
				new FoliageCoord(2, -4)
			},
			new FoliageCoord[]
			{
				new FoliageCoord(0, 0),
				new FoliageCoord(1, 0),
				new FoliageCoord(1, 1),
				new FoliageCoord(0, 1),
				new FoliageCoord(-1, 1),
				new FoliageCoord(-1, 0),
				new FoliageCoord(-1, -1),
				new FoliageCoord(0, -1),
				new FoliageCoord(1, -1),
				new FoliageCoord(2, -1),
				new FoliageCoord(2, 0),
				new FoliageCoord(2, 1),
				new FoliageCoord(2, 2),
				new FoliageCoord(1, 2),
				new FoliageCoord(0, 2),
				new FoliageCoord(-1, 2),
				new FoliageCoord(-2, 2),
				new FoliageCoord(-2, 1),
				new FoliageCoord(-2, 0),
				new FoliageCoord(-2, -1),
				new FoliageCoord(-2, -2),
				new FoliageCoord(-1, -2),
				new FoliageCoord(0, -2),
				new FoliageCoord(1, -2),
				new FoliageCoord(2, -2),
				new FoliageCoord(3, -2),
				new FoliageCoord(3, -1),
				new FoliageCoord(3, 0),
				new FoliageCoord(3, 1),
				new FoliageCoord(3, 2),
				new FoliageCoord(3, 3),
				new FoliageCoord(2, 3),
				new FoliageCoord(1, 3),
				new FoliageCoord(0, 3),
				new FoliageCoord(-1, 3),
				new FoliageCoord(-2, 3),
				new FoliageCoord(-3, 3),
				new FoliageCoord(-3, 2),
				new FoliageCoord(-3, 1),
				new FoliageCoord(-3, 0),
				new FoliageCoord(-3, -1),
				new FoliageCoord(-3, -2),
				new FoliageCoord(-3, -3),
				new FoliageCoord(-2, -3),
				new FoliageCoord(-1, -3),
				new FoliageCoord(0, -3),
				new FoliageCoord(1, -3),
				new FoliageCoord(2, -3),
				new FoliageCoord(3, -3),
				new FoliageCoord(4, -3),
				new FoliageCoord(4, -2),
				new FoliageCoord(4, -1),
				new FoliageCoord(4, 0),
				new FoliageCoord(4, 1),
				new FoliageCoord(4, 2),
				new FoliageCoord(4, 3),
				new FoliageCoord(3, 4),
				new FoliageCoord(2, 4),
				new FoliageCoord(1, 4),
				new FoliageCoord(0, 4),
				new FoliageCoord(-1, 4),
				new FoliageCoord(-2, 4),
				new FoliageCoord(-3, 4),
				new FoliageCoord(-4, 3),
				new FoliageCoord(-4, 2),
				new FoliageCoord(-4, 1),
				new FoliageCoord(-4, 0),
				new FoliageCoord(-4, -1),
				new FoliageCoord(-4, -2),
				new FoliageCoord(-4, -3),
				new FoliageCoord(-3, -4),
				new FoliageCoord(-2, -4),
				new FoliageCoord(-1, -4),
				new FoliageCoord(0, -4),
				new FoliageCoord(1, -4),
				new FoliageCoord(2, -4),
				new FoliageCoord(3, -4),
				new FoliageCoord(5, -1),
				new FoliageCoord(5, 0),
				new FoliageCoord(5, 1),
				new FoliageCoord(1, 5),
				new FoliageCoord(0, 5),
				new FoliageCoord(-1, 5),
				new FoliageCoord(5, 1),
				new FoliageCoord(5, 0),
				new FoliageCoord(5, -1),
				new FoliageCoord(-1, -5),
				new FoliageCoord(0, -5),
				new FoliageCoord(1, -5)
			}
		};

		// Token: 0x040002AC RID: 684
		internal const int MAX_MATRICES_PER_BATCH = 1023;

		/// <summary>
		/// Nelson 2025-07-14: although Graphics.DrawMeshInstanced accepts 1023 instances, it will split them into max
		/// batches of [1, 511, 511] if shader does not have: #pragma instancing_options assumeuniformscaling
		/// So, we might as well do our own splitting of batches to avoid batches of 1.
		/// </summary>
		// Token: 0x040002AD RID: 685
		internal const int NON_UNIFORM_SCALE_INSTANCES_PER_BATCH = 511;

		/// <summary>
		/// Version number associated with this particular system instance.
		/// </summary>
		// Token: 0x040002AE RID: 686
		protected uint version;

		// Token: 0x040002AF RID: 687
		private static bool shouldDrawWithoutInstancing;

		/// <summary>
		/// 2022-04-26: this used to be environment layer, but "scope focus foliage" can draw outside that render distance
		/// so we now use the sky layer which is visible up to the far clip plane.
		/// </summary>
		// Token: 0x040002B0 RID: 688
		private const int foliageRenderLayer = 18;
	}
}
