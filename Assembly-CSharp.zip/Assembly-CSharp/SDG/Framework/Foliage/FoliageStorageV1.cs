﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	/// <summary>
	/// Legacy implementation of foliage storage, with one file per tile.
	/// </summary>
	// Token: 0x020000F6 RID: 246
	public class FoliageStorageV1 : IFoliageStorage
	{
		// Token: 0x06000634 RID: 1588 RVA: 0x000183FD File Offset: 0x000165FD
		public void Initialize()
		{
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x000183FF File Offset: 0x000165FF
		public void Shutdown()
		{
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x00018401 File Offset: 0x00016601
		public void TileBecameRelevantToViewer(FoliageTile tile)
		{
			if (!this.hasAllTilesInMemory)
			{
				this.pendingLoad.AddLast(tile);
			}
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x00018418 File Offset: 0x00016618
		public void TileNoLongerRelevantToViewer(FoliageTile tile)
		{
			if (!this.hasAllTilesInMemory)
			{
				this.pendingLoad.Remove(tile);
				tile.clearAndReleaseInstances();
			}
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x00018438 File Offset: 0x00016638
		public void Update()
		{
			if (this.pendingLoad.Count > 0)
			{
				FoliageTile value = this.pendingLoad.First.Value;
				this.pendingLoad.RemoveFirst();
				this.readInstances(value);
			}
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x00018478 File Offset: 0x00016678
		public void EditorLoadAllTiles(IEnumerable<FoliageTile> tiles)
		{
			this.hasAllTilesInMemory = true;
			foreach (FoliageTile tile in tiles)
			{
				this.readInstances(tile);
			}
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x000184C8 File Offset: 0x000166C8
		public void EditorSaveAllTiles(IEnumerable<FoliageTile> tiles)
		{
			foreach (FoliageTile foliageTile in tiles)
			{
				if (foliageTile.hasUnsavedChanges)
				{
					foliageTile.hasUnsavedChanges = false;
					this.writeInstances(foliageTile);
				}
			}
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x00018520 File Offset: 0x00016720
		protected string formatTilePath(FoliageTile tile)
		{
			FoliageCoord coord = tile.coord;
			string text = coord.x.ToString(CultureInfo.InvariantCulture);
			coord = tile.coord;
			string text2 = coord.y.ToString(CultureInfo.InvariantCulture);
			return string.Concat(new string[]
			{
				Level.info.path,
				"/Foliage/Tile_",
				text,
				"_",
				text2,
				".foliage"
			});
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x00018598 File Offset: 0x00016798
		protected void readInstances(FoliageTile tile)
		{
			string path = this.formatTilePath(tile);
			if (File.Exists(path))
			{
				using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
				{
					BinaryReader binaryReader = new BinaryReader(fileStream);
					int num = binaryReader.ReadInt32();
					int num2 = binaryReader.ReadInt32();
					for (int i = 0; i < num2; i++)
					{
						GuidBuffer guidBuffer = default(GuidBuffer);
						fileStream.Read(this.GUID_BUFFER, 0, 16);
						guidBuffer.Read(this.GUID_BUFFER, 0);
						AssetReference<FoliageInstancedMeshInfoAsset> assetReference = new AssetReference<FoliageInstancedMeshInfoAsset>(guidBuffer.GUID);
						FoliageInstanceList orAddList = tile.getOrAddList(assetReference);
						int num3 = binaryReader.ReadInt32();
						for (int j = 0; j < num3; j++)
						{
							Matrix4x4 newMatrix = default(Matrix4x4);
							for (int k = 0; k < 16; k++)
							{
								newMatrix[k] = binaryReader.ReadSingle();
							}
							bool newClearWhenBaked = num <= 2 || binaryReader.ReadBoolean();
							if (!tile.isInstanceCut(newMatrix.GetPosition()))
							{
								orAddList.addInstanceAppend(new FoliageInstanceGroup(assetReference, newMatrix, newClearWhenBaked));
							}
						}
					}
				}
			}
			tile.updateBounds();
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x000186C4 File Offset: 0x000168C4
		public void writeInstances(FoliageTile tile)
		{
			string path = this.formatTilePath(tile);
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
			{
				BinaryWriter binaryWriter = new BinaryWriter(fileStream);
				binaryWriter.Write(this.FOLIAGE_FILE_VERSION);
				binaryWriter.Write(tile.instances.Count);
				foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in tile.instances)
				{
					GuidBuffer guidBuffer = new GuidBuffer(keyValuePair.Key.GUID);
					guidBuffer.Write(this.GUID_BUFFER, 0);
					fileStream.Write(this.GUID_BUFFER, 0, 16);
					int num = 0;
					foreach (List<Matrix4x4> list in keyValuePair.Value.matrices)
					{
						num += list.Count;
					}
					binaryWriter.Write(num);
					for (int i = 0; i < keyValuePair.Value.matrices.Count; i++)
					{
						List<Matrix4x4> list2 = keyValuePair.Value.matrices[i];
						List<bool> list3 = keyValuePair.Value.clearWhenBaked[i];
						for (int j = 0; j < list2.Count; j++)
						{
							Matrix4x4 matrix4x = list2[j];
							for (int k = 0; k < 16; k++)
							{
								binaryWriter.Write(matrix4x[k]);
							}
							bool value = list3[j];
							binaryWriter.Write(value);
						}
					}
				}
			}
		}

		// Token: 0x0400026A RID: 618
		protected bool hasAllTilesInMemory;

		// Token: 0x0400026B RID: 619
		protected LinkedList<FoliageTile> pendingLoad = new LinkedList<FoliageTile>();

		// Token: 0x0400026C RID: 620
		private readonly int FOLIAGE_FILE_VERSION = 3;

		// Token: 0x0400026D RID: 621
		private byte[] GUID_BUFFER = new byte[16];
	}
}
