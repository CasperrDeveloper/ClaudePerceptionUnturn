﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F9 RID: 249
	// (Invoke) Token: 0x06000656 RID: 1622
	public delegate void FoliageSystemPreBakeHandler();
}
