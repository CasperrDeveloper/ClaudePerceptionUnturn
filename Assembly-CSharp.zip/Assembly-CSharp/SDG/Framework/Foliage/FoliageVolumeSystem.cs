﻿using System;
using System.Collections.Generic;
using SDG.Unturned;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000105 RID: 261
	public static class FoliageVolumeSystem
	{
		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060006CB RID: 1739 RVA: 0x0001C7CF File Offset: 0x0001A9CF
		[Obsolete]
		public static List<FoliageVolume> additiveVolumes
		{
			get
			{
				return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().additiveVolumes;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060006CC RID: 1740 RVA: 0x0001C7DB File Offset: 0x0001A9DB
		[Obsolete]
		public static List<FoliageVolume> subtractiveVolumes
		{
			get
			{
				return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().subtractiveVolumes;
			}
		}
	}
}
