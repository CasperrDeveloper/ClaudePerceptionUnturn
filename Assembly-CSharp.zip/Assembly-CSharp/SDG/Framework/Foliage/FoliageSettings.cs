﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F5 RID: 245
	public class FoliageSettings
	{
		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000625 RID: 1573 RVA: 0x0001838C File Offset: 0x0001658C
		// (set) Token: 0x06000626 RID: 1574 RVA: 0x00018393 File Offset: 0x00016593
		public static bool enabled
		{
			get
			{
				return FoliageSettings._enabled;
			}
			set
			{
				FoliageSettings._enabled = value;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000627 RID: 1575 RVA: 0x0001839B File Offset: 0x0001659B
		// (set) Token: 0x06000628 RID: 1576 RVA: 0x000183A2 File Offset: 0x000165A2
		public static bool drawFocus
		{
			get
			{
				return FoliageSettings._drawFocus;
			}
			set
			{
				FoliageSettings._drawFocus = value;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000629 RID: 1577 RVA: 0x000183AA File Offset: 0x000165AA
		// (set) Token: 0x0600062A RID: 1578 RVA: 0x000183B1 File Offset: 0x000165B1
		public static int drawDistance
		{
			get
			{
				return FoliageSettings._drawDistance;
			}
			set
			{
				FoliageSettings._drawDistance = value;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x0600062B RID: 1579 RVA: 0x000183B9 File Offset: 0x000165B9
		// (set) Token: 0x0600062C RID: 1580 RVA: 0x000183C0 File Offset: 0x000165C0
		public static int drawFocusDistance
		{
			get
			{
				return FoliageSettings._drawFocusDistance;
			}
			set
			{
				FoliageSettings._drawFocusDistance = value;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600062D RID: 1581 RVA: 0x000183C8 File Offset: 0x000165C8
		// (set) Token: 0x0600062E RID: 1582 RVA: 0x000183CF File Offset: 0x000165CF
		public static float instanceDensity
		{
			get
			{
				return FoliageSettings._instanceDensity;
			}
			set
			{
				FoliageSettings._instanceDensity = value;
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600062F RID: 1583 RVA: 0x000183D7 File Offset: 0x000165D7
		// (set) Token: 0x06000630 RID: 1584 RVA: 0x000183DE File Offset: 0x000165DE
		public static bool forceInstancingOff
		{
			get
			{
				return FoliageSettings._forceInstancingOff;
			}
			set
			{
				FoliageSettings._forceInstancingOff = value;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000631 RID: 1585 RVA: 0x000183E6 File Offset: 0x000165E6
		// (set) Token: 0x06000632 RID: 1586 RVA: 0x000183ED File Offset: 0x000165ED
		public static float focusDistance
		{
			get
			{
				return FoliageSettings._focusDistance;
			}
			set
			{
				FoliageSettings._focusDistance = value;
			}
		}

		// Token: 0x04000263 RID: 611
		private static bool _enabled;

		// Token: 0x04000264 RID: 612
		private static bool _drawFocus;

		// Token: 0x04000265 RID: 613
		private static int _drawDistance;

		// Token: 0x04000266 RID: 614
		private static int _drawFocusDistance;

		// Token: 0x04000267 RID: 615
		internal static float _instanceDensity;

		// Token: 0x04000268 RID: 616
		private static bool _forceInstancingOff;

		// Token: 0x04000269 RID: 617
		private static float _focusDistance;
	}
}
