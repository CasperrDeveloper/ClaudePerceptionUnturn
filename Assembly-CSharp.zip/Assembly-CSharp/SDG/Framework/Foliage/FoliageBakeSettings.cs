﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000E9 RID: 233
	public struct FoliageBakeSettings
	{
		// Token: 0x0400022A RID: 554
		public bool bakeInstancesMeshes;

		// Token: 0x0400022B RID: 555
		public bool bakeResources;

		// Token: 0x0400022C RID: 556
		public bool bakeObjects;

		// Token: 0x0400022D RID: 557
		public bool bakeClear;

		// Token: 0x0400022E RID: 558
		public bool bakeApplyScale;
	}
}
