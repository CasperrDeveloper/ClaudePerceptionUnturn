﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000EF RID: 239
	public class FoliageInstancedMeshInfoAsset : FoliageInfoAsset
	{
		/// <summary>
		/// If true, mesh is not loaded when clutter is turned off in graphics menu.
		/// Defaults to false.
		/// </summary>
		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060005F3 RID: 1523 RVA: 0x00017633 File Offset: 0x00015833
		// (set) Token: 0x060005F4 RID: 1524 RVA: 0x0001763B File Offset: 0x0001583B
		public bool IsClutter { get; set; }

		/// <summary>
		/// Get asset ref to replace this one for holiday, invalid to disable, or null if it should not be redirected.
		/// </summary>
		// Token: 0x060005F5 RID: 1525 RVA: 0x00017644 File Offset: 0x00015844
		public AssetReference<FoliageInstancedMeshInfoAsset>? getHolidayRedirect()
		{
			ENPCHoliday activeHoliday = HolidayUtil.getActiveHoliday();
			if (activeHoliday == ENPCHoliday.HALLOWEEN)
			{
				return this.halloweenRedirect;
			}
			if (activeHoliday == ENPCHoliday.CHRISTMAS)
			{
				return this.christmasRedirect;
			}
			return null;
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00017676 File Offset: 0x00015876
		public override void bakeFoliage(FoliageBakeSettings bakeSettings, IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight)
		{
			if (!bakeSettings.bakeInstancesMeshes)
			{
				return;
			}
			if (bakeSettings.bakeClear)
			{
				return;
			}
			base.bakeFoliage(bakeSettings, surface, bounds, surfaceWeight, collectionWeight);
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x00017698 File Offset: 0x00015898
		public override int getInstanceCountInVolume<T>(T volume)
		{
			Bounds worldBounds = volume.worldBounds;
			FoliageBounds foliageBounds = new FoliageBounds(worldBounds);
			int num = 0;
			for (int i = foliageBounds.min.x; i <= foliageBounds.max.x; i++)
			{
				for (int j = foliageBounds.min.y; j <= foliageBounds.max.y; j++)
				{
					FoliageTile tile = FoliageSystem.getTile(new FoliageCoord(i, j));
					FoliageInstanceList foliageInstanceList;
					if (tile != null && tile.instances != null && tile.instances.TryGetValue(base.getReferenceTo<FoliageInstancedMeshInfoAsset>(), out foliageInstanceList))
					{
						foreach (List<Matrix4x4> list in foliageInstanceList.matrices)
						{
							foreach (Matrix4x4 matrix4x in list)
							{
								if (volume.containsPoint(matrix4x.GetPosition()))
								{
									num++;
								}
							}
						}
					}
				}
			}
			return num;
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x000177D8 File Offset: 0x000159D8
		protected override void addFoliage(Vector3 position, Quaternion rotation, Vector3 scale, bool clearWhenBaked)
		{
			FoliageSystem.addInstance(base.getReferenceTo<FoliageInstancedMeshInfoAsset>(), position, rotation, scale, clearWhenBaked);
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x000177EA File Offset: 0x000159EA
		protected override bool isPositionValid(Vector3 position, bool doCollisionChecks)
		{
			return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsPositionBakeable(position, true, false, false);
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00017800 File Offset: 0x00015A00
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			this.mesh = p.data.ParseStruct("Mesh", default(ContentReference<Mesh>));
			this.material = p.data.ParseStruct("Material", default(ContentReference<Material>));
			if (p.data.ContainsKey("Cast_Shadows"))
			{
				this.castShadows = p.data.ParseBool("Cast_Shadows", false);
			}
			else
			{
				this.castShadows = false;
			}
			if (p.data.ContainsKey("Tile_Dither"))
			{
				this.tileDither = p.data.ParseBool("Tile_Dither", false);
			}
			else
			{
				this.tileDither = true;
			}
			this.IsClutter = p.data.ParseBool("Is_Clutter", false);
			if (p.data.ContainsKey("Draw_Distance"))
			{
				this.drawDistance = p.data.ParseInt32("Draw_Distance", 0);
			}
			else
			{
				this.drawDistance = -1;
			}
			if (p.data.ContainsKey("Christmas_Redirect"))
			{
				this.christmasRedirect = new AssetReference<FoliageInstancedMeshInfoAsset>?(p.data.ParseStruct("Christmas_Redirect", default(AssetReference<FoliageInstancedMeshInfoAsset>)));
			}
			if (p.data.ContainsKey("Halloween_Redirect"))
			{
				this.halloweenRedirect = new AssetReference<FoliageInstancedMeshInfoAsset>?(p.data.ParseStruct("Halloween_Redirect", default(AssetReference<FoliageInstancedMeshInfoAsset>)));
			}
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0001796B File Offset: 0x00015B6B
		protected virtual void resetInstancedMeshInfo()
		{
			this.tileDither = true;
			this.drawDistance = -1;
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0001797B File Offset: 0x00015B7B
		public FoliageInstancedMeshInfoAsset()
		{
			this.resetInstancedMeshInfo();
		}

		// Token: 0x04000247 RID: 583
		public ContentReference<Mesh> mesh;

		// Token: 0x04000248 RID: 584
		public ContentReference<Material> material;

		// Token: 0x04000249 RID: 585
		public bool castShadows;

		// Token: 0x0400024A RID: 586
		public bool tileDither;

		// Token: 0x0400024C RID: 588
		public int drawDistance;

		/// <summary>
		/// Foliage to use during the Christmas event instead.
		/// </summary>
		// Token: 0x0400024D RID: 589
		public AssetReference<FoliageInstancedMeshInfoAsset>? christmasRedirect;

		/// <summary>
		/// Foliage to use during the Halloween event instead.
		/// </summary>
		// Token: 0x0400024E RID: 590
		public AssetReference<FoliageInstancedMeshInfoAsset>? halloweenRedirect;
	}
}
