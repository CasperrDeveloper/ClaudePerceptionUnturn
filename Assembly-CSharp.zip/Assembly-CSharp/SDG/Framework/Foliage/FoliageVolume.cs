﻿using System;
using SDG.Framework.Devkit;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000103 RID: 259
	public class FoliageVolume : LevelVolume<FoliageVolume, FoliageVolumeManager>
	{
		// Token: 0x060006C0 RID: 1728 RVA: 0x0001C4AC File Offset: 0x0001A6AC
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new FoliageVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060006C1 RID: 1729 RVA: 0x0001C4C8 File Offset: 0x0001A6C8
		// (set) Token: 0x060006C2 RID: 1730 RVA: 0x0001C4D0 File Offset: 0x0001A6D0
		public FoliageVolume.EFoliageVolumeMode mode
		{
			get
			{
				return this._mode;
			}
			set
			{
				if (!base.enabled)
				{
					this._mode = value;
					return;
				}
				base.GetVolumeManager().RemoveVolume(this);
				this._mode = value;
				base.GetVolumeManager().AddVolume(this);
			}
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x0001C504 File Offset: 0x0001A704
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.mode = reader.readValue<FoliageVolume.EFoliageVolumeMode>("Mode");
			if (reader.containsKey("Instanced_Meshes"))
			{
				this.instancedMeshes = reader.readValue<bool>("Instanced_Meshes");
			}
			if (reader.containsKey("Resources"))
			{
				this.resources = reader.readValue<bool>("Resources");
			}
			if (reader.containsKey("Objects"))
			{
				this.objects = reader.readValue<bool>("Objects");
			}
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x0001C584 File Offset: 0x0001A784
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<FoliageVolume.EFoliageVolumeMode>("Mode", this.mode);
			writer.writeValue<bool>("Instanced_Meshes", this.instancedMeshes);
			writer.writeValue<bool>("Resources", this.resources);
			writer.writeValue<bool>("Objects", this.objects);
		}

		// Token: 0x040002B7 RID: 695
		[SerializeField]
		protected FoliageVolume.EFoliageVolumeMode _mode = FoliageVolume.EFoliageVolumeMode.SUBTRACTIVE;

		// Token: 0x040002B8 RID: 696
		public bool instancedMeshes = true;

		// Token: 0x040002B9 RID: 697
		public bool resources = true;

		// Token: 0x040002BA RID: 698
		public bool objects = true;

		// Token: 0x0200090F RID: 2319
		public enum EFoliageVolumeMode
		{
			// Token: 0x040036DC RID: 14044
			ADDITIVE,
			// Token: 0x040036DD RID: 14045
			SUBTRACTIVE
		}

		// Token: 0x02000910 RID: 2320
		private class Menu : SleekWrapper
		{
			// Token: 0x060050CF RID: 20687 RVA: 0x001F3EE0 File Offset: 0x001F20E0
			public Menu(FoliageVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 160f;
				SleekButtonState sleekButtonState = new SleekButtonState(new GUIContent[]
				{
					new GUIContent("Additive"),
					new GUIContent("Subtractive")
				});
				sleekButtonState.SizeOffset_X = 200f;
				sleekButtonState.SizeOffset_Y = 30f;
				sleekButtonState.AddLabel("Mode", ESleekSide.RIGHT);
				sleekButtonState.state = ((volume.mode == FoliageVolume.EFoliageVolumeMode.ADDITIVE) ? 0 : 1);
				SleekButtonState sleekButtonState2 = sleekButtonState;
				sleekButtonState2.onSwappedState = (SwappedState)Delegate.Combine(sleekButtonState2.onSwappedState, new SwappedState(this.OnSwappedMode));
				base.AddChild(sleekButtonState);
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.PositionOffset_Y = 40f;
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.instancedMeshes;
				sleekToggle.AddLabel("Instanced Meshes", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnInstancedMeshesToggled;
				base.AddChild(sleekToggle);
				ISleekToggle sleekToggle2 = Glazier.Get().CreateToggle();
				sleekToggle2.PositionOffset_Y = 80f;
				sleekToggle2.SizeOffset_X = 40f;
				sleekToggle2.SizeOffset_Y = 40f;
				sleekToggle2.Value = volume.resources;
				sleekToggle2.AddLabel("Resources", ESleekSide.RIGHT);
				sleekToggle2.OnValueChanged += this.OnResourcesToggled;
				base.AddChild(sleekToggle2);
				ISleekToggle sleekToggle3 = Glazier.Get().CreateToggle();
				sleekToggle3.PositionOffset_Y = 120f;
				sleekToggle3.SizeOffset_X = 40f;
				sleekToggle3.SizeOffset_Y = 40f;
				sleekToggle3.Value = volume.objects;
				sleekToggle3.AddLabel("Objects", ESleekSide.RIGHT);
				sleekToggle3.OnValueChanged += this.OnObjectsToggled;
				base.AddChild(sleekToggle3);
			}

			// Token: 0x060050D0 RID: 20688 RVA: 0x001F40AA File Offset: 0x001F22AA
			private void OnSwappedMode(SleekButtonState button, int state)
			{
				this.volume.mode = ((state == 0) ? FoliageVolume.EFoliageVolumeMode.ADDITIVE : FoliageVolume.EFoliageVolumeMode.SUBTRACTIVE);
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D1 RID: 20689 RVA: 0x001F40C3 File Offset: 0x001F22C3
			private void OnInstancedMeshesToggled(ISleekToggle toggle, bool state)
			{
				this.volume.instancedMeshes = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D2 RID: 20690 RVA: 0x001F40D6 File Offset: 0x001F22D6
			private void OnResourcesToggled(ISleekToggle toggle, bool state)
			{
				this.volume.resources = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D3 RID: 20691 RVA: 0x001F40E9 File Offset: 0x001F22E9
			private void OnObjectsToggled(ISleekToggle toggle, bool state)
			{
				this.volume.objects = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036DE RID: 14046
			private FoliageVolume volume;
		}
	}
}
