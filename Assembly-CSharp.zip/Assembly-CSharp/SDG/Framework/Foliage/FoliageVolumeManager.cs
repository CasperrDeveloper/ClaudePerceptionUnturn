﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000104 RID: 260
	public class FoliageVolumeManager : VolumeManager<FoliageVolume, FoliageVolumeManager>
	{
		// Token: 0x060006C6 RID: 1734 RVA: 0x0001C600 File Offset: 0x0001A800
		public bool IsTileBakeable(FoliageTile tile)
		{
			if (this.additiveVolumes.Count > 0)
			{
				Vector3 center = tile.worldBounds.center;
				for (int i = 0; i < this.additiveVolumes.Count; i++)
				{
					if (this.additiveVolumes[i].IsPositionInsideVolume(center))
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x0001C65C File Offset: 0x0001A85C
		public bool IsPositionBakeable(Vector3 point, bool instancedMeshes, bool resources, bool objects)
		{
			bool flag;
			if (this.additiveVolumes.Count > 0)
			{
				flag = false;
				for (int i = 0; i < this.additiveVolumes.Count; i++)
				{
					FoliageVolume foliageVolume = this.additiveVolumes[i];
					if ((!instancedMeshes || foliageVolume.instancedMeshes) && (!resources || foliageVolume.resources) && (!objects || foliageVolume.objects) && foliageVolume.IsPositionInsideVolume(point))
					{
						flag = true;
						break;
					}
				}
			}
			else
			{
				flag = true;
			}
			if (!flag)
			{
				return false;
			}
			for (int j = 0; j < this.subtractiveVolumes.Count; j++)
			{
				FoliageVolume foliageVolume2 = this.subtractiveVolumes[j];
				if ((!instancedMeshes || foliageVolume2.instancedMeshes) && (!resources || foliageVolume2.resources) && (!objects || foliageVolume2.objects) && foliageVolume2.IsPositionInsideVolume(point))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x0001C72A File Offset: 0x0001A92A
		public override void AddVolume(FoliageVolume volume)
		{
			base.AddVolume(volume);
			if (volume.mode == FoliageVolume.EFoliageVolumeMode.ADDITIVE)
			{
				this.additiveVolumes.Add(volume);
				return;
			}
			this.subtractiveVolumes.Add(volume);
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x0001C754 File Offset: 0x0001A954
		public override void RemoveVolume(FoliageVolume volume)
		{
			base.RemoveVolume(volume);
			if (volume.mode == FoliageVolume.EFoliageVolumeMode.ADDITIVE)
			{
				this.additiveVolumes.RemoveFast(volume);
				return;
			}
			this.subtractiveVolumes.RemoveFast(volume);
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x0001C780 File Offset: 0x0001A980
		public FoliageVolumeManager()
		{
			base.FriendlyName = "Foliage";
			this.additiveVolumes = new List<FoliageVolume>();
			this.subtractiveVolumes = new List<FoliageVolume>();
			base.SetDebugColor(new Color32(44, 114, 34, byte.MaxValue));
		}

		// Token: 0x040002BB RID: 699
		internal List<FoliageVolume> additiveVolumes;

		// Token: 0x040002BC RID: 700
		internal List<FoliageVolume> subtractiveVolumes;
	}
}
