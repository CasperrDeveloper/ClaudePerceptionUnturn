﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F4 RID: 244
	public class FoliageResourceInfoAsset : FoliageInfoAsset
	{
		/// <summary>
		/// If true, ResourceAsset's legacy random rotation and scale properties are used.
		/// (As opposed to FoliageInfoAsset properties.)
		/// Defaults to true for backwards compatibility.
		/// </summary>
		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600061B RID: 1563 RVA: 0x00018143 File Offset: 0x00016343
		// (set) Token: 0x0600061C RID: 1564 RVA: 0x0001814B File Offset: 0x0001634B
		public bool UsesLegacyRotationAndScale { get; set; }

		// Token: 0x0600061D RID: 1565 RVA: 0x00018154 File Offset: 0x00016354
		public override void bakeFoliage(FoliageBakeSettings bakeSettings, IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight)
		{
			if (!bakeSettings.bakeResources)
			{
				return;
			}
			if (bakeSettings.bakeClear)
			{
				return;
			}
			base.bakeFoliage(bakeSettings, surface, bounds, surfaceWeight, collectionWeight);
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x00018178 File Offset: 0x00016378
		public override int getInstanceCountInVolume<T>(T volume)
		{
			int num = 0;
			foreach (Vector2Int coord in Regions.GetCoordinateBoundsInt(volume.worldBounds))
			{
				List<ResourceSpawnpoint> treesOrNullInRegion = LevelGround.GetTreesOrNullInRegion(coord);
				if (treesOrNullInRegion != null)
				{
					foreach (ResourceSpawnpoint resourceSpawnpoint in treesOrNullInRegion)
					{
						if (this.resource.isReferenceTo(resourceSpawnpoint.asset) && volume.containsPoint(resourceSpawnpoint.point))
						{
							num++;
						}
					}
				}
			}
			return num;
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00018244 File Offset: 0x00016444
		protected override void addFoliage(Vector3 position, Quaternion rotation, Vector3 scale, bool clearWhenBaked)
		{
			ResourceAsset resourceAsset = Assets.find<ResourceAsset>(this.resource);
			if (resourceAsset == null)
			{
				return;
			}
			if (this.UsesLegacyRotationAndScale)
			{
				resourceAsset.GetLegacyRotationAndScale(position, out rotation, out scale);
			}
			LevelGround.addSpawn(position, rotation, scale, resourceAsset.GUID, clearWhenBaked);
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x00018284 File Offset: 0x00016484
		protected override bool isPositionValid(Vector3 position, bool doCollisionChecks)
		{
			if (!VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsPositionBakeable(position, false, true, false))
			{
				return false;
			}
			if (doCollisionChecks)
			{
				int num = Physics.OverlapSphereNonAlloc(position, this.obstructionRadius, FoliageResourceInfoAsset.OBSTRUCTION_COLLIDERS, RayMasks.BLOCK_RESOURCE);
				for (int i = 0; i < num; i++)
				{
					ObjectAsset asset = LevelObjects.getAsset(FoliageResourceInfoAsset.OBSTRUCTION_COLLIDERS[i].transform);
					if (asset != null && !asset.isSnowshoe)
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x000182EC File Offset: 0x000164EC
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			this.resource = p.data.ParseStruct("Resource", default(AssetReference<ResourceAsset>));
			if (p.data.ContainsKey("Obstruction_Radius"))
			{
				this.obstructionRadius = p.data.ParseFloat("Obstruction_Radius", 0f);
			}
			this.UsesLegacyRotationAndScale = p.data.ParseBool("Legacy_Rotation_and_Scale", true);
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00018363 File Offset: 0x00016563
		protected virtual void resetResource()
		{
			this.obstructionRadius = 4f;
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00018370 File Offset: 0x00016570
		public FoliageResourceInfoAsset()
		{
			this.resetResource();
		}

		// Token: 0x0400025F RID: 607
		private static readonly Collider[] OBSTRUCTION_COLLIDERS = new Collider[16];

		// Token: 0x04000260 RID: 608
		public AssetReference<ResourceAsset> resource;

		// Token: 0x04000261 RID: 609
		public float obstructionRadius;
	}
}
