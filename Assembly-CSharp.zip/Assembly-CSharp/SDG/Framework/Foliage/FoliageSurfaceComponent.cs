﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F8 RID: 248
	public class FoliageSurfaceComponent : MonoBehaviour, IFoliageSurface
	{
		/// <summary>
		/// Nelson 2024-11-11: Collider may have been destroyed by an unexpected mod script configuration (or perhaps
		/// simply missing in the first place). Should fix/prevent public issue #4749.
		/// </summary>
		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x00019AC1 File Offset: 0x00017CC1
		public bool IsValidFoliageSurface
		{
			get
			{
				return this.surfaceCollider != null;
			}
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00019AD0 File Offset: 0x00017CD0
		public FoliageBounds getFoliageSurfaceBounds()
		{
			bool activeSelf = base.gameObject.activeSelf;
			if (!activeSelf)
			{
				base.gameObject.SetActive(true);
			}
			FoliageBounds result = new FoliageBounds(this.surfaceCollider.bounds);
			if (!activeSelf)
			{
				base.gameObject.SetActive(false);
			}
			return result;
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00019B18 File Offset: 0x00017D18
		public bool getFoliageSurfaceInfo(Vector3 position, out Vector3 surfacePosition, out Vector3 surfaceNormal)
		{
			RaycastHit raycastHit;
			if (this.surfaceCollider.Raycast(new Ray(position, Vector3.down), out raycastHit, 1024f))
			{
				surfacePosition = raycastHit.point;
				surfaceNormal = raycastHit.normal;
				return true;
			}
			surfacePosition = Vector3.zero;
			surfaceNormal = Vector3.up;
			return false;
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x00019B78 File Offset: 0x00017D78
		public void bakeFoliageSurface(FoliageBakeSettings bakeSettings, FoliageTile foliageTile)
		{
			FoliageInfoCollectionAsset foliageInfoCollectionAsset = Assets.find<FoliageInfoCollectionAsset>(this.foliage);
			if (foliageInfoCollectionAsset == null)
			{
				return;
			}
			bool activeSelf = base.gameObject.activeSelf;
			if (!activeSelf)
			{
				base.gameObject.SetActive(true);
			}
			Bounds worldBounds = foliageTile.worldBounds;
			Vector3 min = worldBounds.min;
			Vector3 max = worldBounds.max;
			Bounds bounds = this.surfaceCollider.bounds;
			Vector3 min2 = bounds.min;
			Vector3 max2 = bounds.max;
			foliageInfoCollectionAsset.bakeFoliage(bakeSettings, this, new Bounds
			{
				min = new Vector3(Mathf.Max(min.x, min2.x), min2.y, Mathf.Max(min.z, min2.z)),
				max = new Vector3(Mathf.Min(max.x, max2.x), max2.y, Mathf.Min(max.z, max2.z))
			}, 1f);
			if (!activeSelf)
			{
				base.gameObject.SetActive(false);
			}
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00019C78 File Offset: 0x00017E78
		protected void OnEnable()
		{
			if (this.isRegistered)
			{
				return;
			}
			this.isRegistered = true;
			FoliageSystem.addSurface(this);
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x00019C90 File Offset: 0x00017E90
		protected void OnDestroy()
		{
			if (!this.isRegistered)
			{
				return;
			}
			this.isRegistered = false;
			FoliageSystem.removeSurface(this);
		}

		// Token: 0x04000284 RID: 644
		public AssetReference<FoliageInfoCollectionAsset> foliage;

		// Token: 0x04000285 RID: 645
		public Collider surfaceCollider;

		// Token: 0x04000286 RID: 646
		protected bool isRegistered;
	}
}
