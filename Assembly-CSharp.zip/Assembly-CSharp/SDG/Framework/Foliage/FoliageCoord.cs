﻿using System;
using SDG.Framework.IO.FormattedFiles;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000EB RID: 235
	public struct FoliageCoord : IFormattedFileReadable, IFormattedFileWritable, IEquatable<FoliageCoord>
	{
		// Token: 0x060005D0 RID: 1488 RVA: 0x00016DCE File Offset: 0x00014FCE
		public void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			this.x = reader.readValue<int>("X");
			this.y = reader.readValue<int>("Y");
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x00016DFA File Offset: 0x00014FFA
		public void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.writeValue<int>("X", this.x);
			writer.writeValue<int>("Y", this.y);
			writer.endObject();
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x00016E2A File Offset: 0x0001502A
		public static bool operator ==(FoliageCoord a, FoliageCoord b)
		{
			return a.x == b.x && a.y == b.y;
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x00016E4A File Offset: 0x0001504A
		public static bool operator !=(FoliageCoord a, FoliageCoord b)
		{
			return !(a == b);
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x00016E58 File Offset: 0x00015058
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			FoliageCoord foliageCoord = (FoliageCoord)obj;
			return this.x == foliageCoord.x && this.y == foliageCoord.y;
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00016E8F File Offset: 0x0001508F
		public override int GetHashCode()
		{
			return this.x ^ this.y;
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x00016EA0 File Offset: 0x000150A0
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"(",
				this.x.ToString(),
				", ",
				this.y.ToString(),
				")"
			});
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x00016EEC File Offset: 0x000150EC
		public bool Equals(FoliageCoord other)
		{
			return this.x == other.x && this.y == other.y;
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x00016F0C File Offset: 0x0001510C
		public FoliageCoord(int new_x, int new_y)
		{
			this.x = new_x;
			this.y = new_y;
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x00016F1C File Offset: 0x0001511C
		public FoliageCoord(Vector3 position)
		{
			this.x = Mathf.FloorToInt(position.x / FoliageSystem.TILE_SIZE);
			this.y = Mathf.FloorToInt(position.z / FoliageSystem.TILE_SIZE);
		}

		// Token: 0x04000231 RID: 561
		public static FoliageCoord ZERO = new FoliageCoord(0, 0);

		// Token: 0x04000232 RID: 562
		public int x;

		// Token: 0x04000233 RID: 563
		public int y;
	}
}
