﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000100 RID: 256
	internal struct FoliageInstancingBatchData
	{
		// Token: 0x0400028B RID: 651
		public Matrix4x4[] list;

		// Token: 0x0400028C RID: 652
		public int count;
	}
}
