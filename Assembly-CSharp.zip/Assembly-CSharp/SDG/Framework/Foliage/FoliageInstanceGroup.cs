﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F0 RID: 240
	public struct FoliageInstanceGroup
	{
		// Token: 0x060005FD RID: 1533 RVA: 0x00017989 File Offset: 0x00015B89
		public FoliageInstanceGroup(AssetReference<FoliageInstancedMeshInfoAsset> newAssetReference, Matrix4x4 newMatrix, bool newClearWhenBaked)
		{
			this.assetReference = newAssetReference;
			this.matrix = newMatrix;
			this.clearWhenBaked = newClearWhenBaked;
		}

		// Token: 0x0400024F RID: 591
		public AssetReference<FoliageInstancedMeshInfoAsset> assetReference;

		// Token: 0x04000250 RID: 592
		public Matrix4x4 matrix;

		// Token: 0x04000251 RID: 593
		public bool clearWhenBaked;
	}
}
