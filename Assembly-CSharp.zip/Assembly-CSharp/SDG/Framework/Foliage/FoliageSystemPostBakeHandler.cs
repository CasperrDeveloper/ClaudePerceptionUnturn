﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FE RID: 254
	// (Invoke) Token: 0x0600066A RID: 1642
	public delegate void FoliageSystemPostBakeHandler();
}
