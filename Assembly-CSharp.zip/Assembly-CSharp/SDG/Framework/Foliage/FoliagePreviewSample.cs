﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F3 RID: 243
	public struct FoliagePreviewSample
	{
		// Token: 0x0600061A RID: 1562 RVA: 0x00018133 File Offset: 0x00016333
		public FoliagePreviewSample(Vector3 newPosition, Color newColor)
		{
			this.position = newPosition;
			this.color = newColor;
		}

		// Token: 0x0400025D RID: 605
		public Vector3 position;

		// Token: 0x0400025E RID: 606
		public Color color;
	}
}
