﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using SDG.Framework.Devkit;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	/// <summary>
	/// Replacement foliage storage with all tiles in a single file.
	///
	/// In the level editor all tiles are loaded into memory, whereas during gameplay the relevant tiles
	/// are loaded as-needed by a worker thread.
	/// </summary>
	// Token: 0x020000F7 RID: 247
	public class FoliageStorageV2 : IFoliageStorage
	{
		// Token: 0x0600063F RID: 1599 RVA: 0x000188F8 File Offset: 0x00016AF8
		public void Initialize()
		{
			this.tileBlobOffsets.Clear();
			this.tileBlobHeaderOffset = 0L;
			this.assetsHeader.Clear();
			this.loadedFileVersion = 0;
			string path = Level.info.path + "/Foliage.blob";
			if (File.Exists(path))
			{
				this.readerStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				this.reader = new BinaryReader(this.readerStream);
				using (SHA1Stream sha1Stream = new SHA1Stream(this.readerStream))
				{
					using (BinaryReader binaryReader = new BinaryReader(sha1Stream))
					{
						this.loadedFileVersion = binaryReader.ReadInt32();
						int num = binaryReader.ReadInt32();
						UnturnedLog.info("Found {0} foliage v2 tiles", new object[]
						{
							num
						});
						for (int i = 0; i < num; i++)
						{
							int new_x = binaryReader.ReadInt32();
							int new_y = binaryReader.ReadInt32();
							long value = binaryReader.ReadInt64();
							this.tileBlobOffsets.Add(new FoliageCoord(new_x, new_y), value);
						}
						if (this.loadedFileVersion >= 2)
						{
							bool flag = Level.isEditor && EditorAssetRedirector.HasRedirects;
							int num2 = binaryReader.ReadInt32();
							UnturnedLog.info("Found {0} foliage used assets in header", new object[]
							{
								num2
							});
							this.assetsHeader.Capacity = num2;
							for (int j = 0; j < num2; j++)
							{
								GuidBuffer guidBuffer = default(GuidBuffer);
								binaryReader.Read(this.GUID_BUFFER, 0, 16);
								guidBuffer.Read(this.GUID_BUFFER, 0);
								AssetReference<FoliageInstancedMeshInfoAsset> referenceTo = new AssetReference<FoliageInstancedMeshInfoAsset>(guidBuffer.GUID);
								if (flag)
								{
									FoliageInstancedMeshInfoAsset foliageInstancedMeshInfoAsset = EditorAssetRedirector.Redirect<FoliageInstancedMeshInfoAsset>(referenceTo.GUID);
									if (foliageInstancedMeshInfoAsset != null)
									{
										referenceTo = foliageInstancedMeshInfoAsset.getReferenceTo<FoliageInstancedMeshInfoAsset>();
									}
								}
								this.assetsHeader.Add(referenceTo);
								if (referenceTo.Find() == null)
								{
									ClientAssetIntegrity.ServerAddKnownMissingAsset(referenceTo.GUID, string.Format("Foliage asset {0} of {1}", j + 1, num2));
								}
							}
						}
						this.tileBlobHeaderOffset = this.readerStream.Position;
						Level.includeHash("Foliage", sha1Stream.Hash);
					}
				}
				if (Level.isEditor && this.loadedFileVersion < 2)
				{
					LevelHierarchy.MarkDirty();
				}
				if (!Level.isEditor && !Dedicator.IsDedicatedServer)
				{
					this.shouldWorkerThreadContinue = true;
					this.lockObject = new object();
					this.workerThread = new Thread(new ThreadStart(this.WorkerThreadMain));
					this.workerThread.Name = "Foliage Storage Thread";
					this.workerThread.Start();
				}
			}
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x00018BAC File Offset: 0x00016DAC
		public void Shutdown()
		{
			if (this.workerThread != null)
			{
				this.shouldWorkerThreadContinue = false;
				return;
			}
			this.CloseReader();
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00018BC4 File Offset: 0x00016DC4
		public void TileBecameRelevantToViewer(FoliageTile tile)
		{
			if (!this.hasAllTilesInMemory && !this.mainThreadTilesWithRelevancyChanges.Contains(tile))
			{
				this.mainThreadTilesWithRelevancyChanges.Add(tile);
			}
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x00018BE8 File Offset: 0x00016DE8
		public void TileNoLongerRelevantToViewer(FoliageTile tile)
		{
			if (!this.hasAllTilesInMemory)
			{
				tile.clearAndReleaseInstances();
				if (!this.mainThreadTilesWithRelevancyChanges.Contains(tile))
				{
					this.mainThreadTilesWithRelevancyChanges.Add(tile);
				}
			}
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x00018C14 File Offset: 0x00016E14
		public void Update()
		{
			if (this.workerThread == null)
			{
				return;
			}
			FoliageStorageV2.TileData tileData = null;
			object obj = this.lockObject;
			lock (obj)
			{
				foreach (FoliageTile foliageTile in this.mainThreadTilesWithRelevancyChanges)
				{
					if (foliageTile.isRelevantToViewer)
					{
						if (!this.workerThreadTileQueue.Contains(foliageTile.coord))
						{
							this.workerThreadTileQueue.AddLast(foliageTile.coord);
						}
					}
					else
					{
						this.workerThreadTileQueue.Remove(foliageTile.coord);
					}
				}
				if (this.tileDataFromWorkerThread.Count > 0)
				{
					tileData = this.tileDataFromWorkerThread.Dequeue();
				}
				if (this.mainThreadTileDataFromPreviousUpdate != null)
				{
					this.tileDataFromMainThread.Add(this.mainThreadTileDataFromPreviousUpdate);
					this.mainThreadTileDataFromPreviousUpdate = null;
				}
			}
			this.mainThreadTilesWithRelevancyChanges.Clear();
			if (tileData != null)
			{
				FoliageTile tile = FoliageSystem.getTile(tileData.coord);
				if (tile != null && tile.isRelevantToViewer)
				{
					tile.clearAndReleaseInstances();
					this.DeserializeTileOnMainThreadUsingDataFromWorkerThread(tile, tileData);
				}
				this.mainThreadTileDataFromPreviousUpdate = tileData;
			}
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x00018D54 File Offset: 0x00016F54
		public void EditorLoadAllTiles(IEnumerable<FoliageTile> tiles)
		{
			this.hasAllTilesInMemory = true;
			foreach (FoliageTile tile in tiles)
			{
				this.DeserializeTileOnMainThread(tile);
			}
			this.CloseReader();
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x00018DAC File Offset: 0x00016FAC
		public void EditorSaveAllTiles(IEnumerable<FoliageTile> tiles)
		{
			string path = Level.info.path + "/Foliage.blob";
			if (File.Exists(path) && this.loadedFileVersion >= 2)
			{
				bool flag = false;
				using (IEnumerator<FoliageTile> enumerator = tiles.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.hasUnsavedChanges)
						{
							flag = true;
							break;
						}
					}
				}
				if (!flag)
				{
					return;
				}
			}
			List<byte[]> list = new List<byte[]>();
			Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, int> assetRefToIndex = new Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, int>();
			this.tileBlobOffsets.Clear();
			this.assetsHeader.Clear();
			long num = 0L;
			foreach (FoliageTile foliageTile in tiles)
			{
				if (!foliageTile.isEmpty())
				{
					byte[] array = this.SerializeTileOnMainThread(foliageTile, assetRefToIndex);
					if (array != null && array.Length != 0)
					{
						list.Add(array);
						this.tileBlobOffsets.Add(foliageTile.coord, num);
						num += (long)array.Length;
					}
				}
			}
			if (list.Count != this.tileBlobOffsets.Count)
			{
				UnturnedLog.error("Foliage blob count ({0}) does not match offset count ({1})", new object[]
				{
					list.Count,
					this.tileBlobOffsets.Count
				});
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
			{
				BinaryWriter binaryWriter = new BinaryWriter(fileStream);
				binaryWriter.Write(2);
				binaryWriter.Write(this.tileBlobOffsets.Count);
				foreach (KeyValuePair<FoliageCoord, long> keyValuePair in this.tileBlobOffsets)
				{
					binaryWriter.Write(keyValuePair.Key.x);
					binaryWriter.Write(keyValuePair.Key.y);
					binaryWriter.Write(keyValuePair.Value);
				}
				UnturnedLog.info(string.Format("Foliage saving with {0} assets in header", this.assetsHeader.Count));
				binaryWriter.Write(this.assetsHeader.Count);
				foreach (AssetReference<FoliageInstancedMeshInfoAsset> assetReference in this.assetsHeader)
				{
					GuidBuffer guidBuffer = new GuidBuffer(assetReference.GUID);
					guidBuffer.Write(this.GUID_BUFFER, 0);
					binaryWriter.Write(this.GUID_BUFFER, 0, 16);
				}
				foreach (byte[] buffer in list)
				{
					binaryWriter.Write(buffer);
				}
			}
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x000190E4 File Offset: 0x000172E4
		private FoliageStorageV2.TileData GetTileDataOnWorkerThread(FoliageCoord coord)
		{
			FoliageStorageV2.TileData tileData;
			if (this.tileDataPool.Count > 0)
			{
				tileData = this.tileDataPool.Pop();
			}
			else
			{
				tileData = new FoliageStorageV2.TileData();
				tileData.perAssetData = new List<FoliageStorageV2.TilePerAssetData>();
			}
			tileData.coord = coord;
			long num;
			if (this.tileBlobOffsets.TryGetValue(coord, out num))
			{
				this.readerStream.Position = this.tileBlobHeaderOffset + num;
				int num2 = this.reader.ReadInt32();
				tileData.perAssetData.Capacity = Mathf.Max(tileData.perAssetData.Capacity, num2);
				for (int i = 0; i < num2; i++)
				{
					AssetReference<FoliageInstancedMeshInfoAsset> assetRef;
					if (this.loadedFileVersion >= 2)
					{
						int num3 = this.reader.ReadInt32();
						if (num3 >= 0 && num3 < this.assetsHeader.Count)
						{
							assetRef = this.assetsHeader[num3];
						}
						else
						{
							assetRef = AssetReference<FoliageInstancedMeshInfoAsset>.invalid;
						}
					}
					else
					{
						GuidBuffer guidBuffer = default(GuidBuffer);
						this.readerStream.Read(this.GUID_BUFFER, 0, 16);
						guidBuffer.Read(this.GUID_BUFFER, 0);
						assetRef = new AssetReference<FoliageInstancedMeshInfoAsset>(guidBuffer.GUID);
					}
					int num4 = this.reader.ReadInt32();
					FoliageStorageV2.TilePerAssetData tilePerAssetData;
					if (this.perAssetDataPool.Count > 0)
					{
						tilePerAssetData = this.perAssetDataPool.Pop();
						tilePerAssetData.matrices.Capacity = Mathf.Max(tilePerAssetData.matrices.Capacity, num4);
						tilePerAssetData.clearWhenBaked.Capacity = Mathf.Max(tilePerAssetData.clearWhenBaked.Capacity, num4);
					}
					else
					{
						tilePerAssetData = new FoliageStorageV2.TilePerAssetData();
						tilePerAssetData.matrices = new List<Matrix4x4>(num4);
						tilePerAssetData.clearWhenBaked = new List<bool>(num4);
					}
					tilePerAssetData.assetRef = assetRef;
					for (int j = 0; j < num4; j++)
					{
						Matrix4x4 item = default(Matrix4x4);
						for (int k = 0; k < 16; k++)
						{
							item[k] = this.reader.ReadSingle();
						}
						tilePerAssetData.matrices.Add(item);
						bool item2 = this.reader.ReadBoolean();
						tilePerAssetData.clearWhenBaked.Add(item2);
					}
					if (num4 > 0)
					{
						tileData.perAssetData.Add(tilePerAssetData);
					}
				}
			}
			return tileData;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x00019310 File Offset: 0x00017510
		private void DeserializeTileOnMainThreadUsingDataFromWorkerThread(FoliageTile tile, FoliageStorageV2.TileData tileData)
		{
			foreach (FoliageStorageV2.TilePerAssetData tilePerAssetData in tileData.perAssetData)
			{
				if (tilePerAssetData.assetRef.isNull)
				{
					UnturnedLog.error(string.Format("Foliage loaded invalid asset ref for tile {0}", tile.coord));
				}
				else
				{
					FoliageInstanceList orAddList = tile.getOrAddList(tilePerAssetData.assetRef);
					for (int i = 0; i < tilePerAssetData.matrices.Count; i++)
					{
						Matrix4x4 newMatrix = tilePerAssetData.matrices[i];
						bool newClearWhenBaked = tilePerAssetData.clearWhenBaked[i];
						if (!tile.isInstanceCut(newMatrix.GetPosition()))
						{
							orAddList.addInstanceAppend(new FoliageInstanceGroup(tilePerAssetData.assetRef, newMatrix, newClearWhenBaked));
						}
					}
				}
			}
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x000193F0 File Offset: 0x000175F0
		private void DeserializeTileOnMainThread(FoliageTile tile)
		{
			long num;
			if (this.tileBlobOffsets.TryGetValue(tile.coord, out num))
			{
				this.readerStream.Position = this.tileBlobHeaderOffset + num;
				int num2 = this.reader.ReadInt32();
				for (int i = 0; i < num2; i++)
				{
					AssetReference<FoliageInstancedMeshInfoAsset> assetReference;
					bool flag;
					if (this.loadedFileVersion >= 2)
					{
						int num3 = this.reader.ReadInt32();
						if (num3 >= 0 && num3 < this.assetsHeader.Count)
						{
							assetReference = this.assetsHeader[num3];
							flag = !assetReference.isNull;
						}
						else
						{
							assetReference = AssetReference<FoliageInstancedMeshInfoAsset>.invalid;
							UnturnedLog.error(string.Format("Foliage loaded invalid asset index {0} for tile {1}", num3, tile.coord));
							flag = false;
						}
					}
					else
					{
						GuidBuffer guidBuffer = default(GuidBuffer);
						this.readerStream.Read(this.GUID_BUFFER, 0, 16);
						guidBuffer.Read(this.GUID_BUFFER, 0);
						assetReference = new AssetReference<FoliageInstancedMeshInfoAsset>(guidBuffer.GUID);
						flag = !assetReference.isNull;
					}
					FoliageInstanceList orAddList = tile.getOrAddList(assetReference);
					int num4 = this.reader.ReadInt32();
					for (int j = 0; j < num4; j++)
					{
						Matrix4x4 newMatrix = default(Matrix4x4);
						for (int k = 0; k < 16; k++)
						{
							newMatrix[k] = this.reader.ReadSingle();
						}
						bool newClearWhenBaked = this.reader.ReadBoolean();
						if (flag && !tile.isInstanceCut(newMatrix.GetPosition()))
						{
							orAddList.addInstanceAppend(new FoliageInstanceGroup(assetReference, newMatrix, newClearWhenBaked));
						}
					}
				}
			}
			tile.updateBounds();
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00019588 File Offset: 0x00017788
		private int GetOrAddAssetIndex(AssetReference<FoliageInstancedMeshInfoAsset> assetRef, Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, int> assetRefToIndex)
		{
			int result;
			if (assetRefToIndex.TryGetValue(assetRef, out result))
			{
				return result;
			}
			int count = this.assetsHeader.Count;
			this.assetsHeader.Add(assetRef);
			assetRefToIndex.Add(assetRef, count);
			return count;
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x000195C4 File Offset: 0x000177C4
		private byte[] SerializeTileOnMainThread(FoliageTile tile, Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, int> assetRefToIndex)
		{
			this.tileInstanceListsToSave.Clear();
			foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> item in tile.instances)
			{
				if (!item.Key.isNull && !item.Value.IsListEmpty())
				{
					if (!LevelObjects.preserveMissingAssets && item.Key.Find() == null)
					{
						UnturnedLog.info(string.Format("Discarding missing foliage asset {0} from tile {1}", item.Key, tile.coord));
					}
					else
					{
						this.tileInstanceListsToSave.Add(item);
					}
				}
			}
			if (this.tileInstanceListsToSave.Count < 1)
			{
				return null;
			}
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
				binaryWriter.Write(this.tileInstanceListsToSave.Count);
				foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.tileInstanceListsToSave)
				{
					int orAddAssetIndex = this.GetOrAddAssetIndex(keyValuePair.Key, assetRefToIndex);
					binaryWriter.Write(orAddAssetIndex);
					int num = 0;
					foreach (List<Matrix4x4> list in keyValuePair.Value.matrices)
					{
						num += list.Count;
					}
					binaryWriter.Write(num);
					for (int i = 0; i < keyValuePair.Value.matrices.Count; i++)
					{
						List<Matrix4x4> list2 = keyValuePair.Value.matrices[i];
						List<bool> list3 = keyValuePair.Value.clearWhenBaked[i];
						for (int j = 0; j < list2.Count; j++)
						{
							Matrix4x4 matrix4x = list2[j];
							for (int k = 0; k < 16; k++)
							{
								binaryWriter.Write(matrix4x[k]);
							}
							bool value = list3[j];
							binaryWriter.Write(value);
						}
					}
				}
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00019870 File Offset: 0x00017A70
		private void CloseReader()
		{
			if (this.reader != null)
			{
				this.reader.Close();
				this.reader.Dispose();
				this.reader = null;
			}
			if (this.readerStream != null)
			{
				this.readerStream.Close();
				this.readerStream.Dispose();
				this.readerStream = null;
			}
		}

		/// <summary>
		/// Entry point for worker thread loop.
		/// </summary>
		// Token: 0x0600064C RID: 1612 RVA: 0x000198C8 File Offset: 0x00017AC8
		private void WorkerThreadMain()
		{
			this.perAssetDataPool = new Stack<FoliageStorageV2.TilePerAssetData>();
			this.tileDataPool = new Stack<FoliageStorageV2.TileData>();
			FoliageStorageV2.TileData tileData = null;
			while (this.shouldWorkerThreadContinue)
			{
				FoliageCoord coord = default(FoliageCoord);
				bool flag = false;
				object obj = this.lockObject;
				lock (obj)
				{
					if (this.workerThreadTileQueue.Count > 0)
					{
						coord = this.workerThreadTileQueue.First.Value;
						this.workerThreadTileQueue.RemoveFirst();
						flag = true;
					}
					if (tileData != null)
					{
						this.tileDataFromWorkerThread.Enqueue(tileData);
						tileData = null;
					}
					foreach (FoliageStorageV2.TileData tileData2 in this.tileDataFromMainThread)
					{
						foreach (FoliageStorageV2.TilePerAssetData tilePerAssetData in tileData2.perAssetData)
						{
							tilePerAssetData.matrices.Clear();
							tilePerAssetData.clearWhenBaked.Clear();
							this.perAssetDataPool.Push(tilePerAssetData);
						}
						tileData2.perAssetData.Clear();
						this.tileDataPool.Push(tileData2);
					}
					this.tileDataFromMainThread.Clear();
				}
				if (flag)
				{
					tileData = this.GetTileDataOnWorkerThread(coord);
				}
				Thread.Sleep(10);
			}
			this.CloseReader();
		}

		// Token: 0x0400026E RID: 622
		private List<KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList>> tileInstanceListsToSave = new List<KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList>>();

		// Token: 0x0400026F RID: 623
		private const int FOLIAGE_FILE_VERSION_INITIAL = 1;

		// Token: 0x04000270 RID: 624
		private const int FOLIAGE_FILE_VERSION_ADDED_ASSET_LIST_HEADER = 2;

		// Token: 0x04000271 RID: 625
		private const int FOLIAGE_FILE_VERSION_NEWEST = 2;

		// Token: 0x04000272 RID: 626
		private byte[] GUID_BUFFER = new byte[16];

		// Token: 0x04000273 RID: 627
		private FileStream readerStream;

		// Token: 0x04000274 RID: 628
		private BinaryReader reader;

		// Token: 0x04000275 RID: 629
		private bool hasAllTilesInMemory;

		/// <summary>
		/// Order is important because TileBecameRelevant is called from the closest tile outward.
		/// </summary>
		// Token: 0x04000276 RID: 630
		private List<FoliageTile> mainThreadTilesWithRelevancyChanges = new List<FoliageTile>();

		/// <summary>
		/// Offsets into blob for per-tile data.
		/// </summary>
		// Token: 0x04000277 RID: 631
		private Dictionary<FoliageCoord, long> tileBlobOffsets = new Dictionary<FoliageCoord, long>();

		/// <summary>
		/// Tiles save an index into this list rather than guid.
		/// </summary>
		// Token: 0x04000278 RID: 632
		private List<AssetReference<FoliageInstancedMeshInfoAsset>> assetsHeader = new List<AssetReference<FoliageInstancedMeshInfoAsset>>();

		// Token: 0x04000279 RID: 633
		private int loadedFileVersion;

		/// <summary>
		/// Offset from header data.
		/// </summary>
		// Token: 0x0400027A RID: 634
		private long tileBlobHeaderOffset;

		// Token: 0x0400027B RID: 635
		private Thread workerThread;

		// Token: 0x0400027C RID: 636
		private bool shouldWorkerThreadContinue;

		/// <summary>
		/// Ready to be released to the worker thread during the next lock.
		/// </summary>
		// Token: 0x0400027D RID: 637
		private FoliageStorageV2.TileData mainThreadTileDataFromPreviousUpdate;

		/// <summary>
		/// Mutex lock. Only used in the main thread Update loop and worker thread loop.
		/// </summary>
		// Token: 0x0400027E RID: 638
		private object lockObject;

		/// <summary>
		/// SHARED BY BOTH THREADS!
		/// Coordinates requested by main thread for worker thread to read.
		/// This is a list because while main thread is busy the worker thread can continue reading.
		/// </summary>
		// Token: 0x0400027F RID: 639
		private LinkedList<FoliageCoord> workerThreadTileQueue = new LinkedList<FoliageCoord>();

		/// <summary>
		/// SHARED BY BOTH THREADS!
		/// Tiles read by worker thread ready to be copied into actual foliage tiles on main thread.
		/// </summary>
		// Token: 0x04000280 RID: 640
		private Queue<FoliageStorageV2.TileData> tileDataFromWorkerThread = new Queue<FoliageStorageV2.TileData>();

		/// <summary>
		/// SHARED BY BOTH THREADS!
		/// Main thread has finished using this tile data and it can be released back to the pool on the worker thread.
		/// This is a list because main thread could have populated multiple foliage tiles while the worker thread was busy reading.
		/// </summary>
		// Token: 0x04000281 RID: 641
		private List<FoliageStorageV2.TileData> tileDataFromMainThread = new List<FoliageStorageV2.TileData>();

		/// <summary>
		/// Lifecycle:
		/// 1. Worker thread claims or allocates data.
		/// 2. Worker thread passes data to main thread.
		/// 3. Main thread copies data over to actual foliage tile.
		/// 4. Main thread passes data back to worker thread.
		/// 5. Worker thread releases data back to pool.
		/// </summary>
		// Token: 0x04000282 RID: 642
		private Stack<FoliageStorageV2.TilePerAssetData> perAssetDataPool;

		// Token: 0x04000283 RID: 643
		private Stack<FoliageStorageV2.TileData> tileDataPool;

		/// <summary>
		/// Data-only FoliageInstanceList shared between threads.
		/// </summary>
		// Token: 0x0200090D RID: 2317
		private class TilePerAssetData
		{
			// Token: 0x040036D6 RID: 14038
			public AssetReference<FoliageInstancedMeshInfoAsset> assetRef;

			// Token: 0x040036D7 RID: 14039
			public List<Matrix4x4> matrices;

			// Token: 0x040036D8 RID: 14040
			public List<bool> clearWhenBaked;
		}

		/// <summary>
		/// Data-only FoliageTile shared between threads.
		/// </summary>
		// Token: 0x0200090E RID: 2318
		private class TileData
		{
			// Token: 0x040036D9 RID: 14041
			public FoliageCoord coord;

			// Token: 0x040036DA RID: 14042
			public List<FoliageStorageV2.TilePerAssetData> perAssetData;
		}
	}
}
