﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FB RID: 251
	// (Invoke) Token: 0x0600065E RID: 1630
	public delegate void FoliageSystemPostBakeTileHandler(FoliageBakeSettings bakeSettings, FoliageTile foliageTile);
}
