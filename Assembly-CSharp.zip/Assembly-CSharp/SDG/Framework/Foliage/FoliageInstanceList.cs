﻿using System;
using System.Collections.Generic;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F1 RID: 241
	public class FoliageInstanceList : IPoolable
	{
		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x000179A0 File Offset: 0x00015BA0
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x000179A8 File Offset: 0x00015BA8
		public List<List<Matrix4x4>> matrices { get; protected set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x000179B1 File Offset: 0x00015BB1
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x000179B9 File Offset: 0x00015BB9
		public List<List<bool>> clearWhenBaked { get; protected set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x000179C2 File Offset: 0x00015BC2
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x000179CA File Offset: 0x00015BCA
		public bool isAssetLoaded { get; protected set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x000179D3 File Offset: 0x00015BD3
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x000179DB File Offset: 0x00015BDB
		public bool tileDither { get; protected set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x000179E4 File Offset: 0x00015BE4
		// (set) Token: 0x06000607 RID: 1543 RVA: 0x000179EC File Offset: 0x00015BEC
		public int sqrDrawDistance { get; protected set; }

		// Token: 0x06000608 RID: 1544 RVA: 0x000179F5 File Offset: 0x00015BF5
		public virtual void poolClaim()
		{
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x000179F8 File Offset: 0x00015BF8
		public virtual void poolRelease()
		{
			this.assetReference = AssetReference<FoliageInstancedMeshInfoAsset>.invalid;
			foreach (List<Matrix4x4> list in this.matrices)
			{
				ListPool<Matrix4x4>.release(list);
			}
			this.matrices.Clear();
			foreach (List<bool> list2 in this.clearWhenBaked)
			{
				ListPool<bool>.release(list2);
			}
			this.clearWhenBaked.Clear();
			this.isAssetLoaded = false;
			this.isLoadedAndRenderable = false;
			this.maxMatricesPerBatch = 511;
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00017AC4 File Offset: 0x00015CC4
		public bool IsListEmpty()
		{
			using (List<List<Matrix4x4>>.Enumerator enumerator = this.matrices.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Count > 0)
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00017B20 File Offset: 0x00015D20
		public virtual void clearGeneratedInstances()
		{
			for (int i = 0; i < this.matrices.Count; i++)
			{
				List<Matrix4x4> list = this.matrices[i];
				List<bool> list2 = this.clearWhenBaked[i];
				for (int j = list.Count - 1; j >= 0; j--)
				{
					if (list2[j])
					{
						list.RemoveAt(j);
						list2.RemoveAt(j);
					}
				}
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x00017B88 File Offset: 0x00015D88
		public virtual void applyScale()
		{
			FoliageInstancedMeshInfoAsset foliageInstancedMeshInfoAsset = Assets.find<FoliageInstancedMeshInfoAsset>(this.assetReference);
			if (foliageInstancedMeshInfoAsset == null)
			{
				return;
			}
			for (int i = 0; i < this.matrices.Count; i++)
			{
				List<Matrix4x4> list = this.matrices[i];
				List<bool> list2 = this.clearWhenBaked[i];
				for (int j = list.Count - 1; j >= 0; j--)
				{
					Matrix4x4 matrix4x = list[j];
					Vector3 position = matrix4x.GetPosition();
					Quaternion rotation = matrix4x.GetRotation();
					Vector3 randomScale = foliageInstancedMeshInfoAsset.randomScale;
					matrix4x = Matrix4x4.TRS(position, rotation, randomScale);
					list[j] = matrix4x;
				}
			}
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x00017C20 File Offset: 0x00015E20
		protected virtual void getOrAddLists(out List<Matrix4x4> matrixList, out List<bool> clearWhenBakedList)
		{
			matrixList = null;
			foreach (List<Matrix4x4> list in this.matrices)
			{
				if (list.Count < this.maxMatricesPerBatch)
				{
					matrixList = list;
					break;
				}
			}
			if (matrixList == null)
			{
				matrixList = ListPool<Matrix4x4>.claim();
				this.matrices.Add(matrixList);
			}
			clearWhenBakedList = null;
			foreach (List<bool> list2 in this.clearWhenBaked)
			{
				if (list2.Count < this.maxMatricesPerBatch)
				{
					clearWhenBakedList = list2;
					break;
				}
			}
			if (clearWhenBakedList == null)
			{
				clearWhenBakedList = ListPool<bool>.claim();
				this.clearWhenBaked.Add(clearWhenBakedList);
			}
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x00017D04 File Offset: 0x00015F04
		public virtual void addInstanceRandom(FoliageInstanceGroup group)
		{
			List<Matrix4x4> list;
			List<bool> list2;
			this.getOrAddLists(out list, out list2);
			int index = UnityEngine.Random.Range(0, list.Count);
			list.Insert(index, group.matrix);
			list2.Insert(index, group.clearWhenBaked);
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x00017D44 File Offset: 0x00015F44
		public virtual void addInstanceAppend(FoliageInstanceGroup group)
		{
			List<Matrix4x4> list;
			List<bool> list2;
			this.getOrAddLists(out list, out list2);
			list.Add(group.matrix);
			list2.Add(group.clearWhenBaked);
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x00017D74 File Offset: 0x00015F74
		public virtual void removeInstance(int matricesIndex, int matrixIndex)
		{
			List<Matrix4x4> list = this.matrices[matricesIndex];
			List<bool> list2 = this.clearWhenBaked[matricesIndex];
			list.RemoveAt(matrixIndex);
			list2.RemoveAt(matrixIndex);
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x00017DA8 File Offset: 0x00015FA8
		public virtual void loadAsset()
		{
			if (this.isAssetLoaded)
			{
				return;
			}
			this.isAssetLoaded = true;
			FoliageInstancedMeshInfoAsset foliageInstancedMeshInfoAsset = this.assetReference.Find();
			ClientAssetIntegrity.QueueRequest(this.assetReference.GUID, foliageInstancedMeshInfoAsset, "Foliage");
			if (foliageInstancedMeshInfoAsset == null)
			{
				return;
			}
			if (foliageInstancedMeshInfoAsset.IsClutter && Level.ShouldSkipInstantiatingClutter)
			{
				return;
			}
			if (Level.shouldUseHolidayRedirects)
			{
				AssetReference<FoliageInstancedMeshInfoAsset>? holidayRedirect = foliageInstancedMeshInfoAsset.getHolidayRedirect();
				if (holidayRedirect != null)
				{
					this.assetReference = holidayRedirect.Value;
					foliageInstancedMeshInfoAsset = this.assetReference.Find();
					if (foliageInstancedMeshInfoAsset == null)
					{
						return;
					}
				}
			}
			Mesh mesh = Assets.load<Mesh>(foliageInstancedMeshInfoAsset.mesh);
			Material material = Assets.load<Material>(foliageInstancedMeshInfoAsset.material);
			if (material != null)
			{
				if (!material.enableInstancing)
				{
					material.enableInstancing = true;
				}
				if (Assets.shouldValidateAssets)
				{
					if (material.shader.name.Contains("Uniform Scale"))
					{
						if (!foliageInstancedMeshInfoAsset.UniformScale)
						{
							foliageInstancedMeshInfoAsset.ReportAssetError("material has Uniform Scale enabled, but asset does not (instancing will not benefit from assumeuniformscaling!)");
						}
					}
					else if (foliageInstancedMeshInfoAsset.UniformScale)
					{
						foliageInstancedMeshInfoAsset.ReportAssetError("asset has Uniform Scale enabled, but material does not (instancing will not benefit from assumeuniformscaling!)");
					}
				}
			}
			bool castShadows = foliageInstancedMeshInfoAsset.castShadows;
			this.batchConfig = new FoliageInstancingBatchConfig(mesh, material, castShadows);
			this.tileDither = foliageInstancedMeshInfoAsset.tileDither;
			if (foliageInstancedMeshInfoAsset.drawDistance == -1)
			{
				this.sqrDrawDistance = -1;
			}
			else
			{
				this.sqrDrawDistance = foliageInstancedMeshInfoAsset.drawDistance * foliageInstancedMeshInfoAsset.drawDistance;
			}
			this.isLoadedAndRenderable = (mesh != null && material != null);
			this.maxMatricesPerBatch = (foliageInstancedMeshInfoAsset.UniformScale ? 1023 : 511);
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00017F24 File Offset: 0x00016124
		public FoliageInstanceList()
		{
			this.matrices = new List<List<Matrix4x4>>(1);
			this.clearWhenBaked = new List<List<bool>>(1);
		}

		// Token: 0x04000252 RID: 594
		public AssetReference<FoliageInstancedMeshInfoAsset> assetReference;

		// Token: 0x04000255 RID: 597
		internal bool isLoadedAndRenderable;

		// Token: 0x04000256 RID: 598
		internal int maxMatricesPerBatch;

		// Token: 0x04000258 RID: 600
		internal FoliageInstancingBatchConfig batchConfig;
	}
}
