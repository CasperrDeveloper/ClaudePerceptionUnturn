﻿using System;
using System.Collections.Generic;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.Landscapes;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000102 RID: 258
	public class FoliageTile : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060006AD RID: 1709 RVA: 0x0001BF11 File Offset: 0x0001A111
		// (set) Token: 0x060006AE RID: 1710 RVA: 0x0001BF19 File Offset: 0x0001A119
		public FoliageCoord coord
		{
			get
			{
				return this._coord;
			}
			protected set
			{
				this._coord = value;
				this.updateBounds();
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x0001BF28 File Offset: 0x0001A128
		// (set) Token: 0x060006B0 RID: 1712 RVA: 0x0001BF30 File Offset: 0x0001A130
		public Bounds worldBounds { get; protected set; }

		// Token: 0x060006B1 RID: 1713 RVA: 0x0001BF39 File Offset: 0x0001A139
		[Obsolete]
		public void addCut(IShapeVolume cut)
		{
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x0001BF3C File Offset: 0x0001A13C
		internal void AddCut(FoliageCut cut)
		{
			this.cuts.Add(cut);
			foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
			{
				FoliageInstanceList value = keyValuePair.Value;
				for (int i = 0; i < value.matrices.Count; i++)
				{
					List<Matrix4x4> list = value.matrices[i];
					List<bool> list2 = value.clearWhenBaked[i];
					for (int j = list.Count - 1; j >= 0; j--)
					{
						if (cut.ContainsPoint(list[j].GetPosition()))
						{
							list.RemoveAt(j);
							list2.RemoveAt(j);
						}
					}
				}
			}
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x0001C018 File Offset: 0x0001A218
		internal void RemoveCut(FoliageCut cut)
		{
			this.cuts.RemoveFast(cut);
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x0001C028 File Offset: 0x0001A228
		public bool isInstanceCut(Vector3 point)
		{
			using (List<FoliageCut>.Enumerator enumerator = this.cuts.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.ContainsPoint(point))
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Does this tile contain any placed foliage?
		/// </summary>
		// Token: 0x060006B5 RID: 1717 RVA: 0x0001C084 File Offset: 0x0001A284
		public bool isEmpty()
		{
			foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
			{
				if (!keyValuePair.Value.IsListEmpty())
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x0001C0E8 File Offset: 0x0001A2E8
		public FoliageInstanceList getOrAddList(AssetReference<FoliageInstancedMeshInfoAsset> assetReference)
		{
			FoliageInstanceList foliageInstanceList;
			if (!this.instances.TryGetValue(assetReference, out foliageInstanceList))
			{
				foliageInstanceList = PoolablePool<FoliageInstanceList>.claim();
				foliageInstanceList.assetReference = assetReference;
				foliageInstanceList.loadAsset();
				this.instances.Add(assetReference, foliageInstanceList);
			}
			return foliageInstanceList;
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x0001C126 File Offset: 0x0001A326
		public void addInstance(FoliageInstanceGroup instance)
		{
			this.getOrAddList(instance.assetReference).addInstanceRandom(instance);
			this.updateBounds();
			this.hasUnsavedChanges = true;
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x0001C147 File Offset: 0x0001A347
		public void removeInstance(FoliageInstanceList list, int matricesIndex, int matrixIndex)
		{
			list.removeInstance(matricesIndex, matrixIndex);
			this.hasUnsavedChanges = true;
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x0001C158 File Offset: 0x0001A358
		public void clearAndReleaseInstances()
		{
			if (this.instances.Count > 0)
			{
				foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
				{
					PoolablePool<FoliageInstanceList>.release(keyValuePair.Value);
				}
			}
			this.instances.Clear();
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x0001C1CC File Offset: 0x0001A3CC
		public void clearGeneratedInstances()
		{
			foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
			{
				keyValuePair.Value.clearGeneratedInstances();
			}
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x0001C224 File Offset: 0x0001A424
		public void applyScale()
		{
			foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
			{
				keyValuePair.Value.applyScale();
			}
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x0001C27C File Offset: 0x0001A47C
		public virtual void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			this.coord = reader.readValue<FoliageCoord>("Coord");
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x0001C297 File Offset: 0x0001A497
		public virtual void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			writer.writeValue<FoliageCoord>("Coord", this.coord);
			writer.endObject();
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x0001C2B8 File Offset: 0x0001A4B8
		public void updateBounds()
		{
			if (this.instances.Count > 0)
			{
				float num = Landscape.TILE_HEIGHT;
				float num2 = -Landscape.TILE_HEIGHT;
				foreach (KeyValuePair<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> keyValuePair in this.instances)
				{
					foreach (List<Matrix4x4> list in keyValuePair.Value.matrices)
					{
						foreach (Matrix4x4 matrix4x in list)
						{
							float m = matrix4x.m13;
							if (m < num)
							{
								num = m;
							}
							if (m > num2)
							{
								num2 = m;
							}
						}
					}
				}
				float num3 = num2 - num;
				this.worldBounds = new Bounds(new Vector3((float)this.coord.x * FoliageSystem.TILE_SIZE + FoliageSystem.TILE_SIZE / 2f, num + num3 / 2f, (float)this.coord.y * FoliageSystem.TILE_SIZE + FoliageSystem.TILE_SIZE / 2f), new Vector3(FoliageSystem.TILE_SIZE, num3, FoliageSystem.TILE_SIZE));
				return;
			}
			this.worldBounds = new Bounds(new Vector3((float)this.coord.x * FoliageSystem.TILE_SIZE + FoliageSystem.TILE_SIZE / 2f, 0f, (float)this.coord.y * FoliageSystem.TILE_SIZE + FoliageSystem.TILE_SIZE / 2f), new Vector3(FoliageSystem.TILE_SIZE, Landscape.TILE_HEIGHT, FoliageSystem.TILE_SIZE));
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x0001C484 File Offset: 0x0001A684
		public FoliageTile(FoliageCoord newCoord)
		{
			this.instances = new Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList>();
			this.coord = newCoord;
			this.cuts = new List<FoliageCut>();
		}

		// Token: 0x040002B1 RID: 689
		protected FoliageCoord _coord;

		// Token: 0x040002B3 RID: 691
		public Dictionary<AssetReference<FoliageInstancedMeshInfoAsset>, FoliageInstanceList> instances;

		// Token: 0x040002B4 RID: 692
		public bool hasUnsavedChanges;

		// Token: 0x040002B5 RID: 693
		public bool isRelevantToViewer;

		// Token: 0x040002B6 RID: 694
		private List<FoliageCut> cuts;
	}
}
