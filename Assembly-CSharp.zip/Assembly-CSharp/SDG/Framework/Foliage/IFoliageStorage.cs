﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Foliage
{
	/// <summary>
	/// Responsible for reading and writing persistent foliage data.
	/// </summary>
	// Token: 0x02000107 RID: 263
	public interface IFoliageStorage
	{
		/// <summary>
		/// Called after creating instance for level, prior to any loading.
		/// Not called when creating the auto-upgrade instance for editorSaveAllTiles.
		/// </summary>
		// Token: 0x060006D1 RID: 1745
		void Initialize();

		/// <summary>
		/// Called prior to destroying instance.
		/// </summary>
		// Token: 0x060006D2 RID: 1746
		void Shutdown();

		/// <summary>
		/// Called when tile wants to be drawn.
		/// </summary>
		// Token: 0x060006D3 RID: 1747
		void TileBecameRelevantToViewer(FoliageTile tile);

		/// <summary>
		/// Called when tile no longer wants to be drawn.
		/// </summary>
		// Token: 0x060006D4 RID: 1748
		void TileNoLongerRelevantToViewer(FoliageTile tile);

		/// <summary>
		/// Called during Unity's Update loop.
		/// </summary>
		// Token: 0x060006D5 RID: 1749
		void Update();

		/// <summary>
		/// Load known tiles during level load.
		/// </summary>
		// Token: 0x060006D6 RID: 1750
		void EditorLoadAllTiles(IEnumerable<FoliageTile> tiles);

		/// <summary>
		/// Save tiles during level save. 
		/// </summary>
		// Token: 0x060006D7 RID: 1751
		void EditorSaveAllTiles(IEnumerable<FoliageTile> tiles);
	}
}
