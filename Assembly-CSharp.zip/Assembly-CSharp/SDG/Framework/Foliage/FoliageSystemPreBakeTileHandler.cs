﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FA RID: 250
	// (Invoke) Token: 0x0600065A RID: 1626
	public delegate void FoliageSystemPreBakeTileHandler(FoliageBakeSettings bakeSettings, FoliageTile foliageTile);
}
