﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000EE RID: 238
	public class FoliageInfoCollectionAsset : Asset
	{
		// Token: 0x060005F0 RID: 1520 RVA: 0x00017580 File Offset: 0x00015780
		public virtual void bakeFoliage(FoliageBakeSettings bakeSettings, IFoliageSurface surface, Bounds bounds, float weight)
		{
			foreach (FoliageInfoCollectionAsset.FoliageInfoCollectionElement foliageInfoCollectionElement in this.elements)
			{
				FoliageInfoAsset foliageInfoAsset = Assets.find<FoliageInfoAsset>(foliageInfoCollectionElement.asset);
				if (foliageInfoAsset != null)
				{
					foliageInfoAsset.bakeFoliage(bakeSettings, surface, bounds, weight, foliageInfoCollectionElement.weight);
				}
			}
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x000175EC File Offset: 0x000157EC
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			IDatList list;
			if (p.data.TryGetList("Foliage", out list))
			{
				this.elements = list.ParseListOfStructs<FoliageInfoCollectionAsset.FoliageInfoCollectionElement>();
			}
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x00017620 File Offset: 0x00015820
		public FoliageInfoCollectionAsset()
		{
			this.elements = new List<FoliageInfoCollectionAsset.FoliageInfoCollectionElement>();
		}

		// Token: 0x04000246 RID: 582
		public List<FoliageInfoCollectionAsset.FoliageInfoCollectionElement> elements;

		// Token: 0x0200090C RID: 2316
		public struct FoliageInfoCollectionElement : IDatParseable
		{
			// Token: 0x060050CC RID: 20684 RVA: 0x001F3E84 File Offset: 0x001F2084
			public bool TryParse(IDatNode node)
			{
				IDatDictionary datDictionary = node as IDatDictionary;
				if (datDictionary != null)
				{
					this.asset = datDictionary.ParseStruct("Asset", default(AssetReference<FoliageInfoAsset>));
					this.weight = datDictionary.ParseFloat("Weight", 1f);
					return true;
				}
				return false;
			}

			// Token: 0x040036D4 RID: 14036
			public AssetReference<FoliageInfoAsset> asset;

			// Token: 0x040036D5 RID: 14037
			public float weight;
		}
	}
}
