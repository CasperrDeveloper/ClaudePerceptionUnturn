﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FD RID: 253
	// (Invoke) Token: 0x06000666 RID: 1638
	public delegate void FoliageSystemLocalBakeHandler(Vector3 localPosition);
}
