﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000F2 RID: 242
	public class FoliageObjectInfoAsset : FoliageInfoAsset
	{
		// Token: 0x06000613 RID: 1555 RVA: 0x00017F44 File Offset: 0x00016144
		public override void bakeFoliage(FoliageBakeSettings bakeSettings, IFoliageSurface surface, Bounds bounds, float surfaceWeight, float collectionWeight)
		{
			if (!bakeSettings.bakeObjects)
			{
				return;
			}
			if (bakeSettings.bakeClear)
			{
				return;
			}
			base.bakeFoliage(bakeSettings, surface, bounds, surfaceWeight, collectionWeight);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00017F68 File Offset: 0x00016168
		public override int getInstanceCountInVolume<T>(T volume)
		{
			Bounds worldBounds = volume.worldBounds;
			RegionBounds regionBounds = new RegionBounds(worldBounds);
			int num = 0;
			for (byte b = regionBounds.min.x; b <= regionBounds.max.x; b += 1)
			{
				for (byte b2 = regionBounds.min.y; b2 <= regionBounds.max.y; b2 += 1)
				{
					foreach (LevelObject levelObject in LevelObjects.objects[(int)b, (int)b2])
					{
						if (this.obj.isReferenceTo(levelObject.asset) && !(levelObject.transform == null) && volume.containsPoint(levelObject.transform.position))
						{
							num++;
						}
					}
				}
			}
			return num;
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0001806C File Offset: 0x0001626C
		protected override void addFoliage(Vector3 position, Quaternion rotation, Vector3 scale, bool clearWhenBaked)
		{
			ObjectAsset objectAsset = Assets.find<ObjectAsset>(this.obj);
			if (objectAsset == null)
			{
				return;
			}
			LevelObjects.addObject(position, rotation, scale, 0, objectAsset.GUID, clearWhenBaked ? ELevelObjectPlacementOrigin.GENERATED : ELevelObjectPlacementOrigin.PAINTED);
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x000180A1 File Offset: 0x000162A1
		protected override bool isPositionValid(Vector3 position, bool doCollisionChecks)
		{
			return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsPositionBakeable(position, false, false, true);
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x000180B8 File Offset: 0x000162B8
		public override void PopulateAsset(in PopulateAssetParameters p)
		{
			base.PopulateAsset(p);
			this.obj = p.data.ParseStruct("Object", default(AssetReference<ObjectAsset>));
			if (p.data.ContainsKey("Obstruction_Radius"))
			{
				this.obstructionRadius = p.data.ParseFloat("Obstruction_Radius", 0f);
			}
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x00018118 File Offset: 0x00016318
		protected virtual void resetObject()
		{
			this.obstructionRadius = 4f;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00018125 File Offset: 0x00016325
		public FoliageObjectInfoAsset()
		{
			this.resetObject();
		}

		// Token: 0x0400025B RID: 603
		public AssetReference<ObjectAsset> obj;

		// Token: 0x0400025C RID: 604
		public float obstructionRadius;
	}
}
