﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000EC RID: 236
	public class FoliageCut
	{
		// Token: 0x060005DB RID: 1499 RVA: 0x00016F5C File Offset: 0x0001515C
		public bool ContainsPoint(Vector3 position)
		{
			float num = this.height * 0.5f;
			if (position.y > this.center.y - num && position.y < this.center.y + num)
			{
				float num2 = this.radius * this.radius;
				return (new Vector2(position.x, position.z) - new Vector2(this.center.x, this.center.z)).sqrMagnitude < num2;
			}
			return false;
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x00016FEC File Offset: 0x000151EC
		public FoliageCut(Vector3 center, float radius, float height)
		{
			this.center = center;
			this.radius = radius;
			this.height = height;
			float num = radius * 2f;
			Bounds worldBounds = new Bounds(center, new Vector3(num, height, num));
			this.foliageBounds = new FoliageBounds(worldBounds);
		}

		// Token: 0x04000234 RID: 564
		internal FoliageBounds foliageBounds;

		// Token: 0x04000235 RID: 565
		private Vector3 center;

		// Token: 0x04000236 RID: 566
		private float radius;

		// Token: 0x04000237 RID: 567
		private float height;
	}
}
