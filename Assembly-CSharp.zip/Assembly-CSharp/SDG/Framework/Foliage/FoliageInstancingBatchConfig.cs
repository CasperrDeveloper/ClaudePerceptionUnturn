﻿using System;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FF RID: 255
	internal struct FoliageInstancingBatchConfig : IEquatable<FoliageInstancingBatchConfig>
	{
		// Token: 0x0600066D RID: 1645 RVA: 0x00019CB0 File Offset: 0x00017EB0
		public override int GetHashCode()
		{
			return this.hashCode;
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x00019CB8 File Offset: 0x00017EB8
		public bool Equals(FoliageInstancingBatchConfig other)
		{
			return this.mesh == other.mesh && this.material == other.material && this.castShadows == other.castShadows;
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x00019CF0 File Offset: 0x00017EF0
		public override string ToString()
		{
			return string.Format("(Mesh: {0} Material: {1} Shadows: {2})", this.mesh, this.material, this.castShadows);
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x00019D13 File Offset: 0x00017F13
		public FoliageInstancingBatchConfig(Mesh mesh, Material material, bool castShadows)
		{
			this.mesh = mesh;
			this.material = material;
			this.castShadows = castShadows;
			this.hashCode = HashCode.Combine<Mesh, Material, bool>(mesh, material, castShadows);
		}

		// Token: 0x04000287 RID: 647
		public Mesh mesh;

		// Token: 0x04000288 RID: 648
		public Material material;

		// Token: 0x04000289 RID: 649
		public bool castShadows;

		// Token: 0x0400028A RID: 650
		public int hashCode;
	}
}
