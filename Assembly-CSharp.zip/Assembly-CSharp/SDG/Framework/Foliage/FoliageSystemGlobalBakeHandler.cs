﻿using System;

namespace SDG.Framework.Foliage
{
	// Token: 0x020000FC RID: 252
	// (Invoke) Token: 0x06000662 RID: 1634
	public delegate void FoliageSystemGlobalBakeHandler();
}
