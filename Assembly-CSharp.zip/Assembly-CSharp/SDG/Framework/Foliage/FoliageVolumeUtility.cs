﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Foliage
{
	// Token: 0x02000106 RID: 262
	public class FoliageVolumeUtility
	{
		// Token: 0x060006CD RID: 1741 RVA: 0x0001C7E7 File Offset: 0x0001A9E7
		[Obsolete]
		public static bool isTileBakeable(FoliageTile tile)
		{
			return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsTileBakeable(tile);
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0001C7F4 File Offset: 0x0001A9F4
		[Obsolete]
		public static bool isPointValid(Vector3 point, bool instancedMeshes, bool resources, bool objects)
		{
			return VolumeManager<FoliageVolume, FoliageVolumeManager>.Get().IsPositionBakeable(point, instancedMeshes, resources, objects);
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0001C804 File Offset: 0x0001AA04
		[Obsolete]
		public static bool isPointInsideVolume(FoliageVolume volume, Vector3 point)
		{
			return volume.IsPositionInsideVolume(point);
		}
	}
}
