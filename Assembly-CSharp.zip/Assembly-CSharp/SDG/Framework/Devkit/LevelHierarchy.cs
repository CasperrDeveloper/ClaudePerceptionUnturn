﻿using System;
using System.Collections.Generic;
using System.IO;
using SDG.Framework.Devkit.Transactions;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.IO.FormattedFiles.KeyValueTables;
using SDG.Framework.Modules;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000127 RID: 295
	public class LevelHierarchy : IModuleNexus, IDirtyable
	{
		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x0001E48F File Offset: 0x0001C68F
		// (set) Token: 0x06000793 RID: 1939 RVA: 0x0001E496 File Offset: 0x0001C696
		public static LevelHierarchy instance { get; protected set; }

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x06000794 RID: 1940 RVA: 0x0001E4A0 File Offset: 0x0001C6A0
		// (remove) Token: 0x06000795 RID: 1941 RVA: 0x0001E4D4 File Offset: 0x0001C6D4
		public static event LevelHiearchyItemAdded itemAdded;

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x06000796 RID: 1942 RVA: 0x0001E508 File Offset: 0x0001C708
		// (remove) Token: 0x06000797 RID: 1943 RVA: 0x0001E53C File Offset: 0x0001C73C
		public static event LevelHierarchyItemRemoved itemRemoved;

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06000798 RID: 1944 RVA: 0x0001E570 File Offset: 0x0001C770
		// (remove) Token: 0x06000799 RID: 1945 RVA: 0x0001E5A4 File Offset: 0x0001C7A4
		public static event LevelHierarchyLoaded loaded;

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x0600079A RID: 1946 RVA: 0x0001E5D8 File Offset: 0x0001C7D8
		// (remove) Token: 0x0600079B RID: 1947 RVA: 0x0001E60C File Offset: 0x0001C80C
		public static event LevelHierarchyReady ready;

		// Token: 0x0600079C RID: 1948 RVA: 0x0001E63F File Offset: 0x0001C83F
		public static void MarkDirty()
		{
			if (LevelHierarchy.instance != null)
			{
				LevelHierarchy.instance.isDirty = true;
			}
		}

		// Token: 0x0600079D RID: 1949 RVA: 0x0001E653 File Offset: 0x0001C853
		public static uint generateUniqueInstanceID()
		{
			return LevelHierarchy.availableInstanceID++;
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x0001E662 File Offset: 0x0001C862
		[Obsolete("Renamed to AssignInstanceIdAndMarkDirty")]
		public static void initItem(IDevkitHierarchyItem item)
		{
			LevelHierarchy.AssignInstanceIdAndMarkDirty(item);
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x0001E66A File Offset: 0x0001C86A
		public static void AssignInstanceIdAndMarkDirty(IDevkitHierarchyItem item)
		{
			if (item.instanceID == 0U)
			{
				item.instanceID = LevelHierarchy.generateUniqueInstanceID();
			}
			if (LevelHierarchy.instance != null)
			{
				LevelHierarchy.instance.isDirty = true;
			}
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x0001E691 File Offset: 0x0001C891
		public static void addItem(IDevkitHierarchyItem item)
		{
			LevelHierarchy.instance.items.Add(item);
			LevelHierarchy.triggerItemAdded(item);
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x0001E6A9 File Offset: 0x0001C8A9
		public static void removeItem(IDevkitHierarchyItem item)
		{
			LevelHierarchy.instance.items.Remove(item);
			LevelHierarchy.triggerItemRemoved(item);
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x0001E6C2 File Offset: 0x0001C8C2
		protected static void triggerItemAdded(IDevkitHierarchyItem item)
		{
			LevelHiearchyItemAdded levelHiearchyItemAdded = LevelHierarchy.itemAdded;
			if (levelHiearchyItemAdded == null)
			{
				return;
			}
			levelHiearchyItemAdded(item);
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x0001E6D4 File Offset: 0x0001C8D4
		protected static void triggerItemRemoved(IDevkitHierarchyItem item)
		{
			if (Level.isExiting)
			{
				return;
			}
			LevelHierarchyItemRemoved levelHierarchyItemRemoved = LevelHierarchy.itemRemoved;
			if (levelHierarchyItemRemoved == null)
			{
				return;
			}
			levelHierarchyItemRemoved(item);
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x0001E6EE File Offset: 0x0001C8EE
		protected static void triggerLoaded()
		{
			LevelHierarchyLoaded levelHierarchyLoaded = LevelHierarchy.loaded;
			if (levelHierarchyLoaded == null)
			{
				return;
			}
			levelHierarchyLoaded();
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x0001E6FF File Offset: 0x0001C8FF
		protected static void triggerReady()
		{
			LevelHierarchyReady levelHierarchyReady = LevelHierarchy.ready;
			if (levelHierarchyReady == null)
			{
				return;
			}
			levelHierarchyReady();
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x060007A6 RID: 1958 RVA: 0x0001E710 File Offset: 0x0001C910
		// (set) Token: 0x060007A7 RID: 1959 RVA: 0x0001E718 File Offset: 0x0001C918
		public List<IDevkitHierarchyItem> items { get; protected set; }

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x060007A8 RID: 1960 RVA: 0x0001E721 File Offset: 0x0001C921
		// (set) Token: 0x060007A9 RID: 1961 RVA: 0x0001E729 File Offset: 0x0001C929
		public bool isDirty
		{
			get
			{
				return this._isDirty;
			}
			set
			{
				if (this.isDirty == value)
				{
					return;
				}
				this._isDirty = value;
				if (this.isDirty)
				{
					DirtyManager.markDirty(this);
					return;
				}
				DirtyManager.markClean(this);
			}
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0001E754 File Offset: 0x0001C954
		public void load()
		{
			this.loadedAnyDevkitObjects = false;
			string path = Level.info.path + "/Level.hierarchy";
			if (File.Exists(path))
			{
				using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
				{
					using (SHA1Stream sha1Stream = new SHA1Stream(fileStream))
					{
						using (StreamReader streamReader = new StreamReader(sha1Stream))
						{
							IFormattedFileReader reader = new KeyValueTableReader(streamReader);
							this.read(reader);
							byte[] hash = sha1Stream.Hash;
							Level.includeHash("Level.hierarchy", hash);
							goto IL_86;
						}
					}
				}
			}
			LevelHierarchy.availableInstanceID = 1U;
			IL_86:
			if (this.loadedAnyDevkitObjects)
			{
				UnturnedLog.info("Marking level dirty because devkit objects were converted");
				LevelHierarchy.MarkDirty();
			}
			LevelHierarchy.triggerLoaded();
			TimeUtility.updated += this.handleLoadUpdated;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0001E83C File Offset: 0x0001CA3C
		public void save()
		{
			string path = Level.info.path + "/Level.hierarchy";
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (StreamWriter streamWriter = new StreamWriter(path))
			{
				IFormattedFileWriter writer = new KeyValueTableWriter(streamWriter);
				this.write(writer);
			}
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x0001E8A4 File Offset: 0x0001CAA4
		public virtual void read(IFormattedFileReader reader)
		{
			if (reader.containsKey("Available_Instance_ID"))
			{
				LevelHierarchy.availableInstanceID = reader.readValue<uint>("Available_Instance_ID");
			}
			else
			{
				LevelHierarchy.availableInstanceID = 1U;
			}
			int num = reader.readArrayLength("Items");
			for (int i = 0; i < num; i++)
			{
				IFormattedFileReader formattedFileReader = reader.readObject(i);
				Type type = formattedFileReader.readValue<Type>("Type");
				if (type == null)
				{
					UnturnedLog.error("Level hierarchy item index " + i.ToString() + " missing type: " + formattedFileReader.readValue("Type"));
				}
				else
				{
					IDevkitHierarchyItem devkitHierarchyItem;
					if (typeof(MonoBehaviour).IsAssignableFrom(type))
					{
						devkitHierarchyItem = (new GameObject
						{
							name = type.Name
						}.AddComponent(type) as IDevkitHierarchyItem);
					}
					else
					{
						devkitHierarchyItem = (Activator.CreateInstance(type) as IDevkitHierarchyItem);
					}
					if (devkitHierarchyItem != null)
					{
						if (formattedFileReader.containsKey("Instance_ID"))
						{
							devkitHierarchyItem.instanceID = formattedFileReader.readValue<uint>("Instance_ID");
						}
						if (devkitHierarchyItem.instanceID == 0U)
						{
							devkitHierarchyItem.instanceID = LevelHierarchy.generateUniqueInstanceID();
						}
						formattedFileReader.readKey("Item");
						devkitHierarchyItem.read(formattedFileReader);
					}
				}
			}
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0001E9C8 File Offset: 0x0001CBC8
		public virtual void write(IFormattedFileWriter writer)
		{
			writer.writeValue<uint>("Available_Instance_ID", LevelHierarchy.availableInstanceID);
			writer.beginArray("Items");
			for (int i = 0; i < this.items.Count; i++)
			{
				IDevkitHierarchyItem devkitHierarchyItem = this.items[i];
				if (devkitHierarchyItem.instanceID != 0U && devkitHierarchyItem.ShouldSave)
				{
					writer.beginObject();
					writer.writeValue<Type>("Type", devkitHierarchyItem.GetType());
					writer.writeValue<uint>("Instance_ID", devkitHierarchyItem.instanceID);
					writer.writeValue<IDevkitHierarchyItem>("Item", devkitHierarchyItem);
					writer.endObject();
				}
			}
			writer.endArray();
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x0001EA63 File Offset: 0x0001CC63
		public void initialize()
		{
			LevelHierarchy.instance = this;
			this.items = new List<IDevkitHierarchyItem>();
			Level.loadingSteps += this.handleLoadingStep;
			DevkitTransactionManager.transactionsChanged += this.handleTransactionsChanged;
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0001EA98 File Offset: 0x0001CC98
		public void shutdown()
		{
			Level.loadingSteps -= this.handleLoadingStep;
			DevkitTransactionManager.transactionsChanged -= this.handleTransactionsChanged;
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x0001EABC File Offset: 0x0001CCBC
		protected void handleLoadingStep()
		{
			this.items.Clear();
			this.load();
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x0001EACF File Offset: 0x0001CCCF
		protected void handleLoadUpdated()
		{
			TimeUtility.updated -= this.handleLoadUpdated;
			LevelHierarchy.triggerReady();
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x0001EAE7 File Offset: 0x0001CCE7
		protected void handleTransactionsChanged()
		{
			if (!Level.isEditor)
			{
				return;
			}
			this.isDirty = true;
		}

		// Token: 0x04000306 RID: 774
		private static uint availableInstanceID;

		// Token: 0x04000308 RID: 776
		protected bool _isDirty;

		// Token: 0x04000309 RID: 777
		internal bool loadedAnyDevkitObjects;
	}
}
