﻿using System;
using SDG.Unturned;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000136 RID: 310
	public class UndergroundWhitelistVolume : LevelVolume<UndergroundWhitelistVolume, UndergroundWhitelistVolumeManager>
	{
	}
}
