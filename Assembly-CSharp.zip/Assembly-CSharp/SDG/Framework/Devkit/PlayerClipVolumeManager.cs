﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012D RID: 301
	public class PlayerClipVolumeManager : VolumeManager<PlayerClipVolume, PlayerClipVolumeManager>
	{
		// Token: 0x060007C6 RID: 1990 RVA: 0x0001EE3C File Offset: 0x0001D03C
		public PlayerClipVolumeManager()
		{
			base.FriendlyName = "Player Clip";
			base.SetDebugColor(new Color32(63, 0, 0, byte.MaxValue));
		}
	}
}
