﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000119 RID: 281
	// (Invoke) Token: 0x06000743 RID: 1859
	public delegate void SaveableChangedHandler(IDirtyable item, bool isSaveable);
}
