﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000133 RID: 307
	public class TeleporterExitVolume : LevelVolume<TeleporterExitVolume, TeleporterExitVolumeManager>
	{
		// Token: 0x060007EB RID: 2027 RVA: 0x0001F458 File Offset: 0x0001D658
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new TeleporterExitVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x060007EC RID: 2028 RVA: 0x0001F474 File Offset: 0x0001D674
		// (set) Token: 0x060007ED RID: 2029 RVA: 0x0001F47C File Offset: 0x0001D67C
		public string id
		{
			get
			{
				return this._id;
			}
			set
			{
				if (!string.Equals(this._id, value))
				{
					base.GetVolumeManager().RemoveVolumeFromIdDictionary(this);
					this._id = value;
					base.GetVolumeManager().AddVolumeToIdDictionary(this);
				}
			}
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x0001F4AB File Offset: 0x0001D6AB
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.id = reader.readValue<string>("Id");
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0001F4C5 File Offset: 0x0001D6C5
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue("Id", this.id);
		}

		// Token: 0x04000315 RID: 789
		[SerializeField]
		private string _id;

		// Token: 0x0200091A RID: 2330
		private class Menu : SleekWrapper
		{
			// Token: 0x0600510B RID: 20747 RVA: 0x001F5A2C File Offset: 0x001F3C2C
			public Menu(TeleporterExitVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 30f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				sleekField.Text = volume.id;
				sleekField.AddLabel("ID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdChanged;
				base.AddChild(sleekField);
			}

			// Token: 0x0600510C RID: 20748 RVA: 0x001F5AAE File Offset: 0x001F3CAE
			private void OnIdChanged(ISleekField field, string id)
			{
				this.volume.id = id;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036F7 RID: 14071
			private TeleporterExitVolume volume;
		}
	}
}
