﻿using System;
using SDG.Unturned;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000128 RID: 296
	public class NavClipVolume : LevelVolume<NavClipVolume, NavClipVolumeManager>
	{
		// Token: 0x060007B4 RID: 1972 RVA: 0x0001EB00 File Offset: 0x0001CD00
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
			this.volumeCollider.isTrigger = false;
			base.gameObject.layer = 22;
		}
	}
}
