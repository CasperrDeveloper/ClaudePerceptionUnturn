﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012B RID: 299
	public class NPCRewardVolumeManager : VolumeManager<NPCRewardVolume, NPCRewardVolumeManager>
	{
		// Token: 0x060007BE RID: 1982 RVA: 0x0001ED45 File Offset: 0x0001CF45
		public NPCRewardVolumeManager()
		{
			base.FriendlyName = "NPC Reward";
			base.SetDebugColor(new Color32(220, 220, 20, byte.MaxValue));
		}
	}
}
