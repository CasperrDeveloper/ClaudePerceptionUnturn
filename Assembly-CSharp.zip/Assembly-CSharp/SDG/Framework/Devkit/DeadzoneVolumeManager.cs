﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000110 RID: 272
	public class DeadzoneVolumeManager : VolumeManager<DeadzoneVolume, DeadzoneVolumeManager>
	{
		// Token: 0x0600070B RID: 1803 RVA: 0x0001D214 File Offset: 0x0001B414
		public DeadzoneVolume GetMostDangerousOverlappingVolume(Vector3 position)
		{
			DeadzoneVolume deadzoneVolume = null;
			foreach (DeadzoneVolume deadzoneVolume2 in this.allVolumes)
			{
				if ((deadzoneVolume == null || deadzoneVolume2.DeadzoneType > deadzoneVolume.DeadzoneType) && deadzoneVolume2.IsPositionInsideVolume(position))
				{
					deadzoneVolume = deadzoneVolume2;
					if (deadzoneVolume.DeadzoneType == EDeadzoneType.FullSuitRadiation)
					{
						break;
					}
				}
			}
			return deadzoneVolume;
		}

		/// <summary>
		/// Hacked to check horizontal distance.
		/// </summary>
		// Token: 0x0600070C RID: 1804 RVA: 0x0001D290 File Offset: 0x0001B490
		public bool IsNavmeshCenterInsideAnyVolume(Vector3 position)
		{
			foreach (DeadzoneVolume deadzoneVolume in this.allVolumes)
			{
				Vector3 position2 = new Vector3(position.x, deadzoneVolume.transform.position.y, position.z);
				if (deadzoneVolume.IsPositionInsideVolume(position2))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x0001D310 File Offset: 0x0001B510
		public DeadzoneVolumeManager()
		{
			base.FriendlyName = "Deadzone";
			base.SetDebugColor(new Color32(byte.MaxValue, 0, 0, byte.MaxValue));
		}
	}
}
