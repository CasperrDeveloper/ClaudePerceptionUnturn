﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000137 RID: 311
	public class UndergroundWhitelistVolumeManager : VolumeManager<UndergroundWhitelistVolume, UndergroundWhitelistVolumeManager>
	{
		// Token: 0x060007FB RID: 2043 RVA: 0x0001F7FE File Offset: 0x0001D9FE
		public UndergroundWhitelistVolumeManager()
		{
			base.FriendlyName = "Underground Whitelist";
			base.SetDebugColor(new Color32(63, 63, 63, byte.MaxValue));
		}
	}
}
