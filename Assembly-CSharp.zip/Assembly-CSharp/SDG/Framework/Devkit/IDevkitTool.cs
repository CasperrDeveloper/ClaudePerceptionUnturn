﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011F RID: 287
	public interface IDevkitTool
	{
		// Token: 0x06000775 RID: 1909
		void update();

		// Token: 0x06000776 RID: 1910
		void equip();

		// Token: 0x06000777 RID: 1911
		void dequip();
	}
}
