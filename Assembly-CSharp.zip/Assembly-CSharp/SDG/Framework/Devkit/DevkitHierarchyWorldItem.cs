﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000112 RID: 274
	public class DevkitHierarchyWorldItem : DevkitHierarchyItemBase
	{
		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000717 RID: 1815 RVA: 0x0001D382 File Offset: 0x0001B582
		// (set) Token: 0x06000718 RID: 1816 RVA: 0x0001D38F File Offset: 0x0001B58F
		public Vector3 inspectablePosition
		{
			get
			{
				return base.transform.localPosition;
			}
			set
			{
				base.transform.position = value;
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000719 RID: 1817 RVA: 0x0001D39D File Offset: 0x0001B59D
		// (set) Token: 0x0600071A RID: 1818 RVA: 0x0001D3AA File Offset: 0x0001B5AA
		public Quaternion inspectableRotation
		{
			get
			{
				return base.transform.localRotation;
			}
			set
			{
				base.transform.rotation = value;
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600071B RID: 1819 RVA: 0x0001D3B8 File Offset: 0x0001B5B8
		// (set) Token: 0x0600071C RID: 1820 RVA: 0x0001D3C5 File Offset: 0x0001B5C5
		public Vector3 inspectableScale
		{
			get
			{
				return base.transform.localScale;
			}
			set
			{
				base.transform.localScale = value;
			}
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x0001D3D3 File Offset: 0x0001B5D3
		public override void read(IFormattedFileReader reader)
		{
			reader = reader.readObject();
			if (reader == null)
			{
				return;
			}
			this.readHierarchyItem(reader);
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x0001D3E8 File Offset: 0x0001B5E8
		protected virtual void readHierarchyItem(IFormattedFileReader reader)
		{
			base.transform.position = reader.readValue<Vector3>("Position");
			base.transform.SetRotation_RoundIfNearlyAxisAligned(reader.readValue<Quaternion>("Rotation"), 0.05f);
			Vector3 vector = reader.readValue<Vector3>("Scale");
			vector.x = Mathf.Clamp(vector.x, -100000f, 100000f);
			vector.y = Mathf.Clamp(vector.y, -100000f, 100000f);
			vector.z = Mathf.Clamp(vector.z, -100000f, 100000f);
			base.transform.SetLocalScale_RoundIfNearlyEqualToOne(vector, 0.001f);
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0001D497 File Offset: 0x0001B697
		public override void write(IFormattedFileWriter writer)
		{
			writer.beginObject();
			this.writeHierarchyItem(writer);
			writer.endObject();
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0001D4AC File Offset: 0x0001B6AC
		protected virtual void writeHierarchyItem(IFormattedFileWriter writer)
		{
			writer.writeValue<Vector3>("Position", base.transform.position);
			writer.writeValue<Quaternion>("Rotation", base.transform.rotation);
			writer.writeValue<Vector3>("Scale", base.transform.localScale);
		}
	}
}
