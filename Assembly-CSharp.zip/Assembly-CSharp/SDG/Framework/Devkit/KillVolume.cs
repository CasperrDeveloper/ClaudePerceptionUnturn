﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using Steamworks;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000121 RID: 289
	public class KillVolume : LevelVolume<KillVolume, KillVolumeManager>
	{
		// Token: 0x0600077B RID: 1915 RVA: 0x0001E13C File Offset: 0x0001C33C
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new KillVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x0001E158 File Offset: 0x0001C358
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.killPlayers = reader.readValue<bool>("Kill_Players");
			this.killZombies = reader.readValue<bool>("Kill_Zombies");
			this.killAnimals = reader.readValue<bool>("Kill_Animals");
			this.killVehicles = reader.readValue<bool>("Kill_Vehicles");
			this.deathCause = reader.readValue<EDeathCause>("Death_Cause");
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x0001E1C4 File Offset: 0x0001C3C4
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<bool>("Kill_Players", this.killPlayers);
			writer.writeValue<bool>("Kill_Zombies", this.killZombies);
			writer.writeValue<bool>("Kill_Animals", this.killAnimals);
			writer.writeValue<bool>("Kill_Vehicles", this.killVehicles);
			writer.writeValue<EDeathCause>("Death_Cause", this.deathCause);
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x0001E22D File Offset: 0x0001C42D
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x0001E23C File Offset: 0x0001C43C
		private void OnTriggerEnter(Collider other)
		{
			if (other.isTrigger)
			{
				return;
			}
			if (!Provider.isServer)
			{
				return;
			}
			if (other.CompareTag("Player"))
			{
				if (this.killPlayers)
				{
					Player player = DamageTool.getPlayer(other.transform);
					if (player != null)
					{
						EPlayerKill eplayerKill;
						DamageTool.damage(player, this.deathCause, ELimb.SPINE, CSteamID.Nil, Vector3.up, 101f, 1f, out eplayerKill, false, false, ERagdollEffect.NONE);
						return;
					}
				}
			}
			else if (other.CompareTag("Agent"))
			{
				if (this.killZombies || this.killAnimals)
				{
					Zombie zombie = DamageTool.getZombie(other.transform);
					if (zombie != null)
					{
						if (this.killZombies)
						{
							DamageZombieParameters parameters = DamageZombieParameters.makeInstakill(zombie);
							parameters.instigator = this;
							EPlayerKill eplayerKill2;
							uint num;
							DamageTool.damageZombie(parameters, out eplayerKill2, out num);
							return;
						}
					}
					else if (this.killAnimals)
					{
						Animal animal = DamageTool.getAnimal(other.transform);
						if (animal != null)
						{
							DamageAnimalParameters parameters2 = DamageAnimalParameters.makeInstakill(animal);
							parameters2.instigator = this;
							EPlayerKill eplayerKill3;
							uint num2;
							DamageTool.damageAnimal(parameters2, out eplayerKill3, out num2);
							return;
						}
					}
				}
			}
			else if (other.CompareTag("Vehicle"))
			{
				InteractableVehicle vehicle = DamageTool.getVehicle(other.transform);
				if (vehicle != null && !vehicle.isDead)
				{
					if (this.killPlayers)
					{
						for (int i = vehicle.passengers.Length - 1; i >= 0; i--)
						{
							Passenger passenger = vehicle.passengers[i];
							if (passenger != null && passenger.player != null)
							{
								Player player2 = passenger.player.player;
								if (!(player2 == null))
								{
									EPlayerKill eplayerKill4;
									DamageTool.damage(player2, this.deathCause, ELimb.SPINE, CSteamID.Nil, Vector3.up, 101f, 1f, out eplayerKill4, false, false, ERagdollEffect.NONE);
								}
							}
						}
					}
					if (this.killVehicles && !vehicle.isDead)
					{
						EPlayerKill eplayerKill5;
						DamageTool.damage(vehicle, false, Vector3.zero, false, 65000f, 1f, false, out eplayerKill5, default(CSteamID), EDamageOrigin.Kill_Volume);
					}
				}
			}
		}

		// Token: 0x040002FC RID: 764
		public bool killPlayers = true;

		// Token: 0x040002FD RID: 765
		public bool killZombies = true;

		// Token: 0x040002FE RID: 766
		public bool killAnimals = true;

		// Token: 0x040002FF RID: 767
		public bool killVehicles;

		// Token: 0x04000300 RID: 768
		public EDeathCause deathCause = EDeathCause.BURNING;

		// Token: 0x02000914 RID: 2324
		private class Menu : SleekWrapper
		{
			// Token: 0x060050F2 RID: 20722 RVA: 0x001F5258 File Offset: 0x001F3458
			public Menu(KillVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 190f;
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.killPlayers;
				sleekToggle.AddLabel("Kill Players", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnKillPlayersToggled;
				base.AddChild(sleekToggle);
				ISleekToggle sleekToggle2 = Glazier.Get().CreateToggle();
				sleekToggle2.PositionOffset_Y = 40f;
				sleekToggle2.SizeOffset_X = 40f;
				sleekToggle2.SizeOffset_Y = 40f;
				sleekToggle2.Value = volume.killZombies;
				sleekToggle2.AddLabel("Kill Zombies", ESleekSide.RIGHT);
				sleekToggle2.OnValueChanged += this.OnKillZombiesToggled;
				base.AddChild(sleekToggle2);
				ISleekToggle sleekToggle3 = Glazier.Get().CreateToggle();
				sleekToggle3.PositionOffset_Y = 80f;
				sleekToggle3.SizeOffset_X = 40f;
				sleekToggle3.SizeOffset_Y = 40f;
				sleekToggle3.Value = volume.killAnimals;
				sleekToggle3.AddLabel("Kill Animals", ESleekSide.RIGHT);
				sleekToggle3.OnValueChanged += this.OnKillAnimalsToggled;
				base.AddChild(sleekToggle3);
				ISleekToggle sleekToggle4 = Glazier.Get().CreateToggle();
				sleekToggle4.PositionOffset_Y = 120f;
				sleekToggle4.SizeOffset_X = 40f;
				sleekToggle4.SizeOffset_Y = 40f;
				sleekToggle4.Value = volume.killVehicles;
				sleekToggle4.AddLabel("Kill Vehicles", ESleekSide.RIGHT);
				sleekToggle4.OnValueChanged += this.OnKillVehiclesToggled;
				base.AddChild(sleekToggle4);
				SleekButtonStateEnum<EDeathCause> sleekButtonStateEnum = new SleekButtonStateEnum<EDeathCause>();
				sleekButtonStateEnum.PositionOffset_Y = 160f;
				sleekButtonStateEnum.SizeOffset_X = 200f;
				sleekButtonStateEnum.SizeOffset_Y = 30f;
				sleekButtonStateEnum.SetEnum(volume.deathCause);
				sleekButtonStateEnum.AddLabel("Death Cause", ESleekSide.RIGHT);
				SleekButtonStateEnum<EDeathCause> sleekButtonStateEnum2 = sleekButtonStateEnum;
				sleekButtonStateEnum2.OnSwappedEnum = (Action<SleekButtonStateEnum<EDeathCause>, EDeathCause>)Delegate.Combine(sleekButtonStateEnum2.OnSwappedEnum, new Action<SleekButtonStateEnum<EDeathCause>, EDeathCause>(this.OnSwappedDeathCause));
				base.AddChild(sleekButtonStateEnum);
			}

			// Token: 0x060050F3 RID: 20723 RVA: 0x001F5461 File Offset: 0x001F3661
			private void OnKillPlayersToggled(ISleekToggle toggle, bool state)
			{
				this.volume.killPlayers = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F4 RID: 20724 RVA: 0x001F5474 File Offset: 0x001F3674
			private void OnKillZombiesToggled(ISleekToggle toggle, bool state)
			{
				this.volume.killZombies = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F5 RID: 20725 RVA: 0x001F5487 File Offset: 0x001F3687
			private void OnKillAnimalsToggled(ISleekToggle toggle, bool state)
			{
				this.volume.killAnimals = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F6 RID: 20726 RVA: 0x001F549A File Offset: 0x001F369A
			private void OnKillVehiclesToggled(ISleekToggle toggle, bool state)
			{
				this.volume.killVehicles = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F7 RID: 20727 RVA: 0x001F54AD File Offset: 0x001F36AD
			private void OnSwappedDeathCause(SleekButtonStateEnum<EDeathCause> button, EDeathCause deathCause)
			{
				this.volume.deathCause = deathCause;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036EC RID: 14060
			private KillVolume volume;
		}
	}
}
