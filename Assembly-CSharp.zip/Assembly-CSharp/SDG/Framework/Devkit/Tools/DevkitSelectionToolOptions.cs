﻿using System;
using System.IO;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.IO.FormattedFiles.KeyValueTables;
using SDG.Unturned;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x0200014D RID: 333
	public class DevkitSelectionToolOptions : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000885 RID: 2181 RVA: 0x00020F79 File Offset: 0x0001F179
		public static DevkitSelectionToolOptions instance
		{
			get
			{
				return DevkitSelectionToolOptions._instance;
			}
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00020F80 File Offset: 0x0001F180
		public static void load()
		{
			DevkitSelectionToolOptions.wasLoaded = true;
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Selection.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (!File.Exists(path))
			{
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					IFormattedFileReader reader = new KeyValueTableReader(streamReader);
					DevkitSelectionToolOptions.instance.read(reader);
				}
			}
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00021020 File Offset: 0x0001F220
		public static void save()
		{
			if (!DevkitSelectionToolOptions.wasLoaded)
			{
				return;
			}
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Selection.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (StreamWriter streamWriter = new StreamWriter(path))
			{
				((IFormattedFileWriter)new KeyValueTableWriter(streamWriter)).writeValue<DevkitSelectionToolOptions>(DevkitSelectionToolOptions.instance);
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00021094 File Offset: 0x0001F294
		public void read(IFormattedFileReader reader)
		{
			this.snapPosition = reader.readValue<float>("Snap_Position");
			this.snapRotation = reader.readValue<float>("Snap_Rotation");
			this.snapScale = reader.readValue<float>("Snap_Scale");
			this.surfaceOffset = reader.readValue<float>("Surface_Offset");
			this.surfaceAlign = reader.readValue<bool>("Surface_Align");
			this.localSpace = reader.readValue<bool>("Local_Space");
			this.lockHandles = reader.readValue<bool>("Lock_Handles");
			this.selectionMask = reader.readValue<ERayMask>("Selection_Mask");
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x0002112C File Offset: 0x0001F32C
		public void write(IFormattedFileWriter writer)
		{
			writer.writeValue<float>("Snap_Position", this.snapPosition);
			writer.writeValue<float>("Snap_Rotation", this.snapRotation);
			writer.writeValue<float>("Snap_Scale", this.snapScale);
			writer.writeValue<float>("Surface_Offset", this.surfaceOffset);
			writer.writeValue<bool>("Surface_Align", this.surfaceAlign);
			writer.writeValue<bool>("Local_Space", this.localSpace);
			writer.writeValue<bool>("Lock_Handles", this.lockHandles);
			writer.writeValue<ERayMask>("Selection_Mask", this.selectionMask);
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x000211C1 File Offset: 0x0001F3C1
		static DevkitSelectionToolOptions()
		{
			DevkitSelectionToolOptions.load();
		}

		// Token: 0x04000374 RID: 884
		private static DevkitSelectionToolOptions _instance = new DevkitSelectionToolOptions();

		// Token: 0x04000375 RID: 885
		public float snapPosition = 1f;

		// Token: 0x04000376 RID: 886
		public float snapRotation = 15f;

		// Token: 0x04000377 RID: 887
		public float snapScale = 0.1f;

		// Token: 0x04000378 RID: 888
		public float surfaceOffset;

		// Token: 0x04000379 RID: 889
		public bool surfaceAlign;

		// Token: 0x0400037A RID: 890
		public bool localSpace;

		// Token: 0x0400037B RID: 891
		public bool lockHandles;

		// Token: 0x0400037C RID: 892
		public ERayMask selectionMask = ERayMask.LARGE | ERayMask.MEDIUM | ERayMask.SMALL | ERayMask.ENVIRONMENT | ERayMask.GROUND | ERayMask.CLIP | ERayMask.TRAP;

		// Token: 0x0400037D RID: 893
		protected static bool wasLoaded;
	}
}
