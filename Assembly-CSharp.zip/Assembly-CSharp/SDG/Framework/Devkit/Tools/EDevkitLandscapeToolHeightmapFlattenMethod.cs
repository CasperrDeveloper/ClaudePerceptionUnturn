﻿using System;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x02000148 RID: 328
	public enum EDevkitLandscapeToolHeightmapFlattenMethod
	{
		/// <summary>
		/// Directly blend current value toward target value.
		/// </summary>
		// Token: 0x04000348 RID: 840
		REGULAR,
		/// <summary>
		/// Only blend current value toward target value if current is greater than target.
		/// </summary>
		// Token: 0x04000349 RID: 841
		MIN,
		/// <summary>
		/// Only blend current value toward target value if current is less than target.
		/// </summary>
		// Token: 0x0400034A RID: 842
		MAX
	}
}
