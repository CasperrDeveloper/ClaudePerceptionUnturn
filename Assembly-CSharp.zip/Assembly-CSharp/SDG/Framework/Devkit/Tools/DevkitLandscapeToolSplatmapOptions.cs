﻿using System;
using System.IO;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.IO.FormattedFiles.KeyValueTables;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x0200014C RID: 332
	public class DevkitLandscapeToolSplatmapOptions : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600087A RID: 2170 RVA: 0x00020AA0 File Offset: 0x0001ECA0
		public static DevkitLandscapeToolSplatmapOptions instance
		{
			get
			{
				return DevkitLandscapeToolSplatmapOptions._instance;
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600087B RID: 2171 RVA: 0x00020AA7 File Offset: 0x0001ECA7
		// (set) Token: 0x0600087C RID: 2172 RVA: 0x00020AB0 File Offset: 0x0001ECB0
		public static float paintSensitivity
		{
			get
			{
				return DevkitLandscapeToolSplatmapOptions._paintSensitivity;
			}
			set
			{
				DevkitLandscapeToolSplatmapOptions._paintSensitivity = value;
				UnturnedLog.info("Set paint_sensitivity to: " + DevkitLandscapeToolSplatmapOptions.paintSensitivity.ToString());
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600087D RID: 2173 RVA: 0x00020ADF File Offset: 0x0001ECDF
		// (set) Token: 0x0600087E RID: 2174 RVA: 0x00020AE7 File Offset: 0x0001ECE7
		public float brushRadius
		{
			get
			{
				return this._brushRadius;
			}
			set
			{
				this._brushRadius = Mathf.Clamp(value, 0f, 2048f);
			}
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00020B00 File Offset: 0x0001ED00
		public static void load()
		{
			DevkitLandscapeToolSplatmapOptions.wasLoaded = true;
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Splatmap.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (!File.Exists(path))
			{
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					IFormattedFileReader reader = new KeyValueTableReader(streamReader);
					DevkitLandscapeToolSplatmapOptions.instance.read(reader);
				}
			}
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00020BA0 File Offset: 0x0001EDA0
		public static void save()
		{
			if (!DevkitLandscapeToolSplatmapOptions.wasLoaded)
			{
				return;
			}
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Splatmap.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (StreamWriter streamWriter = new StreamWriter(path))
			{
				((IFormattedFileWriter)new KeyValueTableWriter(streamWriter)).writeValue<DevkitLandscapeToolSplatmapOptions>(DevkitLandscapeToolSplatmapOptions.instance);
			}
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x00020C14 File Offset: 0x0001EE14
		public void read(IFormattedFileReader reader)
		{
			this.brushRadius = reader.readValue<float>("Brush_Radius");
			this.brushFalloff = reader.readValue<float>("Brush_Falloff");
			this.brushStrength = reader.readValue<float>("Brush_Strength");
			this.autoStrength = reader.readValue<float>("Auto_Strength");
			this.smoothStrength = reader.readValue<float>("Smooth_Strength");
			this.useWeightTarget = reader.readValue<bool>("Use_Weight_Target");
			this.weightTarget = reader.readValue<float>("Weight_Target");
			this.maxPreviewSamples = reader.readValue<uint>("Max_Preview_Samples");
			this.smoothMethod = reader.readValue<EDevkitLandscapeToolSplatmapSmoothMethod>("Smooth_Method");
			this.previewMethod = reader.readValue<EDevkitLandscapeToolSplatmapPreviewMethod>("Preview_Method");
			this.useAutoSlope = reader.readValue<bool>("Use_Auto_Slope");
			this.autoMinAngleBegin = reader.readValue<float>("Auto_Min_Angle_Begin");
			this.autoMinAngleEnd = reader.readValue<float>("Auto_Min_Angle_End");
			this.autoMaxAngleBegin = reader.readValue<float>("Auto_Max_Angle_Begin");
			this.autoMaxAngleEnd = reader.readValue<float>("Auto_Max_Angle_End");
			this.useAutoFoundation = reader.readValue<bool>("Use_Auto_Foundation");
			this.autoRayRadius = reader.readValue<float>("Auto_Ray_Radius");
			this.autoRayLength = reader.readValue<float>("Auto_Ray_Length");
			this.autoRayMask = reader.readValue<ERayMask>("Auto_Ray_Mask");
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x00020D64 File Offset: 0x0001EF64
		public void write(IFormattedFileWriter writer)
		{
			writer.writeValue<float>("Brush_Radius", this.brushRadius);
			writer.writeValue<float>("Brush_Falloff", this.brushFalloff);
			writer.writeValue<float>("Brush_Strength", this.brushStrength);
			writer.writeValue<float>("Auto_Strength", this.autoStrength);
			writer.writeValue<float>("Smooth_Strength", this.smoothStrength);
			writer.writeValue<bool>("Use_Weight_Target", this.useWeightTarget);
			writer.writeValue<float>("Weight_Target", this.weightTarget);
			writer.writeValue<uint>("Max_Preview_Samples", this.maxPreviewSamples);
			writer.writeValue<EDevkitLandscapeToolSplatmapSmoothMethod>("Smooth_Method", this.smoothMethod);
			writer.writeValue<EDevkitLandscapeToolSplatmapPreviewMethod>("Preview_Method", this.previewMethod);
			writer.writeValue<bool>("Use_Auto_Slope", this.useAutoSlope);
			writer.writeValue<float>("Auto_Min_Angle_Begin", this.autoMinAngleBegin);
			writer.writeValue<float>("Auto_Min_Angle_End", this.autoMinAngleEnd);
			writer.writeValue<float>("Auto_Max_Angle_Begin", this.autoMaxAngleBegin);
			writer.writeValue<float>("Auto_Max_Angle_End", this.autoMaxAngleEnd);
			writer.writeValue<bool>("Use_Auto_Foundation", this.useAutoFoundation);
			writer.writeValue<float>("Auto_Ray_Radius", this.autoRayRadius);
			writer.writeValue<float>("Auto_Ray_Length", this.autoRayLength);
			writer.writeValue<ERayMask>("Auto_Ray_Mask", this.autoRayMask);
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x00020EB4 File Offset: 0x0001F0B4
		static DevkitLandscapeToolSplatmapOptions()
		{
			DevkitLandscapeToolSplatmapOptions._instance = new DevkitLandscapeToolSplatmapOptions();
			DevkitLandscapeToolSplatmapOptions.load();
		}

		// Token: 0x0400035E RID: 862
		private static DevkitLandscapeToolSplatmapOptions _instance;

		// Token: 0x0400035F RID: 863
		protected static float _paintSensitivity = 1f;

		// Token: 0x04000360 RID: 864
		private float _brushRadius = 16f;

		// Token: 0x04000361 RID: 865
		public float brushFalloff = 0.5f;

		// Token: 0x04000362 RID: 866
		public float brushStrength = 1f;

		// Token: 0x04000363 RID: 867
		public float autoStrength = 1f;

		// Token: 0x04000364 RID: 868
		public float smoothStrength = 1f;

		// Token: 0x04000365 RID: 869
		public bool useWeightTarget;

		// Token: 0x04000366 RID: 870
		public float weightTarget;

		// Token: 0x04000367 RID: 871
		public uint maxPreviewSamples = 1024U;

		// Token: 0x04000368 RID: 872
		public EDevkitLandscapeToolSplatmapSmoothMethod smoothMethod = EDevkitLandscapeToolSplatmapSmoothMethod.PIXEL_AVERAGE;

		// Token: 0x04000369 RID: 873
		public EDevkitLandscapeToolSplatmapPreviewMethod previewMethod;

		// Token: 0x0400036A RID: 874
		public bool useAutoSlope;

		// Token: 0x0400036B RID: 875
		public float autoMinAngleBegin = 50f;

		// Token: 0x0400036C RID: 876
		public float autoMinAngleEnd = 70f;

		// Token: 0x0400036D RID: 877
		public float autoMaxAngleBegin = 90f;

		// Token: 0x0400036E RID: 878
		public float autoMaxAngleEnd = 90f;

		// Token: 0x0400036F RID: 879
		public bool useAutoFoundation;

		// Token: 0x04000370 RID: 880
		public float autoRayRadius = 1f;

		// Token: 0x04000371 RID: 881
		public float autoRayLength = 512f;

		// Token: 0x04000372 RID: 882
		public ERayMask autoRayMask = (ERayMask)RayMasks.BLOCK_GRASS;

		// Token: 0x04000373 RID: 883
		protected static bool wasLoaded;
	}
}
