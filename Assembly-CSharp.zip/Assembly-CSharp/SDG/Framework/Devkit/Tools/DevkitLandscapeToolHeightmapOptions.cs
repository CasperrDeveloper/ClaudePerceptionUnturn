﻿using System;
using System.IO;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.IO.FormattedFiles.KeyValueTables;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x02000149 RID: 329
	public class DevkitLandscapeToolHeightmapOptions : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x1700010B RID: 267
		// (get) Token: 0x0600086D RID: 2157 RVA: 0x00020726 File Offset: 0x0001E926
		public static DevkitLandscapeToolHeightmapOptions instance
		{
			get
			{
				return DevkitLandscapeToolHeightmapOptions._instance;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600086E RID: 2158 RVA: 0x0002072D File Offset: 0x0001E92D
		// (set) Token: 0x0600086F RID: 2159 RVA: 0x00020734 File Offset: 0x0001E934
		public static float adjustSensitivity
		{
			get
			{
				return DevkitLandscapeToolHeightmapOptions._adjustSensitivity;
			}
			set
			{
				DevkitLandscapeToolHeightmapOptions._adjustSensitivity = value;
				UnturnedLog.info("Set adjust_sensitivity to: " + DevkitLandscapeToolHeightmapOptions.adjustSensitivity.ToString());
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000870 RID: 2160 RVA: 0x00020763 File Offset: 0x0001E963
		// (set) Token: 0x06000871 RID: 2161 RVA: 0x0002076C File Offset: 0x0001E96C
		public static float flattenSensitivity
		{
			get
			{
				return DevkitLandscapeToolHeightmapOptions._flattenSensitivity;
			}
			set
			{
				DevkitLandscapeToolHeightmapOptions._flattenSensitivity = value;
				UnturnedLog.info("Set flatten_sensitivity to: " + DevkitLandscapeToolHeightmapOptions.flattenSensitivity.ToString());
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000872 RID: 2162 RVA: 0x0002079B File Offset: 0x0001E99B
		// (set) Token: 0x06000873 RID: 2163 RVA: 0x000207A3 File Offset: 0x0001E9A3
		public float brushRadius
		{
			get
			{
				return this._brushRadius;
			}
			set
			{
				this._brushRadius = Mathf.Clamp(value, 0f, 2048f);
			}
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000207BC File Offset: 0x0001E9BC
		public static void load()
		{
			DevkitLandscapeToolHeightmapOptions.wasLoaded = true;
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Heightmap.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (!File.Exists(path))
			{
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					IFormattedFileReader reader = new KeyValueTableReader(streamReader);
					DevkitLandscapeToolHeightmapOptions.instance.read(reader);
				}
			}
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x0002085C File Offset: 0x0001EA5C
		public static void save()
		{
			if (!DevkitLandscapeToolHeightmapOptions.wasLoaded)
			{
				return;
			}
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Heightmap.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (StreamWriter streamWriter = new StreamWriter(path))
			{
				((IFormattedFileWriter)new KeyValueTableWriter(streamWriter)).writeValue<DevkitLandscapeToolHeightmapOptions>(DevkitLandscapeToolHeightmapOptions.instance);
			}
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x000208D0 File Offset: 0x0001EAD0
		public void read(IFormattedFileReader reader)
		{
			this.brushRadius = reader.readValue<float>("Brush_Radius");
			this.brushFalloff = reader.readValue<float>("Brush_Falloff");
			this.brushStrength = reader.readValue<float>("Brush_Strength");
			this.flattenStrength = reader.readValue<float>("Flatten_Strength");
			this.smoothStrength = reader.readValue<float>("Smooth_Strength");
			this.flattenTarget = reader.readValue<float>("Flatten_Target");
			this.maxPreviewSamples = reader.readValue<uint>("Max_Preview_Samples");
			this.smoothMethod = reader.readValue<EDevkitLandscapeToolHeightmapSmoothMethod>("Smooth_Method");
			this.flattenMethod = reader.readValue<EDevkitLandscapeToolHeightmapFlattenMethod>("Flatten_Method");
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00020978 File Offset: 0x0001EB78
		public void write(IFormattedFileWriter writer)
		{
			writer.writeValue<float>("Brush_Radius", this.brushRadius);
			writer.writeValue<float>("Brush_Falloff", this.brushFalloff);
			writer.writeValue<float>("Brush_Strength", this.brushStrength);
			writer.writeValue<float>("Flatten_Strength", this.flattenStrength);
			writer.writeValue<float>("Smooth_Strength", this.smoothStrength);
			writer.writeValue<float>("Flatten_Target", this.flattenTarget);
			writer.writeValue<uint>("Max_Preview_Samples", this.maxPreviewSamples);
			writer.writeValue<EDevkitLandscapeToolHeightmapSmoothMethod>("Smooth_Method", this.smoothMethod);
			writer.writeValue<EDevkitLandscapeToolHeightmapFlattenMethod>("Flatten_Method", this.flattenMethod);
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00020A1E File Offset: 0x0001EC1E
		static DevkitLandscapeToolHeightmapOptions()
		{
			DevkitLandscapeToolHeightmapOptions._instance = new DevkitLandscapeToolHeightmapOptions();
			DevkitLandscapeToolHeightmapOptions.load();
		}

		// Token: 0x0400034B RID: 843
		private static DevkitLandscapeToolHeightmapOptions _instance;

		// Token: 0x0400034C RID: 844
		protected static float _adjustSensitivity = 0.1f;

		// Token: 0x0400034D RID: 845
		protected static float _flattenSensitivity = 1f;

		// Token: 0x0400034E RID: 846
		private float _brushRadius = 16f;

		// Token: 0x0400034F RID: 847
		public float brushFalloff = 0.5f;

		// Token: 0x04000350 RID: 848
		public float brushStrength = 0.05f;

		// Token: 0x04000351 RID: 849
		public float flattenStrength = 1f;

		// Token: 0x04000352 RID: 850
		public float smoothStrength = 1f;

		// Token: 0x04000353 RID: 851
		public float flattenTarget;

		// Token: 0x04000354 RID: 852
		public uint maxPreviewSamples = 1024U;

		// Token: 0x04000355 RID: 853
		public EDevkitLandscapeToolHeightmapSmoothMethod smoothMethod = EDevkitLandscapeToolHeightmapSmoothMethod.PIXEL_AVERAGE;

		// Token: 0x04000356 RID: 854
		public EDevkitLandscapeToolHeightmapFlattenMethod flattenMethod;

		// Token: 0x04000357 RID: 855
		protected static bool wasLoaded;
	}
}
