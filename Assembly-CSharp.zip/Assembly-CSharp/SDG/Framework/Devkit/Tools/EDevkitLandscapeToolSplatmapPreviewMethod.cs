﻿using System;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x0200014B RID: 331
	public enum EDevkitLandscapeToolSplatmapPreviewMethod
	{
		// Token: 0x0400035C RID: 860
		BRUSH_ALPHA,
		// Token: 0x0400035D RID: 861
		WEIGHT
	}
}
