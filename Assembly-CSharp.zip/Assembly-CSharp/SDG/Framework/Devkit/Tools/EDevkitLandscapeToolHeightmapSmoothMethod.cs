﻿using System;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x02000147 RID: 327
	public enum EDevkitLandscapeToolHeightmapSmoothMethod
	{
		// Token: 0x04000345 RID: 837
		BRUSH_AVERAGE,
		// Token: 0x04000346 RID: 838
		PIXEL_AVERAGE
	}
}
