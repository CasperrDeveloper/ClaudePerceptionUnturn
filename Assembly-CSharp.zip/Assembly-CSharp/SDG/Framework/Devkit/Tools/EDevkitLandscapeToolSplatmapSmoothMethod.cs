﻿using System;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x0200014A RID: 330
	public enum EDevkitLandscapeToolSplatmapSmoothMethod
	{
		// Token: 0x04000359 RID: 857
		BRUSH_AVERAGE,
		// Token: 0x0400035A RID: 858
		PIXEL_AVERAGE
	}
}
