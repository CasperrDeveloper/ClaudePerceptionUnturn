﻿using System;
using System.IO;
using SDG.Framework.IO.FormattedFiles;
using SDG.Framework.IO.FormattedFiles.KeyValueTables;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit.Tools
{
	// Token: 0x02000146 RID: 326
	public class DevkitFoliageToolOptions : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000860 RID: 2144 RVA: 0x00020358 File Offset: 0x0001E558
		public static DevkitFoliageToolOptions instance
		{
			get
			{
				return DevkitFoliageToolOptions._instance;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x06000861 RID: 2145 RVA: 0x0002035F File Offset: 0x0001E55F
		// (set) Token: 0x06000862 RID: 2146 RVA: 0x00020368 File Offset: 0x0001E568
		public static float addSensitivity
		{
			get
			{
				return DevkitFoliageToolOptions._addSensitivity;
			}
			set
			{
				DevkitFoliageToolOptions._addSensitivity = value;
				UnturnedLog.info("Set add_sensitivity to: " + DevkitFoliageToolOptions.addSensitivity.ToString());
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000863 RID: 2147 RVA: 0x00020397 File Offset: 0x0001E597
		// (set) Token: 0x06000864 RID: 2148 RVA: 0x000203A0 File Offset: 0x0001E5A0
		public static float removeSensitivity
		{
			get
			{
				return DevkitFoliageToolOptions._removeSensitivity;
			}
			set
			{
				DevkitFoliageToolOptions._removeSensitivity = value;
				UnturnedLog.info("Set remove_sensitivity to: " + DevkitFoliageToolOptions.removeSensitivity.ToString());
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000865 RID: 2149 RVA: 0x000203CF File Offset: 0x0001E5CF
		// (set) Token: 0x06000866 RID: 2150 RVA: 0x000203D7 File Offset: 0x0001E5D7
		public float brushRadius
		{
			get
			{
				return this._brushRadius;
			}
			set
			{
				this._brushRadius = Mathf.Clamp(value, 0f, 2048f);
			}
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x000203F0 File Offset: 0x0001E5F0
		public static void load()
		{
			DevkitFoliageToolOptions.wasLoaded = true;
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Foliage.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (!File.Exists(path))
			{
				return;
			}
			using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					IFormattedFileReader reader = new KeyValueTableReader(streamReader);
					DevkitFoliageToolOptions.instance.read(reader);
				}
			}
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00020490 File Offset: 0x0001E690
		public static void save()
		{
			if (!DevkitFoliageToolOptions.wasLoaded)
			{
				return;
			}
			string path = PathEx.Join(UnturnedPaths.RootDirectory, "Cloud", "Foliage.tool");
			string directoryName = Path.GetDirectoryName(path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			using (StreamWriter streamWriter = new StreamWriter(path))
			{
				((IFormattedFileWriter)new KeyValueTableWriter(streamWriter)).writeValue<DevkitFoliageToolOptions>(DevkitFoliageToolOptions.instance);
			}
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00020504 File Offset: 0x0001E704
		public void read(IFormattedFileReader reader)
		{
			this.bakeInstancedMeshes = reader.readValue<bool>("Bake_Instanced_Meshes");
			this.bakeResources = reader.readValue<bool>("Bake_Resources");
			this.bakeObjects = reader.readValue<bool>("Bake_Objects");
			this.bakeClear = reader.readValue<bool>("Bake_Clear");
			this.bakeApplyScale = reader.readValue<bool>("Bake_Apply_Scale");
			this.brushRadius = reader.readValue<float>("Brush_Radius");
			this.brushFalloff = reader.readValue<float>("Brush_Falloff");
			this.brushStrength = reader.readValue<float>("Brush_Strength");
			this.densityTarget = reader.readValue<float>("Density_Target");
			this.surfaceMask = reader.readValue<ERayMask>("Surface_Mask");
			this.maxPreviewSamples = reader.readValue<uint>("Max_Preview_Samples");
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x000205CC File Offset: 0x0001E7CC
		public void write(IFormattedFileWriter writer)
		{
			writer.writeValue<bool>("Bake_Instanced_Meshes", this.bakeInstancedMeshes);
			writer.writeValue<bool>("Bake_Resources", this.bakeResources);
			writer.writeValue<bool>("Bake_Objects", this.bakeObjects);
			writer.writeValue<bool>("Bake_Clear", this.bakeClear);
			writer.writeValue<bool>("Bake_Apply_Scale", this.bakeApplyScale);
			writer.writeValue<float>("Brush_Radius", this.brushRadius);
			writer.writeValue<float>("Brush_Falloff", this.brushFalloff);
			writer.writeValue<float>("Brush_Strength", this.brushStrength);
			writer.writeValue<float>("Density_Target", this.densityTarget);
			writer.writeValue<ERayMask>("Surface_Mask", this.surfaceMask);
			writer.writeValue<uint>("Max_Preview_Samples", this.maxPreviewSamples);
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x00020694 File Offset: 0x0001E894
		static DevkitFoliageToolOptions()
		{
			DevkitFoliageToolOptions._instance = new DevkitFoliageToolOptions();
			DevkitFoliageToolOptions.load();
		}

		// Token: 0x04000335 RID: 821
		private static DevkitFoliageToolOptions _instance;

		// Token: 0x04000336 RID: 822
		protected static float _addSensitivity = 1f;

		// Token: 0x04000337 RID: 823
		protected static float _removeSensitivity = 1f;

		// Token: 0x04000338 RID: 824
		public bool bakeInstancedMeshes = true;

		// Token: 0x04000339 RID: 825
		public bool bakeResources = true;

		// Token: 0x0400033A RID: 826
		public bool bakeObjects = true;

		// Token: 0x0400033B RID: 827
		public bool bakeClear;

		// Token: 0x0400033C RID: 828
		public bool bakeApplyScale;

		// Token: 0x0400033D RID: 829
		private float _brushRadius = 16f;

		// Token: 0x0400033E RID: 830
		public float brushFalloff = 0.5f;

		// Token: 0x0400033F RID: 831
		public float brushStrength = 0.05f;

		// Token: 0x04000340 RID: 832
		public float densityTarget = 1f;

		// Token: 0x04000341 RID: 833
		public ERayMask surfaceMask = ERayMask.LARGE | ERayMask.MEDIUM | ERayMask.SMALL | ERayMask.ENVIRONMENT | ERayMask.GROUND;

		// Token: 0x04000342 RID: 834
		public uint maxPreviewSamples = 1024U;

		// Token: 0x04000343 RID: 835
		protected static bool wasLoaded;
	}
}
