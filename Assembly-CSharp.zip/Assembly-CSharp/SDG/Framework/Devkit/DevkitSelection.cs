﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	/// <summary>
	/// Hold onto collider and gameobject separately because collider isn't necessarily attached to gameobject.
	/// </summary>
	// Token: 0x02000114 RID: 276
	public class DevkitSelection : IEquatable<DevkitSelection>
	{
		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000728 RID: 1832 RVA: 0x0001D5FD File Offset: 0x0001B7FD
		// (set) Token: 0x06000729 RID: 1833 RVA: 0x0001D61A File Offset: 0x0001B81A
		public Transform transform
		{
			get
			{
				if (!(this.gameObject != null))
				{
					return null;
				}
				return this.gameObject.transform;
			}
			set
			{
				this.gameObject = ((value != null) ? value.gameObject : null);
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600072A RID: 1834 RVA: 0x0001D634 File Offset: 0x0001B834
		public bool isValid
		{
			get
			{
				return this.gameObject != null && this.collider != null;
			}
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0001D652 File Offset: 0x0001B852
		public bool Equals(DevkitSelection other)
		{
			return other != null && this.gameObject == other.gameObject;
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x0001D66C File Offset: 0x0001B86C
		public override bool Equals(object obj)
		{
			DevkitSelection other = obj as DevkitSelection;
			return this.Equals(other);
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x0001D687 File Offset: 0x0001B887
		public override int GetHashCode()
		{
			if (this.gameObject == null)
			{
				return -1;
			}
			return this.gameObject.GetHashCode();
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x0001D6A4 File Offset: 0x0001B8A4
		public DevkitSelection(GameObject newGameObject, Collider newCollider)
		{
			this.gameObject = newGameObject;
			this.collider = newCollider;
		}

		// Token: 0x040002E1 RID: 737
		public static DevkitSelection invalid = new DevkitSelection(null, null);

		// Token: 0x040002E2 RID: 738
		public GameObject gameObject;

		// Token: 0x040002E3 RID: 739
		public Collider collider;

		// Token: 0x040002E4 RID: 740
		public Vector3 preTransformPosition;

		// Token: 0x040002E5 RID: 741
		public Quaternion preTransformRotation;

		// Token: 0x040002E6 RID: 742
		public Vector3 preTransformLocalScale;

		// Token: 0x040002E7 RID: 743
		public Matrix4x4 localToWorld;

		// Token: 0x040002E8 RID: 744
		public Matrix4x4 relativeToPivot;
	}
}
