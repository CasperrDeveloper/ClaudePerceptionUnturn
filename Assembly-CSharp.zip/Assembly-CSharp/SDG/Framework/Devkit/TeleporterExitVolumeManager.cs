﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000135 RID: 309
	public class TeleporterExitVolumeManager : VolumeManager<TeleporterExitVolume, TeleporterExitVolumeManager>
	{
		// Token: 0x060007F3 RID: 2035 RVA: 0x0001F634 File Offset: 0x0001D834
		public TeleporterExitVolume FindExitVolume(string id)
		{
			if (string.IsNullOrEmpty(id))
			{
				return null;
			}
			List<TeleporterExitVolume> list;
			if (!this.idToVolumes.TryGetValue(id, out list))
			{
				return null;
			}
			return list.RandomOrDefault<TeleporterExitVolume>();
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x0001F663 File Offset: 0x0001D863
		public override void AddVolume(TeleporterExitVolume volume)
		{
			base.AddVolume(volume);
			this.AddVolumeToIdDictionary(volume);
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x0001F673 File Offset: 0x0001D873
		public override void RemoveVolume(TeleporterExitVolume volume)
		{
			this.RemoveVolumeFromIdDictionary(volume);
			base.RemoveVolume(volume);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x0001F684 File Offset: 0x0001D884
		internal void AddVolumeToIdDictionary(TeleporterExitVolume volume)
		{
			if (string.IsNullOrEmpty(volume.id))
			{
				return;
			}
			List<TeleporterExitVolume> list;
			if (!this.idToVolumes.TryGetValue(volume.id, out list))
			{
				list = new List<TeleporterExitVolume>();
				this.idToVolumes.Add(volume.id, list);
			}
			list.Add(volume);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x0001F6D4 File Offset: 0x0001D8D4
		internal void RemoveVolumeFromIdDictionary(TeleporterExitVolume volume)
		{
			if (string.IsNullOrEmpty(volume.id))
			{
				return;
			}
			List<TeleporterExitVolume> list;
			if (this.idToVolumes.TryGetValue(volume.id, out list))
			{
				list.RemoveFast(volume);
				if (list.Count < 1)
				{
					this.idToVolumes.Remove(volume.id);
				}
			}
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x0001F728 File Offset: 0x0001D928
		protected override void OnUpdateGizmos(RuntimeGizmos runtimeGizmos)
		{
			base.OnUpdateGizmos(runtimeGizmos);
			foreach (TeleporterExitVolume teleporterExitVolume in this.allVolumes)
			{
				Color color = teleporterExitVolume.isSelected ? Color.yellow : this.debugColor;
				runtimeGizmos.Arrow(teleporterExitVolume.transform.position, teleporterExitVolume.transform.forward, 1f, color, 0f, EGizmoLayer.World);
			}
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x0001F7BC File Offset: 0x0001D9BC
		public TeleporterExitVolumeManager()
		{
			base.FriendlyName = "Teleporter Exit";
			base.SetDebugColor(new Color32(0, 0, byte.MaxValue, byte.MaxValue));
		}

		// Token: 0x04000316 RID: 790
		internal Dictionary<string, List<TeleporterExitVolume>> idToVolumes = new Dictionary<string, List<TeleporterExitVolume>>();
	}
}
