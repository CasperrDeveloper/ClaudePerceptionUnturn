﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Interactable
{
	// Token: 0x0200014E RID: 334
	public interface IDevkitSelectionCopyableHandler
	{
		/// <returns>Identical to this object.</returns>
		// Token: 0x0600088C RID: 2188
		GameObject copySelection();
	}
}
