﻿using System;

namespace SDG.Framework.Devkit.Interactable
{
	// Token: 0x0200014F RID: 335
	public interface IDevkitSelectionTransformableHandler
	{
		/// <summary>
		/// Called when we position, rotate or scale this transform.
		/// </summary>
		// Token: 0x0600088D RID: 2189
		void transformSelection();
	}
}
