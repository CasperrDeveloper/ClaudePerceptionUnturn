﻿using System;

namespace SDG.Framework.Devkit.Interactable
{
	// Token: 0x02000151 RID: 337
	public interface IDevkitInteractableEndSelectionHandler
	{
		// Token: 0x0600088F RID: 2191
		void endSelection(InteractionData data);
	}
}
