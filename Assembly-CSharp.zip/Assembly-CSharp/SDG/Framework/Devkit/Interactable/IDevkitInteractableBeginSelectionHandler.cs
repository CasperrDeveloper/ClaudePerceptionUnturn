﻿using System;

namespace SDG.Framework.Devkit.Interactable
{
	// Token: 0x02000150 RID: 336
	public interface IDevkitInteractableBeginSelectionHandler
	{
		// Token: 0x0600088E RID: 2190
		void beginSelection(InteractionData data);
	}
}
