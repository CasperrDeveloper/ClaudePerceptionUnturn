﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Interactable
{
	// Token: 0x02000152 RID: 338
	public class InteractionData
	{
		// Token: 0x0400037E RID: 894
		public Vector3 point;

		// Token: 0x0400037F RID: 895
		public Collider collider;
	}
}
