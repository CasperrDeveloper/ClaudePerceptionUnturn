﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000113 RID: 275
	[Obsolete]
	public class DevkitHierarchyWorldObject : DevkitHierarchyWorldItem
	{
		/// <summary>
		/// Devkit objects are now converted to regular objects and excluded from the file when re-saving.
		/// </summary>
		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000722 RID: 1826 RVA: 0x0001D503 File Offset: 0x0001B703
		public override bool ShouldSave
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0001D508 File Offset: 0x0001B708
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.GUID = reader.readValue<Guid>("GUID");
			this.placementOrigin = reader.readValue<ELevelObjectPlacementOrigin>("Origin");
			this.customMaterialOverride = reader.readValue<AssetReference<MaterialPaletteAsset>>("Custom_Material_Override");
			if (reader.containsKey("Material_Index_Override"))
			{
				this.materialIndexOverride = reader.readValue<int>("Material_Index_Override");
			}
			else
			{
				this.materialIndexOverride = -1;
			}
			LevelHierarchy.instance.loadedAnyDevkitObjects = true;
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0001D581 File Offset: 0x0001B781
		protected void OnEnable()
		{
			LevelHierarchy.addItem(this);
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0001D589 File Offset: 0x0001B789
		protected void OnDisable()
		{
			LevelHierarchy.removeItem(this);
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x0001D594 File Offset: 0x0001B794
		protected void Start()
		{
			NetId devkitObjectNetId = LevelNetIdRegistry.GetDevkitObjectNetId(this.instanceID);
			byte b;
			byte b2;
			LevelObjects.registerDevkitObject(new LevelObject(base.inspectablePosition, base.inspectableRotation, base.inspectableScale, 0, this.GUID, this.placementOrigin, this.instanceID, this.customMaterialOverride, this.materialIndexOverride, devkitObjectNetId, true), out b, out b2);
		}

		// Token: 0x040002DD RID: 733
		public AssetReference<MaterialPaletteAsset> customMaterialOverride;

		// Token: 0x040002DE RID: 734
		public int materialIndexOverride = -1;

		// Token: 0x040002DF RID: 735
		public Guid GUID;

		// Token: 0x040002E0 RID: 736
		public ELevelObjectPlacementOrigin placementOrigin;
	}
}
