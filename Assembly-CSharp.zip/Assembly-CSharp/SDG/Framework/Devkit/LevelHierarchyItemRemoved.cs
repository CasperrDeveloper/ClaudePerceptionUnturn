﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000124 RID: 292
	// (Invoke) Token: 0x06000787 RID: 1927
	public delegate void LevelHierarchyItemRemoved(IDevkitHierarchyItem item);
}
