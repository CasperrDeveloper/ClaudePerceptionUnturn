﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012E RID: 302
	public class PlayerClipVolumeUtility
	{
		// Token: 0x060007C7 RID: 1991 RVA: 0x0001EE68 File Offset: 0x0001D068
		[Obsolete]
		public static bool isPointInsideVolume(Vector3 point)
		{
			return VolumeManager<PlayerClipVolume, PlayerClipVolumeManager>.Get().IsPositionInsideAnyVolume(point);
		}
	}
}
