﻿using System;
using System.Collections.Generic;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000134 RID: 308
	public class TeleporterEntranceVolumeManager : VolumeManager<TeleporterEntranceVolume, TeleporterEntranceVolumeManager>
	{
		// Token: 0x060007F1 RID: 2033 RVA: 0x0001F4E8 File Offset: 0x0001D6E8
		protected override void OnUpdateGizmos(RuntimeGizmos runtimeGizmos)
		{
			base.OnUpdateGizmos(runtimeGizmos);
			foreach (TeleporterEntranceVolume teleporterEntranceVolume in this.allVolumes)
			{
				Color color = teleporterEntranceVolume.isSelected ? Color.yellow : this.debugColor;
				runtimeGizmos.Arrow(teleporterEntranceVolume.transform.position, teleporterEntranceVolume.transform.forward, 1f, color, 0f, EGizmoLayer.World);
				List<TeleporterExitVolume> list;
				if (!string.IsNullOrEmpty(teleporterEntranceVolume.pairId) && VolumeManager<TeleporterExitVolume, TeleporterExitVolumeManager>.Get().idToVolumes.TryGetValue(teleporterEntranceVolume.pairId, out list))
				{
					foreach (TeleporterExitVolume teleporterExitVolume in list)
					{
						runtimeGizmos.Line(teleporterEntranceVolume.transform.position, teleporterExitVolume.transform.position, color, 0f, EGizmoLayer.World);
					}
				}
			}
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x0001F604 File Offset: 0x0001D804
		public TeleporterEntranceVolumeManager()
		{
			base.FriendlyName = "Teleporter Entrance";
			base.SetDebugColor(new Color32(0, 0, byte.MaxValue, byte.MaxValue));
		}
	}
}
