﻿using System;
using SDG.Framework.IO.FormattedFiles;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011E RID: 286
	public interface IDevkitHierarchyItem : IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000770 RID: 1904
		// (set) Token: 0x06000771 RID: 1905
		uint instanceID { get; set; }

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x06000772 RID: 1906
		GameObject areaSelectGameObject { get; }

		/// <summary>
		/// If true, write to LevelHierarchy file.
		/// False for externally managed objects like legacy lighting WaterVolume.
		/// </summary>
		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x06000773 RID: 1907
		bool ShouldSave { get; }

		/// <summary>
		/// If true, editor tools can select and transform.
		/// False for items like the object-owned culling volumes.
		/// </summary>
		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000774 RID: 1908
		bool CanBeSelected { get; }
	}
}
