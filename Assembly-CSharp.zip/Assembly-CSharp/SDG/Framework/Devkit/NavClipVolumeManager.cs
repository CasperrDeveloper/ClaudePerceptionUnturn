﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000129 RID: 297
	public class NavClipVolumeManager : VolumeManager<NavClipVolume, NavClipVolumeManager>
	{
		// Token: 0x060007B6 RID: 1974 RVA: 0x0001EB30 File Offset: 0x0001CD30
		public NavClipVolumeManager()
		{
			base.FriendlyName = "Navmesh Clip";
			base.SetDebugColor(new Color32(63, 63, 0, byte.MaxValue));
		}
	}
}
