﻿using System;
using SDG.Framework.IO.FormattedFiles;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010C RID: 268
	[Serializable]
	internal struct AmbianceVolumeTimeOfDaySettings
	{
		// Token: 0x060006E0 RID: 1760 RVA: 0x0001C871 File Offset: 0x0001AA71
		public AmbianceVolumeTimeOfDaySettings(IFormattedFileReader reader)
		{
			if (reader == null)
			{
				this.fogColor = Color.white;
				this.fogIntensity = 1f;
				return;
			}
			this.fogColor = reader.readValue<Color>("Fog_Color");
			this.fogIntensity = reader.readValue<float>("Fog_Intensity");
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x0001C8AF File Offset: 0x0001AAAF
		public void Write(IFormattedFileWriter writer)
		{
			writer.writeValue<Color>("Fog_Color", this.fogColor);
			writer.writeValue<float>("Fog_Intensity", this.fogIntensity);
		}

		// Token: 0x040002C1 RID: 705
		public Color fogColor;

		// Token: 0x040002C2 RID: 706
		public float fogIntensity;
	}
}
