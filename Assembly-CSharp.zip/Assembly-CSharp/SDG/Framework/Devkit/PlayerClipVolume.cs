﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012C RID: 300
	public class PlayerClipVolume : LevelVolume<PlayerClipVolume, PlayerClipVolumeManager>
	{
		// Token: 0x060007BF RID: 1983 RVA: 0x0001ED7C File Offset: 0x0001CF7C
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new PlayerClipVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x0001ED98 File Offset: 0x0001CF98
		// (set) Token: 0x060007C1 RID: 1985 RVA: 0x0001EDA0 File Offset: 0x0001CFA0
		public bool blockPlayer
		{
			get
			{
				return this._blockPlayer;
			}
			set
			{
				this._blockPlayer = value;
				if (!Level.isEditor)
				{
					this.volumeCollider.enabled = value;
				}
			}
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x0001EDBC File Offset: 0x0001CFBC
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			if (reader.containsKey("Block_Player"))
			{
				this.blockPlayer = reader.readValue<bool>("Block_Player");
				return;
			}
			this.blockPlayer = true;
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x0001EDEB File Offset: 0x0001CFEB
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<bool>("Block_Player", this.blockPlayer);
		}

		// Token: 0x060007C4 RID: 1988 RVA: 0x0001EE05 File Offset: 0x0001D005
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
			this.volumeCollider.isTrigger = false;
			base.gameObject.layer = 21;
		}

		// Token: 0x0400030D RID: 781
		[SerializeField]
		protected bool _blockPlayer = true;

		// Token: 0x02000916 RID: 2326
		private class Menu : SleekWrapper
		{
			// Token: 0x060050FC RID: 20732 RVA: 0x001F56C4 File Offset: 0x001F38C4
			public Menu(PlayerClipVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 40f;
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.blockPlayer;
				sleekToggle.AddLabel("Block Player", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnBlockPlayerToggled;
				base.AddChild(sleekToggle);
			}

			// Token: 0x060050FD RID: 20733 RVA: 0x001F5746 File Offset: 0x001F3946
			private void OnBlockPlayerToggled(ISleekToggle toggle, bool state)
			{
				this.volume.blockPlayer = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036EF RID: 14063
			private PlayerClipVolume volume;
		}
	}
}
