﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000118 RID: 280
	// (Invoke) Token: 0x0600073F RID: 1855
	public delegate void MarkedCleanHandler(IDirtyable item);
}
