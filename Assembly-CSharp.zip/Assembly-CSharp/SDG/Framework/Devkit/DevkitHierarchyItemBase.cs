﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000111 RID: 273
	public abstract class DevkitHierarchyItemBase : MonoBehaviour, IDevkitHierarchyItem, IFormattedFileReadable, IFormattedFileWritable
	{
		// Token: 0x170000DE RID: 222
		// (get) Token: 0x0600070E RID: 1806 RVA: 0x0001D33F File Offset: 0x0001B53F
		// (set) Token: 0x0600070F RID: 1807 RVA: 0x0001D347 File Offset: 0x0001B547
		public virtual uint instanceID { get; set; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000710 RID: 1808 RVA: 0x0001D350 File Offset: 0x0001B550
		public virtual GameObject areaSelectGameObject
		{
			get
			{
				return base.gameObject;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x06000711 RID: 1809 RVA: 0x0001D358 File Offset: 0x0001B558
		public virtual bool ShouldSave
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000712 RID: 1810 RVA: 0x0001D35B File Offset: 0x0001B55B
		public virtual bool CanBeSelected
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0001D35E File Offset: 0x0001B55E
		public NetId GetNetIdFromInstanceId()
		{
			if (this.instanceID > 0U)
			{
				return LevelNetIdRegistry.GetDevkitObjectNetId(this.instanceID);
			}
			return NetId.INVALID;
		}

		// Token: 0x06000714 RID: 1812
		public abstract void read(IFormattedFileReader reader);

		// Token: 0x06000715 RID: 1813
		public abstract void write(IFormattedFileWriter writer);
	}
}
