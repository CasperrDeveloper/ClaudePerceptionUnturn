﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000120 RID: 288
	public interface IDirtyable
	{
		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000778 RID: 1912
		// (set) Token: 0x06000779 RID: 1913
		bool isDirty { get; set; }

		// Token: 0x0600077A RID: 1914
		void save();
	}
}
