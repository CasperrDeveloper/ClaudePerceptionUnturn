﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000122 RID: 290
	public class KillVolumeManager : VolumeManager<KillVolume, KillVolumeManager>
	{
		// Token: 0x06000781 RID: 1921 RVA: 0x0001E45E File Offset: 0x0001C65E
		public KillVolumeManager()
		{
			base.FriendlyName = "Kill";
			base.SetDebugColor(new Color32(220, 100, 20, byte.MaxValue));
		}
	}
}
