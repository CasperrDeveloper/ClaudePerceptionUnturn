﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010B RID: 267
	public enum EAmbianceVolumeFogOverrideMode
	{
		/// <summary>
		/// Volume doesn't override fog.
		/// </summary>
		// Token: 0x040002BE RID: 702
		None,
		/// <summary>
		/// Volume fog settings are the same at all times of day.
		/// </summary>
		// Token: 0x040002BF RID: 703
		Constant,
		/// <summary>
		/// Volume fog settings vary throughout the day.
		/// </summary>
		// Token: 0x040002C0 RID: 704
		PerTimeOfDay
	}
}
