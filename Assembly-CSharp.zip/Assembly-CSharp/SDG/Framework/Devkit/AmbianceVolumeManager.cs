﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000109 RID: 265
	public class AmbianceVolumeManager : VolumeManager<AmbianceVolume, AmbianceVolumeManager>
	{
		// Token: 0x060006DC RID: 1756 RVA: 0x0001C815 File Offset: 0x0001AA15
		public AmbianceVolumeManager()
		{
			base.FriendlyName = "Ambiance";
			base.SetDebugColor(new Color32(0, 127, 127, byte.MaxValue));
			this.supportsFalloff = true;
		}
	}
}
