﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000126 RID: 294
	// (Invoke) Token: 0x0600078F RID: 1935
	public delegate void LevelHierarchyReady();
}
