﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012F RID: 303
	public class Spawnpoint : TempNodeBase
	{
		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x060007C9 RID: 1993 RVA: 0x0001EE7D File Offset: 0x0001D07D
		// (set) Token: 0x060007CA RID: 1994 RVA: 0x0001EE85 File Offset: 0x0001D085
		public string SpawnpointID
		{
			get
			{
				return this.id;
			}
			set
			{
				if (!string.Equals(this.id, value))
				{
					SpawnpointSystemV2.Get().RemoveSpawnpointFromIdDictionary(this);
					this.id = value;
					SpawnpointSystemV2.Get().AddSpawnpointToIdDictionary(this);
				}
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x0001EEB2 File Offset: 0x0001D0B2
		// (set) Token: 0x060007CC RID: 1996 RVA: 0x0001EEBA File Offset: 0x0001D0BA
		public SphereCollider sphere { get; protected set; }

		// Token: 0x060007CD RID: 1997 RVA: 0x0001EEC3 File Offset: 0x0001D0C3
		internal override ISleekElement CreateMenu()
		{
			return new Spawnpoint.Menu(this);
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x0001EECB File Offset: 0x0001D0CB
		internal void UpdateEditorVisibility()
		{
			this.sphere.enabled = SpawnpointSystemV2.Get().IsVisible;
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x0001EEE2 File Offset: 0x0001D0E2
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.SpawnpointID = reader.readValue<string>("ID");
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x0001EEFC File Offset: 0x0001D0FC
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue("ID", this.SpawnpointID);
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x0001EF16 File Offset: 0x0001D116
		protected void OnEnable()
		{
			LevelHierarchy.addItem(this);
			SpawnpointSystemV2.Get().AddSpawnpoint(this);
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x0001EF29 File Offset: 0x0001D129
		protected void OnDisable()
		{
			SpawnpointSystemV2.Get().RemoveSpawnpoint(this);
			LevelHierarchy.removeItem(this);
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x0001EF3C File Offset: 0x0001D13C
		protected void Awake()
		{
			base.name = "Spawnpoint";
			base.gameObject.layer = 30;
			if (Level.isEditor)
			{
				this.sphere = base.gameObject.GetOrAddComponent<SphereCollider>();
				this.sphere.radius = 0.5f;
				this.UpdateEditorVisibility();
			}
		}

		// Token: 0x0400030E RID: 782
		[SerializeField]
		public string id;

		// Token: 0x02000917 RID: 2327
		private class Menu : SleekWrapper
		{
			// Token: 0x060050FE RID: 20734 RVA: 0x001F575C File Offset: 0x001F395C
			public Menu(Spawnpoint node)
			{
				this.node = node;
				base.SizeOffset_X = 400f;
				float num = 0f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.PositionOffset_Y = num;
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				sleekField.Text = node.id;
				sleekField.AddLabel("ID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdTyped;
				base.AddChild(sleekField);
				num += sleekField.SizeOffset_Y + 10f;
				base.SizeOffset_Y = num - 10f;
			}

			// Token: 0x060050FF RID: 20735 RVA: 0x001F57FC File Offset: 0x001F39FC
			private void OnIdTyped(ISleekField field, string state)
			{
				this.node.SpawnpointID = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036F0 RID: 14064
			private Spawnpoint node;
		}
	}
}
