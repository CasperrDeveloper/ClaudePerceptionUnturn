﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011A RID: 282
	// (Invoke) Token: 0x06000747 RID: 1863
	public delegate void DirtySaved();
}
