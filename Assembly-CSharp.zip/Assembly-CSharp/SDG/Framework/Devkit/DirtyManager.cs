﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011B RID: 283
	public class DirtyManager
	{
		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x0001DA17 File Offset: 0x0001BC17
		public static List<IDirtyable> dirty
		{
			get
			{
				return DirtyManager._dirty;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600074B RID: 1867 RVA: 0x0001DA1E File Offset: 0x0001BC1E
		public static HashSet<IDirtyable> notSaveable
		{
			get
			{
				return DirtyManager._notSaveable;
			}
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x0600074C RID: 1868 RVA: 0x0001DA28 File Offset: 0x0001BC28
		// (remove) Token: 0x0600074D RID: 1869 RVA: 0x0001DA5C File Offset: 0x0001BC5C
		public static event MarkedDirtyHandler markedDirty;

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x0600074E RID: 1870 RVA: 0x0001DA90 File Offset: 0x0001BC90
		// (remove) Token: 0x0600074F RID: 1871 RVA: 0x0001DAC4 File Offset: 0x0001BCC4
		public static event MarkedCleanHandler markedClean;

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x06000750 RID: 1872 RVA: 0x0001DAF8 File Offset: 0x0001BCF8
		// (remove) Token: 0x06000751 RID: 1873 RVA: 0x0001DB2C File Offset: 0x0001BD2C
		public static event SaveableChangedHandler saveableChanged;

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x06000752 RID: 1874 RVA: 0x0001DB60 File Offset: 0x0001BD60
		// (remove) Token: 0x06000753 RID: 1875 RVA: 0x0001DB94 File Offset: 0x0001BD94
		public static event DirtySaved saved;

		// Token: 0x06000754 RID: 1876 RVA: 0x0001DBC7 File Offset: 0x0001BDC7
		public static void markDirty(IDirtyable item)
		{
			DirtyManager.dirty.Add(item);
			DirtyManager.triggerMarkedDirty(item);
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0001DBDA File Offset: 0x0001BDDA
		public static void markClean(IDirtyable item)
		{
			if (DirtyManager.isSaving)
			{
				return;
			}
			DirtyManager.dirty.Remove(item);
			DirtyManager.triggerMarkedClean(item);
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x0001DBF6 File Offset: 0x0001BDF6
		public static bool checkSaveable(IDirtyable item)
		{
			return !DirtyManager.notSaveable.Contains(item);
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0001DC06 File Offset: 0x0001BE06
		public static void toggleSaveable(IDirtyable item)
		{
			if (!DirtyManager.notSaveable.Remove(item))
			{
				DirtyManager.notSaveable.Add(item);
				DirtyManager.triggerSaveableChanged(item, true);
				return;
			}
			DirtyManager.triggerSaveableChanged(item, false);
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x0001DC30 File Offset: 0x0001BE30
		public static void save()
		{
			DirtyManager.isSaving = true;
			for (int i = DirtyManager.dirty.Count - 1; i >= 0; i--)
			{
				IDirtyable dirtyable = DirtyManager.dirty[i];
				if (!DirtyManager.notSaveable.Contains(dirtyable))
				{
					dirtyable.save();
					dirtyable.isDirty = false;
					DirtyManager.dirty.RemoveAt(i);
				}
			}
			DirtyManager.isSaving = false;
			DirtyManager.triggerSaved();
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0001DC96 File Offset: 0x0001BE96
		protected static void triggerMarkedDirty(IDirtyable item)
		{
			MarkedDirtyHandler markedDirtyHandler = DirtyManager.markedDirty;
			if (markedDirtyHandler == null)
			{
				return;
			}
			markedDirtyHandler(item);
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x0001DCA8 File Offset: 0x0001BEA8
		protected static void triggerMarkedClean(IDirtyable item)
		{
			MarkedCleanHandler markedCleanHandler = DirtyManager.markedClean;
			if (markedCleanHandler == null)
			{
				return;
			}
			markedCleanHandler(item);
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x0001DCBA File Offset: 0x0001BEBA
		protected static void triggerSaveableChanged(IDirtyable item, bool isSaveable)
		{
			SaveableChangedHandler saveableChangedHandler = DirtyManager.saveableChanged;
			if (saveableChangedHandler == null)
			{
				return;
			}
			saveableChangedHandler(item, isSaveable);
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0001DCCD File Offset: 0x0001BECD
		protected static void triggerSaved()
		{
			DirtySaved dirtySaved = DirtyManager.saved;
			if (dirtySaved == null)
			{
				return;
			}
			dirtySaved();
		}

		// Token: 0x040002EE RID: 750
		protected static List<IDirtyable> _dirty = new List<IDirtyable>();

		// Token: 0x040002EF RID: 751
		public static HashSet<IDirtyable> _notSaveable = new HashSet<IDirtyable>();

		// Token: 0x040002F4 RID: 756
		protected static bool isSaving;
	}
}
