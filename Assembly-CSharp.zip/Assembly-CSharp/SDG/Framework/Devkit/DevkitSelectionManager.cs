﻿using System;
using System.Collections.Generic;
using SDG.Framework.Devkit.Interactable;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000115 RID: 277
	public class DevkitSelectionManager
	{
		// Token: 0x06000730 RID: 1840 RVA: 0x0001D6C8 File Offset: 0x0001B8C8
		public static void select(DevkitSelection select)
		{
			if (select == null)
			{
				return;
			}
			if (!InputEx.GetKey(KeyCode.LeftShift) && !InputEx.GetKey(KeyCode.LeftControl))
			{
				DevkitSelectionManager.clear();
				DevkitSelectionManager.add(select);
				return;
			}
			if (DevkitSelectionManager.selection.Contains(select))
			{
				DevkitSelectionManager.remove(select);
				return;
			}
			DevkitSelectionManager.add(select);
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x0001D718 File Offset: 0x0001B918
		public static void add(DevkitSelection select)
		{
			if (select == null || select.gameObject == null)
			{
				return;
			}
			if (DevkitSelectionManager.selection.Contains(select))
			{
				return;
			}
			if (DevkitSelectionManager.beginSelection(select))
			{
				DevkitSelectionManager.selection.Add(select);
				DevkitSelectionManager.mostRecentGameObject = select.gameObject;
			}
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x0001D764 File Offset: 0x0001B964
		public static void remove(DevkitSelection select)
		{
			if (select == null)
			{
				return;
			}
			if (DevkitSelectionManager.selection.Remove(select))
			{
				DevkitSelectionManager.endSelection(select);
				if (select.gameObject == DevkitSelectionManager.mostRecentGameObject)
				{
					DevkitSelectionManager.mostRecentGameObject = null;
				}
			}
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x0001D798 File Offset: 0x0001B998
		public static void clear()
		{
			foreach (DevkitSelection select in DevkitSelectionManager.selection)
			{
				DevkitSelectionManager.endSelection(select);
			}
			DevkitSelectionManager.selection.Clear();
			DevkitSelectionManager.mostRecentGameObject = null;
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x0001D7F8 File Offset: 0x0001B9F8
		public static bool beginSelection(DevkitSelection select)
		{
			if (select == null || select.gameObject == null)
			{
				return false;
			}
			DevkitSelectionManager.data.collider = select.collider;
			DevkitSelectionManager.beginSelectionHandlers.Clear();
			select.gameObject.GetComponentsInChildren<IDevkitInteractableBeginSelectionHandler>(DevkitSelectionManager.beginSelectionHandlers);
			foreach (IDevkitInteractableBeginSelectionHandler devkitInteractableBeginSelectionHandler in DevkitSelectionManager.beginSelectionHandlers)
			{
				devkitInteractableBeginSelectionHandler.beginSelection(DevkitSelectionManager.data);
			}
			return DevkitSelectionManager.beginSelectionHandlers.Count > 0;
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x0001D898 File Offset: 0x0001BA98
		public static bool endSelection(DevkitSelection select)
		{
			if (select == null || select.gameObject == null)
			{
				return false;
			}
			DevkitSelectionManager.data.collider = select.collider;
			DevkitSelectionManager.endSelectionHandlers.Clear();
			select.gameObject.GetComponentsInChildren<IDevkitInteractableEndSelectionHandler>(DevkitSelectionManager.endSelectionHandlers);
			foreach (IDevkitInteractableEndSelectionHandler devkitInteractableEndSelectionHandler in DevkitSelectionManager.endSelectionHandlers)
			{
				devkitInteractableEndSelectionHandler.endSelection(DevkitSelectionManager.data);
			}
			return DevkitSelectionManager.endSelectionHandlers.Count > 0;
		}

		// Token: 0x040002E9 RID: 745
		protected static List<IDevkitInteractableBeginSelectionHandler> beginSelectionHandlers = new List<IDevkitInteractableBeginSelectionHandler>();

		// Token: 0x040002EA RID: 746
		protected static List<IDevkitInteractableEndSelectionHandler> endSelectionHandlers = new List<IDevkitInteractableEndSelectionHandler>();

		// Token: 0x040002EB RID: 747
		public static HashSet<DevkitSelection> selection = new HashSet<DevkitSelection>();

		// Token: 0x040002EC RID: 748
		public static InteractionData data = new InteractionData();

		// Token: 0x040002ED RID: 749
		public static GameObject mostRecentGameObject = null;
	}
}
