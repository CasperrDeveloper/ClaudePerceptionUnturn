﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010A RID: 266
	public class AmbianceUtility
	{
		// Token: 0x060006DD RID: 1757 RVA: 0x0001C849 File Offset: 0x0001AA49
		[Obsolete]
		public static bool isPointInsideVolume(Vector3 point, out AmbianceVolume volume)
		{
			volume = VolumeManager<AmbianceVolume, AmbianceVolumeManager>.Get().GetFirstOverlappingVolume(point);
			return volume != null;
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x0001C860 File Offset: 0x0001AA60
		[Obsolete]
		public static bool isPointInsideVolume(AmbianceVolume volume, Vector3 point)
		{
			return volume.IsPositionInsideVolume(point);
		}
	}
}
