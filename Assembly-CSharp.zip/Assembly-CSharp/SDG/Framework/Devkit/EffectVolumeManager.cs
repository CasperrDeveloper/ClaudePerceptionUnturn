﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011D RID: 285
	public class EffectVolumeManager : VolumeManager<EffectVolume, EffectVolumeManager>
	{
		// Token: 0x0600076F RID: 1903 RVA: 0x0001E102 File Offset: 0x0001C302
		public EffectVolumeManager()
		{
			base.FriendlyName = "Effect";
			base.SetDebugColor(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue));
		}
	}
}
