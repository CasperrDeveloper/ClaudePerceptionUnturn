﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000132 RID: 306
	public class TeleporterEntranceVolume : LevelVolume<TeleporterEntranceVolume, TeleporterEntranceVolumeManager>
	{
		// Token: 0x060007E5 RID: 2021 RVA: 0x0001F3A4 File Offset: 0x0001D5A4
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new TeleporterEntranceVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x0001F3C0 File Offset: 0x0001D5C0
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.pairId = reader.readValue<string>("Pair_Id");
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x0001F3DA File Offset: 0x0001D5DA
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue("Pair_Id", this.pairId);
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x0001F3F4 File Offset: 0x0001D5F4
		public void OnTriggerEnter(Collider other)
		{
			TeleporterExitVolume teleporterExitVolume = VolumeManager<TeleporterExitVolume, TeleporterExitVolumeManager>.Get().FindExitVolume(this.pairId);
			if (teleporterExitVolume != null)
			{
				PlayerMovement component = other.gameObject.GetComponent<PlayerMovement>();
				if (component != null && component.CanEnterTeleporter)
				{
					component.EnterTeleporterVolume(this, teleporterExitVolume);
				}
			}
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x0001F440 File Offset: 0x0001D640
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
		}

		// Token: 0x04000314 RID: 788
		[SerializeField]
		public string pairId;

		// Token: 0x02000919 RID: 2329
		private class Menu : SleekWrapper
		{
			// Token: 0x06005109 RID: 20745 RVA: 0x001F5994 File Offset: 0x001F3B94
			public Menu(TeleporterEntranceVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 30f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				sleekField.Text = volume.pairId;
				sleekField.AddLabel("Pair ID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdChanged;
				base.AddChild(sleekField);
			}

			// Token: 0x0600510A RID: 20746 RVA: 0x001F5A16 File Offset: 0x001F3C16
			private void OnIdChanged(ISleekField field, string id)
			{
				this.volume.pairId = id;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036F6 RID: 14070
			private TeleporterEntranceVolume volume;
		}
	}
}
