﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200011C RID: 284
	public class EffectVolume : LevelVolume<EffectVolume, EffectVolumeManager>
	{
		// Token: 0x0600075F RID: 1887 RVA: 0x0001DCFC File Offset: 0x0001BEFC
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new EffectVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000760 RID: 1888 RVA: 0x0001DD18 File Offset: 0x0001BF18
		public Guid EffectGuid
		{
			get
			{
				return this._effectGuid;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000761 RID: 1889 RVA: 0x0001DD20 File Offset: 0x0001BF20
		// (set) Token: 0x06000762 RID: 1890 RVA: 0x0001DD28 File Offset: 0x0001BF28
		public ushort id
		{
			[Obsolete]
			get
			{
				return this._id;
			}
			[Obsolete]
			set
			{
				this._id = value;
				this.SyncEffect();
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000763 RID: 1891 RVA: 0x0001DD37 File Offset: 0x0001BF37
		// (set) Token: 0x06000764 RID: 1892 RVA: 0x0001DD3F File Offset: 0x0001BF3F
		public float emissionMultiplier
		{
			get
			{
				return this._emissionMultiplier;
			}
			set
			{
				this._emissionMultiplier = value;
				if (this.effect != null)
				{
					this.applyEmission();
				}
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000765 RID: 1893 RVA: 0x0001DD5C File Offset: 0x0001BF5C
		// (set) Token: 0x06000766 RID: 1894 RVA: 0x0001DD64 File Offset: 0x0001BF64
		public float audioRangeMultiplier
		{
			get
			{
				return this._audioRangeMultiplier;
			}
			set
			{
				this._audioRangeMultiplier = value;
				if (this.effect != null)
				{
					this.applyAudioRange();
				}
			}
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x0001DD84 File Offset: 0x0001BF84
		private void SyncEffect()
		{
			if (this.effect != null)
			{
				UnityEngine.Object.Destroy(this.effect.gameObject);
				this.effect = null;
			}
			EffectAsset effectAsset = Assets.FindEffectAssetByGuidOrLegacyId(this._effectGuid, this._id);
			if (effectAsset != null && effectAsset.effect != null && (!Dedicator.IsDedicatedServer || effectAsset.spawnOnDedicatedServer))
			{
				InstantiateParameters parameters = new InstantiateParameters
				{
					parent = base.transform,
					worldSpace = false
				};
				this.effect = UnityEngine.Object.Instantiate<GameObject>(effectAsset.effect, Vector3.zero, Quaternion.Euler(-90f, 0f, 0f), parameters).transform;
				this.effect.name = "Effect";
				this.effect.transform.localScale = new Vector3(1f, 1f, 1f);
				ParticleSystem component = this.effect.GetComponent<ParticleSystem>();
				if (component != null)
				{
					this.maxParticlesBase = component.main.maxParticles;
					this.rateOverTimeBase = component.emission.rateOverTimeMultiplier;
				}
				AudioSource component2 = this.effect.GetComponent<AudioSource>();
				if (component2 != null && component2.clip != null)
				{
					component2.time = UnityEngine.Random.Range(0f, component2.clip.length);
				}
			}
			if (this.effect != null)
			{
				this.applyEmission();
				this.applyAudioRange();
			}
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x0001DF0C File Offset: 0x0001C10C
		protected virtual void applyEmission()
		{
			if (this.effect == null)
			{
				return;
			}
			ParticleSystem component = this.effect.GetComponent<ParticleSystem>();
			if (component == null)
			{
				return;
			}
			component.main.maxParticles = (int)((float)this.maxParticlesBase * this.emissionMultiplier);
			component.emission.rateOverTimeMultiplier = this.rateOverTimeBase * this.emissionMultiplier;
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x0001DF78 File Offset: 0x0001C178
		protected virtual void applyAudioRange()
		{
			if (this.effect == null)
			{
				return;
			}
			AudioSource component = this.effect.GetComponent<AudioSource>();
			if (component == null)
			{
				return;
			}
			component.maxDistance = this.audioRangeMultiplier;
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x0001DFB8 File Offset: 0x0001C1B8
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			if (reader.containsKey("Emission"))
			{
				this._emissionMultiplier = reader.readValue<float>("Emission");
			}
			if (reader.containsKey("Audio_Range"))
			{
				this._audioRangeMultiplier = reader.readValue<float>("Audio_Range");
			}
			string text = reader.readValue("ID");
			if (ushort.TryParse(text, out this._id))
			{
				this._effectGuid = Guid.Empty;
				this.SyncEffect();
				return;
			}
			if (Guid.TryParse(text, out this._effectGuid))
			{
				this._id = 0;
				this.SyncEffect();
			}
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x0001E050 File Offset: 0x0001C250
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			if (!this._effectGuid.IsEmpty())
			{
				writer.writeValue<Guid>("ID", this._effectGuid);
			}
			else
			{
				writer.writeValue<ushort>("ID", this._id);
			}
			writer.writeValue<float>("Emission", this.emissionMultiplier);
			writer.writeValue<float>("Audio_Range", this.audioRangeMultiplier);
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x0001E0B7 File Offset: 0x0001C2B7
		protected override void Awake()
		{
			this.supportsSphereShape = false;
			base.Awake();
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x0001E0C6 File Offset: 0x0001C2C6
		protected override void Start()
		{
			base.Start();
			this.effect = base.transform.Find("Effect");
		}

		// Token: 0x040002F5 RID: 757
		[SerializeField]
		internal Guid _effectGuid;

		/// <summary>
		/// Kept because lots of modders have been using this script in Unity,
		/// so removing legacy effect id would break their content.
		/// </summary>
		// Token: 0x040002F6 RID: 758
		[SerializeField]
		protected ushort _id;

		// Token: 0x040002F7 RID: 759
		[SerializeField]
		protected int maxParticlesBase;

		// Token: 0x040002F8 RID: 760
		[SerializeField]
		protected float rateOverTimeBase;

		// Token: 0x040002F9 RID: 761
		[SerializeField]
		protected float _emissionMultiplier = 1f;

		// Token: 0x040002FA RID: 762
		[SerializeField]
		protected float _audioRangeMultiplier = 1f;

		// Token: 0x040002FB RID: 763
		protected Transform effect;

		// Token: 0x02000913 RID: 2323
		private class Menu : SleekWrapper
		{
			// Token: 0x060050EE RID: 20718 RVA: 0x001F5034 File Offset: 0x001F3234
			public Menu(EffectVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 110f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				if (volume._effectGuid.IsEmpty())
				{
					sleekField.Text = volume._id.ToString();
				}
				else
				{
					sleekField.Text = volume._effectGuid.ToString("N");
				}
				sleekField.AddLabel("Effect ID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdChanged;
				base.AddChild(sleekField);
				ISleekFloat32Field sleekFloat32Field = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field.PositionOffset_Y = 40f;
				sleekFloat32Field.SizeOffset_X = 200f;
				sleekFloat32Field.SizeOffset_Y = 30f;
				sleekFloat32Field.Value = volume.emissionMultiplier;
				sleekFloat32Field.AddLabel("Emission Rate", ESleekSide.RIGHT);
				sleekFloat32Field.OnValueChanged += this.OnEmissionChanged;
				base.AddChild(sleekFloat32Field);
				ISleekFloat32Field sleekFloat32Field2 = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field2.PositionOffset_Y = 80f;
				sleekFloat32Field2.SizeOffset_X = 200f;
				sleekFloat32Field2.SizeOffset_Y = 30f;
				sleekFloat32Field2.Value = volume.audioRangeMultiplier;
				sleekFloat32Field2.AddLabel("Audio Range", ESleekSide.RIGHT);
				sleekFloat32Field2.OnValueChanged += this.OnAudioRangeChanged;
				base.AddChild(sleekFloat32Field2);
			}

			// Token: 0x060050EF RID: 20719 RVA: 0x001F519C File Offset: 0x001F339C
			private void OnIdChanged(ISleekField field, string effectIdString)
			{
				if (ushort.TryParse(effectIdString, out this.volume._id))
				{
					this.volume._effectGuid = Guid.Empty;
					this.volume.SyncEffect();
				}
				else if (Guid.TryParse(effectIdString, out this.volume._effectGuid))
				{
					this.volume._id = 0;
					this.volume.SyncEffect();
				}
				else
				{
					this.volume._effectGuid = Guid.Empty;
					this.volume._id = 0;
					this.volume.SyncEffect();
				}
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F0 RID: 20720 RVA: 0x001F5231 File Offset: 0x001F3431
			private void OnEmissionChanged(ISleekFloat32Field field, float value)
			{
				this.volume.emissionMultiplier = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050F1 RID: 20721 RVA: 0x001F5244 File Offset: 0x001F3444
			private void OnAudioRangeChanged(ISleekFloat32Field field, float value)
			{
				this.volume.audioRangeMultiplier = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036EB RID: 14059
			private EffectVolume volume;
		}
	}
}
