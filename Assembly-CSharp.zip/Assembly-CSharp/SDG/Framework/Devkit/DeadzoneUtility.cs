﻿using System;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010E RID: 270
	public class DeadzoneUtility
	{
		// Token: 0x060006FA RID: 1786 RVA: 0x0001D03B File Offset: 0x0001B23B
		[Obsolete]
		public static bool isPointInsideVolume(Vector3 point, out DeadzoneVolume volume)
		{
			volume = VolumeManager<DeadzoneVolume, DeadzoneVolumeManager>.Get().GetMostDangerousOverlappingVolume(point);
			return volume != null;
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x0001D052 File Offset: 0x0001B252
		[Obsolete]
		public static bool isPointInsideVolume(DeadzoneVolume volume, Vector3 point)
		{
			return volume.IsPositionInsideVolume(point);
		}
	}
}
