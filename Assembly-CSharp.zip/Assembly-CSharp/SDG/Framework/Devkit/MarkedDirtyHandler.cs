﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000117 RID: 279
	// (Invoke) Token: 0x0600073B RID: 1851
	public delegate void MarkedDirtyHandler(IDirtyable item);
}
