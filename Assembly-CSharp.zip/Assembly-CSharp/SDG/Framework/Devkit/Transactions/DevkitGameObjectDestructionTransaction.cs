﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000138 RID: 312
	public class DevkitGameObjectDestructionTransaction : IDevkitTransaction
	{
		// Token: 0x170000FC RID: 252
		// (get) Token: 0x060007FC RID: 2044 RVA: 0x0001F82C File Offset: 0x0001DA2C
		public bool delta
		{
			get
			{
				return true;
			}
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x0001F82F File Offset: 0x0001DA2F
		public void undo()
		{
			if (this.go != null)
			{
				this.go.SetActive(true);
			}
			this.isActive = true;
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x0001F852 File Offset: 0x0001DA52
		public void redo()
		{
			if (this.go != null)
			{
				this.go.SetActive(false);
			}
			this.isActive = false;
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x0001F875 File Offset: 0x0001DA75
		public void begin()
		{
			if (this.go != null)
			{
				this.go.SetActive(false);
			}
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x0001F891 File Offset: 0x0001DA91
		public void end()
		{
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x0001F893 File Offset: 0x0001DA93
		public void forget()
		{
			if (this.go != null && !this.isActive)
			{
				UnityEngine.Object.Destroy(this.go);
			}
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x0001F8B6 File Offset: 0x0001DAB6
		public DevkitGameObjectDestructionTransaction(GameObject newGO)
		{
			this.go = newGO;
			this.isActive = false;
		}

		// Token: 0x04000317 RID: 791
		protected GameObject go;

		// Token: 0x04000318 RID: 792
		protected bool isActive;
	}
}
