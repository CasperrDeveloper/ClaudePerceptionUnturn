﻿using System;
using System.Collections.Generic;
using SDG.Unturned;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013E RID: 318
	public class DevkitTransactionManager
	{
		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000825 RID: 2085 RVA: 0x0001FE02 File Offset: 0x0001E002
		// (set) Token: 0x06000826 RID: 2086 RVA: 0x0001FE0C File Offset: 0x0001E00C
		public static uint historyLength
		{
			get
			{
				return DevkitTransactionManager._historyLength;
			}
			set
			{
				DevkitTransactionManager._historyLength = value;
				UnturnedLog.info("Set history_length to: " + DevkitTransactionManager.historyLength.ToString());
			}
		}

		// Token: 0x14000028 RID: 40
		// (add) Token: 0x06000827 RID: 2087 RVA: 0x0001FE3C File Offset: 0x0001E03C
		// (remove) Token: 0x06000828 RID: 2088 RVA: 0x0001FE70 File Offset: 0x0001E070
		public static event DevkitTransactionPerformedHandler transactionPerformed;

		// Token: 0x06000829 RID: 2089 RVA: 0x0001FEA3 File Offset: 0x0001E0A3
		protected static void triggerTransactionPerformed(DevkitTransactionGroup group)
		{
			DevkitTransactionPerformedHandler devkitTransactionPerformedHandler = DevkitTransactionManager.transactionPerformed;
			if (devkitTransactionPerformedHandler == null)
			{
				return;
			}
			devkitTransactionPerformedHandler(group);
		}

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x0600082A RID: 2090 RVA: 0x0001FEB8 File Offset: 0x0001E0B8
		// (remove) Token: 0x0600082B RID: 2091 RVA: 0x0001FEEC File Offset: 0x0001E0EC
		public static event DevkitTransactionsChangedHandler transactionsChanged;

		// Token: 0x0600082C RID: 2092 RVA: 0x0001FF1F File Offset: 0x0001E11F
		protected static void triggerTransactionsChanged()
		{
			DevkitTransactionsChangedHandler devkitTransactionsChangedHandler = DevkitTransactionManager.transactionsChanged;
			if (devkitTransactionsChangedHandler == null)
			{
				return;
			}
			devkitTransactionsChangedHandler();
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600082D RID: 2093 RVA: 0x0001FF30 File Offset: 0x0001E130
		public static bool canUndo
		{
			get
			{
				return DevkitTransactionManager.undoable.Count > 0;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x0600082E RID: 2094 RVA: 0x0001FF3F File Offset: 0x0001E13F
		public static bool canRedo
		{
			get
			{
				return DevkitTransactionManager.redoable.Count > 0;
			}
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x0001FF4E File Offset: 0x0001E14E
		public static IEnumerable<DevkitTransactionGroup> getUndoable()
		{
			return DevkitTransactionManager.undoable;
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x0001FF55 File Offset: 0x0001E155
		public static IEnumerable<DevkitTransactionGroup> getRedoable()
		{
			return DevkitTransactionManager.redoable;
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x0001FF5C File Offset: 0x0001E15C
		public static DevkitTransactionGroup undo()
		{
			if (!DevkitTransactionManager.canUndo)
			{
				return null;
			}
			DevkitTransactionGroup devkitTransactionGroup = DevkitTransactionManager.popUndo();
			devkitTransactionGroup.undo();
			DevkitTransactionManager.pushRedo(devkitTransactionGroup);
			DevkitTransactionManager.triggerTransactionPerformed(devkitTransactionGroup);
			return devkitTransactionGroup;
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x0001FF7E File Offset: 0x0001E17E
		public static DevkitTransactionGroup redo()
		{
			if (!DevkitTransactionManager.canRedo)
			{
				return null;
			}
			DevkitTransactionGroup devkitTransactionGroup = DevkitTransactionManager.popRedo();
			devkitTransactionGroup.redo();
			DevkitTransactionManager.pushUndo(devkitTransactionGroup);
			DevkitTransactionManager.triggerTransactionPerformed(devkitTransactionGroup);
			return devkitTransactionGroup;
		}

		/// <summary>
		/// Open a new transaction group which stores multiple undo/redoable actions, for example this would be called before moving an object.
		/// </summary>
		// Token: 0x06000833 RID: 2099 RVA: 0x0001FFA0 File Offset: 0x0001E1A0
		public static void beginTransaction(string name)
		{
			if (DevkitTransactionManager.transactionDepth == 0)
			{
				DevkitTransactionManager.clearRedo();
				DevkitTransactionManager.pendingGroup = new DevkitTransactionGroup(name);
			}
			DevkitTransactionManager.transactionDepth++;
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x0001FFC5 File Offset: 0x0001E1C5
		public static void recordTransaction(IDevkitTransaction transaction)
		{
			if (DevkitTransactionManager.pendingGroup == null)
			{
				return;
			}
			DevkitTransactionManager.pendingGroup.record(transaction);
		}

		/// <summary>
		/// Close the pending transaction and finalize any change checks.
		/// </summary>
		// Token: 0x06000835 RID: 2101 RVA: 0x0001FFDC File Offset: 0x0001E1DC
		public static void endTransaction()
		{
			if (DevkitTransactionManager.transactionDepth == 0)
			{
				return;
			}
			DevkitTransactionManager.transactionDepth--;
			if (DevkitTransactionManager.transactionDepth == 0)
			{
				DevkitTransactionManager.pendingGroup.end();
				if (DevkitTransactionManager.pendingGroup.delta)
				{
					DevkitTransactionManager.pushUndo(DevkitTransactionManager.pendingGroup);
				}
				else
				{
					DevkitTransactionManager.pendingGroup.forget();
				}
				DevkitTransactionManager.pendingGroup = null;
				DevkitTransactionManager.triggerTransactionsChanged();
			}
		}

		/// <summary>
		/// Clear the undo/redo queues.
		/// </summary>
		// Token: 0x06000836 RID: 2102 RVA: 0x0002003B File Offset: 0x0001E23B
		public static void resetTransactions()
		{
			DevkitTransactionManager.clearUndo();
			DevkitTransactionManager.clearRedo();
			DevkitTransactionManager.pendingGroup = null;
			DevkitTransactionManager.transactionDepth = 0;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x00020053 File Offset: 0x0001E253
		protected static void pushUndo(DevkitTransactionGroup group)
		{
			if ((long)DevkitTransactionManager.undoable.Count >= (long)((ulong)DevkitTransactionManager.historyLength))
			{
				DevkitTransactionManager.undoable.First.Value.forget();
				DevkitTransactionManager.undoable.RemoveFirst();
			}
			DevkitTransactionManager.undoable.AddLast(group);
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00020092 File Offset: 0x0001E292
		protected static DevkitTransactionGroup popUndo()
		{
			DevkitTransactionGroup value = DevkitTransactionManager.undoable.Last.Value;
			DevkitTransactionManager.undoable.RemoveLast();
			return value;
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000200AD File Offset: 0x0001E2AD
		protected static void clearUndo()
		{
			while (DevkitTransactionManager.undoable.Count > 0)
			{
				DevkitTransactionGroup value = DevkitTransactionManager.undoable.Last.Value;
				DevkitTransactionManager.undoable.RemoveLast();
				value.forget();
			}
			DevkitTransactionManager.undoable.Clear();
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x000200E6 File Offset: 0x0001E2E6
		protected static void pushRedo(DevkitTransactionGroup group)
		{
			DevkitTransactionManager.redoable.Push(group);
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x000200F3 File Offset: 0x0001E2F3
		protected static DevkitTransactionGroup popRedo()
		{
			return DevkitTransactionManager.redoable.Pop();
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x000200FF File Offset: 0x0001E2FF
		protected static void clearRedo()
		{
			while (DevkitTransactionManager.redoable.Count > 0)
			{
				DevkitTransactionManager.redoable.Pop().forget();
			}
			DevkitTransactionManager.redoable.Clear();
		}

		// Token: 0x04000321 RID: 801
		private static uint _historyLength = 25U;

		// Token: 0x04000324 RID: 804
		protected static LinkedList<DevkitTransactionGroup> undoable = new LinkedList<DevkitTransactionGroup>();

		// Token: 0x04000325 RID: 805
		protected static Stack<DevkitTransactionGroup> redoable = new Stack<DevkitTransactionGroup>();

		// Token: 0x04000326 RID: 806
		protected static DevkitTransactionGroup pendingGroup;

		// Token: 0x04000327 RID: 807
		protected static int transactionDepth;
	}
}
