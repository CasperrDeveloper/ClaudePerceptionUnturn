﻿using System;
using System.Reflection;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000144 RID: 324
	public struct TransactionFieldDelta : ITransactionDelta
	{
		// Token: 0x06000858 RID: 2136 RVA: 0x000202C2 File Offset: 0x0001E4C2
		public void undo(object instance)
		{
			this.field.SetValue(instance, this.before);
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x000202D6 File Offset: 0x0001E4D6
		public void redo(object instance)
		{
			this.field.SetValue(instance, this.after);
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x000202EA File Offset: 0x0001E4EA
		public TransactionFieldDelta(FieldInfo newField)
		{
			this = new TransactionFieldDelta(newField, null, null);
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x000202F5 File Offset: 0x0001E4F5
		public TransactionFieldDelta(FieldInfo newField, object newBefore, object newAfter)
		{
			this.field = newField;
			this.before = newBefore;
			this.after = newAfter;
		}

		// Token: 0x0400032F RID: 815
		public FieldInfo field;

		// Token: 0x04000330 RID: 816
		public object before;

		// Token: 0x04000331 RID: 817
		public object after;
	}
}
