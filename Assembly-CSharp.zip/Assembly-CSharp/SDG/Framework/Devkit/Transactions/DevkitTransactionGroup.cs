﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013B RID: 315
	public class DevkitTransactionGroup
	{
		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000812 RID: 2066 RVA: 0x0001FC8D File Offset: 0x0001DE8D
		// (set) Token: 0x06000813 RID: 2067 RVA: 0x0001FC95 File Offset: 0x0001DE95
		public string name { get; protected set; }

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06000814 RID: 2068 RVA: 0x0001FC9E File Offset: 0x0001DE9E
		// (set) Token: 0x06000815 RID: 2069 RVA: 0x0001FCA6 File Offset: 0x0001DEA6
		public List<IDevkitTransaction> transactions { get; protected set; }

		// Token: 0x06000816 RID: 2070 RVA: 0x0001FCAF File Offset: 0x0001DEAF
		public void record(IDevkitTransaction transaction)
		{
			transaction.begin();
			this.transactions.Add(transaction);
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000817 RID: 2071 RVA: 0x0001FCC4 File Offset: 0x0001DEC4
		public bool delta
		{
			get
			{
				for (int i = this.transactions.Count - 1; i >= 0; i--)
				{
					if (!this.transactions[i].delta)
					{
						this.transactions.RemoveAt(i);
					}
				}
				return this.transactions.Count > 0;
			}
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x0001FD18 File Offset: 0x0001DF18
		public void undo()
		{
			for (int i = 0; i < this.transactions.Count; i++)
			{
				this.transactions[i].undo();
			}
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x0001FD4C File Offset: 0x0001DF4C
		public void redo()
		{
			for (int i = 0; i < this.transactions.Count; i++)
			{
				this.transactions[i].redo();
			}
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x0001FD80 File Offset: 0x0001DF80
		public void end()
		{
			for (int i = 0; i < this.transactions.Count; i++)
			{
				this.transactions[i].end();
			}
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x0001FDB4 File Offset: 0x0001DFB4
		public void forget()
		{
			for (int i = 0; i < this.transactions.Count; i++)
			{
				this.transactions[i].forget();
			}
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x0001FDE8 File Offset: 0x0001DFE8
		public DevkitTransactionGroup(string newName)
		{
			this.name = newName;
			this.transactions = new List<IDevkitTransaction>();
		}
	}
}
