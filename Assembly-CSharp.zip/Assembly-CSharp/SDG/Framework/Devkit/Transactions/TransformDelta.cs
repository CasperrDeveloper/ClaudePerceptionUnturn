﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000140 RID: 320
	public class TransformDelta
	{
		// Token: 0x06000846 RID: 2118 RVA: 0x0002019E File Offset: 0x0001E39E
		public void get(Transform transform)
		{
			this.localPosition = transform.localPosition;
			this.localRotation = transform.localRotation;
			this.localScale = transform.localScale;
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x000201C4 File Offset: 0x0001E3C4
		public void set(Transform transform)
		{
			transform.parent = this.parent;
			transform.localPosition = this.localPosition;
			transform.localRotation = this.localRotation;
			transform.localScale = this.localScale;
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x000201F6 File Offset: 0x0001E3F6
		public TransformDelta(Transform newParent)
		{
			this.parent = newParent;
		}

		// Token: 0x04000328 RID: 808
		public Transform parent;

		// Token: 0x04000329 RID: 809
		public Vector3 localPosition;

		// Token: 0x0400032A RID: 810
		public Quaternion localRotation;

		// Token: 0x0400032B RID: 811
		public Vector3 localScale;
	}
}
