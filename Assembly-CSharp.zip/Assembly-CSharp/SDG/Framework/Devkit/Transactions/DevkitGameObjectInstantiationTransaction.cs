﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000139 RID: 313
	public class DevkitGameObjectInstantiationTransaction : IDevkitTransaction
	{
		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x0001F8CC File Offset: 0x0001DACC
		public bool delta
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x0001F8CF File Offset: 0x0001DACF
		public void undo()
		{
			if (this.go != null)
			{
				this.go.SetActive(false);
			}
			this.isActive = false;
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x0001F8F2 File Offset: 0x0001DAF2
		public void redo()
		{
			if (this.go != null)
			{
				this.go.SetActive(true);
			}
			this.isActive = true;
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x0001F915 File Offset: 0x0001DB15
		public void begin()
		{
			if (this.go != null)
			{
				this.go.SetActive(true);
			}
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x0001F931 File Offset: 0x0001DB31
		public void end()
		{
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x0001F933 File Offset: 0x0001DB33
		public void forget()
		{
			if (this.go != null && !this.isActive)
			{
				UnityEngine.Object.Destroy(this.go);
			}
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x0001F956 File Offset: 0x0001DB56
		public DevkitGameObjectInstantiationTransaction(GameObject newGO)
		{
			this.go = newGO;
			this.isActive = true;
		}

		// Token: 0x04000319 RID: 793
		protected GameObject go;

		// Token: 0x0400031A RID: 794
		protected bool isActive;
	}
}
