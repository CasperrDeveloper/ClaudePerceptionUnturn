﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013F RID: 319
	public class DevkitTransactionUtility
	{
		// Token: 0x0600083F RID: 2111 RVA: 0x0002014E File Offset: 0x0001E34E
		public static void beginGenericTransaction()
		{
			DevkitTransactionManager.beginTransaction("Generic");
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x0002015A File Offset: 0x0001E35A
		public static void endGenericTransaction()
		{
			DevkitTransactionManager.endTransaction();
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00020161 File Offset: 0x0001E361
		public static void recordInstantiation(GameObject go)
		{
			DevkitTransactionManager.recordTransaction(new DevkitGameObjectInstantiationTransaction(go));
		}

		/// <summary>
		/// Save the state of all the fields and properties on this object to the current transaction group so that they can be checked for changes once the transaction has ended.
		/// </summary>
		// Token: 0x06000842 RID: 2114 RVA: 0x0002016E File Offset: 0x0001E36E
		public static void recordObjectDelta(object instance)
		{
			DevkitTransactionManager.recordTransaction(new DevkitObjectDeltaTransaction(instance));
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x0002017B File Offset: 0x0001E37B
		public static void recordDestruction(GameObject go)
		{
			DevkitTransactionManager.recordTransaction(new DevkitGameObjectDestructionTransaction(go));
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00020188 File Offset: 0x0001E388
		public static void recordTransformChangeParent(Transform transform, Transform parent)
		{
			DevkitTransactionManager.recordTransaction(new DevkitTransformChangeParentTransaction(transform, parent));
		}
	}
}
