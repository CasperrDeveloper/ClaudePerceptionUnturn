﻿using System;
using System.Reflection;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000145 RID: 325
	public struct TransactionPropertyDelta : ITransactionDelta
	{
		// Token: 0x0600085C RID: 2140 RVA: 0x0002030C File Offset: 0x0001E50C
		public void undo(object instance)
		{
			this.property.SetValue(instance, this.before, null);
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00020321 File Offset: 0x0001E521
		public void redo(object instance)
		{
			this.property.SetValue(instance, this.after, null);
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00020336 File Offset: 0x0001E536
		public TransactionPropertyDelta(PropertyInfo newProperty)
		{
			this = new TransactionPropertyDelta(newProperty, null, null);
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00020341 File Offset: 0x0001E541
		public TransactionPropertyDelta(PropertyInfo newProperty, object newBefore, object newAfter)
		{
			this.property = newProperty;
			this.before = newBefore;
			this.after = newAfter;
		}

		// Token: 0x04000332 RID: 818
		public PropertyInfo property;

		// Token: 0x04000333 RID: 819
		public object before;

		// Token: 0x04000334 RID: 820
		public object after;
	}
}
