﻿using System;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013C RID: 316
	// (Invoke) Token: 0x0600081E RID: 2078
	public delegate void DevkitTransactionPerformedHandler(DevkitTransactionGroup group);
}
