﻿using System;
using System.Collections.Generic;
using System.Reflection;
using SDG.Framework.Utilities;
using SDG.Unturned;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013A RID: 314
	public class DevkitObjectDeltaTransaction : IDevkitTransaction
	{
		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600080A RID: 2058 RVA: 0x0001F96C File Offset: 0x0001DB6C
		public bool delta
		{
			get
			{
				return this.deltas.Count > 0;
			}
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x0001F97C File Offset: 0x0001DB7C
		public void undo()
		{
			for (int i = 0; i < this.deltas.Count; i++)
			{
				this.deltas[i].undo(this.instance);
			}
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x0001F9B8 File Offset: 0x0001DBB8
		public void redo()
		{
			for (int i = 0; i < this.deltas.Count; i++)
			{
				this.deltas[i].redo(this.instance);
			}
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x0001F9F4 File Offset: 0x0001DBF4
		public void begin()
		{
			this.tempFields = ListPool<object>.claim();
			this.tempProperties = ListPool<object>.claim();
			Type type = this.instance.GetType();
			FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public);
			for (int i = 0; i < fields.Length; i++)
			{
				try
				{
					object value = fields[i].GetValue(this.instance);
					this.tempFields.Add(value);
				}
				catch
				{
					this.tempFields.Add(null);
				}
			}
			PropertyInfo[] properties = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
			for (int j = 0; j < properties.Length; j++)
			{
				try
				{
					PropertyInfo propertyInfo = properties[j];
					if (propertyInfo.CanRead && propertyInfo.CanWrite)
					{
						object value2 = propertyInfo.GetValue(this.instance, null);
						this.tempProperties.Add(value2);
					}
					else
					{
						this.tempProperties.Add(null);
					}
				}
				catch
				{
					this.tempProperties.Add(null);
				}
			}
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x0001FAF8 File Offset: 0x0001DCF8
		public void end()
		{
			this.deltas = ListPool<ITransactionDelta>.claim();
			Type type = this.instance.GetType();
			FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public);
			for (int i = 0; i < fields.Length; i++)
			{
				try
				{
					FieldInfo fieldInfo = fields[i];
					object value = fieldInfo.GetValue(this.instance);
					if (this.changed(this.tempFields[i], value))
					{
						this.deltas.Add(new TransactionFieldDelta(fieldInfo, this.tempFields[i], value));
					}
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e);
				}
			}
			PropertyInfo[] properties = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
			for (int j = 0; j < properties.Length; j++)
			{
				try
				{
					PropertyInfo propertyInfo = properties[j];
					if (propertyInfo.CanRead && propertyInfo.CanWrite)
					{
						object value2 = propertyInfo.GetValue(this.instance, null);
						if (this.changed(this.tempProperties[j], value2))
						{
							this.deltas.Add(new TransactionPropertyDelta(propertyInfo, this.tempProperties[j], value2));
						}
					}
				}
				catch (Exception e2)
				{
					UnturnedLog.exception(e2);
				}
			}
			ListPool<object>.release(this.tempFields);
			ListPool<object>.release(this.tempProperties);
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x0001FC48 File Offset: 0x0001DE48
		public void forget()
		{
			if (this.deltas != null)
			{
				ListPool<ITransactionDelta>.release(this.deltas);
				this.deltas = null;
			}
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x0001FC64 File Offset: 0x0001DE64
		protected bool changed(object before, object after)
		{
			if (before == null || after == null)
			{
				return before != after;
			}
			return !before.Equals(after);
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x0001FC7E File Offset: 0x0001DE7E
		public DevkitObjectDeltaTransaction(object newInstance)
		{
			this.instance = newInstance;
		}

		// Token: 0x0400031B RID: 795
		protected object instance;

		// Token: 0x0400031C RID: 796
		protected List<object> tempFields;

		// Token: 0x0400031D RID: 797
		protected List<object> tempProperties;

		// Token: 0x0400031E RID: 798
		protected List<ITransactionDelta> deltas;
	}
}
