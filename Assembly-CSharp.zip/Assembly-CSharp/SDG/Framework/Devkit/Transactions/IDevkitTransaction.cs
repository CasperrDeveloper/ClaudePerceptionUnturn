﻿using System;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000142 RID: 322
	public interface IDevkitTransaction
	{
		/// <summary>
		/// If false this transaction is ignored. If there were no changes at all in the group it's discarded.
		/// </summary>
		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000850 RID: 2128
		bool delta { get; }

		// Token: 0x06000851 RID: 2129
		void undo();

		// Token: 0x06000852 RID: 2130
		void redo();

		// Token: 0x06000853 RID: 2131
		void begin();

		// Token: 0x06000854 RID: 2132
		void end();

		/// <summary>
		/// Called when history buffer is too long so this transaction is discarded.
		/// </summary>
		// Token: 0x06000855 RID: 2133
		void forget();
	}
}
