﻿using System;
using UnityEngine;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000141 RID: 321
	public class DevkitTransformChangeParentTransaction : IDevkitTransaction
	{
		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000849 RID: 2121 RVA: 0x00020205 File Offset: 0x0001E405
		public bool delta
		{
			get
			{
				return this.parentBefore.parent != this.parentAfter.parent;
			}
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00020222 File Offset: 0x0001E422
		public void undo()
		{
			this.parentBefore.set(this.transform);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00020235 File Offset: 0x0001E435
		public void redo()
		{
			this.parentAfter.set(this.transform);
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00020248 File Offset: 0x0001E448
		public void begin()
		{
			this.parentBefore = new TransformDelta(this.transform.parent);
			this.parentBefore.get(this.transform);
			this.transform.parent = this.parentAfter.parent;
			this.parentAfter.get(this.transform);
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x000202A3 File Offset: 0x0001E4A3
		public void end()
		{
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x000202A5 File Offset: 0x0001E4A5
		public void forget()
		{
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x000202A7 File Offset: 0x0001E4A7
		public DevkitTransformChangeParentTransaction(Transform newTransform, Transform newParent)
		{
			this.transform = newTransform;
			this.parentAfter = new TransformDelta(newParent);
		}

		// Token: 0x0400032C RID: 812
		protected Transform transform;

		// Token: 0x0400032D RID: 813
		protected TransformDelta parentBefore;

		// Token: 0x0400032E RID: 814
		protected TransformDelta parentAfter;
	}
}
