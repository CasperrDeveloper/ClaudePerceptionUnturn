﻿using System;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x02000143 RID: 323
	public interface ITransactionDelta
	{
		// Token: 0x06000856 RID: 2134
		void undo(object instance);

		// Token: 0x06000857 RID: 2135
		void redo(object instance);
	}
}
