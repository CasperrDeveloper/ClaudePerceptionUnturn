﻿using System;

namespace SDG.Framework.Devkit.Transactions
{
	// Token: 0x0200013D RID: 317
	// (Invoke) Token: 0x06000822 RID: 2082
	public delegate void DevkitTransactionsChangedHandler();
}
