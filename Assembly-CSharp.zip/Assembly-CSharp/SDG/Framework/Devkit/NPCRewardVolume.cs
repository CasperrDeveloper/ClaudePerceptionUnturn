﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200012A RID: 298
	public class NPCRewardVolume : LevelVolume<NPCRewardVolume, NPCRewardVolumeManager>
	{
		// Token: 0x060007B7 RID: 1975 RVA: 0x0001EB60 File Offset: 0x0001CD60
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new NPCRewardVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x0001EB7C File Offset: 0x0001CD7C
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			this.parsedAssetGuid = reader.readValue<Guid>("AssetGuid");
			this._assetGuid = this.parsedAssetGuid.ToString("N");
			this.shouldAffectVehiclePassengers = reader.readValue<bool>("ShouldAffectVehiclePassengers");
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0001EBC8 File Offset: 0x0001CDC8
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<Guid>("AssetGuid", this.parsedAssetGuid);
			writer.writeValue<bool>("ShouldAffectVehiclePassengers", this.shouldAffectVehiclePassengers);
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x0001EBF3 File Offset: 0x0001CDF3
		protected override void Awake()
		{
			this.forceShouldAddCollider = true;
			base.Awake();
			Guid.TryParse(this._assetGuid, out this.parsedAssetGuid);
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x0001EC14 File Offset: 0x0001CE14
		private void OnTriggerEnter(Collider other)
		{
			if (!Provider.isServer)
			{
				return;
			}
			bool flag = other.CompareTag("Player");
			bool flag2 = other.CompareTag("Vehicle");
			if (!flag && (!flag2 || !this.shouldAffectVehiclePassengers))
			{
				return;
			}
			if (this.parsedAssetGuid.IsEmpty())
			{
				return;
			}
			NPCRewardsAsset npcrewardsAsset = Assets.find(this.parsedAssetGuid) as NPCRewardsAsset;
			if (npcrewardsAsset == null)
			{
				UnturnedLog.warn(string.Format("NPC reward volume unable to find asset ({0:N})", this.parsedAssetGuid));
				return;
			}
			if (flag)
			{
				Player player = DamageTool.getPlayer(other.transform);
				if (player != null)
				{
					this.EvaluateForPlayer(player, npcrewardsAsset);
					return;
				}
			}
			else if (flag2)
			{
				InteractableVehicle vehicle = DamageTool.getVehicle(other.transform);
				if (vehicle != null && vehicle.passengers != null)
				{
					foreach (Passenger passenger in vehicle.passengers)
					{
						if (passenger.player != null && passenger.player.player != null)
						{
							this.EvaluateForPlayer(passenger.player.player, npcrewardsAsset);
						}
					}
				}
			}
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x0001ED24 File Offset: 0x0001CF24
		private void EvaluateForPlayer(Player player, NPCRewardsAsset asset)
		{
			if (asset.AreConditionsMet(player))
			{
				asset.ApplyConditions(player);
				asset.GrantRewards(player);
			}
		}

		/// <summary>
		/// Nelson 2024-06-10: Changed this from guid to string because Unity serialization doesn't support guids
		/// and neither does the inspector. (e.g., couldn't duplicate reward volume without re-assigning guid)
		/// </summary>
		// Token: 0x0400030A RID: 778
		[SerializeField]
		internal string _assetGuid;

		// Token: 0x0400030B RID: 779
		private Guid parsedAssetGuid;

		/// <summary>
		/// If true, vehicles overlapping volume will check conditions and (if met) grant rewards to passengers.
		/// </summary>
		// Token: 0x0400030C RID: 780
		public bool shouldAffectVehiclePassengers;

		// Token: 0x02000915 RID: 2325
		private class Menu : SleekWrapper
		{
			// Token: 0x060050F8 RID: 20728 RVA: 0x001F54C0 File Offset: 0x001F36C0
			public Menu(NPCRewardVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				base.SizeOffset_Y = 120f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				sleekField.Text = volume.parsedAssetGuid.ToString("N");
				sleekField.AddLabel("Asset GUID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdChanged;
				base.AddChild(sleekField);
				this.assetNameBox = Glazier.Get().CreateBox();
				this.assetNameBox.PositionOffset_Y = 40f;
				this.assetNameBox.SizeOffset_X = 200f;
				this.assetNameBox.SizeOffset_Y = 30f;
				this.assetNameBox.AddLabel("Asset", ESleekSide.RIGHT);
				base.AddChild(this.assetNameBox);
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.PositionOffset_Y = 80f;
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.shouldAffectVehiclePassengers;
				sleekToggle.AddLabel("Affect Vehicle Passengers", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnAffectVehiclePassengersToggled;
				base.AddChild(sleekToggle);
				this.SyncAssetName();
			}

			// Token: 0x060050F9 RID: 20729 RVA: 0x001F560C File Offset: 0x001F380C
			private void OnIdChanged(ISleekField field, string idString)
			{
				if (!Guid.TryParse(idString, out this.volume.parsedAssetGuid))
				{
					this.volume.parsedAssetGuid = Guid.Empty;
				}
				this.volume._assetGuid = this.volume.parsedAssetGuid.ToString("N");
				this.SyncAssetName();
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050FA RID: 20730 RVA: 0x001F5668 File Offset: 0x001F3868
			private void SyncAssetName()
			{
				NPCRewardsAsset npcrewardsAsset = Assets.find(this.volume.parsedAssetGuid) as NPCRewardsAsset;
				if (npcrewardsAsset != null)
				{
					this.assetNameBox.Text = npcrewardsAsset.FriendlyName;
					return;
				}
				this.assetNameBox.Text = "null";
			}

			// Token: 0x060050FB RID: 20731 RVA: 0x001F56B0 File Offset: 0x001F38B0
			private void OnAffectVehiclePassengersToggled(ISleekToggle toggle, bool state)
			{
				this.volume.shouldAffectVehiclePassengers = state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036ED RID: 14061
			private ISleekBox assetNameBox;

			// Token: 0x040036EE RID: 14062
			private NPCRewardVolume volume;
		}
	}
}
