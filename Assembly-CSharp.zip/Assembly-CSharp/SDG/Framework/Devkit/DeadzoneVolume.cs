﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010F RID: 271
	public class DeadzoneVolume : LevelVolume<DeadzoneVolume, DeadzoneVolumeManager>, IDeadzoneNode
	{
		// Token: 0x060006FD RID: 1789 RVA: 0x0001D064 File Offset: 0x0001B264
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new DeadzoneVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060006FE RID: 1790 RVA: 0x0001D080 File Offset: 0x0001B280
		// (set) Token: 0x060006FF RID: 1791 RVA: 0x0001D088 File Offset: 0x0001B288
		public EDeadzoneType DeadzoneType
		{
			get
			{
				return this._deadzoneType;
			}
			set
			{
				this._deadzoneType = value;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06000700 RID: 1792 RVA: 0x0001D091 File Offset: 0x0001B291
		// (set) Token: 0x06000701 RID: 1793 RVA: 0x0001D099 File Offset: 0x0001B299
		public float UnprotectedDamagePerSecond
		{
			get
			{
				return this._unprotectedDamagePerSecond;
			}
			set
			{
				this._unprotectedDamagePerSecond = value;
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x06000702 RID: 1794 RVA: 0x0001D0A2 File Offset: 0x0001B2A2
		// (set) Token: 0x06000703 RID: 1795 RVA: 0x0001D0AA File Offset: 0x0001B2AA
		public float ProtectedDamagePerSecond
		{
			get
			{
				return this._protectedDamagePerSecond;
			}
			set
			{
				this._protectedDamagePerSecond = value;
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000704 RID: 1796 RVA: 0x0001D0B3 File Offset: 0x0001B2B3
		// (set) Token: 0x06000705 RID: 1797 RVA: 0x0001D0BB File Offset: 0x0001B2BB
		public float UnprotectedRadiationPerSecond
		{
			get
			{
				return this._unprotectedRadiationPerSecond;
			}
			set
			{
				this._unprotectedRadiationPerSecond = value;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000706 RID: 1798 RVA: 0x0001D0C4 File Offset: 0x0001B2C4
		// (set) Token: 0x06000707 RID: 1799 RVA: 0x0001D0CC File Offset: 0x0001B2CC
		public float MaskFilterDamagePerSecond
		{
			get
			{
				return this._maskFilterDamagePerSecond;
			}
			set
			{
				this._maskFilterDamagePerSecond = value;
			}
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x0001D0D8 File Offset: 0x0001B2D8
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			if (reader.containsKey("Deadzone_Type"))
			{
				this._deadzoneType = reader.readValue<EDeadzoneType>("Deadzone_Type");
			}
			else
			{
				this._deadzoneType = EDeadzoneType.DefaultRadiation;
			}
			this._unprotectedDamagePerSecond = reader.readValue<float>("UnprotectedDamagePerSecond");
			this._protectedDamagePerSecond = reader.readValue<float>("ProtectedDamagePerSecond");
			if (reader.containsKey("UnprotectedRadiationPerSecond"))
			{
				this._unprotectedRadiationPerSecond = reader.readValue<float>("UnprotectedRadiationPerSecond");
			}
			else
			{
				this._unprotectedRadiationPerSecond = 6.25f;
			}
			if (reader.containsKey("MaskFilterDamagePerSecond"))
			{
				this._maskFilterDamagePerSecond = reader.readValue<float>("MaskFilterDamagePerSecond");
				return;
			}
			this._maskFilterDamagePerSecond = 0.4f;
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x0001D18C File Offset: 0x0001B38C
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			writer.writeValue<EDeadzoneType>("Deadzone_Type", this._deadzoneType);
			writer.writeValue<float>("UnprotectedDamagePerSecond", this._unprotectedDamagePerSecond);
			writer.writeValue<float>("ProtectedDamagePerSecond", this._protectedDamagePerSecond);
			writer.writeValue<float>("UnprotectedRadiationPerSecond", this._unprotectedRadiationPerSecond);
			writer.writeValue<float>("MaskFilterDamagePerSecond", this._maskFilterDamagePerSecond);
		}

		// Token: 0x040002D7 RID: 727
		[SerializeField]
		private EDeadzoneType _deadzoneType;

		// Token: 0x040002D8 RID: 728
		[SerializeField]
		private float _unprotectedDamagePerSecond;

		// Token: 0x040002D9 RID: 729
		[SerializeField]
		private float _protectedDamagePerSecond;

		// Token: 0x040002DA RID: 730
		[SerializeField]
		private float _unprotectedRadiationPerSecond = 6.25f;

		// Token: 0x040002DB RID: 731
		[SerializeField]
		private float _maskFilterDamagePerSecond = 0.4f;

		// Token: 0x02000912 RID: 2322
		private class Menu : SleekWrapper
		{
			// Token: 0x060050E8 RID: 20712 RVA: 0x001F4D58 File Offset: 0x001F2F58
			public Menu(DeadzoneVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				float num = 0f;
				SleekButtonState sleekButtonState = new SleekButtonState(new GUIContent[]
				{
					new GUIContent("Default Radiation"),
					new GUIContent("Full Suit Radiation")
				});
				sleekButtonState.PositionOffset_Y = num;
				sleekButtonState.SizeOffset_X = 200f;
				sleekButtonState.SizeOffset_Y = 30f;
				sleekButtonState.state = (int)volume.DeadzoneType;
				sleekButtonState.AddLabel("Deadzone Type", ESleekSide.RIGHT);
				SleekButtonState sleekButtonState2 = sleekButtonState;
				sleekButtonState2.onSwappedState = (SwappedState)Delegate.Combine(sleekButtonState2.onSwappedState, new SwappedState(this.OnSwappedState));
				base.AddChild(sleekButtonState);
				num += sleekButtonState.SizeOffset_Y + 10f;
				ISleekFloat32Field sleekFloat32Field = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field.PositionOffset_Y = num;
				sleekFloat32Field.SizeOffset_X = 200f;
				sleekFloat32Field.SizeOffset_Y = 30f;
				sleekFloat32Field.Value = volume.UnprotectedDamagePerSecond;
				sleekFloat32Field.AddLabel("Damage per Second (Unprotected)", ESleekSide.RIGHT);
				sleekFloat32Field.OnValueChanged += this.OnUnprotectedDamageChanged;
				base.AddChild(sleekFloat32Field);
				num += sleekFloat32Field.SizeOffset_Y + 10f;
				ISleekFloat32Field sleekFloat32Field2 = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field2.PositionOffset_Y = num;
				sleekFloat32Field2.SizeOffset_X = 200f;
				sleekFloat32Field2.SizeOffset_Y = 30f;
				sleekFloat32Field2.Value = volume.ProtectedDamagePerSecond;
				sleekFloat32Field2.AddLabel("Damage per Second (Protected)", ESleekSide.RIGHT);
				sleekFloat32Field2.OnValueChanged += this.OnProtectedDamageChanged;
				base.AddChild(sleekFloat32Field2);
				num += sleekFloat32Field2.SizeOffset_Y + 10f;
				ISleekFloat32Field sleekFloat32Field3 = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field3.PositionOffset_Y = num;
				sleekFloat32Field3.SizeOffset_X = 200f;
				sleekFloat32Field3.SizeOffset_Y = 30f;
				sleekFloat32Field3.Value = volume.UnprotectedRadiationPerSecond;
				sleekFloat32Field3.AddLabel("Radiation per Second", ESleekSide.RIGHT);
				sleekFloat32Field3.OnValueChanged += this.OnUnprotectedRadiationChanged;
				base.AddChild(sleekFloat32Field3);
				num += sleekFloat32Field3.SizeOffset_Y + 10f;
				ISleekFloat32Field sleekFloat32Field4 = Glazier.Get().CreateFloat32Field();
				sleekFloat32Field4.PositionOffset_Y = num;
				sleekFloat32Field4.SizeOffset_X = 200f;
				sleekFloat32Field4.SizeOffset_Y = 30f;
				sleekFloat32Field4.Value = volume.MaskFilterDamagePerSecond;
				sleekFloat32Field4.AddLabel("Mask Filter Degradation per Second", ESleekSide.RIGHT);
				sleekFloat32Field4.OnValueChanged += this.OnMaskFilterDamageChanged;
				base.AddChild(sleekFloat32Field4);
				num += sleekFloat32Field4.SizeOffset_Y + 10f;
				base.SizeOffset_Y = num - 10f;
			}

			// Token: 0x060050E9 RID: 20713 RVA: 0x001F4FD5 File Offset: 0x001F31D5
			private void OnSwappedState(SleekButtonState button, int state)
			{
				this.volume.DeadzoneType = (EDeadzoneType)state;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050EA RID: 20714 RVA: 0x001F4FE8 File Offset: 0x001F31E8
			private void OnUnprotectedDamageChanged(ISleekFloat32Field field, float value)
			{
				this.volume.UnprotectedDamagePerSecond = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050EB RID: 20715 RVA: 0x001F4FFB File Offset: 0x001F31FB
			private void OnProtectedDamageChanged(ISleekFloat32Field field, float value)
			{
				this.volume.ProtectedDamagePerSecond = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050EC RID: 20716 RVA: 0x001F500E File Offset: 0x001F320E
			private void OnUnprotectedRadiationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.UnprotectedRadiationPerSecond = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050ED RID: 20717 RVA: 0x001F5021 File Offset: 0x001F3221
			private void OnMaskFilterDamageChanged(ISleekFloat32Field field, float value)
			{
				this.volume.MaskFilterDamagePerSecond = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x040036EA RID: 14058
			private DeadzoneVolume volume;
		}
	}
}
