﻿using System;
using System.Collections.Generic;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000131 RID: 305
	[Obsolete("Made SpawnpointSystem no longer static")]
	public static class SpawnpointSystem
	{
		// Token: 0x170000FA RID: 250
		// (get) Token: 0x060007E3 RID: 2019 RVA: 0x0001F389 File Offset: 0x0001D589
		[Obsolete("Made SpawnpointSystem no longer static")]
		public static List<Spawnpoint> spawnpoints
		{
			get
			{
				return SpawnpointSystemV2.Get().allSpawnpoints;
			}
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x0001F395 File Offset: 0x0001D595
		[Obsolete("Made SpawnpointSystem no longer static")]
		public static Spawnpoint getSpawnpoint(string id)
		{
			return SpawnpointSystemV2.Get().FindFirstSpawnpoint(id);
		}
	}
}
