﻿using System;
using SDG.Framework.IO.FormattedFiles;
using SDG.Unturned;
using UnityEngine;
using Unturned.SystemEx;

namespace SDG.Framework.Devkit
{
	// Token: 0x0200010D RID: 269
	public class AmbianceVolume : LevelVolume<AmbianceVolume, AmbianceVolumeManager>, IAmbianceNode
	{
		// Token: 0x060006E2 RID: 1762 RVA: 0x0001C8D4 File Offset: 0x0001AAD4
		public override ISleekElement CreateMenu()
		{
			ISleekElement sleekElement = new AmbianceVolume.Menu(this);
			base.AppendBaseMenu(sleekElement);
			return sleekElement;
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060006E3 RID: 1763 RVA: 0x0001C8F0 File Offset: 0x0001AAF0
		// (set) Token: 0x060006E4 RID: 1764 RVA: 0x0001C8F8 File Offset: 0x0001AAF8
		public Guid EffectGuid
		{
			get
			{
				return this._effectGuid;
			}
			set
			{
				this._effectGuid = value;
				this.cachedEffectAsset = null;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060006E5 RID: 1765 RVA: 0x0001C908 File Offset: 0x0001AB08
		// (set) Token: 0x060006E6 RID: 1766 RVA: 0x0001C910 File Offset: 0x0001AB10
		public ushort id
		{
			[Obsolete]
			get
			{
				return this._id;
			}
			set
			{
				this._id = value;
				this.cachedEffectAsset = null;
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060006E7 RID: 1767 RVA: 0x0001C920 File Offset: 0x0001AB20
		// (set) Token: 0x060006E8 RID: 1768 RVA: 0x0001C928 File Offset: 0x0001AB28
		public bool noWater
		{
			get
			{
				return this._noWater;
			}
			set
			{
				this._noWater = value;
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060006E9 RID: 1769 RVA: 0x0001C931 File Offset: 0x0001AB31
		// (set) Token: 0x060006EA RID: 1770 RVA: 0x0001C939 File Offset: 0x0001AB39
		public bool noLighting
		{
			get
			{
				return this._noLighting;
			}
			set
			{
				this._noLighting = value;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060006EB RID: 1771 RVA: 0x0001C942 File Offset: 0x0001AB42
		// (set) Token: 0x060006EC RID: 1772 RVA: 0x0001C94A File Offset: 0x0001AB4A
		public EAmbianceVolumeFogOverrideMode FogOverrideMode
		{
			get
			{
				return this._fogOverrideMode;
			}
			set
			{
				this._fogOverrideMode = value;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060006ED RID: 1773 RVA: 0x0001C953 File Offset: 0x0001AB53
		// (set) Token: 0x060006EE RID: 1774 RVA: 0x0001C95B File Offset: 0x0001AB5B
		[Obsolete]
		public bool overrideFog
		{
			get
			{
				return this._overrideFog;
			}
			set
			{
				this._overrideFog = false;
				this._fogOverrideMode = (value ? EAmbianceVolumeFogOverrideMode.Constant : EAmbianceVolumeFogOverrideMode.PerTimeOfDay);
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060006EF RID: 1775 RVA: 0x0001C971 File Offset: 0x0001AB71
		// (set) Token: 0x060006F0 RID: 1776 RVA: 0x0001C979 File Offset: 0x0001AB79
		public Color fogColor
		{
			get
			{
				return this._fogColor;
			}
			set
			{
				this._fogColor = value;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060006F1 RID: 1777 RVA: 0x0001C982 File Offset: 0x0001AB82
		// (set) Token: 0x060006F2 RID: 1778 RVA: 0x0001C98A File Offset: 0x0001AB8A
		public float fogIntensity
		{
			get
			{
				return this._fogIntensity;
			}
			set
			{
				this._fogIntensity = value;
			}
		}

		/// <summary>
		/// Used by lighting to get the currently active effect.
		/// </summary>
		// Token: 0x060006F3 RID: 1779 RVA: 0x0001C993 File Offset: 0x0001AB93
		public EffectAsset GetEffectAsset()
		{
			if (this.cachedEffectAsset == null || this.cachedEffectAsset.hasBeenReplaced)
			{
				this.cachedEffectAsset = Assets.FindEffectAssetByGuidOrLegacyId(this._effectGuid, this._id);
			}
			return this.cachedEffectAsset;
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x0001C9C8 File Offset: 0x0001ABC8
		internal void GetFogSettings(int blendKey, int currentKey, float timeAlpha, out Color overrideFogColor, out float overrideFogIntensity)
		{
			if (this._fogOverrideMode != EAmbianceVolumeFogOverrideMode.PerTimeOfDay)
			{
				overrideFogColor = this.fogColor;
				overrideFogIntensity = this.fogIntensity;
				return;
			}
			if (this.perTimeOfDaySettings == null || this.perTimeOfDaySettings.Length != 4)
			{
				overrideFogColor = Color.white;
				overrideFogIntensity = 0f;
				return;
			}
			ref AmbianceVolumeTimeOfDaySettings ptr = ref this.perTimeOfDaySettings[currentKey];
			ref AmbianceVolumeTimeOfDaySettings ptr2 = ref this.perTimeOfDaySettings[(blendKey == -1) ? currentKey : blendKey];
			overrideFogColor = Color.Lerp(ptr2.fogColor, ptr.fogColor, timeAlpha);
			overrideFogIntensity = Mathf.Lerp(ptr2.fogIntensity, ptr.fogIntensity, timeAlpha);
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x0001CA6C File Offset: 0x0001AC6C
		internal ref AmbianceVolumeTimeOfDaySettings GetFogSettings(ELightingTime time)
		{
			if (this.perTimeOfDaySettings == null || this.perTimeOfDaySettings.Length != 4)
			{
				this.perTimeOfDaySettings = new AmbianceVolumeTimeOfDaySettings[4];
				for (int i = 0; i < 4; i++)
				{
					AmbianceVolumeTimeOfDaySettings[] array = this.perTimeOfDaySettings;
					int num = i;
					array[num].fogColor = Color.white;
					array[num].fogIntensity = 1f;
				}
			}
			return ref this.perTimeOfDaySettings[(int)time];
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x0001CAD4 File Offset: 0x0001ACD4
		protected override void readHierarchyItem(IFormattedFileReader reader)
		{
			base.readHierarchyItem(reader);
			string text = reader.readValue("Ambiance_ID");
			if (ushort.TryParse(text, out this._id))
			{
				this._effectGuid = Guid.Empty;
			}
			else if (Guid.TryParse(text, out this._effectGuid))
			{
				this._id = 0;
			}
			this.noWater = reader.readValue<bool>("No_Water");
			this.noLighting = reader.readValue<bool>("No_Lighting");
			if (reader.containsKey("Weather_Mask"))
			{
				this.weatherMask = reader.readValue<uint>("Weather_Mask");
			}
			else
			{
				this.weatherMask = uint.MaxValue;
				if (reader.containsKey("Can_Rain") && !reader.readValue<bool>("Can_Rain"))
				{
					this.weatherMask &= 4294967294U;
				}
				if (reader.containsKey("Can_Snow") && !reader.readValue<bool>("Can_Snow"))
				{
					this.weatherMask &= 4294967293U;
				}
			}
			if (reader.containsKey("Override_Fog_Mode"))
			{
				this._fogOverrideMode = reader.readValue<EAmbianceVolumeFogOverrideMode>("Override_Fog_Mode");
				if (this._fogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay)
				{
					this.perTimeOfDaySettings = new AmbianceVolumeTimeOfDaySettings[4];
					this.perTimeOfDaySettings[0] = new AmbianceVolumeTimeOfDaySettings(reader.readObject("Dawn"));
					this.perTimeOfDaySettings[1] = new AmbianceVolumeTimeOfDaySettings(reader.readObject("Midday"));
					this.perTimeOfDaySettings[2] = new AmbianceVolumeTimeOfDaySettings(reader.readObject("Dusk"));
					this.perTimeOfDaySettings[3] = new AmbianceVolumeTimeOfDaySettings(reader.readObject("Midnight"));
				}
			}
			else if (reader.readValue<bool>("Override_Fog"))
			{
				this._fogOverrideMode = EAmbianceVolumeFogOverrideMode.Constant;
			}
			this.fogColor = reader.readValue<Color>("Fog_Color");
			if (reader.containsKey("Fog_Intensity"))
			{
				this.fogIntensity = reader.readValue<float>("Fog_Intensity");
			}
			else
			{
				float value = reader.readValue<float>("Fog_Height");
				this.fogIntensity = Mathf.InverseLerp(-1024f, 1024f, value);
			}
			this.overrideAtmosphericFog = reader.readValue<bool>("Override_Atmospheric_Fog");
			this.enableFalloff = reader.readValue<bool>("Enable_Falloff");
			this.priority = reader.readValue<int>("Priority");
			if (reader.containsKey("Audio_FadeIn"))
			{
				this.audioFadeInDuration = reader.readValue<float>("Audio_FadeIn");
			}
			if (reader.containsKey("Audio_FadeOut"))
			{
				this.audioFadeOutDuration = reader.readValue<float>("Audio_FadeOut");
			}
			if (reader.containsKey("Fog_FadeIn"))
			{
				this.fogFadeInDuration = reader.readValue<float>("Fog_FadeIn");
			}
			if (reader.containsKey("Fog_FadeOut"))
			{
				this.fogFadeOutDuration = reader.readValue<float>("Fog_FadeOut");
			}
			if (reader.containsKey("Lighting_FadeIn"))
			{
				this.lightingFadeInDuration = reader.readValue<float>("Lighting_FadeIn");
			}
			if (reader.containsKey("Lighting_FadeOut"))
			{
				this.lightingFadeOutDuration = reader.readValue<float>("Lighting_FadeOut");
			}
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x0001CDB8 File Offset: 0x0001AFB8
		protected override void writeHierarchyItem(IFormattedFileWriter writer)
		{
			base.writeHierarchyItem(writer);
			if (!this._effectGuid.IsEmpty())
			{
				writer.writeValue<Guid>("Ambiance_ID", this._effectGuid);
			}
			else
			{
				writer.writeValue<ushort>("Ambiance_ID", this._id);
			}
			writer.writeValue<bool>("No_Water", this.noWater);
			writer.writeValue<bool>("No_Lighting", this.noLighting);
			writer.writeValue<uint>("Weather_Mask", this.weatherMask);
			writer.writeValue<EAmbianceVolumeFogOverrideMode>("Override_Fog_Mode", this._fogOverrideMode);
			if (this._fogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay && this.perTimeOfDaySettings != null && this.perTimeOfDaySettings.Length == 4)
			{
				writer.beginObject("Dawn");
				this.perTimeOfDaySettings[0].Write(writer);
				writer.endObject();
				writer.beginObject("Midday");
				this.perTimeOfDaySettings[1].Write(writer);
				writer.endObject();
				writer.beginObject("Dusk");
				this.perTimeOfDaySettings[2].Write(writer);
				writer.endObject();
				writer.beginObject("Midnight");
				this.perTimeOfDaySettings[3].Write(writer);
				writer.endObject();
			}
			writer.writeValue<Color>("Fog_Color", this.fogColor);
			writer.writeValue<float>("Fog_Intensity", this.fogIntensity);
			writer.writeValue<bool>("Override_Atmospheric_Fog", this.overrideAtmosphericFog);
			writer.writeValue<bool>("Enable_Falloff", this.enableFalloff);
			writer.writeValue<int>("Priority", this.priority);
			writer.writeValue<float>("Audio_FadeIn", this.audioFadeInDuration);
			writer.writeValue<float>("Audio_FadeOut", this.audioFadeOutDuration);
			writer.writeValue<float>("Fog_FadeIn", this.fogFadeInDuration);
			writer.writeValue<float>("Fog_FadeOut", this.fogFadeOutDuration);
			writer.writeValue<float>("Lighting_FadeIn", this.lightingFadeInDuration);
			writer.writeValue<float>("Lighting_FadeOut", this.lightingFadeOutDuration);
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x0001CFAD File Offset: 0x0001B1AD
		protected override void Awake()
		{
			this.supportsFalloff = true;
			if (this._overrideFog)
			{
				this._overrideFog = false;
				this._fogOverrideMode = EAmbianceVolumeFogOverrideMode.Constant;
			}
			base.Awake();
		}

		// Token: 0x040002C3 RID: 707
		[SerializeField]
		internal Guid _effectGuid;

		/// <summary>
		/// Kept because lots of modders have been using this script in Unity,
		/// so removing legacy effect id would break their content.
		/// </summary>
		// Token: 0x040002C4 RID: 708
		[SerializeField]
		protected ushort _id;

		// Token: 0x040002C5 RID: 709
		[SerializeField]
		protected bool _noWater;

		// Token: 0x040002C6 RID: 710
		[SerializeField]
		protected bool _noLighting;

		/// <summary>
		/// If per-weather mask AND is non zero the weather will blend in.
		/// </summary>
		// Token: 0x040002C7 RID: 711
		[SerializeField]
		public uint weatherMask = uint.MaxValue;

		// Token: 0x040002C8 RID: 712
		[SerializeField]
		protected EAmbianceVolumeFogOverrideMode _fogOverrideMode;

		/// <summary>
		/// Kept for backwards compatibility with fog volumes created in Unity / by mods.
		/// </summary>
		// Token: 0x040002C9 RID: 713
		[SerializeField]
		protected bool _overrideFog;

		// Token: 0x040002CA RID: 714
		[SerializeField]
		protected Color _fogColor = Color.white;

		// Token: 0x040002CB RID: 715
		[SerializeField]
		protected float _fogIntensity;

		// Token: 0x040002CC RID: 716
		[SerializeField]
		internal AmbianceVolumeTimeOfDaySettings[] perTimeOfDaySettings;

		// Token: 0x040002CD RID: 717
		[SerializeField]
		public bool overrideAtmosphericFog;

		/// <summary>
		/// Distinguishes from zero falloff which may be useful deep in a cave.
		/// </summary>
		// Token: 0x040002CE RID: 718
		[SerializeField]
		public bool enableFalloff;

		/// <summary>
		/// Higher priority volumes override lower priority volumes.
		/// </summary>
		// Token: 0x040002CF RID: 719
		public int priority;

		/// <summary>
		/// When falloff is OFF, how long to fade in audio by time.
		/// </summary>
		// Token: 0x040002D0 RID: 720
		public float audioFadeInDuration = 2f;

		/// <summary>
		/// When falloff is OFF, how long to fade out audio by time.
		/// </summary>
		// Token: 0x040002D1 RID: 721
		public float audioFadeOutDuration = 2f;

		/// <summary>
		/// When falloff is OFF, how long to fade in audio by time.
		/// </summary>
		// Token: 0x040002D2 RID: 722
		public float fogFadeInDuration = 20f;

		/// <summary>
		/// When falloff is OFF, how long to fade out audio by time.
		/// </summary>
		// Token: 0x040002D3 RID: 723
		public float fogFadeOutDuration = 8f;

		/// <summary>
		/// When falloff is OFF, how long to fade in lighting by time.
		/// </summary>
		// Token: 0x040002D4 RID: 724
		public float lightingFadeInDuration = 4f;

		/// <summary>
		/// When falloff is OFF, how long to fade out lighting by time.
		/// </summary>
		// Token: 0x040002D5 RID: 725
		public float lightingFadeOutDuration = 4f;

		// Token: 0x040002D6 RID: 726
		private EffectAsset cachedEffectAsset;

		// Token: 0x02000911 RID: 2321
		private class Menu : SleekWrapper
		{
			// Token: 0x060050D4 RID: 20692 RVA: 0x001F40FC File Offset: 0x001F22FC
			public Menu(AmbianceVolume volume)
			{
				this.volume = volume;
				base.SizeOffset_X = 400f;
				float num = 0f;
				ISleekField sleekField = Glazier.Get().CreateStringField();
				sleekField.PositionOffset_Y = num;
				sleekField.SizeOffset_X = 200f;
				sleekField.SizeOffset_Y = 30f;
				if (volume._effectGuid.IsEmpty())
				{
					sleekField.Text = volume._id.ToString();
				}
				else
				{
					sleekField.Text = volume._effectGuid.ToString("N");
				}
				sleekField.AddLabel("Effect ID", ESleekSide.RIGHT);
				sleekField.OnTextChanged += this.OnIdChanged;
				base.AddChild(sleekField);
				num += sleekField.SizeOffset_Y + 10f;
				ISleekToggle sleekToggle = Glazier.Get().CreateToggle();
				sleekToggle.PositionOffset_Y = num;
				sleekToggle.SizeOffset_X = 40f;
				sleekToggle.SizeOffset_Y = 40f;
				sleekToggle.Value = volume.noWater;
				sleekToggle.AddLabel("No Water", ESleekSide.RIGHT);
				sleekToggle.OnValueChanged += this.OnNoWaterToggled;
				base.AddChild(sleekToggle);
				num += sleekToggle.SizeOffset_Y + 10f;
				ISleekToggle sleekToggle2 = Glazier.Get().CreateToggle();
				sleekToggle2.PositionOffset_Y = num;
				sleekToggle2.SizeOffset_X = 40f;
				sleekToggle2.SizeOffset_Y = 40f;
				sleekToggle2.Value = volume.noLighting;
				sleekToggle2.AddLabel("No Lighting", ESleekSide.RIGHT);
				sleekToggle2.OnValueChanged += this.OnNoLightingToggled;
				base.AddChild(sleekToggle2);
				num += sleekToggle2.SizeOffset_Y + 10f;
				ISleekUInt32Field sleekUInt32Field = Glazier.Get().CreateUInt32Field();
				sleekUInt32Field.PositionOffset_Y = num;
				sleekUInt32Field.SizeOffset_X = 200f;
				sleekUInt32Field.SizeOffset_Y = 30f;
				sleekUInt32Field.Value = volume.weatherMask;
				sleekUInt32Field.AddLabel("Weather Mask", ESleekSide.RIGHT);
				sleekUInt32Field.OnValueChanged += this.OnWeatherMaskChanged;
				base.AddChild(sleekUInt32Field);
				num += sleekUInt32Field.SizeOffset_Y + 10f;
				this.fogMode = new SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode>();
				this.fogMode.PositionOffset_Y = num;
				this.fogMode.SizeOffset_X = 200f;
				this.fogMode.SizeOffset_Y = 30f;
				this.fogMode.SetEnum(volume.FogOverrideMode);
				this.fogMode.AddLabel("Override Fog", ESleekSide.RIGHT);
				SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode> sleekButtonStateEnum = this.fogMode;
				sleekButtonStateEnum.OnSwappedEnum = (Action<SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode>, EAmbianceVolumeFogOverrideMode>)Delegate.Combine(sleekButtonStateEnum.OnSwappedEnum, new Action<SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode>, EAmbianceVolumeFogOverrideMode>(this.OnFogModeChanged));
				base.AddChild(this.fogMode);
				num += this.fogMode.SizeOffset_Y + 10f;
				this.timeButton = new SleekButtonStateEnum<ELightingTime>();
				this.timeButton.PositionOffset_Y = num;
				this.timeButton.SizeOffset_X = 200f;
				this.timeButton.SizeOffset_Y = 30f;
				this.timeButton.AddLabel("Fog Time", ESleekSide.RIGHT);
				SleekButtonStateEnum<ELightingTime> sleekButtonStateEnum2 = this.timeButton;
				sleekButtonStateEnum2.OnSwappedEnum = (Action<SleekButtonStateEnum<ELightingTime>, ELightingTime>)Delegate.Combine(sleekButtonStateEnum2.OnSwappedEnum, new Action<SleekButtonStateEnum<ELightingTime>, ELightingTime>(this.OnFogTimeChanged));
				base.AddChild(this.timeButton);
				num += this.timeButton.SizeOffset_Y + 10f;
				this.fogColor = new SleekColorPicker();
				this.fogColor.PositionOffset_Y = num;
				SleekColorPicker sleekColorPicker = this.fogColor;
				sleekColorPicker.onColorPicked = (ColorPicked)Delegate.Combine(sleekColorPicker.onColorPicked, new ColorPicked(this.OnFogColorPicked));
				base.AddChild(this.fogColor);
				num += this.fogColor.SizeOffset_Y + 10f;
				this.fogIntensityField = Glazier.Get().CreateFloat32Field();
				this.fogIntensityField.PositionOffset_Y = num;
				this.fogIntensityField.SizeOffset_X = 200f;
				this.fogIntensityField.SizeOffset_Y = 30f;
				this.fogIntensityField.AddLabel("Fog Intensity", ESleekSide.RIGHT);
				this.fogIntensityField.OnValueChanged += this.OnFogIntensityChanged;
				base.AddChild(this.fogIntensityField);
				num += this.fogIntensityField.SizeOffset_Y + 10f;
				ISleekToggle sleekToggle3 = Glazier.Get().CreateToggle();
				sleekToggle3.PositionOffset_Y = num;
				sleekToggle3.SizeOffset_X = 40f;
				sleekToggle3.SizeOffset_Y = 40f;
				sleekToggle3.Value = volume.overrideAtmosphericFog;
				sleekToggle3.AddLabel("Override Atmospheric Fog", ESleekSide.RIGHT);
				sleekToggle3.OnValueChanged += this.OnOverrideAtmosphericFogToggled;
				base.AddChild(sleekToggle3);
				num += sleekToggle3.SizeOffset_Y + 10f;
				ISleekToggle sleekToggle4 = Glazier.Get().CreateToggle();
				sleekToggle4.PositionOffset_Y = num;
				sleekToggle4.SizeOffset_X = 40f;
				sleekToggle4.SizeOffset_Y = 40f;
				sleekToggle4.Value = volume.enableFalloff;
				sleekToggle4.AddLabel("Use Falloff", ESleekSide.RIGHT);
				sleekToggle4.OnValueChanged += this.OnEnableFalloffToggled;
				base.AddChild(sleekToggle4);
				num += sleekToggle4.SizeOffset_Y + 10f;
				ISleekInt32Field sleekInt32Field = Glazier.Get().CreateInt32Field();
				sleekInt32Field.PositionOffset_Y = num;
				sleekInt32Field.SizeOffset_X = 200f;
				sleekInt32Field.SizeOffset_Y = 30f;
				sleekInt32Field.Value = volume.priority;
				sleekInt32Field.AddLabel("Priority", ESleekSide.RIGHT);
				sleekInt32Field.OnValueChanged += this.OnPriorityChanged;
				base.AddChild(sleekInt32Field);
				num += sleekInt32Field.SizeOffset_Y + 10f;
				this.audioFadeInField = Glazier.Get().CreateFloat32Field();
				this.audioFadeInField.PositionOffset_Y = num;
				this.audioFadeInField.SizeOffset_X = 200f;
				this.audioFadeInField.SizeOffset_Y = 30f;
				this.audioFadeInField.Value = volume.audioFadeInDuration;
				this.audioFadeInField.AddLabel("Audio Fade-In", ESleekSide.RIGHT);
				this.audioFadeInField.TooltipText = "Seconds for effect audio to fade in when distance falloff is disabled.";
				this.audioFadeInField.OnValueChanged += this.OnAudioFadeInDurationChanged;
				base.AddChild(this.audioFadeInField);
				num += this.audioFadeInField.SizeOffset_Y + 10f;
				this.audioFadeOutField = Glazier.Get().CreateFloat32Field();
				this.audioFadeOutField.PositionOffset_Y = num;
				this.audioFadeOutField.SizeOffset_X = 200f;
				this.audioFadeOutField.SizeOffset_Y = 30f;
				this.audioFadeOutField.Value = volume.audioFadeOutDuration;
				this.audioFadeOutField.AddLabel("Audio Fade-Out", ESleekSide.RIGHT);
				this.audioFadeOutField.TooltipText = "Seconds for effect audio to fade out when distance falloff is disabled.";
				this.audioFadeOutField.OnValueChanged += this.OnAudioFadeOutDurationChanged;
				base.AddChild(this.audioFadeOutField);
				num += this.audioFadeOutField.SizeOffset_Y + 10f;
				this.fogFadeInField = Glazier.Get().CreateFloat32Field();
				this.fogFadeInField.PositionOffset_Y = num;
				this.fogFadeInField.SizeOffset_X = 200f;
				this.fogFadeInField.SizeOffset_Y = 30f;
				this.fogFadeInField.Value = volume.fogFadeInDuration;
				this.fogFadeInField.AddLabel("Fog Fade-In", ESleekSide.RIGHT);
				this.fogFadeInField.TooltipText = "Seconds for fog to fade in when distance falloff is disabled.";
				this.fogFadeInField.OnValueChanged += this.OnFogFadeInDurationChanged;
				base.AddChild(this.fogFadeInField);
				num += this.fogFadeInField.SizeOffset_Y + 10f;
				this.fogFadeOutField = Glazier.Get().CreateFloat32Field();
				this.fogFadeOutField.PositionOffset_Y = num;
				this.fogFadeOutField.SizeOffset_X = 200f;
				this.fogFadeOutField.SizeOffset_Y = 30f;
				this.fogFadeOutField.Value = volume.fogFadeOutDuration;
				this.fogFadeOutField.AddLabel("Fog Fade-Out", ESleekSide.RIGHT);
				this.fogFadeOutField.TooltipText = "Seconds for fog to fade out when distance falloff is disabled.";
				this.fogFadeOutField.OnValueChanged += this.OnFogFadeOutDurationChanged;
				base.AddChild(this.fogFadeOutField);
				num += this.fogFadeOutField.SizeOffset_Y + 10f;
				this.lightingFadeInField = Glazier.Get().CreateFloat32Field();
				this.lightingFadeInField.PositionOffset_Y = num;
				this.lightingFadeInField.SizeOffset_X = 200f;
				this.lightingFadeInField.SizeOffset_Y = 30f;
				this.lightingFadeInField.Value = volume.lightingFadeInDuration;
				this.lightingFadeInField.AddLabel("Lighting Fade-In", ESleekSide.RIGHT);
				this.lightingFadeInField.TooltipText = "Seconds for lighting to fade in when distance falloff is disabled.";
				this.lightingFadeInField.OnValueChanged += this.OnLightingFadeInDurationChanged;
				base.AddChild(this.lightingFadeInField);
				num += this.lightingFadeInField.SizeOffset_Y + 10f;
				this.lightingFadeOutField = Glazier.Get().CreateFloat32Field();
				this.lightingFadeOutField.PositionOffset_Y = num;
				this.lightingFadeOutField.SizeOffset_X = 200f;
				this.lightingFadeOutField.SizeOffset_Y = 30f;
				this.lightingFadeOutField.Value = volume.lightingFadeOutDuration;
				this.lightingFadeOutField.AddLabel("Lighting Fade-Out", ESleekSide.RIGHT);
				this.lightingFadeOutField.TooltipText = "Seconds for lighting to fade out when distance falloff is disabled.";
				this.lightingFadeOutField.OnValueChanged += this.OnLightingFadeOutDurationChanged;
				base.AddChild(this.lightingFadeOutField);
				num += this.lightingFadeOutField.SizeOffset_Y + 10f;
				this.UpdateFogSettings();
				this.UpdateFade();
				base.SizeOffset_Y = num - 10f;
			}

			// Token: 0x060050D5 RID: 20693 RVA: 0x001F4A58 File Offset: 0x001F2C58
			private void OnIdChanged(ISleekField field, string effectIdString)
			{
				if (ushort.TryParse(effectIdString, out this.volume._id))
				{
					this.volume._effectGuid = Guid.Empty;
				}
				else if (Guid.TryParse(effectIdString, out this.volume._effectGuid))
				{
					this.volume._id = 0;
				}
				else
				{
					this.volume._effectGuid = Guid.Empty;
					this.volume._id = 0;
				}
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D6 RID: 20694 RVA: 0x001F4ACC File Offset: 0x001F2CCC
			private void OnNoWaterToggled(ISleekToggle toggle, bool noWater)
			{
				this.volume.noWater = noWater;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D7 RID: 20695 RVA: 0x001F4ADF File Offset: 0x001F2CDF
			private void OnNoLightingToggled(ISleekToggle toggle, bool noLighting)
			{
				this.volume.noLighting = noLighting;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D8 RID: 20696 RVA: 0x001F4AF2 File Offset: 0x001F2CF2
			private void OnWeatherMaskChanged(ISleekUInt32Field field, uint mask)
			{
				this.volume.weatherMask = mask;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050D9 RID: 20697 RVA: 0x001F4B05 File Offset: 0x001F2D05
			private void OnFogModeChanged(SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode> button, EAmbianceVolumeFogOverrideMode newFogMode)
			{
				this.volume.FogOverrideMode = newFogMode;
				this.UpdateFogSettings();
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050DA RID: 20698 RVA: 0x001F4B1E File Offset: 0x001F2D1E
			private void OnFogTimeChanged(SleekButtonStateEnum<ELightingTime> button, ELightingTime newTime)
			{
				this.UpdateFogSettings();
			}

			// Token: 0x060050DB RID: 20699 RVA: 0x001F4B26 File Offset: 0x001F2D26
			private void OnFogColorPicked(SleekColorPicker picker, Color color)
			{
				if (this.volume.FogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay)
				{
					this.volume.GetFogSettings(this.timeButton.GetEnum()).fogColor = color;
				}
				else
				{
					this.volume.fogColor = color;
				}
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050DC RID: 20700 RVA: 0x001F4B65 File Offset: 0x001F2D65
			private void OnFogIntensityChanged(ISleekFloat32Field field, float value)
			{
				if (this.volume.FogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay)
				{
					this.volume.GetFogSettings(this.timeButton.GetEnum()).fogIntensity = value;
				}
				else
				{
					this.volume.fogIntensity = value;
				}
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050DD RID: 20701 RVA: 0x001F4BA4 File Offset: 0x001F2DA4
			private void OnOverrideAtmosphericFogToggled(ISleekToggle toggle, bool overrideAtmosphericFog)
			{
				this.volume.overrideAtmosphericFog = overrideAtmosphericFog;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050DE RID: 20702 RVA: 0x001F4BB7 File Offset: 0x001F2DB7
			private void OnEnableFalloffToggled(ISleekToggle toggle, bool enableFalloff)
			{
				this.volume.enableFalloff = enableFalloff;
				this.UpdateFade();
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050DF RID: 20703 RVA: 0x001F4BD0 File Offset: 0x001F2DD0
			private void OnPriorityChanged(ISleekInt32Field field, int value)
			{
				this.volume.priority = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E0 RID: 20704 RVA: 0x001F4BE3 File Offset: 0x001F2DE3
			private void OnAudioFadeInDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.audioFadeInDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E1 RID: 20705 RVA: 0x001F4BF6 File Offset: 0x001F2DF6
			private void OnAudioFadeOutDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.audioFadeOutDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E2 RID: 20706 RVA: 0x001F4C09 File Offset: 0x001F2E09
			private void OnFogFadeInDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.fogFadeInDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E3 RID: 20707 RVA: 0x001F4C1C File Offset: 0x001F2E1C
			private void OnFogFadeOutDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.fogFadeOutDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E4 RID: 20708 RVA: 0x001F4C2F File Offset: 0x001F2E2F
			private void OnLightingFadeInDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.lightingFadeInDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E5 RID: 20709 RVA: 0x001F4C42 File Offset: 0x001F2E42
			private void OnLightingFadeOutDurationChanged(ISleekFloat32Field field, float value)
			{
				this.volume.lightingFadeOutDuration = value;
				LevelHierarchy.MarkDirty();
			}

			// Token: 0x060050E6 RID: 20710 RVA: 0x001F4C58 File Offset: 0x001F2E58
			private void UpdateFade()
			{
				bool isClickable = !this.volume.enableFalloff;
				this.audioFadeInField.IsClickable = isClickable;
				this.audioFadeOutField.IsClickable = isClickable;
				this.fogFadeInField.IsClickable = isClickable;
				this.fogFadeOutField.IsClickable = isClickable;
				this.lightingFadeInField.IsClickable = isClickable;
				this.lightingFadeOutField.IsClickable = isClickable;
			}

			// Token: 0x060050E7 RID: 20711 RVA: 0x001F4CBC File Offset: 0x001F2EBC
			private void UpdateFogSettings()
			{
				this.timeButton.isInteractable = (this.volume.FogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay);
				if (this.volume.FogOverrideMode == EAmbianceVolumeFogOverrideMode.PerTimeOfDay)
				{
					ref AmbianceVolumeTimeOfDaySettings fogSettings = ref this.volume.GetFogSettings(this.timeButton.GetEnum());
					this.fogColor.state = fogSettings.fogColor;
					this.fogIntensityField.Value = fogSettings.fogIntensity;
					return;
				}
				this.fogColor.state = this.volume.fogColor;
				this.fogIntensityField.Value = this.volume.fogIntensity;
			}

			// Token: 0x040036DF RID: 14047
			private AmbianceVolume volume;

			// Token: 0x040036E0 RID: 14048
			private SleekButtonStateEnum<EAmbianceVolumeFogOverrideMode> fogMode;

			// Token: 0x040036E1 RID: 14049
			private SleekButtonStateEnum<ELightingTime> timeButton;

			// Token: 0x040036E2 RID: 14050
			private SleekColorPicker fogColor;

			// Token: 0x040036E3 RID: 14051
			private ISleekFloat32Field fogIntensityField;

			// Token: 0x040036E4 RID: 14052
			private ISleekFloat32Field audioFadeInField;

			// Token: 0x040036E5 RID: 14053
			private ISleekFloat32Field audioFadeOutField;

			// Token: 0x040036E6 RID: 14054
			private ISleekFloat32Field fogFadeInField;

			// Token: 0x040036E7 RID: 14055
			private ISleekFloat32Field fogFadeOutField;

			// Token: 0x040036E8 RID: 14056
			private ISleekFloat32Field lightingFadeInField;

			// Token: 0x040036E9 RID: 14057
			private ISleekFloat32Field lightingFadeOutField;
		}
	}
}
