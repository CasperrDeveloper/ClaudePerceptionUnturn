﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000123 RID: 291
	// (Invoke) Token: 0x06000783 RID: 1923
	public delegate void LevelHiearchyItemAdded(IDevkitHierarchyItem item);
}
