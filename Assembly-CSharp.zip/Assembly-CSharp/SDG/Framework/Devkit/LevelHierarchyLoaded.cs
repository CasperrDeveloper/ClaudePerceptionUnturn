﻿using System;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000125 RID: 293
	// (Invoke) Token: 0x0600078B RID: 1931
	public delegate void LevelHierarchyLoaded();
}
