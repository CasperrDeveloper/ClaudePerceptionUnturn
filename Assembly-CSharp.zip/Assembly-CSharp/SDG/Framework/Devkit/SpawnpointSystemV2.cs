﻿using System;
using System.Collections.Generic;
using System.Linq;
using SDG.Framework.Utilities;
using SDG.Unturned;
using UnityEngine;

namespace SDG.Framework.Devkit
{
	// Token: 0x02000130 RID: 304
	public class SpawnpointSystemV2 : TempNodeSystemBase
	{
		// Token: 0x060007D5 RID: 2005 RVA: 0x0001EF97 File Offset: 0x0001D197
		public static SpawnpointSystemV2 Get()
		{
			return SpawnpointSystemV2.instance;
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x0001EF9E File Offset: 0x0001D19E
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x0001EFA8 File Offset: 0x0001D1A8
		public bool IsVisible
		{
			get
			{
				return this._isVisible;
			}
			set
			{
				if (this._isVisible != value)
				{
					this._isVisible = value;
					ConvenientSavedata.get().write("Visibility_Spawnpoints", value);
					if (Level.isEditor)
					{
						foreach (AirdropDevkitNode airdropDevkitNode in AirdropDevkitNodeSystem.Get().GetAllNodes())
						{
							airdropDevkitNode.UpdateEditorVisibility();
						}
						foreach (LocationDevkitNode locationDevkitNode in LocationDevkitNodeSystem.Get().GetAllNodes())
						{
							locationDevkitNode.UpdateEditorVisibility();
						}
						foreach (Spawnpoint spawnpoint in this.allSpawnpoints)
						{
							spawnpoint.UpdateEditorVisibility();
						}
					}
				}
			}
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x0001F0A0 File Offset: 0x0001D2A0
		public IReadOnlyList<Spawnpoint> GetAllSpawnpoints()
		{
			return this.allSpawnpoints;
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x0001F0A8 File Offset: 0x0001D2A8
		public Spawnpoint FindFirstSpawnpoint(string id)
		{
			if (string.IsNullOrEmpty(id))
			{
				return null;
			}
			List<Spawnpoint> source;
			if (this.idToSpawnpoints.TryGetValue(id, out source))
			{
				return source.FirstOrDefault<Spawnpoint>();
			}
			return null;
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x0001F0D7 File Offset: 0x0001D2D7
		internal override Type GetComponentType()
		{
			return typeof(Spawnpoint);
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x0001F0E3 File Offset: 0x0001D2E3
		internal override IEnumerable<GameObject> EnumerateGameObjects()
		{
			foreach (Spawnpoint spawnpoint in this.allSpawnpoints)
			{
				yield return spawnpoint.gameObject;
			}
			List<Spawnpoint>.Enumerator enumerator = default(List<Spawnpoint>.Enumerator);
			yield break;
			yield break;
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x0001F0F3 File Offset: 0x0001D2F3
		internal void AddSpawnpoint(Spawnpoint spawnpoint)
		{
			this.allSpawnpoints.Add(spawnpoint);
			this.AddSpawnpointToIdDictionary(spawnpoint);
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x0001F108 File Offset: 0x0001D308
		internal void RemoveSpawnpoint(Spawnpoint spawnpoint)
		{
			this.RemoveSpawnpointFromIdDictionary(spawnpoint);
			this.allSpawnpoints.RemoveFast(spawnpoint);
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x0001F120 File Offset: 0x0001D320
		internal void AddSpawnpointToIdDictionary(Spawnpoint spawnpoint)
		{
			string spawnpointID = spawnpoint.SpawnpointID;
			if (string.IsNullOrEmpty(spawnpointID))
			{
				return;
			}
			List<Spawnpoint> list;
			if (!this.idToSpawnpoints.TryGetValue(spawnpointID, out list))
			{
				list = new List<Spawnpoint>();
				this.idToSpawnpoints.Add(spawnpointID, list);
			}
			list.Add(spawnpoint);
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x0001F168 File Offset: 0x0001D368
		internal void RemoveSpawnpointFromIdDictionary(Spawnpoint spawnpoint)
		{
			string spawnpointID = spawnpoint.SpawnpointID;
			if (string.IsNullOrEmpty(spawnpointID))
			{
				return;
			}
			List<Spawnpoint> list;
			if (this.idToSpawnpoints.TryGetValue(spawnpointID, out list))
			{
				list.RemoveFast(spawnpoint);
				if (list.Count < 1)
				{
					this.idToSpawnpoints.Remove(spawnpointID);
				}
			}
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x0001F1B4 File Offset: 0x0001D3B4
		internal SpawnpointSystemV2()
		{
			SpawnpointSystemV2.instance = this;
			this.allSpawnpoints = new List<Spawnpoint>();
			this.idToSpawnpoints = new Dictionary<string, List<Spawnpoint>>(StringComparer.InvariantCultureIgnoreCase);
			TimeUtility.updated += this.OnUpdateGizmos;
			bool isVisible;
			if (ConvenientSavedata.get().read("Visibility_Nodes", out isVisible))
			{
				this._isVisible = isVisible;
				return;
			}
			this._isVisible = true;
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x0001F21C File Offset: 0x0001D41C
		private void OnUpdateGizmos()
		{
			if (!this._isVisible || !Level.isEditor)
			{
				return;
			}
			foreach (Spawnpoint spawnpoint in this.allSpawnpoints)
			{
				Color color = spawnpoint.isSelected ? Color.yellow : Color.red;
				Matrix4x4 localToWorldMatrix = spawnpoint.transform.localToWorldMatrix;
				RuntimeGizmos.Get().Line(localToWorldMatrix.MultiplyPoint3x4(new Vector3(-0.5f, 0f, 0f)), localToWorldMatrix.MultiplyPoint3x4(new Vector3(0.5f, 0f, 0f)), color, 0f, EGizmoLayer.World);
				RuntimeGizmos.Get().Line(localToWorldMatrix.MultiplyPoint3x4(new Vector3(0f, -0.5f, 0f)), localToWorldMatrix.MultiplyPoint3x4(new Vector3(0f, 0.5f, 0f)), color, 0f, EGizmoLayer.World);
				RuntimeGizmos.Get().ArrowFromTo(localToWorldMatrix.MultiplyPoint3x4(new Vector3(0f, 0f, -0.5f)), localToWorldMatrix.MultiplyPoint3x4(new Vector3(0f, 0f, 1f)), color, 0f, EGizmoLayer.World);
			}
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x0001F380 File Offset: 0x0001D580
		[Obsolete("Renamed to clarify behavior")]
		public Spawnpoint FindSpawnpoint(string id)
		{
			return this.FindFirstSpawnpoint(id);
		}

		// Token: 0x04000310 RID: 784
		private bool _isVisible;

		// Token: 0x04000311 RID: 785
		private static SpawnpointSystemV2 instance;

		// Token: 0x04000312 RID: 786
		internal List<Spawnpoint> allSpawnpoints;

		// Token: 0x04000313 RID: 787
		internal Dictionary<string, List<Spawnpoint>> idToSpawnpoints;
	}
}
