﻿using System;
using System.Net;
using System.Net.Sockets;
using SDG.Framework.Utilities;
using SDG.Unturned;
using Unturned.SystemEx;

namespace SDG.NetTransport.SystemSockets
{
	/// <summary>
	/// Implementation using .NET Berkeley sockets.
	/// </summary>
	// Token: 0x0200006A RID: 106
	public class ClientTransport_SystemSockets : TransportBase_SystemSockets, IClientTransport
	{
		// Token: 0x0600025E RID: 606 RVA: 0x0000A028 File Offset: 0x00008228
		public void Initialize(ClientTransportReady callback, ClientTransportFailure failureCallback)
		{
			uint value = Provider.CurrentServerConnectParameters.address.value;
			long address = (long)((ulong)((value & 255U) << 24 | (value >> 8 & 255U) << 16 | (value >> 16 & 255U) << 8 | (value >> 24 & 255U)));
			int connectionPort = (int)Provider.CurrentServerConnectParameters.connectionPort;
			this.remoteAddress = value;
			this.remotePort = Provider.CurrentServerConnectParameters.connectionPort;
			IPEndPoint remoteEP = new IPEndPoint(address, connectionPort);
			this.socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			this.socket.Connect(remoteEP);
			this.socket.Blocking = false;
			this.messageQueue = new SocketMessageLayer();
			TimeUtility.updated += this.OnUpdate;
			callback();
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0000A0E6 File Offset: 0x000082E6
		public void TearDown()
		{
			TimeUtility.updated -= this.OnUpdate;
			this.socket.Close();
			this.socket = null;
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0000A10B File Offset: 0x0000830B
		public void Send(byte[] buffer, long size, ENetReliability reliability)
		{
			if (this.socket == null)
			{
				return;
			}
			this.messageQueue.SendMessage(this.socket, buffer, (int)size);
		}

		// Token: 0x06000261 RID: 609 RVA: 0x0000A12C File Offset: 0x0000832C
		public bool Receive(byte[] buffer, out long size)
		{
			if (this.socket == null)
			{
				size = 0L;
				return false;
			}
			byte[] array;
			if (this.messageQueue.DequeueMessage(out array))
			{
				array.CopyTo(buffer, 0);
				size = (long)array.Length;
				return true;
			}
			size = 0L;
			return false;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x0000A16B File Offset: 0x0000836B
		public bool TryGetIPv4Address(out IPv4Address address)
		{
			address = new IPv4Address(this.remoteAddress);
			return true;
		}

		// Token: 0x06000263 RID: 611 RVA: 0x0000A17F File Offset: 0x0000837F
		public bool TryGetConnectionPort(out ushort connectionPort)
		{
			connectionPort = this.remotePort;
			return true;
		}

		// Token: 0x06000264 RID: 612 RVA: 0x0000A18A File Offset: 0x0000838A
		public bool TryGetQueryPort(out ushort queryPort)
		{
			queryPort = MathfEx.ClampToUShort((int)(this.remotePort - 1));
			return true;
		}

		// Token: 0x06000265 RID: 613 RVA: 0x0000A19C File Offset: 0x0000839C
		public bool TryGetPing(out int pingMs)
		{
			pingMs = 0;
			return false;
		}

		// Token: 0x06000266 RID: 614 RVA: 0x0000A1A2 File Offset: 0x000083A2
		private void OnUpdate()
		{
			this.messageQueue.ReceiveMessages(this.socket);
		}

		// Token: 0x0400012C RID: 300
		private Socket socket;

		// Token: 0x0400012D RID: 301
		private SocketMessageLayer messageQueue;

		// Token: 0x0400012E RID: 302
		private uint remoteAddress;

		// Token: 0x0400012F RID: 303
		private ushort remotePort;
	}
}
