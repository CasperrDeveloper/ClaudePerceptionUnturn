﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using SDG.Framework.Utilities;
using SDG.Unturned;

namespace SDG.NetTransport.SystemSockets
{
	/// <summary>
	/// Implementation using .NET Berkeley sockets.
	/// </summary>
	// Token: 0x0200006B RID: 107
	public class ServerTransport_SystemSockets : TransportBase_SystemSockets, IServerTransport
	{
		// Token: 0x06000268 RID: 616 RVA: 0x0000A1C0 File Offset: 0x000083C0
		public void Initialize(ServerTransportConnectionFailureCallback connectionClosedCallback)
		{
			int serverConnectionPort = (int)Provider.GetServerConnectionPort();
			IPAddress any;
			if (!IPAddress.TryParse(Provider.bindAddress, out any))
			{
				any = IPAddress.Any;
			}
			IPEndPoint localEP = new IPEndPoint(any, serverConnectionPort);
			this.listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			this.listenSocket.Blocking = false;
			this.listenSocket.Bind(localEP);
			this.listenSocket.Listen(10);
			TimeUtility.updated += this.OnUpdate;
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0000A234 File Offset: 0x00008434
		public void TearDown()
		{
			TimeUtility.updated -= this.OnUpdate;
			this.listenSocket.Close();
			this.listenSocket = null;
			foreach (TransportConnection_SystemSocket transportConnection_SystemSocket in this.connections)
			{
				transportConnection_SystemSocket.clientSocket.Close();
			}
			this.connections.Clear();
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0000A2B8 File Offset: 0x000084B8
		public bool Receive(byte[] buffer, out long size, out ITransportConnection transportConnection)
		{
			if (this.listenSocket == null)
			{
				size = 0L;
				transportConnection = null;
				return false;
			}
			if (this.messages.Count > 0)
			{
				ServerTransport_SystemSockets.PendingMessage pendingMessage = this.messages.Dequeue();
				pendingMessage.buffer.CopyTo(buffer, 0);
				size = (long)pendingMessage.buffer.Length;
				transportConnection = pendingMessage.transportConnection;
				return true;
			}
			transportConnection = null;
			size = 0L;
			return false;
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0000A31A File Offset: 0x0000851A
		internal void CloseConnection(TransportConnection_SystemSocket connection)
		{
			if (connection.wasClosed)
			{
				return;
			}
			connection.wasClosed = true;
			connection.clientSocket.Close();
			this.connections.RemoveFast(connection);
		}

		// Token: 0x0600026C RID: 620 RVA: 0x0000A344 File Offset: 0x00008544
		private void OnUpdate()
		{
			foreach (TransportConnection_SystemSocket transportConnection_SystemSocket in this.connections)
			{
				transportConnection_SystemSocket.messageQueue.ReceiveMessages(transportConnection_SystemSocket.clientSocket);
				byte[] buffer;
				while (transportConnection_SystemSocket.messageQueue.DequeueMessage(out buffer))
				{
					ServerTransport_SystemSockets.PendingMessage item = default(ServerTransport_SystemSockets.PendingMessage);
					item.transportConnection = transportConnection_SystemSocket;
					item.buffer = buffer;
					this.messages.Enqueue(item);
				}
			}
			if (Provider.hasRoomForNewConnection)
			{
				try
				{
					Socket socket = this.listenSocket.Accept();
					socket.Blocking = false;
					TransportConnection_SystemSocket item2 = new TransportConnection_SystemSocket(this, socket);
					this.connections.Add(item2);
				}
				catch
				{
				}
			}
		}

		// Token: 0x04000130 RID: 304
		private Socket listenSocket;

		// Token: 0x04000131 RID: 305
		private List<TransportConnection_SystemSocket> connections = new List<TransportConnection_SystemSocket>();

		// Token: 0x04000132 RID: 306
		private Queue<ServerTransport_SystemSockets.PendingMessage> messages = new Queue<ServerTransport_SystemSockets.PendingMessage>();

		// Token: 0x020008F8 RID: 2296
		internal struct PendingMessage
		{
			// Token: 0x040036B6 RID: 14006
			public TransportConnection_SystemSocket transportConnection;

			// Token: 0x040036B7 RID: 14007
			public byte[] buffer;
		}
	}
}
