﻿using System;
using System.Net;
using System.Net.Sockets;

namespace SDG.NetTransport.SystemSockets
{
	// Token: 0x0200006E RID: 110
	internal class TransportConnection_SystemSocket : ITransportConnection, IEquatable<ITransportConnection>
	{
		// Token: 0x06000275 RID: 629 RVA: 0x0000A645 File Offset: 0x00008845
		public TransportConnection_SystemSocket(ServerTransport_SystemSockets serverTransport, Socket clientSocket)
		{
			this.serverTransport = serverTransport;
			this.clientSocket = clientSocket;
		}

		// Token: 0x06000276 RID: 630 RVA: 0x0000A668 File Offset: 0x00008868
		public bool TryGetIPv4Address(out uint address)
		{
			if (!this.wasClosed)
			{
				IPEndPoint ipendPoint = this.clientSocket.RemoteEndPoint as IPEndPoint;
				if (ipendPoint != null)
				{
					byte[] addressBytes = ipendPoint.Address.GetAddressBytes();
					if (addressBytes.Length == 4)
					{
						address = (uint)(((int)addressBytes[0] << 24 & 255) | ((int)addressBytes[0] << 16 & 255) | ((int)addressBytes[0] << 8 & 255) | (int)(addressBytes[0] & byte.MaxValue));
						return true;
					}
				}
			}
			address = 0U;
			return false;
		}

		// Token: 0x06000277 RID: 631 RVA: 0x0000A6DC File Offset: 0x000088DC
		public bool TryGetPort(out ushort port)
		{
			if (!this.wasClosed)
			{
				IPEndPoint ipendPoint = this.clientSocket.RemoteEndPoint as IPEndPoint;
				if (ipendPoint != null)
				{
					port = (ushort)ipendPoint.Port;
					return true;
				}
			}
			port = 0;
			return false;
		}

		// Token: 0x06000278 RID: 632 RVA: 0x0000A714 File Offset: 0x00008914
		public bool TryGetSteamId(out ulong steamId)
		{
			steamId = 0UL;
			return false;
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0000A71C File Offset: 0x0000891C
		public IPAddress GetAddress()
		{
			if (!this.wasClosed)
			{
				IPEndPoint ipendPoint = this.clientSocket.RemoteEndPoint as IPEndPoint;
				if (ipendPoint != null)
				{
					return ipendPoint.Address;
				}
			}
			return null;
		}

		// Token: 0x0600027A RID: 634 RVA: 0x0000A750 File Offset: 0x00008950
		public string GetAddressString(bool withPort)
		{
			if (!this.wasClosed)
			{
				IPEndPoint ipendPoint = this.clientSocket.RemoteEndPoint as IPEndPoint;
				if (ipendPoint != null)
				{
					string text = ipendPoint.Address.ToString();
					if (withPort)
					{
						text += ":";
						text += ipendPoint.Port.ToString();
					}
					return text;
				}
			}
			return null;
		}

		// Token: 0x0600027B RID: 635 RVA: 0x0000A7AC File Offset: 0x000089AC
		public void CloseConnection()
		{
			this.serverTransport.CloseConnection(this);
		}

		// Token: 0x0600027C RID: 636 RVA: 0x0000A7BA File Offset: 0x000089BA
		public void Send(byte[] buffer, long size, ENetReliability reliability)
		{
			if (this.wasClosed)
			{
				return;
			}
			this.messageQueue.SendMessage(this.clientSocket, buffer, (int)size);
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000A7D9 File Offset: 0x000089D9
		bool IEquatable<ITransportConnection>.Equals(ITransportConnection other)
		{
			return this == other;
		}

		// Token: 0x0600027E RID: 638 RVA: 0x0000A7DF File Offset: 0x000089DF
		public override int GetHashCode()
		{
			return this.clientSocket.GetHashCode();
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0000A7EC File Offset: 0x000089EC
		public override string ToString()
		{
			if (this.wasClosed)
			{
				return "Closed Socket";
			}
			if (this.clientSocket.RemoteEndPoint == null)
			{
				return "Invalid Socket";
			}
			return this.clientSocket.RemoteEndPoint.ToString();
		}

		// Token: 0x0400013A RID: 314
		public ServerTransport_SystemSockets serverTransport;

		// Token: 0x0400013B RID: 315
		public Socket clientSocket;

		// Token: 0x0400013C RID: 316
		public SocketMessageLayer messageQueue = new SocketMessageLayer();

		// Token: 0x0400013D RID: 317
		internal bool wasClosed;
	}
}
