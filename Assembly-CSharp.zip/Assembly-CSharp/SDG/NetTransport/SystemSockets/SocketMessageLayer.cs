﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;

namespace SDG.NetTransport.SystemSockets
{
	/// <summary>
	/// Implements message boundaries on top of a TCP stream socket.
	/// </summary>
	// Token: 0x0200006C RID: 108
	internal class SocketMessageLayer
	{
		// Token: 0x0600026E RID: 622 RVA: 0x0000A43C File Offset: 0x0000863C
		public void SendMessage(Socket socket, byte[] buffer, int size)
		{
			SocketMessageLayer.sizeBuffer[0] = (byte)(size >> 8 & 255);
			SocketMessageLayer.sizeBuffer[1] = (byte)(size & 255);
			socket.Send(SocketMessageLayer.sizeBuffer);
			SocketError socketError;
			socket.Send(buffer, 0, size, SocketFlags.None, out socketError);
		}

		// Token: 0x0600026F RID: 623 RVA: 0x0000A484 File Offset: 0x00008684
		public void ReceiveMessages(Socket socket)
		{
			if (socket.Available < 1)
			{
				return;
			}
			SocketError socketError;
			int num = socket.Receive(SocketMessageLayer.internalBuffer, 0, SocketMessageLayer.internalBuffer.Length, SocketFlags.None, out socketError);
			if (socketError == SocketError.WouldBlock)
			{
				return;
			}
			if (socketError != SocketError.Success)
			{
				return;
			}
			if (num < 1)
			{
				return;
			}
			int i = 0;
			while (i < num)
			{
				if (this.pendingMessage == null)
				{
					if (this.pendingMessageSizeParts < 2)
					{
						int num2 = this.pendingMessageSizeParts;
						if (num2 != 0)
						{
							if (num2 == 1)
							{
								this.pendingMessageTotalSize += (int)SocketMessageLayer.internalBuffer[i];
							}
						}
						else
						{
							this.pendingMessageTotalSize += (int)SocketMessageLayer.internalBuffer[i] << 8;
						}
						this.pendingMessageSizeParts++;
						i++;
					}
					else
					{
						this.pendingMessage = new byte[this.pendingMessageTotalSize];
						this.pendingMessageOffset = 0;
					}
				}
				else
				{
					int num3 = num - i;
					int num4 = this.pendingMessage.Length - this.pendingMessageOffset;
					if (num3 < num4)
					{
						Array.Copy(SocketMessageLayer.internalBuffer, i, this.pendingMessage, this.pendingMessageOffset, num3);
						this.pendingMessageOffset += num3;
						i += num3;
					}
					else
					{
						Array.Copy(SocketMessageLayer.internalBuffer, i, this.pendingMessage, this.pendingMessageOffset, num4);
						i += num4;
						this.messageQueue.Enqueue(this.pendingMessage);
						this.pendingMessage = null;
						this.pendingMessageTotalSize = 0;
						this.pendingMessageSizeParts = 0;
					}
				}
			}
		}

		// Token: 0x06000270 RID: 624 RVA: 0x0000A5E2 File Offset: 0x000087E2
		public bool DequeueMessage(out byte[] buffer)
		{
			if (this.messageQueue.Count > 0)
			{
				buffer = this.messageQueue.Dequeue();
				return true;
			}
			buffer = null;
			return false;
		}

		// Token: 0x04000133 RID: 307
		private static byte[] sizeBuffer = new byte[2];

		// Token: 0x04000134 RID: 308
		private static byte[] internalBuffer = new byte[1200];

		// Token: 0x04000135 RID: 309
		private Queue<byte[]> messageQueue = new Queue<byte[]>();

		// Token: 0x04000136 RID: 310
		private byte[] pendingMessage;

		// Token: 0x04000137 RID: 311
		private int pendingMessageTotalSize;

		// Token: 0x04000138 RID: 312
		private int pendingMessageSizeParts;

		// Token: 0x04000139 RID: 313
		private int pendingMessageOffset;
	}
}
