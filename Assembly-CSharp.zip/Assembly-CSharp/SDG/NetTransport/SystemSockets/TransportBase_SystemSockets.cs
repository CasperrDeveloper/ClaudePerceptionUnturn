﻿using System;
using System.Diagnostics;
using SDG.Unturned;

namespace SDG.NetTransport.SystemSockets
{
	// Token: 0x0200006D RID: 109
	public abstract class TransportBase_SystemSockets
	{
		// Token: 0x06000273 RID: 627 RVA: 0x0000A634 File Offset: 0x00008834
		[Conditional("LOG_NETTRANSPORT_SYSTEMSOCKETS")]
		internal static void Log(string format, params object[] args)
		{
			UnturnedLog.info(format, args);
		}
	}
}
