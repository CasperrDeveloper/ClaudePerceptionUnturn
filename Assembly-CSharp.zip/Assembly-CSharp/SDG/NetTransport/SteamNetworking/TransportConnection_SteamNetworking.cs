﻿using System;
using System.Net;
using SDG.Unturned;
using Steamworks;

namespace SDG.NetTransport.SteamNetworking
{
	// Token: 0x02000076 RID: 118
	internal struct TransportConnection_SteamNetworking : ITransportConnection, IEquatable<ITransportConnection>
	{
		// Token: 0x060002D6 RID: 726 RVA: 0x0000C527 File Offset: 0x0000A727
		public TransportConnection_SteamNetworking(CSteamID steamId)
		{
			this.steamId = steamId;
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x0000C530 File Offset: 0x0000A730
		public bool TryGetIPv4Address(out uint address)
		{
			P2PSessionState_t p2PSessionState_t;
			if (SteamGameServerNetworking.GetP2PSessionState(this.steamId, out p2PSessionState_t) && p2PSessionState_t.m_bUsingRelay == 0)
			{
				address = p2PSessionState_t.m_nRemoteIP;
				return true;
			}
			address = 0U;
			return false;
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x0000C564 File Offset: 0x0000A764
		public bool TryGetPort(out ushort port)
		{
			P2PSessionState_t p2PSessionState_t;
			if (SteamGameServerNetworking.GetP2PSessionState(this.steamId, out p2PSessionState_t) && p2PSessionState_t.m_bUsingRelay == 0)
			{
				port = p2PSessionState_t.m_nRemotePort;
				return true;
			}
			port = 0;
			return false;
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x0000C596 File Offset: 0x0000A796
		public bool TryGetSteamId(out ulong steamId)
		{
			steamId = this.steamId.m_SteamID;
			return steamId > 0UL;
		}

		// Token: 0x060002DA RID: 730 RVA: 0x0000C5AC File Offset: 0x0000A7AC
		public IPAddress GetAddress()
		{
			P2PSessionState_t p2PSessionState_t;
			if (SteamGameServerNetworking.GetP2PSessionState(this.steamId, out p2PSessionState_t) && p2PSessionState_t.m_bUsingRelay == 0)
			{
				return new IPAddress((long)((ulong)p2PSessionState_t.m_nRemoteIP));
			}
			return null;
		}

		// Token: 0x060002DB RID: 731 RVA: 0x0000C5E0 File Offset: 0x0000A7E0
		public string GetAddressString(bool withPort)
		{
			P2PSessionState_t p2PSessionState_t;
			if (SteamGameServerNetworking.GetP2PSessionState(this.steamId, out p2PSessionState_t) && p2PSessionState_t.m_bUsingRelay == 0)
			{
				string text = Parser.getIPFromUInt32(p2PSessionState_t.m_nRemoteIP);
				if (withPort)
				{
					text += ":";
					text += p2PSessionState_t.m_nRemotePort.ToString();
				}
				return text;
			}
			return null;
		}

		// Token: 0x060002DC RID: 732 RVA: 0x0000C635 File Offset: 0x0000A835
		public void CloseConnection()
		{
			SteamGameServerNetworking.CloseP2PSessionWithUser(this.steamId);
		}

		// Token: 0x060002DD RID: 733 RVA: 0x0000C644 File Offset: 0x0000A844
		public void Send(byte[] buffer, long size, ENetReliability reliability)
		{
			if (Provider.shouldNetIgnoreSteamId(this.steamId))
			{
				return;
			}
			EP2PSend eP2PSendType;
			if (reliability != ENetReliability.Reliable)
			{
				if (reliability != ENetReliability.Unreliable)
				{
				}
				eP2PSendType = EP2PSend.k_EP2PSendUnreliable;
			}
			else
			{
				eP2PSendType = EP2PSend.k_EP2PSendReliableWithBuffering;
			}
			SteamGameServerNetworking.SendP2PPacket(this.steamId, buffer, (uint)size, eP2PSendType, 0);
		}

		// Token: 0x060002DE RID: 734 RVA: 0x0000C67F File Offset: 0x0000A87F
		public override bool Equals(object obj)
		{
			return obj is TransportConnection_SteamNetworking && this.steamId == ((TransportConnection_SteamNetworking)obj).steamId;
		}

		// Token: 0x060002DF RID: 735 RVA: 0x0000C6A1 File Offset: 0x0000A8A1
		public bool Equals(TransportConnection_SteamNetworking other)
		{
			return this.steamId == other.steamId;
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x0000C6B4 File Offset: 0x0000A8B4
		public bool Equals(ITransportConnection other)
		{
			return other is TransportConnection_SteamNetworking && this.steamId == ((TransportConnection_SteamNetworking)other).steamId;
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x0000C6D6 File Offset: 0x0000A8D6
		public override int GetHashCode()
		{
			return this.steamId.GetHashCode();
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x0000C6E9 File Offset: 0x0000A8E9
		public override string ToString()
		{
			return this.steamId.ToString();
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x0000C6FC File Offset: 0x0000A8FC
		public static implicit operator CSteamID(TransportConnection_SteamNetworking clientId)
		{
			return clientId.steamId;
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x0000C704 File Offset: 0x0000A904
		public static bool operator ==(TransportConnection_SteamNetworking lhs, TransportConnection_SteamNetworking rhs)
		{
			return lhs.Equals(rhs);
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x0000C70E File Offset: 0x0000A90E
		public static bool operator !=(TransportConnection_SteamNetworking lhs, TransportConnection_SteamNetworking rhs)
		{
			return !(lhs == rhs);
		}

		// Token: 0x04000162 RID: 354
		public CSteamID steamId;
	}
}
