﻿using System;
using SDG.Unturned;
using Steamworks;

namespace SDG.NetTransport.SteamNetworking
{
	/// <summary>
	/// SteamNetworking is deprecated.
	/// </summary>
	// Token: 0x02000074 RID: 116
	public class ServerTransport_SteamNetworking : TransportBase_SteamNetworking, IServerTransport
	{
		// Token: 0x060002CF RID: 719 RVA: 0x0000C46F File Offset: 0x0000A66F
		public void Initialize(ServerTransportConnectionFailureCallback connectionClosedCallback)
		{
			this.p2pSessionRequest = Callback<P2PSessionRequest_t>.CreateGameServer(new Callback<P2PSessionRequest_t>.DispatchDelegate(this.OnP2PSessionRequest));
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x0000C488 File Offset: 0x0000A688
		public void TearDown()
		{
			this.p2pSessionRequest.Dispose();
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x0000C498 File Offset: 0x0000A698
		public bool Receive(byte[] buffer, out long size, out ITransportConnection transportConnection)
		{
			transportConnection = null;
			size = 0L;
			int nChannel = 0;
			uint num;
			CSteamID steamId;
			if (!SteamGameServerNetworking.ReadP2PPacket(buffer, (uint)buffer.Length, out num, out steamId, nChannel))
			{
				return false;
			}
			if ((ulong)num > (ulong)((long)buffer.Length))
			{
				num = (uint)buffer.Length;
			}
			size = (long)((ulong)num);
			transportConnection = new TransportConnection_SteamNetworking(steamId);
			return true;
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x0000C4E0 File Offset: 0x0000A6E0
		private void OnP2PSessionRequest(P2PSessionRequest_t callback)
		{
			CSteamID steamIDRemote = callback.m_steamIDRemote;
			if (Provider.shouldNetIgnoreSteamId(steamIDRemote))
			{
				return;
			}
			if (!steamIDRemote.BIndividualAccount())
			{
				return;
			}
			SteamGameServerNetworking.AcceptP2PSessionWithUser(steamIDRemote);
		}

		// Token: 0x04000161 RID: 353
		private Callback<P2PSessionRequest_t> p2pSessionRequest;
	}
}
