﻿using System;
using System.Diagnostics;
using SDG.Unturned;

namespace SDG.NetTransport.SteamNetworking
{
	// Token: 0x02000075 RID: 117
	public abstract class TransportBase_SteamNetworking
	{
		// Token: 0x060002D4 RID: 724 RVA: 0x0000C516 File Offset: 0x0000A716
		[Conditional("LOG_NETTRANSPORT_STEAMNETWORKING")]
		internal static void Log(string format, params object[] args)
		{
			UnturnedLog.info(format, args);
		}
	}
}
