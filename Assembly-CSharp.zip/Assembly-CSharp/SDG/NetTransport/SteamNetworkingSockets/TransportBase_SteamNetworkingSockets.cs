﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using SDG.Unturned;
using Steamworks;

namespace SDG.NetTransport.SteamNetworkingSockets
{
	// Token: 0x02000071 RID: 113
	public abstract class TransportBase_SteamNetworkingSockets : TransportBase
	{
		/// <summary>
		/// Log verbose information that should not be included in release builds.
		/// </summary>
		// Token: 0x060002A8 RID: 680 RVA: 0x0000BCD6 File Offset: 0x00009ED6
		[Conditional("LOG_NETTRANSPORT_STEAMNETWORKINGSOCKETS")]
		internal void DebugLog(string format, params object[] args)
		{
			UnturnedLog.info(format, args);
		}

		/// <summary>
		/// Log helpful information that should be included in release builds.
		/// </summary>
		// Token: 0x060002A9 RID: 681 RVA: 0x0000BCDF File Offset: 0x00009EDF
		internal void Log(string format, params object[] args)
		{
			UnturnedLog.info(format, args);
		}

		// Token: 0x060002AA RID: 682 RVA: 0x0000BCE8 File Offset: 0x00009EE8
		internal string AddressToString(SteamNetworkingIPAddr address, bool withPort = true)
		{
			string result;
			address.ToString(out result, withPort);
			return result;
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0000BD00 File Offset: 0x00009F00
		internal string IdentityToString(SteamNetworkingIdentity identity)
		{
			string result;
			identity.ToString(out result);
			return result;
		}

		// Token: 0x060002AC RID: 684 RVA: 0x0000BD17 File Offset: 0x00009F17
		internal string IdentityToString(ref SteamNetworkingMessage_t message)
		{
			return this.IdentityToString(message.m_identityPeer);
		}

		// Token: 0x060002AD RID: 685 RVA: 0x0000BD25 File Offset: 0x00009F25
		internal string IdentityToString(ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			return this.IdentityToString(callback.m_info.m_identityRemote);
		}

		// Token: 0x060002AE RID: 686 RVA: 0x0000BD38 File Offset: 0x00009F38
		protected void DumpSteamNetworkingMessage(SteamNetworkingMessage_t message)
		{
			this.Log("Message Number {0}", new object[]
			{
				message.m_nMessageNumber
			});
			this.Log("\tData: {0}", new object[]
			{
				message.m_pData
			});
			this.Log("\tSize: {0}", new object[]
			{
				message.m_cbSize
			});
			this.Log("\tConnection: {0}", new object[]
			{
				message.m_conn
			});
			this.Log("\tPeer Identity: {0}", new object[]
			{
				this.IdentityToString(message.m_identityPeer)
			});
		}

		// Token: 0x060002AF RID: 687 RVA: 0x0000BDE4 File Offset: 0x00009FE4
		protected void LogDebugOutput()
		{
			TransportBase_SteamNetworkingSockets.DebugOutput debugOutput;
			while (this.debugOutputQueue.TryDequeue(out debugOutput))
			{
				string text;
				switch (debugOutput.type)
				{
				case ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_Bug:
					text = "Bug";
					break;
				case ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_Error:
					text = "Error";
					break;
				case ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_Important:
					text = "Important";
					break;
				case ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_Warning:
					text = "Warning";
					break;
				default:
					text = null;
					break;
				}
				if (string.IsNullOrEmpty(text))
				{
					UnturnedLog.info("SteamNetworkingSockets: " + debugOutput.message);
				}
				else
				{
					UnturnedLog.info("SteamNetworkingSockets " + text + ": " + debugOutput.message);
				}
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x0000BE82 File Offset: 0x0000A082
		internal int ReliabilityToSendFlags(ENetReliability reliability)
		{
			if (reliability == ENetReliability.Reliable || reliability != ENetReliability.Unreliable)
			{
				return 8;
			}
			return 0;
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x0000BE90 File Offset: 0x0000A090
		protected ESteamNetworkingSocketsDebugOutputType SelectDebugOutputDetailLevel()
		{
			if (TransportBase_SteamNetworkingSockets.clLogSteamNetworkingSockets.hasValue)
			{
				try
				{
					return (ESteamNetworkingSocketsDebugOutputType)TransportBase_SteamNetworkingSockets.clLogSteamNetworkingSockets.value;
				}
				catch
				{
					this.Log("Unable to match {0} with a SNS output type", new object[]
					{
						TransportBase_SteamNetworkingSockets.clLogSteamNetworkingSockets.value
					});
				}
				return ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_None;
			}
			return ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_None;
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x0000BEF0 File Offset: 0x0000A0F0
		protected virtual List<SteamNetworkingConfigValue_t> BuildDefaultConfig()
		{
			List<SteamNetworkingConfigValue_t> list = new List<SteamNetworkingConfigValue_t>();
			if (TransportBase_SteamNetworkingSockets.clAllowWithoutAuth)
			{
				SteamNetworkingConfigValue_t item = default(SteamNetworkingConfigValue_t);
				item.m_eDataType = ESteamNetworkingConfigDataType.k_ESteamNetworkingConfig_Int32;
				item.m_eValue = ESteamNetworkingConfigValue.k_ESteamNetworkingConfig_IP_AllowWithoutAuth;
				item.m_val.m_int32 = 1;
				list.Add(item);
			}
			if (TransportBase_SteamNetworkingSockets.clSendBufferSize.hasValue && TransportBase_SteamNetworkingSockets.clSendBufferSize.value > 0)
			{
				SteamNetworkingConfigValue_t item2 = default(SteamNetworkingConfigValue_t);
				item2.m_eDataType = ESteamNetworkingConfigDataType.k_ESteamNetworkingConfig_Int32;
				item2.m_eValue = ESteamNetworkingConfigValue.k_ESteamNetworkingConfig_SendBufferSize;
				item2.m_val.m_int32 = TransportBase_SteamNetworkingSockets.clSendBufferSize.value;
				list.Add(item2);
			}
			if (TransportBase_SteamNetworkingSockets.clEnableDiagnosticsUI)
			{
				SteamNetworkingConfigValue_t item3 = default(SteamNetworkingConfigValue_t);
				item3.m_eDataType = ESteamNetworkingConfigDataType.k_ESteamNetworkingConfig_Int32;
				item3.m_eValue = ESteamNetworkingConfigValue.k_ESteamNetworkingConfig_EnableDiagnosticsUI;
				item3.m_val.m_int32 = 1;
				list.Add(item3);
			}
			SteamNetworkingConfigValue_t item4 = default(SteamNetworkingConfigValue_t);
			item4.m_eDataType = ESteamNetworkingConfigDataType.k_ESteamNetworkingConfig_Int32;
			item4.m_eValue = ESteamNetworkingConfigValue.k_ESteamNetworkingConfig_TimeoutInitial;
			item4.m_val.m_int32 = 30000;
			list.Add(item4);
			SteamNetworkingConfigValue_t item5 = default(SteamNetworkingConfigValue_t);
			item5.m_eDataType = ESteamNetworkingConfigDataType.k_ESteamNetworkingConfig_Int32;
			item5.m_eValue = ESteamNetworkingConfigValue.k_ESteamNetworkingConfig_TimeoutConnected;
			item5.m_val.m_int32 = 30000;
			list.Add(item5);
			return list;
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x0000C029 File Offset: 0x0000A229
		protected FSteamNetworkingSocketsDebugOutput GetDebugOutputFunction()
		{
			this.debugOutputFunc = new FSteamNetworkingSocketsDebugOutput(this.OnDebugOutput);
			return this.debugOutputFunc;
		}

		/// <summary>
		/// This callback may be called from a service thread. It must be threadsafe and fast! Do not make any other
		/// Steamworks calls from within the handler.
		/// </summary>
		// Token: 0x060002B4 RID: 692 RVA: 0x0000C044 File Offset: 0x0000A244
		private void OnDebugOutput(ESteamNetworkingSocketsDebugOutputType nType, IntPtr pszMsg)
		{
			try
			{
				string text = InteropHelp.PtrToStringUTF8(pszMsg);
				if (!string.IsNullOrEmpty(text))
				{
					TransportBase_SteamNetworkingSockets.DebugOutput item = default(TransportBase_SteamNetworkingSockets.DebugOutput);
					item.type = nType;
					item.message = text;
					this.debugOutputQueue.Enqueue(item);
				}
			}
			catch
			{
			}
		}

		/// <summary>
		/// Should certificate authentication be disabled for UDP connections?
		/// </summary>
		// Token: 0x04000156 RID: 342
		protected static CommandLineFlag clAllowWithoutAuth = new CommandLineFlag(false, "-SNS_AllowWithoutAuth");

		/// <summary>
		/// Ensures GC does not release the delegate.
		/// </summary>
		// Token: 0x04000157 RID: 343
		private FSteamNetworkingSocketsDebugOutput debugOutputFunc;

		// Token: 0x04000158 RID: 344
		private ConcurrentQueue<TransportBase_SteamNetworkingSockets.DebugOutput> debugOutputQueue = new ConcurrentQueue<TransportBase_SteamNetworkingSockets.DebugOutput>();

		/// <summary>
		/// Does host want extra debug output?
		/// </summary>
		// Token: 0x04000159 RID: 345
		private static CommandLineInt clLogSteamNetworkingSockets = new CommandLineInt("-LogSteamNetworkingSockets");

		/// <summary>
		/// Overrides k_ESteamNetworkingConfig_SendBufferSize.
		/// </summary>
		// Token: 0x0400015A RID: 346
		private static CommandLineInt clSendBufferSize = new CommandLineInt("-SNS_SendBufferSize");

		/// <summary>
		/// Overrides k_ESteamNetworkingConfig_EnableDiagnosticsUI.
		/// </summary>
		// Token: 0x0400015B RID: 347
		private static CommandLineFlag clEnableDiagnosticsUI = new CommandLineFlag(false, "-SNS_EnableDiagnosticsUI");

		// Token: 0x020008F9 RID: 2297
		private struct DebugOutput
		{
			// Token: 0x040036B8 RID: 14008
			public ESteamNetworkingSocketsDebugOutputType type;

			// Token: 0x040036B9 RID: 14009
			public string message;
		}
	}
}
