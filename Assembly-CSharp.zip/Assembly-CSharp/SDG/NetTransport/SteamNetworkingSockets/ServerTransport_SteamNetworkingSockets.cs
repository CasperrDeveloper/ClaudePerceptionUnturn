﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using SDG.Framework.Utilities;
using SDG.Unturned;
using Steamworks;
using Unturned.SystemEx;

namespace SDG.NetTransport.SteamNetworkingSockets
{
	// Token: 0x02000070 RID: 112
	public class ServerTransport_SteamNetworkingSockets : TransportBase_SteamNetworkingSockets, IServerTransport
	{
		// Token: 0x06000298 RID: 664 RVA: 0x0000B308 File Offset: 0x00009508
		public void Initialize(ServerTransportConnectionFailureCallback connectionFailureCallback)
		{
			this.connectionFailureCallback = connectionFailureCallback;
			this.steamNetConnectionStatusChanged = Callback<SteamNetConnectionStatusChangedCallback_t>.CreateGameServer(new Callback<SteamNetConnectionStatusChangedCallback_t>.DispatchDelegate(this.OnSteamNetConnectionStatusChanged));
			this.steamNetAuthenticationStatusChanged = Callback<SteamNetAuthenticationStatus_t>.CreateGameServer(new Callback<SteamNetAuthenticationStatus_t>.DispatchDelegate(this.OnSteamNetAuthenticationStatusChanged));
			ESteamNetworkingSocketsDebugOutputType esteamNetworkingSocketsDebugOutputType = base.SelectDebugOutputDetailLevel();
			if (esteamNetworkingSocketsDebugOutputType != ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_None)
			{
				this.didSetupDebugOutput = true;
				base.Log("Server set SNS debug output detail level to {0}", new object[]
				{
					esteamNetworkingSocketsDebugOutputType
				});
				Steamworks.SteamGameServerNetworkingUtils.SetDebugOutputFunction(esteamNetworkingSocketsDebugOutputType, base.GetDebugOutputFunction());
			}
			TimeUtility.updated += this.OnUpdate;
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Combine(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
			SteamNetworkingConfigValue_t[] array = this.BuildDefaultConfig().ToArray();
			SteamNetworkingIPAddr address = default(SteamNetworkingIPAddr);
			if (string.IsNullOrEmpty(Provider.bindAddress))
			{
				address.Clear();
			}
			else if (Provider.ip > 0U)
			{
				address.SetIPv4(Provider.ip, 0);
			}
			else
			{
				base.Log("Unable to parse \"{0}\" as listen bind address", new object[]
				{
					Provider.bindAddress
				});
				address.Clear();
			}
			address.m_port = Provider.GetServerConnectionPort();
			if (ServerTransport_SteamNetworkingSockets.clUseIpSocket)
			{
				this.ipListenSocket = SteamGameServerNetworkingSockets.CreateListenSocketIP(ref address, array.Length, array);
				base.Log("Server listen socket bound to {0}", new object[]
				{
					base.AddressToString(address, true)
				});
			}
			else
			{
				base.Log("Server skipping creation of IP listen socket", Array.Empty<object>());
			}
			if (Provider.configData.Server.Use_FakeIP)
			{
				this.fakeIpListenSocket = SteamGameServerNetworkingSockets.CreateListenSocketP2PFakeIP(0, array.Length, array);
				base.Log("Server FakeIP listen socket: {0}", new object[]
				{
					this.fakeIpListenSocket
				});
				SteamNetworkingFakeIPResult_t steamNetworkingFakeIPResult_t;
				SteamGameServerNetworkingSockets.GetFakeIP(0, out steamNetworkingFakeIPResult_t);
				if (steamNetworkingFakeIPResult_t.m_eResult == EResult.k_EResultBusy)
				{
					this.steamNetworkingFakeIpResultCallback = Callback<SteamNetworkingFakeIPResult_t>.CreateGameServer(new Callback<SteamNetworkingFakeIPResult_t>.DispatchDelegate(this.OnSteamNetworkingFakeIpResultCallback));
					base.Log("Waiting for FakeIP callback...", Array.Empty<object>());
				}
				else
				{
					this.OnSteamNetworkingFakeIpResultCallback(steamNetworkingFakeIPResult_t);
				}
			}
			if (ServerTransport_SteamNetworkingSockets.clUseP2pSocket)
			{
				this.p2pListenSocket = SteamGameServerNetworkingSockets.CreateListenSocketP2P(0, array.Length, array);
				base.Log("Server P2P listen socket: {0}", new object[]
				{
					this.p2pListenSocket
				});
			}
			else
			{
				base.Log("Server skipping creation of P2P listen socket", Array.Empty<object>());
			}
			if (this.ipListenSocket == HSteamListenSocket.Invalid && this.fakeIpListenSocket == HSteamListenSocket.Invalid && this.p2pListenSocket == HSteamListenSocket.Invalid)
			{
				base.Log("SNS did not create any sockets! This will probably not work properly!", Array.Empty<object>());
			}
			this.pollGroup = SteamGameServerNetworkingSockets.CreatePollGroup();
		}

		// Token: 0x06000299 RID: 665 RVA: 0x0000B58C File Offset: 0x0000978C
		public void TearDown()
		{
			TimeUtility.updated -= this.OnUpdate;
			CommandLogMemoryUsage.OnExecuted = (Action<List<string>>)Delegate.Remove(CommandLogMemoryUsage.OnExecuted, new Action<List<string>>(this.OnLogMemoryUsage));
			this.steamNetConnectionStatusChanged.Dispose();
			this.steamNetAuthenticationStatusChanged.Dispose();
			Callback<SteamNetworkingFakeIPResult_t> callback = this.steamNetworkingFakeIpResultCallback;
			if (callback != null)
			{
				callback.Dispose();
			}
			if (this.ipListenSocket != HSteamListenSocket.Invalid && !SteamGameServerNetworkingSockets.CloseListenSocket(this.ipListenSocket))
			{
				base.Log("Server failed to close IP listen socket {0}", new object[]
				{
					this.ipListenSocket
				});
			}
			if (this.fakeIpListenSocket != HSteamListenSocket.Invalid)
			{
				bool flag = SteamGameServerNetworkingSockets.CloseListenSocket(this.fakeIpListenSocket);
				if (!flag)
				{
					base.Log("Server failed to close \"Fake IP\" listen socket {0}", new object[]
					{
						flag
					});
				}
			}
			if (this.p2pListenSocket != HSteamListenSocket.Invalid && !SteamGameServerNetworkingSockets.CloseListenSocket(this.p2pListenSocket))
			{
				base.Log("Server failed to close P2P listen socket {0}", new object[]
				{
					this.p2pListenSocket
				});
			}
			if (!SteamGameServerNetworkingSockets.DestroyPollGroup(this.pollGroup))
			{
				base.Log("Server failed to destroy poll group {0}", new object[]
				{
					this.pollGroup
				});
			}
			if (this.didSetupDebugOutput)
			{
				this.didSetupDebugOutput = false;
				Steamworks.SteamGameServerNetworkingUtils.SetDebugOutputFunction(ESteamNetworkingSocketsDebugOutputType.k_ESteamNetworkingSocketsDebugOutputType_None, null);
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0000B6EC File Offset: 0x000098EC
		public bool Receive(byte[] buffer, out long size, out ITransportConnection transportConnection)
		{
			while (SteamGameServerNetworkingSockets.ReceiveMessagesOnPollGroup(this.pollGroup, this.messageAddresses, this.messageAddresses.Length) >= 1)
			{
				IntPtr intPtr = this.messageAddresses[0];
				SteamNetworkingMessage_t steamNetworkingMessage_t = Marshal.PtrToStructure<SteamNetworkingMessage_t>(intPtr);
				if (steamNetworkingMessage_t.m_pData == IntPtr.Zero || steamNetworkingMessage_t.m_cbSize < 1)
				{
					SteamNetworkingMessage_t.Release(intPtr);
				}
				else
				{
					TransportConnection_SteamNetworkingSockets transportConnection_SteamNetworkingSockets = this.FindConnection(steamNetworkingMessage_t.m_conn);
					if (transportConnection_SteamNetworkingSockets != null && !transportConnection_SteamNetworkingSockets.wasClosed)
					{
						transportConnection = transportConnection_SteamNetworkingSockets;
						size = (long)steamNetworkingMessage_t.m_cbSize;
						if (size > (long)buffer.Length)
						{
							size = (long)buffer.Length;
						}
						Marshal.Copy(steamNetworkingMessage_t.m_pData, buffer, 0, (int)size);
						SteamNetworkingMessage_t.Release(intPtr);
						return true;
					}
					SteamNetworkingMessage_t.Release(intPtr);
				}
			}
			size = 0L;
			transportConnection = null;
			return false;
		}

		// Token: 0x0600029B RID: 667 RVA: 0x0000B7A5 File Offset: 0x000099A5
		internal void CloseConnection(TransportConnection_SteamNetworkingSockets transportConnection)
		{
			if (transportConnection.wasClosed)
			{
				return;
			}
			transportConnection.wasClosed = true;
			SteamGameServerNetworkingSockets.CloseConnection(transportConnection.steamConnectionHandle, 0, null, true);
			this.transportConnections.RemoveFast(transportConnection);
		}

		/// <summary>
		/// Find game connection associated with Steam connection.
		/// </summary>
		// Token: 0x0600029C RID: 668 RVA: 0x0000B7D4 File Offset: 0x000099D4
		private TransportConnection_SteamNetworkingSockets FindConnection(HSteamNetConnection steamConnectionHandle)
		{
			foreach (TransportConnection_SteamNetworkingSockets transportConnection_SteamNetworkingSockets in this.transportConnections)
			{
				if (transportConnection_SteamNetworkingSockets.steamConnectionHandle == steamConnectionHandle)
				{
					return transportConnection_SteamNetworkingSockets;
				}
			}
			return null;
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0000B838 File Offset: 0x00009A38
		private void OnUpdate()
		{
			base.LogDebugOutput();
		}

		// Token: 0x0600029E RID: 670 RVA: 0x0000B840 File Offset: 0x00009A40
		private void OnLogMemoryUsage(List<string> results)
		{
			results.Add(string.Format("Steam networking sockets transport connections: {0}", this.transportConnections.Count));
		}

		// Token: 0x0600029F RID: 671 RVA: 0x0000B864 File Offset: 0x00009A64
		private void OnSteamNetworkingFakeIpResultCallback(SteamNetworkingFakeIPResult_t callback)
		{
			if (callback.m_eResult == EResult.k_EResultOK)
			{
				CommandWindow.Log("//////////////////////////////////////////////////////");
				Local localization = Provider.localization;
				string arg = new IPv4Address(callback.m_unIP).ToString();
				string arg2 = string.Format("{0}:{1}", arg, callback.m_unPorts[0]);
				CommandWindow.Log(localization.format("FakeIPHeader", arg2));
				CommandWindow.Log(localization.format("FakeIPDetails"));
				CommandWindow.Log(localization.format("FakeIPCopy", "CopyFakeIP"));
				CommandWindow.Log("//////////////////////////////////////////////////////");
				return;
			}
			CommandWindow.LogError(string.Format("Fatal FakeIP result: {0}", callback.m_eResult));
			Provider.QuitGame(string.Format("fatal fake IP result ({0})", callback.m_eResult));
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x0000B934 File Offset: 0x00009B34
		private void OnSteamNetConnectionStatusChanged(SteamNetConnectionStatusChangedCallback_t callback)
		{
			switch (callback.m_info.m_eState)
			{
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_None:
				return;
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_Connecting:
				this.HandleState_Connecting(ref callback);
				return;
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_FindingRoute:
				return;
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_Connected:
				this.HandleState_Connected(ref callback);
				return;
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_ClosedByPeer:
				this.HandleState_ClosedByPeer(ref callback);
				return;
			case ESteamNetworkingConnectionState.k_ESteamNetworkingConnectionState_ProblemDetectedLocally:
				this.HandleState_ProblemDetectedLocally(ref callback);
				return;
			default:
				return;
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x0000B994 File Offset: 0x00009B94
		private void HandleState_Connecting(ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			if (Provider.didServerShutdownTimerReachZero)
			{
				if (!SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 1002, null, false))
				{
					base.Log("Server failed to close connecting connection while shutdown from {0} (End Reason: {1})", new object[]
					{
						base.IdentityToString(ref callback),
						1002
					});
					return;
				}
			}
			else if (Provider.hasRoomForNewConnection)
			{
				ulong steamID = callback.m_info.m_identityRemote.GetSteamID64();
				if (steamID == 0UL || Provider.shouldNetIgnoreSteamId(new CSteamID(steamID)))
				{
					if (!SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 1003, null, false))
					{
						base.Log("Server failed to close connecting connection from {0} (blocked) (End Reason: {1})", new object[]
						{
							base.IdentityToString(ref callback),
							1003
						});
						return;
					}
				}
				else
				{
					bool flag = SteamGameServerNetworkingSockets.SetConnectionPollGroup(callback.m_hConn, this.pollGroup);
					EResult eresult = SteamGameServerNetworkingSockets.AcceptConnection(callback.m_hConn);
					if (!flag || eresult != EResult.k_EResultOK)
					{
						SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 0, null, false);
						return;
					}
				}
			}
			else if (!SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 1001, null, false))
			{
				base.Log("Server failed to close connecting connection from {0} (End Reason: {1})", new object[]
				{
					base.IdentityToString(ref callback),
					1001
				});
			}
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x0000BAC8 File Offset: 0x00009CC8
		private void HandleState_Connected(ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			TransportConnection_SteamNetworkingSockets item = new TransportConnection_SteamNetworkingSockets(this, ref callback);
			this.transportConnections.Add(item);
		}

		/// <summary>
		/// Must close the handle to free up resources.
		/// </summary>
		// Token: 0x060002A3 RID: 675 RVA: 0x0000BAEC File Offset: 0x00009CEC
		private void HandleState_ClosedByPeer(ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			TransportConnection_SteamNetworkingSockets transportConnection_SteamNetworkingSockets = this.FindConnection(callback.m_hConn);
			if (transportConnection_SteamNetworkingSockets != null)
			{
				try
				{
					string debugString = string.Format("ClosedByPeer Reason: {0} Message: \"{1}\"", callback.m_info.m_eEndReason, callback.m_info.m_szEndDebug);
					bool isError = callback.m_info.m_eEndReason != 1000;
					this.connectionFailureCallback(transportConnection_SteamNetworkingSockets, debugString, isError);
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e, "SteamNetworkingSockets caught exception during closed by peer failure callback:");
				}
				transportConnection_SteamNetworkingSockets.CloseConnection();
				return;
			}
			SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 0, null, false);
		}

		/// <summary>
		/// Must close the handle to free up resources.
		/// </summary>
		// Token: 0x060002A4 RID: 676 RVA: 0x0000BB88 File Offset: 0x00009D88
		private void HandleState_ProblemDetectedLocally(ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			TransportConnection_SteamNetworkingSockets transportConnection_SteamNetworkingSockets = this.FindConnection(callback.m_hConn);
			if (transportConnection_SteamNetworkingSockets != null)
			{
				try
				{
					string debugString = string.Format("ProblemDetectedLocally Reason: {0} Message: \"{1}\"", callback.m_info.m_eEndReason, callback.m_info.m_szEndDebug);
					this.connectionFailureCallback(transportConnection_SteamNetworkingSockets, debugString, true);
				}
				catch (Exception e)
				{
					UnturnedLog.exception(e, "SteamNetworkingSockets caught exception during problem detected locally failure callback:");
				}
				transportConnection_SteamNetworkingSockets.CloseConnection();
				return;
			}
			SteamGameServerNetworkingSockets.CloseConnection(callback.m_hConn, 0, null, false);
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x0000BC10 File Offset: 0x00009E10
		private void OnSteamNetAuthenticationStatusChanged(SteamNetAuthenticationStatus_t callback)
		{
			if (string.IsNullOrEmpty(callback.m_debugMsg))
			{
				base.Log("Readiness to participate in authenticated communications changed to {0}", new object[]
				{
					callback.m_eAvail
				});
				return;
			}
			base.Log("Readiness to participate in authenticated communications changed to {0} \"{1}\"", new object[]
			{
				callback.m_eAvail,
				callback.m_debugMsg
			});
		}

		// Token: 0x04000149 RID: 329
		private Callback<SteamNetworkingFakeIPResult_t> steamNetworkingFakeIpResultCallback;

		// Token: 0x0400014A RID: 330
		private Callback<SteamNetConnectionStatusChangedCallback_t> steamNetConnectionStatusChanged;

		// Token: 0x0400014B RID: 331
		private Callback<SteamNetAuthenticationStatus_t> steamNetAuthenticationStatusChanged;

		// Token: 0x0400014C RID: 332
		private ServerTransportConnectionFailureCallback connectionFailureCallback;

		// Token: 0x0400014D RID: 333
		private HSteamListenSocket ipListenSocket = HSteamListenSocket.Invalid;

		// Token: 0x0400014E RID: 334
		private HSteamListenSocket fakeIpListenSocket = HSteamListenSocket.Invalid;

		// Token: 0x0400014F RID: 335
		private HSteamListenSocket p2pListenSocket = HSteamListenSocket.Invalid;

		// Token: 0x04000150 RID: 336
		private HSteamNetPollGroup pollGroup;

		// Token: 0x04000151 RID: 337
		private List<TransportConnection_SteamNetworkingSockets> transportConnections = new List<TransportConnection_SteamNetworkingSockets>();

		// Token: 0x04000152 RID: 338
		private IntPtr[] messageAddresses = new IntPtr[1];

		// Token: 0x04000153 RID: 339
		private bool didSetupDebugOutput;

		/// <summary>
		/// Defaults to true. If false, skip Steam Networking Sockets creation of regular IP socket.
		/// </summary>
		// Token: 0x04000154 RID: 340
		private static CommandLineFlag clUseIpSocket = new CommandLineFlag(true, "-SNS_DisableIPSocket");

		/// <summary>
		/// Defaults to true. If false, skip Steam Networking Sockets creation of non-FakeIP P2P socket.
		/// (this is the socket used by "server codes")
		/// </summary>
		// Token: 0x04000155 RID: 341
		private static CommandLineFlag clUseP2pSocket = new CommandLineFlag(true, "-SNS_DisableP2PSocket");
	}
}
