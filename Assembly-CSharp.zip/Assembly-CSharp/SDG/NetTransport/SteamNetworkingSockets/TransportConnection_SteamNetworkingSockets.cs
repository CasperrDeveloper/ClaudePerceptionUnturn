﻿using System;
using System.Net;
using Steamworks;

namespace SDG.NetTransport.SteamNetworkingSockets
{
	/// <summary>
	/// Implementing as a struct wrapping the connection handle would remove the cost of looking up the connection,
	/// but implementing as a class makes it cheap to cache information like the remote identity.
	/// </summary>
	// Token: 0x02000072 RID: 114
	internal class TransportConnection_SteamNetworkingSockets : ITransportConnection, IEquatable<ITransportConnection>
	{
		// Token: 0x060002B7 RID: 695 RVA: 0x0000C0EF File Offset: 0x0000A2EF
		public TransportConnection_SteamNetworkingSockets(ServerTransport_SteamNetworkingSockets serverTransport, ref SteamNetConnectionStatusChangedCallback_t callback)
		{
			this.serverTransport = serverTransport;
			this.steamConnectionHandle = callback.m_hConn;
			this.steamIdentity = callback.m_info.m_identityRemote;
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x0000C11C File Offset: 0x0000A31C
		public bool TryGetIPv4Address(out uint address)
		{
			SteamNetConnectionInfo_t steamNetConnectionInfo_t;
			if (SteamGameServerNetworkingSockets.GetConnectionInfo(this.steamConnectionHandle, out steamNetConnectionInfo_t))
			{
				address = steamNetConnectionInfo_t.m_addrRemote.GetIPv4();
				return address > 0U;
			}
			address = 0U;
			return false;
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x0000C150 File Offset: 0x0000A350
		public bool TryGetPort(out ushort port)
		{
			SteamNetConnectionInfo_t steamNetConnectionInfo_t;
			if (SteamGameServerNetworkingSockets.GetConnectionInfo(this.steamConnectionHandle, out steamNetConnectionInfo_t))
			{
				port = steamNetConnectionInfo_t.m_addrRemote.m_port;
				return port > 0;
			}
			port = 0;
			return false;
		}

		// Token: 0x060002BA RID: 698 RVA: 0x0000C184 File Offset: 0x0000A384
		public bool TryGetSteamId(out ulong steamId)
		{
			SteamNetConnectionInfo_t steamNetConnectionInfo_t;
			if (SteamGameServerNetworkingSockets.GetConnectionInfo(this.steamConnectionHandle, out steamNetConnectionInfo_t))
			{
				steamId = steamNetConnectionInfo_t.m_identityRemote.GetSteamID64();
				return steamId > 0UL;
			}
			steamId = 0UL;
			return false;
		}

		// Token: 0x060002BB RID: 699 RVA: 0x0000C1BC File Offset: 0x0000A3BC
		public IPAddress GetAddress()
		{
			SteamNetConnectionInfo_t steamNetConnectionInfo_t;
			if (SteamGameServerNetworkingSockets.GetConnectionInfo(this.steamConnectionHandle, out steamNetConnectionInfo_t))
			{
				return new IPAddress(steamNetConnectionInfo_t.m_addrRemote.m_ipv6);
			}
			return null;
		}

		// Token: 0x060002BC RID: 700 RVA: 0x0000C1EC File Offset: 0x0000A3EC
		public string GetAddressString(bool withPort)
		{
			SteamNetConnectionInfo_t steamNetConnectionInfo_t;
			if (SteamGameServerNetworkingSockets.GetConnectionInfo(this.steamConnectionHandle, out steamNetConnectionInfo_t))
			{
				string result;
				steamNetConnectionInfo_t.m_addrRemote.ToString(out result, withPort);
				return result;
			}
			return null;
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0000C21A File Offset: 0x0000A41A
		public override bool Equals(object obj)
		{
			return this.Equals(obj as TransportConnection_SteamNetworkingSockets);
		}

		// Token: 0x060002BE RID: 702 RVA: 0x0000C228 File Offset: 0x0000A428
		public bool Equals(TransportConnection_SteamNetworkingSockets other)
		{
			return other != null && this.steamConnectionHandle == other.steamConnectionHandle;
		}

		// Token: 0x060002BF RID: 703 RVA: 0x0000C240 File Offset: 0x0000A440
		public bool Equals(ITransportConnection other)
		{
			return this.Equals(other as TransportConnection_SteamNetworkingSockets);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x0000C24E File Offset: 0x0000A44E
		public override int GetHashCode()
		{
			return this.steamConnectionHandle.GetHashCode();
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x0000C261 File Offset: 0x0000A461
		public override string ToString()
		{
			return this.serverTransport.IdentityToString(this.steamIdentity);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x0000C274 File Offset: 0x0000A474
		public void CloseConnection()
		{
			this.serverTransport.CloseConnection(this);
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x0000C284 File Offset: 0x0000A484
		public unsafe void Send(byte[] buffer, long size, ENetReliability reliability)
		{
			int nSendFlags = this.serverTransport.ReliabilityToSendFlags(reliability);
			fixed (byte[] array = buffer)
			{
				byte* value;
				if (buffer == null || array.Length == 0)
				{
					value = null;
				}
				else
				{
					value = &array[0];
				}
				IntPtr pData = new IntPtr((void*)value);
				long num;
				SteamGameServerNetworkingSockets.SendMessageToConnection(this.steamConnectionHandle, pData, (uint)size, nSendFlags, out num);
			}
		}

		// Token: 0x0400015C RID: 348
		internal bool wasClosed;

		// Token: 0x0400015D RID: 349
		internal HSteamNetConnection steamConnectionHandle;

		// Token: 0x0400015E RID: 350
		internal SteamNetworkingIdentity steamIdentity;

		// Token: 0x0400015F RID: 351
		private ServerTransport_SteamNetworkingSockets serverTransport;
	}
}
