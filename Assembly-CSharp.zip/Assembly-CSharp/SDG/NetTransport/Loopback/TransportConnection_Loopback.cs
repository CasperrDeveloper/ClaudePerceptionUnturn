﻿using System;
using System.Net;

namespace SDG.NetTransport.Loopback
{
	/// <summary>
	/// Dummy connection used in singleplayer.
	/// </summary>
	// Token: 0x02000077 RID: 119
	public struct TransportConnection_Loopback : ITransportConnection, IEquatable<ITransportConnection>
	{
		// Token: 0x060002E6 RID: 742 RVA: 0x0000C71A File Offset: 0x0000A91A
		public static TransportConnection_Loopback Create()
		{
			return new TransportConnection_Loopback(++TransportConnection_Loopback.counter);
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x0000C72E File Offset: 0x0000A92E
		public bool TryGetIPv4Address(out uint address)
		{
			address = 0U;
			return false;
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x0000C734 File Offset: 0x0000A934
		public bool TryGetPort(out ushort port)
		{
			port = 0;
			return false;
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x0000C73A File Offset: 0x0000A93A
		public bool TryGetSteamId(out ulong steamId)
		{
			steamId = 0UL;
			return false;
		}

		// Token: 0x060002EA RID: 746 RVA: 0x0000C741 File Offset: 0x0000A941
		public IPAddress GetAddress()
		{
			return null;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x0000C744 File Offset: 0x0000A944
		public string GetAddressString(bool withPort)
		{
			return null;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x0000C747 File Offset: 0x0000A947
		public void CloseConnection()
		{
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0000C749 File Offset: 0x0000A949
		public void Send(byte[] buffer, long size, ENetReliability reliability)
		{
			throw new NotSupportedException();
		}

		// Token: 0x060002EE RID: 750 RVA: 0x0000C750 File Offset: 0x0000A950
		public override bool Equals(object obj)
		{
			return obj is TransportConnection_Loopback && this.id == ((TransportConnection_Loopback)obj).id;
		}

		// Token: 0x060002EF RID: 751 RVA: 0x0000C76F File Offset: 0x0000A96F
		public bool Equals(TransportConnection_Loopback other)
		{
			return this.id == other.id;
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x0000C77F File Offset: 0x0000A97F
		public bool Equals(ITransportConnection other)
		{
			return other is TransportConnection_Loopback && this.id == ((TransportConnection_Loopback)other).id;
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x0000C79E File Offset: 0x0000A99E
		public override int GetHashCode()
		{
			return this.id.GetHashCode();
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x0000C7AB File Offset: 0x0000A9AB
		public override string ToString()
		{
			if (this == TransportConnection_Loopback.DedicatedServerLoopback)
			{
				return "DedicatedServerLoopback";
			}
			return string.Format("Loopback_{0}", this.id.ToString());
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x0000C7DA File Offset: 0x0000A9DA
		public static bool operator ==(TransportConnection_Loopback lhs, TransportConnection_Loopback rhs)
		{
			return lhs.Equals(rhs);
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x0000C7E4 File Offset: 0x0000A9E4
		public static bool operator !=(TransportConnection_Loopback lhs, TransportConnection_Loopback rhs)
		{
			return !(lhs == rhs);
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x0000C7F0 File Offset: 0x0000A9F0
		private TransportConnection_Loopback(int id)
		{
			this.id = id;
		}

		// Token: 0x04000163 RID: 355
		public static readonly ITransportConnection DedicatedServer = TransportConnection_Loopback.DedicatedServerLoopback;

		// Token: 0x04000164 RID: 356
		private int id;

		// Token: 0x04000165 RID: 357
		private static int counter;

		// Token: 0x04000166 RID: 358
		private static readonly TransportConnection_Loopback DedicatedServerLoopback = TransportConnection_Loopback.Create();
	}
}
