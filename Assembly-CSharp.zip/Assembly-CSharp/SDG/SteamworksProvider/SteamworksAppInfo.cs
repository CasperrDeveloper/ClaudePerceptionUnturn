﻿using System;

namespace SDG.SteamworksProvider
{
	// Token: 0x02000016 RID: 22
	public class SteamworksAppInfo
	{
		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000058 RID: 88 RVA: 0x00003A34 File Offset: 0x00001C34
		// (set) Token: 0x06000059 RID: 89 RVA: 0x00003A3C File Offset: 0x00001C3C
		public uint id { get; protected set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600005A RID: 90 RVA: 0x00003A45 File Offset: 0x00001C45
		// (set) Token: 0x0600005B RID: 91 RVA: 0x00003A4D File Offset: 0x00001C4D
		public string name { get; protected set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600005C RID: 92 RVA: 0x00003A56 File Offset: 0x00001C56
		// (set) Token: 0x0600005D RID: 93 RVA: 0x00003A5E File Offset: 0x00001C5E
		public string version { get; protected set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600005E RID: 94 RVA: 0x00003A67 File Offset: 0x00001C67
		// (set) Token: 0x0600005F RID: 95 RVA: 0x00003A6F File Offset: 0x00001C6F
		public bool isDedicated { get; protected set; }

		// Token: 0x06000060 RID: 96 RVA: 0x00003A78 File Offset: 0x00001C78
		public SteamworksAppInfo(uint newID, string newName, string newVersion, bool newIsDedicated)
		{
			this.id = newID;
			this.name = newName;
			this.version = newVersion;
			this.isDedicated = newIsDedicated;
		}
	}
}
