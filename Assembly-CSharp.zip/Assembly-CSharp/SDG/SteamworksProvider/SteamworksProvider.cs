﻿using System;
using SDG.Provider;
using SDG.Provider.Services.Achievements;
using SDG.Provider.Services.Browser;
using SDG.Provider.Services.Cloud;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Multiplayer;
using SDG.Provider.Services.Statistics;
using SDG.Provider.Services.Store;
using SDG.Provider.Services.Translation;
using SDG.SteamworksProvider.Services.Achievements;
using SDG.SteamworksProvider.Services.Browser;
using SDG.SteamworksProvider.Services.Cloud;
using SDG.SteamworksProvider.Services.Community;
using SDG.SteamworksProvider.Services.Multiplayer;
using SDG.SteamworksProvider.Services.Statistics;
using SDG.SteamworksProvider.Services.Store;
using SDG.SteamworksProvider.Services.Translation;
using Steamworks;

namespace SDG.SteamworksProvider
{
	// Token: 0x02000017 RID: 23
	public class SteamworksProvider : IProvider
	{
		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000061 RID: 97 RVA: 0x00003A9D File Offset: 0x00001C9D
		// (set) Token: 0x06000062 RID: 98 RVA: 0x00003AA5 File Offset: 0x00001CA5
		public IAchievementsService achievementsService { get; protected set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000063 RID: 99 RVA: 0x00003AAE File Offset: 0x00001CAE
		// (set) Token: 0x06000064 RID: 100 RVA: 0x00003AB6 File Offset: 0x00001CB6
		public IBrowserService browserService { get; protected set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000065 RID: 101 RVA: 0x00003ABF File Offset: 0x00001CBF
		// (set) Token: 0x06000066 RID: 102 RVA: 0x00003AC7 File Offset: 0x00001CC7
		public ICloudService cloudService { get; protected set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000067 RID: 103 RVA: 0x00003AD0 File Offset: 0x00001CD0
		// (set) Token: 0x06000068 RID: 104 RVA: 0x00003AD8 File Offset: 0x00001CD8
		public ICommunityService communityService { get; protected set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000069 RID: 105 RVA: 0x00003AE1 File Offset: 0x00001CE1
		// (set) Token: 0x0600006A RID: 106 RVA: 0x00003AE9 File Offset: 0x00001CE9
		public TempSteamworksEconomy economyService { get; protected set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600006B RID: 107 RVA: 0x00003AF2 File Offset: 0x00001CF2
		// (set) Token: 0x0600006C RID: 108 RVA: 0x00003AFA File Offset: 0x00001CFA
		public TempSteamworksMatchmaking matchmakingService { get; protected set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600006D RID: 109 RVA: 0x00003B03 File Offset: 0x00001D03
		// (set) Token: 0x0600006E RID: 110 RVA: 0x00003B0B File Offset: 0x00001D0B
		public IMultiplayerService multiplayerService { get; protected set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600006F RID: 111 RVA: 0x00003B14 File Offset: 0x00001D14
		// (set) Token: 0x06000070 RID: 112 RVA: 0x00003B1C File Offset: 0x00001D1C
		public IStatisticsService statisticsService { get; protected set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000071 RID: 113 RVA: 0x00003B25 File Offset: 0x00001D25
		// (set) Token: 0x06000072 RID: 114 RVA: 0x00003B2D File Offset: 0x00001D2D
		public IStoreService storeService { get; protected set; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000073 RID: 115 RVA: 0x00003B36 File Offset: 0x00001D36
		// (set) Token: 0x06000074 RID: 116 RVA: 0x00003B3E File Offset: 0x00001D3E
		public ITranslationService translationService { get; protected set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000075 RID: 117 RVA: 0x00003B47 File Offset: 0x00001D47
		// (set) Token: 0x06000076 RID: 118 RVA: 0x00003B4F File Offset: 0x00001D4F
		public TempSteamworksWorkshop workshopService { get; protected set; }

		// Token: 0x06000077 RID: 119 RVA: 0x00003B58 File Offset: 0x00001D58
		public void intialize()
		{
			if (!this.appInfo.isDedicated)
			{
				if (SteamAPI.RestartAppIfNecessary((AppId_t)this.appInfo.id))
				{
					throw new Exception("Restarting app from Steam.");
				}
				if (!SteamAPI.Init())
				{
					throw new Exception("Steam API initialization failed.");
				}
			}
			this.initializeServices();
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00003BAC File Offset: 0x00001DAC
		public void update()
		{
			if (this.multiplayerService.serverMultiplayerService.isHosting)
			{
				GameServer.RunCallbacks();
			}
			if (!this.appInfo.isDedicated)
			{
				SteamAPI.RunCallbacks();
			}
			this.updateServices();
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00003BDD File Offset: 0x00001DDD
		public void shutdown()
		{
			if (!this.appInfo.isDedicated)
			{
				SteamAPI.Shutdown();
			}
			this.shutdownServices();
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00003BF8 File Offset: 0x00001DF8
		private void constructServices()
		{
			this.achievementsService = new SteamworksAchievementsService();
			this.economyService = new TempSteamworksEconomy(this.appInfo);
			this.multiplayerService = new SteamworksMultiplayerService(this.appInfo);
			this.statisticsService = new SteamworksStatisticsService();
			this.workshopService = new TempSteamworksWorkshop(this.appInfo);
			if (!this.appInfo.isDedicated)
			{
				this.browserService = new SteamworksBrowserService();
				this.cloudService = new SteamworksCloudService();
				this.communityService = new SteamworksCommunityService();
				this.matchmakingService = new TempSteamworksMatchmaking();
				this.storeService = new SteamworksStoreService(this.appInfo);
				this.translationService = new SteamworksTranslationService();
			}
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00003CA4 File Offset: 0x00001EA4
		private void initializeServices()
		{
			if (this.achievementsService != null)
			{
				this.achievementsService.initialize();
			}
			if (this.multiplayerService != null)
			{
				this.multiplayerService.initialize();
			}
			if (this.statisticsService != null)
			{
				this.statisticsService.initialize();
			}
			if (!this.appInfo.isDedicated)
			{
				if (this.browserService != null)
				{
					this.browserService.initialize();
				}
				if (this.cloudService != null)
				{
					this.cloudService.initialize();
				}
				if (this.communityService != null)
				{
					this.communityService.initialize();
				}
				if (this.economyService != null)
				{
					this.economyService.initializeClient();
				}
				if (this.storeService != null)
				{
					this.storeService.initialize();
				}
				if (this.translationService != null)
				{
					this.translationService.initialize();
				}
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00003D6C File Offset: 0x00001F6C
		private void updateServices()
		{
			if (this.achievementsService != null)
			{
				this.achievementsService.update();
			}
			if (this.multiplayerService != null)
			{
				this.multiplayerService.update();
			}
			if (this.statisticsService != null)
			{
				this.statisticsService.update();
			}
			if (this.workshopService != null)
			{
				this.workshopService.update();
			}
			if (!this.appInfo.isDedicated)
			{
				if (this.browserService != null)
				{
					this.browserService.update();
				}
				if (this.cloudService != null)
				{
					this.cloudService.update();
				}
				if (this.communityService != null)
				{
					this.communityService.update();
				}
				if (this.storeService != null)
				{
					this.storeService.update();
				}
				if (this.translationService != null)
				{
					this.translationService.update();
				}
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00003E34 File Offset: 0x00002034
		private void shutdownServices()
		{
			if (this.achievementsService != null)
			{
				this.achievementsService.shutdown();
			}
			if (this.multiplayerService != null)
			{
				this.multiplayerService.shutdown();
			}
			if (this.statisticsService != null)
			{
				this.statisticsService.shutdown();
			}
			if (!this.appInfo.isDedicated)
			{
				if (this.browserService != null)
				{
					this.browserService.shutdown();
				}
				if (this.cloudService != null)
				{
					this.cloudService.shutdown();
				}
				if (this.communityService != null)
				{
					this.communityService.shutdown();
				}
				if (this.storeService != null)
				{
					this.storeService.shutdown();
				}
				if (this.translationService != null)
				{
					this.translationService.shutdown();
				}
			}
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00003EE6 File Offset: 0x000020E6
		public SteamworksProvider(SteamworksAppInfo newAppInfo)
		{
			this.appInfo = newAppInfo;
			this.constructServices();
		}

		// Token: 0x04000054 RID: 84
		private SteamworksAppInfo appInfo;
	}
}
