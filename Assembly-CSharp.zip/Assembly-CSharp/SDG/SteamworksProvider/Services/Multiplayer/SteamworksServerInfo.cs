﻿using System;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Multiplayer;
using SDG.SteamworksProvider.Services.Community;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Multiplayer
{
	// Token: 0x02000020 RID: 32
	public class SteamworksServerInfo : IServerInfo
	{
		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000AD RID: 173 RVA: 0x00004353 File Offset: 0x00002553
		// (set) Token: 0x060000AE RID: 174 RVA: 0x0000435B File Offset: 0x0000255B
		public ICommunityEntity entity { get; protected set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000AF RID: 175 RVA: 0x00004364 File Offset: 0x00002564
		// (set) Token: 0x060000B0 RID: 176 RVA: 0x0000436C File Offset: 0x0000256C
		public string name { get; protected set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000B1 RID: 177 RVA: 0x00004375 File Offset: 0x00002575
		// (set) Token: 0x060000B2 RID: 178 RVA: 0x0000437D File Offset: 0x0000257D
		public byte players { get; protected set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000B3 RID: 179 RVA: 0x00004386 File Offset: 0x00002586
		// (set) Token: 0x060000B4 RID: 180 RVA: 0x0000438E File Offset: 0x0000258E
		public byte capacity { get; protected set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x00004397 File Offset: 0x00002597
		// (set) Token: 0x060000B6 RID: 182 RVA: 0x0000439F File Offset: 0x0000259F
		public int ping { get; protected set; }

		// Token: 0x060000B7 RID: 183 RVA: 0x000043A8 File Offset: 0x000025A8
		public SteamworksServerInfo(gameserveritem_t server)
		{
			this.entity = new SteamworksCommunityEntity(server.m_steamID);
			this.name = server.GetServerName();
			this.players = (byte)server.m_nPlayers;
			this.capacity = (byte)server.m_nMaxPlayers;
			this.ping = server.m_nPing;
		}
	}
}
