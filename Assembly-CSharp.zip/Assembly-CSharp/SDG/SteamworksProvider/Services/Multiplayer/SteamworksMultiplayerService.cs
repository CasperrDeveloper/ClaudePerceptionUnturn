﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Multiplayer;
using SDG.Provider.Services.Multiplayer.Client;
using SDG.Provider.Services.Multiplayer.Server;
using SDG.SteamworksProvider.Services.Multiplayer.Client;
using SDG.SteamworksProvider.Services.Multiplayer.Server;

namespace SDG.SteamworksProvider.Services.Multiplayer
{
	// Token: 0x0200001F RID: 31
	public class SteamworksMultiplayerService : IMultiplayerService, IService
	{
		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x0000428A File Offset: 0x0000248A
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x00004292 File Offset: 0x00002492
		public IClientMultiplayerService clientMultiplayerService { get; protected set; }

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000429B File Offset: 0x0000249B
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x000042A3 File Offset: 0x000024A3
		public IServerMultiplayerService serverMultiplayerService { get; protected set; }

		// Token: 0x060000A9 RID: 169 RVA: 0x000042AC File Offset: 0x000024AC
		public void initialize()
		{
			this.serverMultiplayerService.initialize();
			if (!this.appInfo.isDedicated)
			{
				this.clientMultiplayerService.initialize();
			}
		}

		// Token: 0x060000AA RID: 170 RVA: 0x000042D1 File Offset: 0x000024D1
		public void update()
		{
			this.serverMultiplayerService.update();
			if (!this.appInfo.isDedicated)
			{
				this.clientMultiplayerService.update();
			}
		}

		// Token: 0x060000AB RID: 171 RVA: 0x000042F6 File Offset: 0x000024F6
		public void shutdown()
		{
			this.serverMultiplayerService.shutdown();
			if (!this.appInfo.isDedicated)
			{
				this.clientMultiplayerService.shutdown();
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000431B File Offset: 0x0000251B
		public SteamworksMultiplayerService(SteamworksAppInfo newAppInfo)
		{
			this.appInfo = newAppInfo;
			this.serverMultiplayerService = new SteamworksServerMultiplayerService(this.appInfo);
			if (!this.appInfo.isDedicated)
			{
				this.clientMultiplayerService = new SteamworksClientMultiplayerService();
			}
		}

		// Token: 0x04000060 RID: 96
		private SteamworksAppInfo appInfo;
	}
}
