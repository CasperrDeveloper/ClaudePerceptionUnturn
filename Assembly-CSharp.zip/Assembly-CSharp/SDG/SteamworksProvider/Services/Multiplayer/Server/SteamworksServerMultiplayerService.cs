﻿using System;
using System.IO;
using SDG.Provider.Services;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Multiplayer;
using SDG.Provider.Services.Multiplayer.Server;
using SDG.SteamworksProvider.Services.Community;
using SDG.Unturned;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Multiplayer.Server
{
	// Token: 0x02000021 RID: 33
	public class SteamworksServerMultiplayerService : Service, IServerMultiplayerService, IService
	{
		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000B8 RID: 184 RVA: 0x00004403 File Offset: 0x00002603
		// (set) Token: 0x060000B9 RID: 185 RVA: 0x0000440B File Offset: 0x0000260B
		public IServerInfo serverInfo { get; protected set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000BA RID: 186 RVA: 0x00004414 File Offset: 0x00002614
		// (set) Token: 0x060000BB RID: 187 RVA: 0x0000441C File Offset: 0x0000261C
		public bool isHosting { get; protected set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000BC RID: 188 RVA: 0x00004425 File Offset: 0x00002625
		// (set) Token: 0x060000BD RID: 189 RVA: 0x0000442D File Offset: 0x0000262D
		public MemoryStream stream { get; protected set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000BE RID: 190 RVA: 0x00004436 File Offset: 0x00002636
		// (set) Token: 0x060000BF RID: 191 RVA: 0x0000443E File Offset: 0x0000263E
		public BinaryReader reader { get; protected set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x00004447 File Offset: 0x00002647
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x0000444F File Offset: 0x0000264F
		public BinaryWriter writer { get; protected set; }

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060000C2 RID: 194 RVA: 0x00004458 File Offset: 0x00002658
		// (remove) Token: 0x060000C3 RID: 195 RVA: 0x00004490 File Offset: 0x00002690
		public event ServerMultiplayerServiceReadyHandler ready;

		// Token: 0x060000C4 RID: 196 RVA: 0x000044C8 File Offset: 0x000026C8
		public void open(uint ip, ushort port, ESecurityMode security)
		{
			if (this.isHosting)
			{
				return;
			}
			EServerMode eServerMode = EServerMode.eServerModeInvalid;
			switch (security)
			{
			case ESecurityMode.LAN:
				eServerMode = EServerMode.eServerModeNoAuthentication;
				break;
			case ESecurityMode.SECURE:
				eServerMode = EServerMode.eServerModeAuthenticationAndSecure;
				break;
			case ESecurityMode.INSECURE:
				eServerMode = EServerMode.eServerModeAuthentication;
				break;
			}
			if (!GameServer.Init(ip, port, port, eServerMode, "1.0.0.0"))
			{
				throw new Exception("GameServer API initialization failed!");
			}
			SteamGameServer.SetDedicatedServer(this.appInfo.isDedicated);
			SteamGameServer.SetProduct(this.appInfo.name);
			SteamGameServer.SetModDir(this.appInfo.name);
			if (Provider.configData.Server.Use_FakeIP)
			{
				if (!SteamGameServerNetworkingSockets.BeginAsyncRequestFakeIP(1))
				{
					CommandWindow.LogError("Fatal: BeginAsyncRequestFakeIP returned false");
					throw new NotSupportedException("BeginAsyncRequestFakeIP returned false");
				}
				CommandWindow.Log("Requesting \"FakeIP\" from Steam");
			}
			if (SteamworksServerMultiplayerService.clShouldLogin)
			{
				string loginToken = CommandGSLT.loginToken;
				string text = (loginToken != null) ? loginToken.Trim() : null;
				if (string.IsNullOrEmpty(text))
				{
					string login_Token = Provider.configData.Browser.Login_Token;
					text = ((login_Token != null) ? login_Token.Trim() : null);
				}
				if (string.IsNullOrEmpty(text))
				{
					UnturnedLog.info("Not using login token");
					if (security != ESecurityMode.LAN)
					{
						Level.onPostLevelLoaded = (PostLevelLoaded)Delegate.Combine(Level.onPostLevelLoaded, new PostLevelLoaded(this.OnPostLevelLoaded));
					}
					SteamGameServer.LogOnAnonymous();
				}
				else
				{
					if (text.Length == 32)
					{
						UnturnedLog.info("Using login token");
					}
					else
					{
						UnturnedLog.warn("Using login token, but it does not seem to be correctly formatted");
					}
					SteamGameServer.LogOn(text);
				}
			}
			else
			{
				UnturnedLog.info("Skipping Steam game server login");
			}
			if (SteamworksServerMultiplayerService.clShouldEnableAdvertisement)
			{
				SteamGameServer.SetAdvertiseServerActive(true);
			}
			else
			{
				UnturnedLog.info("Not enabling Steam game server advertisement");
			}
			this.isHosting = true;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000465F File Offset: 0x0000285F
		public void close()
		{
			if (!this.isHosting)
			{
				return;
			}
			SteamGameServer.SetAdvertiseServerActive(false);
			SteamGameServer.LogOff();
			GameServer.Shutdown();
			this.isHosting = false;
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00004681 File Offset: 0x00002881
		public bool read(out ICommunityEntity entity, byte[] data, out ulong length, int channel)
		{
			entity = SteamworksCommunityEntity.INVALID;
			length = 0UL;
			return false;
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x00004694 File Offset: 0x00002894
		public void write(ICommunityEntity entity, byte[] data, ulong length)
		{
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00004696 File Offset: 0x00002896
		public void write(ICommunityEntity entity, byte[] data, ulong length, ESendMethod method, int channel)
		{
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00004698 File Offset: 0x00002898
		public SteamworksServerMultiplayerService(SteamworksAppInfo newAppInfo)
		{
			this.appInfo = newAppInfo;
			SteamworksServerMultiplayerService.steamServerConnectFailure = Callback<SteamServerConnectFailure_t>.CreateGameServer(new Callback<SteamServerConnectFailure_t>.DispatchDelegate(this.onSteamServerConnectFailure));
			SteamworksServerMultiplayerService.steamServersConnected = Callback<SteamServersConnected_t>.CreateGameServer(new Callback<SteamServersConnected_t>.DispatchDelegate(this.onSteamServersConnected));
			SteamworksServerMultiplayerService.steamServersDisconnected = Callback<SteamServersDisconnected_t>.CreateGameServer(new Callback<SteamServersDisconnected_t>.DispatchDelegate(this.onSteamServersDisconnected));
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000046F4 File Offset: 0x000028F4
		private void onSteamServerConnectFailure(SteamServerConnectFailure_t callback)
		{
			if (Dedicator.offlineOnly)
			{
				return;
			}
			if (callback.m_bStillRetrying)
			{
				CommandWindow.LogFormat("Failed to connect to Steam servers because {0}, still retrying", new object[]
				{
					callback.m_eResult
				});
			}
			else
			{
				CommandWindow.LogFormat("Failed to connect to Steam servers because {0}, no longer retrying", new object[]
				{
					callback.m_eResult
				});
			}
			if (callback.m_eResult == EResult.k_EResultInvalidParam || callback.m_eResult == EResult.k_EResultAccountNotFound)
			{
				CommandWindow.LogWarning(string.Format("{0} probably means Game Server Login Token (GSLT) is invalid", callback.m_eResult));
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00004781 File Offset: 0x00002981
		private void onSteamServersConnected(SteamServersConnected_t callback)
		{
			ServerMultiplayerServiceReadyHandler serverMultiplayerServiceReadyHandler = this.ready;
			if (serverMultiplayerServiceReadyHandler == null)
			{
				return;
			}
			serverMultiplayerServiceReadyHandler();
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00004793 File Offset: 0x00002993
		private void onSteamServersDisconnected(SteamServersDisconnected_t callback)
		{
			if (Dedicator.offlineOnly)
			{
				return;
			}
			CommandWindow.LogFormat("Lost connection to Steam servers because {0}", new object[]
			{
				callback.m_eResult
			});
		}

		// Token: 0x060000CD RID: 205 RVA: 0x000047C0 File Offset: 0x000029C0
		private void OnPostLevelLoaded(int id)
		{
			CommandWindow.LogWarning("Steam Game Server Login Token (GSLT) not set");
			CommandWindow.LogWarning("Without a login token the server:");
			CommandWindow.LogWarning("- Is not visible in Internet server list");
			CommandWindow.LogWarning("- Cannot be joined over the Internet");
			CommandWindow.LogWarning("See this link for guide and more information:");
			CommandWindow.LogWarning("https://docs.smartlydressedgames.com/en/stable/servers/game-server-login-tokens.html");
		}

		// Token: 0x0400006C RID: 108
		private SteamworksAppInfo appInfo;

		// Token: 0x0400006D RID: 109
		private static Callback<SteamServerConnectFailure_t> steamServerConnectFailure;

		// Token: 0x0400006E RID: 110
		private static Callback<SteamServersConnected_t> steamServersConnected;

		// Token: 0x0400006F RID: 111
		private static Callback<SteamServersDisconnected_t> steamServersDisconnected;

		// Token: 0x04000070 RID: 112
		private static CommandLineFlag clShouldLogin = new CommandLineFlag(true, "-NoSteamGameServerLogin");

		// Token: 0x04000071 RID: 113
		private static CommandLineFlag clShouldEnableAdvertisement = new CommandLineFlag(true, "-NoSteamGameServerAdvertisement");
	}
}
