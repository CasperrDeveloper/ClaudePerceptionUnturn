﻿using System;
using System.IO;
using SDG.Provider.Services;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Multiplayer;
using SDG.Provider.Services.Multiplayer.Client;
using SDG.SteamworksProvider.Services.Community;

namespace SDG.SteamworksProvider.Services.Multiplayer.Client
{
	// Token: 0x02000022 RID: 34
	public class SteamworksClientMultiplayerService : Service, IClientMultiplayerService, IService
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000CF RID: 207 RVA: 0x00004820 File Offset: 0x00002A20
		// (set) Token: 0x060000D0 RID: 208 RVA: 0x00004828 File Offset: 0x00002A28
		public IServerInfo serverInfo { get; protected set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000D1 RID: 209 RVA: 0x00004831 File Offset: 0x00002A31
		// (set) Token: 0x060000D2 RID: 210 RVA: 0x00004839 File Offset: 0x00002A39
		public bool isConnected { get; protected set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000D3 RID: 211 RVA: 0x00004842 File Offset: 0x00002A42
		// (set) Token: 0x060000D4 RID: 212 RVA: 0x0000484A File Offset: 0x00002A4A
		public bool isAttempting { get; protected set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000D5 RID: 213 RVA: 0x00004853 File Offset: 0x00002A53
		// (set) Token: 0x060000D6 RID: 214 RVA: 0x0000485B File Offset: 0x00002A5B
		public MemoryStream stream { get; protected set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000D7 RID: 215 RVA: 0x00004864 File Offset: 0x00002A64
		// (set) Token: 0x060000D8 RID: 216 RVA: 0x0000486C File Offset: 0x00002A6C
		public BinaryReader reader { get; protected set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000D9 RID: 217 RVA: 0x00004875 File Offset: 0x00002A75
		// (set) Token: 0x060000DA RID: 218 RVA: 0x0000487D File Offset: 0x00002A7D
		public BinaryWriter writer { get; protected set; }

		// Token: 0x060000DB RID: 219 RVA: 0x00004886 File Offset: 0x00002A86
		public void connect(IServerInfo newServerInfo)
		{
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00004888 File Offset: 0x00002A88
		public void disconnect()
		{
		}

		// Token: 0x060000DD RID: 221 RVA: 0x0000488A File Offset: 0x00002A8A
		public bool read(out ICommunityEntity entity, byte[] data, out ulong length, int channel)
		{
			entity = SteamworksCommunityEntity.INVALID;
			length = 0UL;
			return false;
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000489D File Offset: 0x00002A9D
		public void write(ICommunityEntity entity, byte[] data, ulong length)
		{
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0000489F File Offset: 0x00002A9F
		public void write(ICommunityEntity entity, byte[] data, ulong length, ESendMethod method, int channel)
		{
		}
	}
}
