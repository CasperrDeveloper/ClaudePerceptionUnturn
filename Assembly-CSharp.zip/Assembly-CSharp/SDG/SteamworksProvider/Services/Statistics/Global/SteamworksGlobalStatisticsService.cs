﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Statistics.Global;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Statistics.Global
{
	// Token: 0x0200001E RID: 30
	public class SteamworksGlobalStatisticsService : Service, IGlobalStatisticsService, IService
	{
		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600009D RID: 157 RVA: 0x00004198 File Offset: 0x00002398
		// (remove) Token: 0x0600009E RID: 158 RVA: 0x000041D0 File Offset: 0x000023D0
		public event GlobalStatisticsRequestReady onGlobalStatisticsRequestReady;

		// Token: 0x0600009F RID: 159 RVA: 0x00004205 File Offset: 0x00002405
		private void triggerGlobalStatisticsRequestReady()
		{
			GlobalStatisticsRequestReady globalStatisticsRequestReady = this.onGlobalStatisticsRequestReady;
			if (globalStatisticsRequestReady == null)
			{
				return;
			}
			globalStatisticsRequestReady();
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00004217 File Offset: 0x00002417
		public bool getStatistic(string name, out long data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			return SteamUserStats.GetGlobalStat(name, out data);
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000422E File Offset: 0x0000242E
		public bool getStatistic(string name, out double data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			return SteamUserStats.GetGlobalStat(name, out data);
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00004245 File Offset: 0x00002445
		public bool requestStatistics()
		{
			SteamUserStats.RequestGlobalStats(0);
			return true;
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x0000424F File Offset: 0x0000244F
		public SteamworksGlobalStatisticsService()
		{
			this.globalStatsReceived = Callback<GlobalStatsReceived_t>.Create(new Callback<GlobalStatsReceived_t>.DispatchDelegate(this.onGlobalStatsReceived));
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x0000426E File Offset: 0x0000246E
		private void onGlobalStatsReceived(GlobalStatsReceived_t callback)
		{
			if (callback.m_nGameID != (ulong)SteamUtils.GetAppID().m_AppId)
			{
				return;
			}
			this.triggerGlobalStatisticsRequestReady();
		}

		// Token: 0x0400005D RID: 93
		private Callback<GlobalStatsReceived_t> globalStatsReceived;
	}
}
