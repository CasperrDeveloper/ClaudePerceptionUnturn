﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Statistics;
using SDG.Provider.Services.Statistics.Global;
using SDG.Provider.Services.Statistics.User;
using SDG.SteamworksProvider.Services.Statistics.Global;
using SDG.SteamworksProvider.Services.Statistics.User;

namespace SDG.SteamworksProvider.Services.Statistics
{
	// Token: 0x0200001C RID: 28
	public class SteamworksStatisticsService : IStatisticsService, IService
	{
		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600008B RID: 139 RVA: 0x00003FC2 File Offset: 0x000021C2
		// (set) Token: 0x0600008C RID: 140 RVA: 0x00003FCA File Offset: 0x000021CA
		public IUserStatisticsService userStatisticsService { get; protected set; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600008D RID: 141 RVA: 0x00003FD3 File Offset: 0x000021D3
		// (set) Token: 0x0600008E RID: 142 RVA: 0x00003FDB File Offset: 0x000021DB
		public IGlobalStatisticsService globalStatisticsService { get; protected set; }

		// Token: 0x0600008F RID: 143 RVA: 0x00003FE4 File Offset: 0x000021E4
		public void initialize()
		{
			this.userStatisticsService.initialize();
			this.globalStatisticsService.initialize();
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00003FFC File Offset: 0x000021FC
		public void update()
		{
			this.userStatisticsService.update();
			this.globalStatisticsService.update();
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00004014 File Offset: 0x00002214
		public void shutdown()
		{
			this.userStatisticsService.shutdown();
			this.globalStatisticsService.shutdown();
		}

		// Token: 0x06000092 RID: 146 RVA: 0x0000402C File Offset: 0x0000222C
		public SteamworksStatisticsService()
		{
			this.userStatisticsService = new SteamworksUserStatisticsService();
			this.globalStatisticsService = new SteamworksGlobalStatisticsService();
		}
	}
}
