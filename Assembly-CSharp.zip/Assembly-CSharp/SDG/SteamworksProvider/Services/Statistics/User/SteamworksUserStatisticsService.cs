﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Community;
using SDG.Provider.Services.Statistics.User;
using SDG.SteamworksProvider.Services.Community;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Statistics.User
{
	// Token: 0x0200001D RID: 29
	public class SteamworksUserStatisticsService : Service, IUserStatisticsService, IService
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000093 RID: 147 RVA: 0x0000404C File Offset: 0x0000224C
		// (remove) Token: 0x06000094 RID: 148 RVA: 0x00004084 File Offset: 0x00002284
		public event UserStatisticsRequestReady onUserStatisticsRequestReady;

		// Token: 0x06000095 RID: 149 RVA: 0x000040B9 File Offset: 0x000022B9
		private void triggerUserStatisticsRequestReady(ICommunityEntity entityID)
		{
			UserStatisticsRequestReady userStatisticsRequestReady = this.onUserStatisticsRequestReady;
			if (userStatisticsRequestReady == null)
			{
				return;
			}
			userStatisticsRequestReady(entityID);
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000040CC File Offset: 0x000022CC
		public bool getStatistic(string name, out int data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			return SteamUserStats.GetStat(name, out data);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x000040E3 File Offset: 0x000022E3
		public bool setStatistic(string name, int data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			bool result = SteamUserStats.SetStat(name, data);
			SteamUserStats.StoreStats();
			return result;
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00004100 File Offset: 0x00002300
		public bool getStatistic(string name, out float data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			return SteamUserStats.GetStat(name, out data);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004117 File Offset: 0x00002317
		public bool setStatistic(string name, float data)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			bool result = SteamUserStats.SetStat(name, data);
			SteamUserStats.StoreStats();
			return result;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00004134 File Offset: 0x00002334
		public bool requestStatistics()
		{
			SteamUserStats.RequestCurrentStats();
			return true;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0000413D File Offset: 0x0000233D
		public SteamworksUserStatisticsService()
		{
			this.userStatsReceivedCallback = Callback<UserStatsReceived_t>.Create(new Callback<UserStatsReceived_t>.DispatchDelegate(this.onUserStatsReceived));
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0000415C File Offset: 0x0000235C
		private void onUserStatsReceived(UserStatsReceived_t callback)
		{
			if (callback.m_nGameID != (ulong)SteamUtils.GetAppID().m_AppId)
			{
				return;
			}
			SteamworksCommunityEntity steamworksCommunityEntity = new SteamworksCommunityEntity(callback.m_steamIDUser);
			this.triggerUserStatisticsRequestReady(steamworksCommunityEntity);
		}

		// Token: 0x0400005B RID: 91
		private Callback<UserStatsReceived_t> userStatsReceivedCallback;
	}
}
