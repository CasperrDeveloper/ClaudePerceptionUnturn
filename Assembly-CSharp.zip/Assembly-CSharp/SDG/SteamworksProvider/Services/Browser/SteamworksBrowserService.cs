﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Browser;
using SDG.Unturned;

namespace SDG.SteamworksProvider.Services.Browser
{
	// Token: 0x0200002E RID: 46
	public class SteamworksBrowserService : Service, IBrowserService, IService
	{
		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000121 RID: 289 RVA: 0x00005170 File Offset: 0x00003370
		public bool canOpenBrowser
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00005173 File Offset: 0x00003373
		public void open(string url)
		{
			Provider.openURL(url);
		}
	}
}
