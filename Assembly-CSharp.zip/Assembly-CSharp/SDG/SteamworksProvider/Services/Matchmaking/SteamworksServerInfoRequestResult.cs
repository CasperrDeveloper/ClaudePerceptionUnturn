﻿using System;
using SDG.Provider.Services.Matchmaking;
using SDG.Provider.Services.Multiplayer;
using SDG.SteamworksProvider.Services.Multiplayer;

namespace SDG.SteamworksProvider.Services.Matchmaking
{
	// Token: 0x02000025 RID: 37
	public class SteamworksServerInfoRequestResult : IServerInfoRequestResult
	{
		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x000049AC File Offset: 0x00002BAC
		// (set) Token: 0x060000E9 RID: 233 RVA: 0x000049B4 File Offset: 0x00002BB4
		public IServerInfo serverInfo { get; protected set; }

		// Token: 0x060000EA RID: 234 RVA: 0x000049BD File Offset: 0x00002BBD
		public SteamworksServerInfoRequestResult(SteamworksServerInfo newServerInfo)
		{
			this.serverInfo = newServerInfo;
		}
	}
}
