﻿using System;
using SDG.Provider.Services.Matchmaking;
using SDG.SteamworksProvider.Services.Multiplayer;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Matchmaking
{
	// Token: 0x02000024 RID: 36
	public class SteamworksServerInfoRequestHandle : IServerInfoRequestHandle
	{
		// Token: 0x060000E3 RID: 227 RVA: 0x0000490C File Offset: 0x00002B0C
		public void onServerResponded(gameserveritem_t server)
		{
			SteamworksServerInfoRequestResult result = new SteamworksServerInfoRequestResult(new SteamworksServerInfo(server));
			this.triggerCallback(result);
			this.cleanupQuery();
			SteamworksMatchmakingService.serverInfoRequestHandles.Remove(this);
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00004940 File Offset: 0x00002B40
		public void onServerFailedToRespond()
		{
			SteamworksServerInfoRequestResult result = new SteamworksServerInfoRequestResult(null);
			this.triggerCallback(result);
			this.cleanupQuery();
			SteamworksMatchmakingService.serverInfoRequestHandles.Remove(this);
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0000496D File Offset: 0x00002B6D
		public void triggerCallback(IServerInfoRequestResult result)
		{
			if (this.callback == null)
			{
				return;
			}
			this.callback(this, result);
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x00004985 File Offset: 0x00002B85
		private void cleanupQuery()
		{
			SteamMatchmakingServers.CancelServerQuery(this.query);
			this.query = HServerQuery.Invalid;
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000499D File Offset: 0x00002B9D
		public SteamworksServerInfoRequestHandle(ServerInfoRequestReadyCallback newCallback)
		{
			this.callback = newCallback;
		}

		// Token: 0x04000079 RID: 121
		public HServerQuery query;

		// Token: 0x0400007A RID: 122
		public ISteamMatchmakingPingResponse pingResponse;

		// Token: 0x0400007B RID: 123
		private ServerInfoRequestReadyCallback callback;
	}
}
