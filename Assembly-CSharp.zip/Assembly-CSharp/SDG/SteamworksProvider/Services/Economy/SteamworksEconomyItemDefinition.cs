﻿using System;
using SDG.Framework.IO.Streams;
using SDG.Provider.Services.Economy;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Economy
{
	// Token: 0x02000027 RID: 39
	public class SteamworksEconomyItemDefinition : IEconomyItemDefinition, INetworkStreamable
	{
		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x00004A6E File Offset: 0x00002C6E
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x00004A76 File Offset: 0x00002C76
		public SteamItemDef_t steamItemDef { get; protected set; }

		// Token: 0x060000F6 RID: 246 RVA: 0x00004A7F File Offset: 0x00002C7F
		public void readFromStream(NetworkStream networkStream)
		{
			this.steamItemDef = (SteamItemDef_t)networkStream.readInt32();
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x00004A92 File Offset: 0x00002C92
		public void writeToStream(NetworkStream networkStream)
		{
			networkStream.writeInt32((int)this.steamItemDef);
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x00004AA8 File Offset: 0x00002CA8
		public string getPropertyValue(string key)
		{
			uint num = 1024U;
			string result;
			SteamInventory.GetItemDefinitionProperty(this.steamItemDef, key, out result, ref num);
			return result;
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00004ACD File Offset: 0x00002CCD
		public SteamworksEconomyItemDefinition(SteamItemDef_t newSteamItemDef)
		{
			this.steamItemDef = newSteamItemDef;
		}
	}
}
