﻿using System;
using SDG.Framework.IO.Streams;
using SDG.Provider.Services.Economy;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Economy
{
	// Token: 0x02000026 RID: 38
	public class SteamworksEconomyItem : IEconomyItem, INetworkStreamable
	{
		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000EB RID: 235 RVA: 0x000049CC File Offset: 0x00002BCC
		// (set) Token: 0x060000EC RID: 236 RVA: 0x000049D4 File Offset: 0x00002BD4
		public SteamItemDetails_t steamItemDetail { get; protected set; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000ED RID: 237 RVA: 0x000049DD File Offset: 0x00002BDD
		// (set) Token: 0x060000EE RID: 238 RVA: 0x000049E5 File Offset: 0x00002BE5
		public IEconomyItemDefinition itemDefinitionID { get; protected set; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000EF RID: 239 RVA: 0x000049EE File Offset: 0x00002BEE
		// (set) Token: 0x060000F0 RID: 240 RVA: 0x000049F6 File Offset: 0x00002BF6
		public IEconomyItemInstance itemInstanceID { get; protected set; }

		// Token: 0x060000F1 RID: 241 RVA: 0x000049FF File Offset: 0x00002BFF
		public void readFromStream(NetworkStream networkStream)
		{
			this.itemDefinitionID.readFromStream(networkStream);
			this.itemInstanceID.readFromStream(networkStream);
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00004A19 File Offset: 0x00002C19
		public void writeToStream(NetworkStream networkStream)
		{
			this.itemDefinitionID.writeToStream(networkStream);
			this.itemInstanceID.writeToStream(networkStream);
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x00004A33 File Offset: 0x00002C33
		public SteamworksEconomyItem(SteamItemDetails_t newSteamItemDetail)
		{
			this.steamItemDetail = newSteamItemDetail;
			this.itemDefinitionID = new SteamworksEconomyItemDefinition(this.steamItemDetail.m_iDefinition);
			this.itemInstanceID = new SteamworksEconomyItemInstance(this.steamItemDetail.m_itemId);
		}
	}
}
