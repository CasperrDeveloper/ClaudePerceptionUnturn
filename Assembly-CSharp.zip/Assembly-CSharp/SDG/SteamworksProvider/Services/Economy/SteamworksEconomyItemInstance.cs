﻿using System;
using SDG.Framework.IO.Streams;
using SDG.Provider.Services.Economy;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Economy
{
	// Token: 0x02000028 RID: 40
	public class SteamworksEconomyItemInstance : IEconomyItemInstance, INetworkStreamable
	{
		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000FA RID: 250 RVA: 0x00004ADC File Offset: 0x00002CDC
		// (set) Token: 0x060000FB RID: 251 RVA: 0x00004AE4 File Offset: 0x00002CE4
		public SteamItemInstanceID_t steamItemInstanceID { get; protected set; }

		// Token: 0x060000FC RID: 252 RVA: 0x00004AED File Offset: 0x00002CED
		public void readFromStream(NetworkStream networkStream)
		{
			this.steamItemInstanceID = (SteamItemInstanceID_t)networkStream.readUInt64();
		}

		// Token: 0x060000FD RID: 253 RVA: 0x00004B00 File Offset: 0x00002D00
		public void writeToStream(NetworkStream networkStream)
		{
			networkStream.writeUInt64((ulong)this.steamItemInstanceID);
		}

		// Token: 0x060000FE RID: 254 RVA: 0x00004B13 File Offset: 0x00002D13
		public SteamworksEconomyItemInstance(SteamItemInstanceID_t newSteamItemInstanceID)
		{
			this.steamItemInstanceID = newSteamItemInstanceID;
		}
	}
}
