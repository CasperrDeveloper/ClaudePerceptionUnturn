﻿using System;
using SDG.Provider.Services.Economy;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Economy
{
	// Token: 0x02000029 RID: 41
	public class SteamworksEconomyRequestHandle : IEconomyRequestHandle
	{
		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000FF RID: 255 RVA: 0x00004B22 File Offset: 0x00002D22
		// (set) Token: 0x06000100 RID: 256 RVA: 0x00004B2A File Offset: 0x00002D2A
		public SteamInventoryResult_t steamInventoryResult { get; protected set; }

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000101 RID: 257 RVA: 0x00004B33 File Offset: 0x00002D33
		// (set) Token: 0x06000102 RID: 258 RVA: 0x00004B3B File Offset: 0x00002D3B
		private EconomyRequestReadyCallback economyRequestReadyCallback { get; set; }

		// Token: 0x06000103 RID: 259 RVA: 0x00004B44 File Offset: 0x00002D44
		public void triggerInventoryRequestReadyCallback(IEconomyRequestResult inventoryRequestResult)
		{
			if (this.economyRequestReadyCallback == null)
			{
				return;
			}
			this.economyRequestReadyCallback(this, inventoryRequestResult);
		}

		// Token: 0x06000104 RID: 260 RVA: 0x00004B5C File Offset: 0x00002D5C
		public SteamworksEconomyRequestHandle(SteamInventoryResult_t newSteamInventoryResult, EconomyRequestReadyCallback newEconomyRequestReadyCallback)
		{
			this.steamInventoryResult = newSteamInventoryResult;
			this.economyRequestReadyCallback = newEconomyRequestReadyCallback;
		}
	}
}
