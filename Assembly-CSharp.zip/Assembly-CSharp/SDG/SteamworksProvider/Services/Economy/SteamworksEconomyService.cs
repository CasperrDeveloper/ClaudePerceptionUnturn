﻿using System;
using System.Collections.Generic;
using SDG.Provider.Services;
using SDG.Provider.Services.Economy;
using SDG.Unturned;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Economy
{
	// Token: 0x0200002A RID: 42
	public class SteamworksEconomyService : Service, IEconomyService, IService
	{
		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000105 RID: 261 RVA: 0x00004B72 File Offset: 0x00002D72
		public bool canOpenInventory
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00004B78 File Offset: 0x00002D78
		public IEconomyRequestHandle requestInventory(EconomyRequestReadyCallback inventoryRequestReadyCallback)
		{
			SteamInventoryResult_t steamInventoryResult;
			SteamInventory.GetAllItems(out steamInventoryResult);
			return this.addInventoryRequestHandle(steamInventoryResult, inventoryRequestReadyCallback);
		}

		// Token: 0x06000107 RID: 263 RVA: 0x00004B98 File Offset: 0x00002D98
		public IEconomyRequestHandle requestPromo(EconomyRequestReadyCallback inventoryRequestReadyCallback)
		{
			SteamInventoryResult_t steamInventoryResult;
			SteamInventory.GrantPromoItems(out steamInventoryResult);
			return this.addInventoryRequestHandle(steamInventoryResult, inventoryRequestReadyCallback);
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00004BB8 File Offset: 0x00002DB8
		public IEconomyRequestHandle exchangeItems(IEconomyItemInstance[] inputItemInstanceIDs, uint[] inputItemQuantities, IEconomyItemDefinition[] outputItemDefinitionIDs, uint[] outputItemQuantities, EconomyRequestReadyCallback inventoryRequestReadyCallback)
		{
			if (inputItemInstanceIDs.Length != inputItemQuantities.Length)
			{
				throw new ArgumentException("Input item arrays need to be the same length.", "inputItemQuantities");
			}
			if (outputItemDefinitionIDs.Length != outputItemQuantities.Length)
			{
				throw new ArgumentException("Output item arrays need to be the same length.", "outputItemQuantities");
			}
			SteamItemInstanceID_t[] array = new SteamItemInstanceID_t[inputItemInstanceIDs.Length];
			for (int i = 0; i < inputItemInstanceIDs.Length; i++)
			{
				SteamworksEconomyItemInstance steamworksEconomyItemInstance = (SteamworksEconomyItemInstance)inputItemInstanceIDs[i];
				array[i] = steamworksEconomyItemInstance.steamItemInstanceID;
			}
			SteamItemDef_t[] array2 = new SteamItemDef_t[outputItemDefinitionIDs.Length];
			for (int j = 0; j < outputItemDefinitionIDs.Length; j++)
			{
				SteamworksEconomyItemDefinition steamworksEconomyItemDefinition = (SteamworksEconomyItemDefinition)outputItemDefinitionIDs[j];
				array2[j] = steamworksEconomyItemDefinition.steamItemDef;
			}
			SteamInventoryResult_t steamInventoryResult;
			SteamInventory.ExchangeItems(out steamInventoryResult, array2, outputItemQuantities, (uint)array2.Length, array, inputItemQuantities, (uint)array.Length);
			return this.addInventoryRequestHandle(steamInventoryResult, inventoryRequestReadyCallback);
		}

		// Token: 0x06000109 RID: 265 RVA: 0x00004C78 File Offset: 0x00002E78
		public void open(ulong id)
		{
			Provider.openURL(string.Concat(new string[]
			{
				"https://steamcommunity.com/profiles/",
				SteamUser.GetSteamID().ToString(),
				"/inventory/?sellOnLoad=1#",
				SteamUtils.GetAppID().ToString(),
				"_2_",
				id.ToString()
			}));
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00004CE4 File Offset: 0x00002EE4
		private SteamworksEconomyRequestHandle findSteamworksEconomyRequestHandles(SteamInventoryResult_t steamInventoryResult)
		{
			return this.steamworksEconomyRequestHandles.Find((SteamworksEconomyRequestHandle handle) => handle.steamInventoryResult == steamInventoryResult);
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00004D18 File Offset: 0x00002F18
		private IEconomyRequestHandle addInventoryRequestHandle(SteamInventoryResult_t steamInventoryResult, EconomyRequestReadyCallback inventoryRequestReadyCallback)
		{
			SteamworksEconomyRequestHandle steamworksEconomyRequestHandle = new SteamworksEconomyRequestHandle(steamInventoryResult, inventoryRequestReadyCallback);
			this.steamworksEconomyRequestHandles.Add(steamworksEconomyRequestHandle);
			return steamworksEconomyRequestHandle;
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00004D3C File Offset: 0x00002F3C
		private IEconomyRequestResult createInventoryRequestResult(SteamInventoryResult_t steamInventoryResult)
		{
			uint num = 0U;
			SteamworksEconomyItem[] array2;
			if (SteamGameServerInventory.GetResultItems(steamInventoryResult, null, ref num) && num > 0U)
			{
				SteamItemDetails_t[] array = new SteamItemDetails_t[num];
				SteamGameServerInventory.GetResultItems(steamInventoryResult, array, ref num);
				array2 = new SteamworksEconomyItem[num];
				for (uint num2 = 0U; num2 < num; num2 += 1U)
				{
					SteamworksEconomyItem steamworksEconomyItem = new SteamworksEconomyItem(array[(int)num2]);
					array2[(int)num2] = steamworksEconomyItem;
				}
			}
			else
			{
				array2 = new SteamworksEconomyItem[0];
			}
			EEconomyRequestState newEconomyRequestState = EEconomyRequestState.SUCCESS;
			IEconomyItem[] newItems = array2;
			return new EconomyRequestResult(newEconomyRequestState, newItems);
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00004DA8 File Offset: 0x00002FA8
		private void onSteamInventoryResultReady(SteamInventoryResultReady_t callback)
		{
			SteamworksEconomyRequestHandle steamworksEconomyRequestHandle = this.findSteamworksEconomyRequestHandles(callback.m_handle);
			if (steamworksEconomyRequestHandle == null)
			{
				return;
			}
			IEconomyRequestResult inventoryRequestResult = this.createInventoryRequestResult(steamworksEconomyRequestHandle.steamInventoryResult);
			steamworksEconomyRequestHandle.triggerInventoryRequestReadyCallback(inventoryRequestResult);
			SteamInventory.DestroyResult(steamworksEconomyRequestHandle.steamInventoryResult);
		}

		// Token: 0x0600010E RID: 270 RVA: 0x00004DE5 File Offset: 0x00002FE5
		public SteamworksEconomyService()
		{
			this.steamworksEconomyRequestHandles = new List<SteamworksEconomyRequestHandle>();
			this.steamInventoryResultReady = Callback<SteamInventoryResultReady_t>.Create(new Callback<SteamInventoryResultReady_t>.DispatchDelegate(this.onSteamInventoryResultReady));
		}

		// Token: 0x04000084 RID: 132
		private List<SteamworksEconomyRequestHandle> steamworksEconomyRequestHandles;

		// Token: 0x04000085 RID: 133
		private Callback<SteamInventoryResultReady_t> steamInventoryResultReady;
	}
}
