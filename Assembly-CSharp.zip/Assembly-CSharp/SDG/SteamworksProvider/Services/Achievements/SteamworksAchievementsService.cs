﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Achievements;
using SDG.Unturned;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Achievements
{
	// Token: 0x0200002F RID: 47
	public class SteamworksAchievementsService : Service, IAchievementsService, IService
	{
		// Token: 0x06000124 RID: 292 RVA: 0x00005183 File Offset: 0x00003383
		public bool getAchievement(string name, out bool has)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			bool achievement = SteamUserStats.GetAchievement(name, out has);
			if (!achievement)
			{
				UnturnedLog.error("Failed to get Steam achievement \"" + name + "\" status");
			}
			return achievement;
		}

		// Token: 0x06000125 RID: 293 RVA: 0x000051B2 File Offset: 0x000033B2
		public bool setAchievement(string name)
		{
			if (name == null)
			{
				throw new ArgumentNullException("name");
			}
			bool flag = SteamUserStats.SetAchievement(name);
			if (flag)
			{
				UnturnedLog.info("Unlocked Steam achievement \"" + name + "\"");
			}
			SteamUserStats.StoreStats();
			return flag;
		}
	}
}
