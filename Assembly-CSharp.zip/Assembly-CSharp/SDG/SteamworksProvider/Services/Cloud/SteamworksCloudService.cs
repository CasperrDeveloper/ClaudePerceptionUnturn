﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Cloud;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Cloud
{
	// Token: 0x0200002D RID: 45
	public class SteamworksCloudService : Service, ICloudService, IService
	{
		// Token: 0x0600011B RID: 283 RVA: 0x000050B4 File Offset: 0x000032B4
		public bool read(string path, byte[] data)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (data == null)
			{
				throw new ArgumentNullException("data");
			}
			int fileSize = SteamRemoteStorage.GetFileSize(path);
			return data.Length >= fileSize && SteamRemoteStorage.FileRead(path, data, fileSize) == fileSize;
		}

		// Token: 0x0600011C RID: 284 RVA: 0x000050FA File Offset: 0x000032FA
		public bool write(string path, byte[] data, int size)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			if (data == null)
			{
				throw new ArgumentNullException("data");
			}
			return SteamRemoteStorage.FileWrite(path, data, size);
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00005120 File Offset: 0x00003320
		public bool getSize(string path, out int size)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			size = SteamRemoteStorage.GetFileSize(path);
			return true;
		}

		// Token: 0x0600011E RID: 286 RVA: 0x00005139 File Offset: 0x00003339
		public bool exists(string path, out bool exists)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			exists = SteamRemoteStorage.FileExists(path);
			return true;
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00005152 File Offset: 0x00003352
		public bool delete(string path)
		{
			if (path == null)
			{
				throw new ArgumentNullException("path");
			}
			return SteamRemoteStorage.FileDelete(path);
		}
	}
}
