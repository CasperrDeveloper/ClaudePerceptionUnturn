﻿using System;
using SDG.Framework.IO.Streams;
using SDG.Provider.Services.Community;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Community
{
	// Token: 0x0200002B RID: 43
	public struct SteamworksCommunityEntity : ICommunityEntity, INetworkStreamable
	{
		// Token: 0x17000031 RID: 49
		// (get) Token: 0x0600010F RID: 271 RVA: 0x00004E0F File Offset: 0x0000300F
		public bool isValid
		{
			get
			{
				return this.steamID.IsValid();
			}
		}

		// Token: 0x06000110 RID: 272 RVA: 0x00004E1C File Offset: 0x0000301C
		public void readFromStream(NetworkStream networkStream)
		{
			this.steamID = (CSteamID)networkStream.readUInt64();
		}

		// Token: 0x06000111 RID: 273 RVA: 0x00004E2F File Offset: 0x0000302F
		public void writeToStream(NetworkStream networkStream)
		{
			networkStream.writeUInt64((ulong)this.steamID);
		}

		// Token: 0x06000112 RID: 274 RVA: 0x00004E42 File Offset: 0x00003042
		public SteamworksCommunityEntity(CSteamID newSteamID)
		{
			this.steamID = newSteamID;
		}

		// Token: 0x04000086 RID: 134
		public static readonly SteamworksCommunityEntity INVALID = new SteamworksCommunityEntity(CSteamID.Nil);

		// Token: 0x04000087 RID: 135
		public CSteamID steamID;
	}
}
