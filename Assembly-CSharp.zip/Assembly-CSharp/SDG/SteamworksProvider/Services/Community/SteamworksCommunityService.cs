﻿using System;
using System.Collections.Generic;
using SDG.Provider.Services;
using SDG.Provider.Services.Community;
using SDG.Unturned;
using Steamworks;
using UnityEngine;

namespace SDG.SteamworksProvider.Services.Community
{
	// Token: 0x0200002C RID: 44
	public class SteamworksCommunityService : Service, ICommunityService, IService
	{
		// Token: 0x06000114 RID: 276 RVA: 0x00004E5C File Offset: 0x0000305C
		public void setStatus(string status)
		{
			SteamFriends.SetRichPresence("status", status);
		}

		// Token: 0x06000115 RID: 277 RVA: 0x00004E6C File Offset: 0x0000306C
		public Texture2D getIcon(int id)
		{
			if (id < 0)
			{
				return null;
			}
			uint num;
			uint num2;
			if (!SteamUtils.GetImageSize(id, out num, out num2))
			{
				return null;
			}
			if (num < 1U || num2 < 1U || num > 2048U || num2 > 2048U)
			{
				return null;
			}
			byte[] array = new byte[num * num2 * 4U];
			if (!SteamUtils.GetImageRGBA(id, array, array.Length))
			{
				return null;
			}
			int num3 = (int)num;
			int num4 = (int)num2;
			int num5 = num4 / 2;
			for (int i = 0; i < num5; i++)
			{
				int num6 = num4 - 1 - i;
				int num7 = i * num3 * 4;
				int num8 = num6 * num3 * 4;
				for (int j = 0; j < num3; j++)
				{
					int num9 = num7 + j * 4;
					int num10 = num8 + j * 4;
					for (int k = 0; k < 4; k++)
					{
						int num11 = num9 + k;
						int num12 = num10 + k;
						byte b = array[num11];
						array[num11] = array[num12];
						array[num12] = b;
					}
				}
			}
			Texture2D texture2D;
			try
			{
				texture2D = new Texture2D(num3, num4, TextureFormat.RGBA32, false);
				texture2D.hideFlags = HideFlags.HideAndDontSave;
				texture2D.LoadRawTextureData(array);
				texture2D.Apply(true, true);
			}
			catch (Exception e)
			{
				texture2D = null;
				UnturnedLog.exception(e, string.Format("Caught exception creating Steam avatar {0}x{1}:", num, num2));
			}
			return texture2D;
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00004FA0 File Offset: 0x000031A0
		public Texture2D getIcon(CSteamID steamID, bool shouldCache = false)
		{
			Texture2D texture2D = null;
			if (!shouldCache || !this.cachedAvatars.TryGetValue(steamID, out texture2D))
			{
				texture2D = this.getIcon(SteamFriends.GetSmallFriendAvatar(steamID));
				if (shouldCache)
				{
					this.cachedAvatars.Add(steamID, texture2D);
				}
			}
			return texture2D;
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00004FE0 File Offset: 0x000031E0
		public SteamGroup getCachedGroup(CSteamID steamID)
		{
			SteamGroup result;
			this.cachedGroups.TryGetValue(steamID, out result);
			return result;
		}

		// Token: 0x06000118 RID: 280 RVA: 0x00005000 File Offset: 0x00003200
		public SteamGroup[] getGroups()
		{
			SteamGroup[] array = new SteamGroup[SteamFriends.GetClanCount()];
			for (int i = 0; i < array.Length; i++)
			{
				CSteamID clanByIndex = SteamFriends.GetClanByIndex(i);
				SteamGroup steamGroup = this.getCachedGroup(clanByIndex);
				if (steamGroup == null)
				{
					string clanName = SteamFriends.GetClanName(clanByIndex);
					Texture2D icon = this.getIcon(clanByIndex, false);
					steamGroup = new SteamGroup(clanByIndex, clanName, icon);
					this.cachedGroups.Add(clanByIndex, steamGroup);
				}
				array[i] = steamGroup;
			}
			return array;
		}

		// Token: 0x06000119 RID: 281 RVA: 0x00005068 File Offset: 0x00003268
		public bool checkGroup(CSteamID steamID)
		{
			for (int i = 0; i < SteamFriends.GetClanCount(); i++)
			{
				if (SteamFriends.GetClanByIndex(i) == steamID)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00005096 File Offset: 0x00003296
		public SteamworksCommunityService()
		{
			this.cachedGroups = new Dictionary<CSteamID, SteamGroup>();
			this.cachedAvatars = new Dictionary<CSteamID, Texture2D>();
		}

		// Token: 0x04000088 RID: 136
		private Dictionary<CSteamID, SteamGroup> cachedGroups;

		// Token: 0x04000089 RID: 137
		private Dictionary<CSteamID, Texture2D> cachedAvatars;
	}
}
