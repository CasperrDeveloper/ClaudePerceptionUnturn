﻿using System;
using SDG.Provider.Services.Store;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Store
{
	// Token: 0x0200001A RID: 26
	public class SteamworksStorePackageID : IStorePackageID
	{
		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000086 RID: 134 RVA: 0x00003F49 File Offset: 0x00002149
		// (set) Token: 0x06000087 RID: 135 RVA: 0x00003F51 File Offset: 0x00002151
		public AppId_t appID { get; protected set; }

		// Token: 0x06000088 RID: 136 RVA: 0x00003F5A File Offset: 0x0000215A
		public SteamworksStorePackageID(uint appID)
		{
			this.appID = new AppId_t(appID);
		}
	}
}
