﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Store;
using SDG.Unturned;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Store
{
	// Token: 0x0200001B RID: 27
	public class SteamworksStoreService : Service, IStoreService, IService
	{
		// Token: 0x06000089 RID: 137 RVA: 0x00003F70 File Offset: 0x00002170
		public void open(IStorePackageID packageID)
		{
			AppId_t appID = ((SteamworksStorePackageID)packageID).appID;
			if (SteamUtils.IsOverlayEnabled())
			{
				SteamFriends.ActivateGameOverlayToStore(appID, EOverlayToStoreFlag.k_EOverlayToStoreFlag_None);
				return;
			}
			Provider.openURL("https://store.steampowered.com/app/" + appID.m_AppId.ToString());
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00003FB3 File Offset: 0x000021B3
		public SteamworksStoreService(SteamworksAppInfo newAppInfo)
		{
			this.appInfo = newAppInfo;
		}

		// Token: 0x04000057 RID: 87
		private SteamworksAppInfo appInfo;
	}
}
