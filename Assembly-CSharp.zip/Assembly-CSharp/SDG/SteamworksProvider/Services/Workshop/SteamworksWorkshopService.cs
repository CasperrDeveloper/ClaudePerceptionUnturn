﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Workshop;
using SDG.Unturned;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Workshop
{
	// Token: 0x02000018 RID: 24
	public class SteamworksWorkshopService : Service, IWorkshopService, IService
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600007F RID: 127 RVA: 0x00003EFB File Offset: 0x000020FB
		public bool canOpenWorkshop
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00003EFE File Offset: 0x000020FE
		public void open(PublishedFileId_t id)
		{
			Provider.openURL("https://steamcommunity.com/sharedfiles/filedetails/?id=" + id.m_PublishedFileId.ToString());
		}
	}
}
