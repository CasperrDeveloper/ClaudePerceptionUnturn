﻿using System;
using SDG.Provider.Services;
using SDG.Provider.Services.Translation;
using Steamworks;

namespace SDG.SteamworksProvider.Services.Translation
{
	// Token: 0x02000019 RID: 25
	public class SteamworksTranslationService : Service, ITranslationService, IService
	{
		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000082 RID: 130 RVA: 0x00003F23 File Offset: 0x00002123
		// (set) Token: 0x06000083 RID: 131 RVA: 0x00003F2B File Offset: 0x0000212B
		public string language { get; protected set; }

		// Token: 0x06000084 RID: 132 RVA: 0x00003F34 File Offset: 0x00002134
		public override void initialize()
		{
			this.language = SteamUtils.GetSteamUILanguage();
		}
	}
}
