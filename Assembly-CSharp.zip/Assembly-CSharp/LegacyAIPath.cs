﻿using System;
using System.Collections.Generic;
using Pathfinding;
using UnityEngine;

/// <summary>
/// Nelson 2025-04-30: carrying this over from whatever very old version of the A* Pathfinding Project the game was
/// using because it has a few hacked-in behaviors the newer components don't. Ideally, we should write a custom
/// movement component using the newer AIBase class.
/// </summary>
// Token: 0x0200000F RID: 15
[RequireComponent(typeof(Seeker))]
[AddComponentMenu("Pathfinding/AI/LegacyAIPath")]
public class LegacyAIPath : MonoBehaviour
{
	/// Returns if the end-of-path has been reached
	/// \see targetReached 
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000032 RID: 50 RVA: 0x00002D5F File Offset: 0x00000F5F
	public bool TargetReached
	{
		get
		{
			return this.targetReached;
		}
	}

	/// Initializes reference variables.
	/// 	 * If you override this function you should in most cases call base.Awake () at the start of it.
	/// 	  * 
	// Token: 0x06000033 RID: 51 RVA: 0x00002D67 File Offset: 0x00000F67
	protected virtual void Awake()
	{
		this.seeker = base.GetComponent<Seeker>();
		this.tr = base.transform;
		this.controller = base.GetComponent<CharacterController>();
	}

	/// Run at start and when reenabled.
	/// Starts RepeatTrySearchPath.
	///
	/// \see Start
	// Token: 0x06000034 RID: 52 RVA: 0x00002D8D File Offset: 0x00000F8D
	protected virtual void OnEnable()
	{
		this.lastRepath = -9999f;
		this.canSearchAgain = true;
		this.lastFoundWaypointPosition = this.GetFeetPosition();
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00002DB0 File Offset: 0x00000FB0
	public void OnDisable()
	{
		if (this.seeker != null && !this.seeker.IsDone())
		{
			this.seeker.GetCurrentPath().Error();
		}
		if (this.path != null)
		{
			this.path.Release(this, false);
		}
		this.path = null;
	}

	/// Requests a path to the target 
	// Token: 0x06000036 RID: 54 RVA: 0x00002E04 File Offset: 0x00001004
	public virtual void SearchPath()
	{
		if (this.target == null)
		{
			throw new InvalidOperationException("Target is null");
		}
		this.lastRepath = Time.time;
		Vector3 position = this.target.position;
		this.canSearchAgain = false;
		this.seeker.StartPath(this.GetFeetPosition(), position, new OnPathDelegate(this.OnPathComplete));
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00002E68 File Offset: 0x00001068
	public virtual void OnTargetReached()
	{
	}

	/// Called when a requested path has finished calculation.
	/// A path is first requested by #SearchPath, it is then calculated, probably in the same or the next frame.
	/// Finally it is returned to the seeker which forwards it to this function.\n
	// Token: 0x06000038 RID: 56 RVA: 0x00002E6C File Offset: 0x0000106C
	public virtual void OnPathComplete(Path _p)
	{
		ABPath abpath = _p as ABPath;
		if (abpath == null)
		{
			throw new Exception("This function only handles ABPaths, do not use special path types");
		}
		this.canSearchAgain = true;
		abpath.Claim(this);
		if (abpath.error)
		{
			abpath.Release(this, false);
			return;
		}
		if (this.path != null)
		{
			this.path.Release(this, false);
		}
		this.path = abpath;
		this.currentWaypointIndex = 0;
		this.targetReached = false;
		if (this.closestOnPathCheck)
		{
			Vector3 vector = (Time.time - this.lastFoundWaypointTime < 0.3f) ? this.lastFoundWaypointPosition : abpath.originalStartPoint;
			Vector3 vector2 = this.GetFeetPosition() - vector;
			float magnitude = vector2.magnitude;
			vector2 /= magnitude;
			int num = (int)(magnitude / this.pickNextWaypointDist);
			for (int i = 0; i <= num; i++)
			{
				this.CalculateVelocity(vector);
				vector += vector2;
			}
		}
	}

	// Token: 0x06000039 RID: 57 RVA: 0x00002F4A File Offset: 0x0000114A
	public virtual Vector3 GetFeetPosition()
	{
		return this.tr.position;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00002F58 File Offset: 0x00001158
	public void move(float delta)
	{
		if (!this.canMove)
		{
			return;
		}
		if (Time.time - this.lastRepath >= this.repathRate && this.canSearchAgain && this.canSearch && this.target != null)
		{
			this.SearchPath();
		}
		if (this.path == null)
		{
			return;
		}
		Vector3 a = this.CalculateVelocity(base.transform.position);
		a.y = Physics.gravity.y * 2f;
		this.RotateTowards(this.targetDirection);
		if (this.controller != null && this.controller.enabled)
		{
			this.controller.Move(a * delta);
		}
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00003014 File Offset: 0x00001214
	protected float XZSqrMagnitude(Vector3 a, Vector3 b)
	{
		float num = b.x - a.x;
		float num2 = b.z - a.z;
		return num * num + num2 * num2;
	}

	/// Calculates desired velocity.
	/// Finds the target path segment and returns the forward direction, scaled with speed.
	/// A whole bunch of restrictions on the velocity is applied to make sure it doesn't overshoot, does not look too far ahead,
	/// and slows down when close to the target.
	/// /see speed
	/// /see endReachedDistance
	/// /see slowdownDistance
	/// /see CalculateTargetPoint
	/// /see targetPoint
	/// /see targetDirection
	/// /see currentWaypointIndex
	// Token: 0x0600003C RID: 60 RVA: 0x00003044 File Offset: 0x00001244
	protected Vector3 CalculateVelocity(Vector3 currentPosition)
	{
		if (this.path == null || this.path.vectorPath == null || this.path.vectorPath.Count == 0)
		{
			return Vector3.zero;
		}
		List<Vector3> vectorPath = this.path.vectorPath;
		if (vectorPath.Count == 1)
		{
			vectorPath.Insert(0, currentPosition);
		}
		if (this.currentWaypointIndex >= vectorPath.Count)
		{
			this.currentWaypointIndex = vectorPath.Count - 1;
		}
		if (this.currentWaypointIndex <= 1)
		{
			this.currentWaypointIndex = 1;
		}
		while (this.currentWaypointIndex < vectorPath.Count - 1 && this.XZSqrMagnitude(vectorPath[this.currentWaypointIndex], currentPosition) < this.pickNextWaypointDist * this.pickNextWaypointDist)
		{
			this.lastFoundWaypointPosition = currentPosition;
			this.lastFoundWaypointTime = Time.time;
			this.currentWaypointIndex++;
		}
		Vector3 vector = vectorPath[this.currentWaypointIndex] - vectorPath[this.currentWaypointIndex - 1];
		Vector3 a = this.CalculateTargetPoint(currentPosition, vectorPath[this.currentWaypointIndex - 1], vectorPath[this.currentWaypointIndex], this.currentWaypointIndex == vectorPath.Count - 1);
		vector = a - currentPosition;
		vector.y = 0f;
		float magnitude = vector.magnitude;
		float num = Mathf.Clamp01(magnitude / this.slowdownDistance);
		if (this.canTurn)
		{
			this.targetDirection = vector;
		}
		this.targetPoint = a;
		if (this.currentWaypointIndex == vectorPath.Count - 1 && magnitude <= this.endReachedDistance)
		{
			if (!this.targetReached)
			{
				this.targetReached = true;
				this.OnTargetReached();
			}
			return Vector3.zero;
		}
		Vector3 forward = this.tr.forward;
		float a2 = Vector3.Dot(vector.normalized, forward);
		float num2 = this.speed * Mathf.Max(a2, this.minMoveScale) * num;
		if (Time.deltaTime > 0f)
		{
			num2 = Mathf.Clamp(num2, 0f, magnitude / (Time.deltaTime * 2f));
		}
		return forward * num2;
	}

	/// Rotates in the specified direction.
	/// Rotates around the Y-axis.
	/// \see turningSpeed
	// Token: 0x0600003D RID: 61 RVA: 0x00003248 File Offset: 0x00001448
	protected virtual void RotateTowards(Vector3 dir)
	{
		if (dir == Vector3.zero)
		{
			return;
		}
		Quaternion quaternion = this.tr.rotation;
		Quaternion b = Quaternion.LookRotation(dir);
		Vector3 eulerAngles = Quaternion.Slerp(quaternion, b, this.turningSpeed * Time.deltaTime).eulerAngles;
		eulerAngles.z = 0f;
		eulerAngles.x = 0f;
		quaternion = Quaternion.Euler(eulerAngles);
		this.tr.rotation = quaternion;
	}

	/// Calculates target point from the current line segment.
	/// \param p Current position
	/// \param a Line segment start
	/// \param b Line segment end
	/// The returned point will lie somewhere on the line segment.
	/// \see #forwardLook
	/// \todo This function uses .magnitude quite a lot, can it be optimized?
	// Token: 0x0600003E RID: 62 RVA: 0x000032C0 File Offset: 0x000014C0
	protected Vector3 CalculateTargetPoint(Vector3 p, Vector3 a, Vector3 b, bool canGoDirectly)
	{
		if (canGoDirectly && (b - this.target.position).sqrMagnitude < 16f)
		{
			return this.target.position;
		}
		a.y = p.y;
		b.y = p.y;
		float magnitude = (a - b).magnitude;
		if (magnitude == 0f)
		{
			return a;
		}
		float num = Mathf.Clamp01(this.NearestPointFactor(a, b, p));
		float magnitude2 = ((b - a) * num + a - p).magnitude;
		float num2 = Mathf.Clamp(this.forwardLook - magnitude2, 0f, this.forwardLook) / magnitude;
		num2 = Mathf.Clamp(num2 + num, 0f, 1f);
		return (b - a) * num2 + a;
	}

	// Token: 0x0600003F RID: 63 RVA: 0x000033A8 File Offset: 0x000015A8
	protected float NearestPointFactor(Vector3 lineStart, Vector3 lineEnd, Vector3 point)
	{
		Vector3 vector = lineEnd - lineStart;
		float magnitude = vector.magnitude;
		vector /= magnitude;
		return Vector3.Dot(point - lineStart, vector) / magnitude;
	}

	/// Determines how often it will search for new paths. 
	/// If you have fast moving targets or AIs, you might want to set it to a lower value.
	/// The value is in seconds between path requests.
	// Token: 0x04000025 RID: 37
	public float repathRate = 0.5f;

	/// Target to move towards.
	/// The AI will try to follow/move towards this target.
	/// It can be a point on the ground where the player has clicked in an RTS for example, or it can be the player object in a zombie game.
	// Token: 0x04000026 RID: 38
	public Transform target;

	/// Enables or disables searching for paths.
	/// Setting this to false does not stop any active path requests from being calculated or stop it from continuing to follow the current path.
	/// \see #canMove
	// Token: 0x04000027 RID: 39
	public bool canSearch = true;

	/// Enables or disables movement.
	/// \see #canSearch 
	// Token: 0x04000028 RID: 40
	public bool canMove = true;

	// Token: 0x04000029 RID: 41
	public bool canTurn = true;

	/// Maximum velocity.
	/// This is the maximum speed in world units per second.
	// Token: 0x0400002A RID: 42
	public float speed = 3f;

	/// Rotation speed.
	/// Rotation is calculated using Quaternion.SLerp. This variable represents the damping, the higher, the faster it will be able to rotate.
	// Token: 0x0400002B RID: 43
	public float turningSpeed = 5f;

	/// Distance from the target point where the AI will start to slow down.
	/// 	 * Note that this doesn't only affect the end point of the path
	///  	 * but also any intermediate points, so be sure to set #forwardLook and #pickNextWaypointDist to a higher value than this
	// Token: 0x0400002C RID: 44
	public float slowdownDistance = 0.6f;

	/// Determines within what range it will switch to target the next waypoint in the path 
	// Token: 0x0400002D RID: 45
	public float pickNextWaypointDist = 2f;

	/// Target point is Interpolated on the current segment in the path so that it has a distance of #forwardLook from the AI.
	/// See the detailed description of AIPath for an illustrative image 
	// Token: 0x0400002E RID: 46
	public float forwardLook = 1f;

	/// Distance to the end point to consider the end of path to be reached.
	/// When this has been reached, the AI will not move anymore until the target changes and OnTargetReached will be called.
	// Token: 0x0400002F RID: 47
	public float endReachedDistance = 0.2f;

	/// Do a closest point on path check when receiving path callback.
	/// Usually the AI has moved a bit between requesting the path, and getting it back, and there is usually a small gap between the AI
	/// and the closest node.
	/// If this option is enabled, it will simulate, when the path callback is received, movement between the closest node and the current
	/// AI position. This helps to reduce the moments when the AI just get a new path back, and thinks it ought to move backwards to the start of the new path
	/// even though it really should just proceed forward.
	// Token: 0x04000030 RID: 48
	public bool closestOnPathCheck = true;

	// Token: 0x04000031 RID: 49
	protected float minMoveScale = 0.05f;

	/// Cached Seeker component 
	// Token: 0x04000032 RID: 50
	protected Seeker seeker;

	/// Cached Transform component 
	// Token: 0x04000033 RID: 51
	protected Transform tr;

	/// Time when the last path request was sent 
	// Token: 0x04000034 RID: 52
	protected float lastRepath = -9999f;

	/// Current path which is followed 
	// Token: 0x04000035 RID: 53
	protected Path path;

	/// Cached CharacterController component 
	// Token: 0x04000036 RID: 54
	protected CharacterController controller;

	/// Current index in the path which is current target 
	// Token: 0x04000037 RID: 55
	protected int currentWaypointIndex;

	/// Holds if the end-of-path is reached
	/// \see TargetReached 
	// Token: 0x04000038 RID: 56
	protected bool targetReached;

	/// Only when the previous path has been returned should be search for a new path 
	// Token: 0x04000039 RID: 57
	protected bool canSearchAgain = true;

	// Token: 0x0400003A RID: 58
	protected Vector3 lastFoundWaypointPosition;

	// Token: 0x0400003B RID: 59
	protected float lastFoundWaypointTime = -9999f;

	/// Point to where the AI is heading.
	/// Filled in by #CalculateVelocity 
	// Token: 0x0400003C RID: 60
	protected Vector3 targetPoint;

	/// Relative direction to where the AI is heading.
	/// Filled in by #CalculateVelocity 
	// Token: 0x0400003D RID: 61
	public Vector3 targetDirection;
}
