﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200000E RID: 14
public class ItemLook : MonoBehaviour
{
	// Token: 0x06000030 RID: 48 RVA: 0x00002C00 File Offset: 0x00000E00
	private void Update()
	{
		if (this.target == null)
		{
			return;
		}
		this.renderers.Clear();
		this.target.GetComponentsInChildren<Renderer>(false, this.renderers);
		Bounds bounds = default(Bounds);
		bool flag = false;
		foreach (Renderer renderer in this.renderers)
		{
			if (renderer is MeshRenderer || renderer is SkinnedMeshRenderer)
			{
				if (flag)
				{
					bounds.Encapsulate(renderer.bounds);
				}
				else
				{
					flag = true;
					bounds = renderer.bounds;
				}
			}
		}
		if (!flag)
		{
			return;
		}
		Vector3 center = bounds.center;
		float d = bounds.extents.magnitude * 2.25f;
		this._yaw = Mathf.Lerp(this._yaw, this.yaw, 4f * Time.deltaTime);
		this.inspectCamera.transform.rotation = Quaternion.Euler(20f, -this._yaw, 0f);
		this.inspectCamera.transform.position = center - this.inspectCamera.transform.forward * d;
	}

	// Token: 0x04000020 RID: 32
	public Camera inspectCamera;

	// Token: 0x04000021 RID: 33
	public float _yaw;

	// Token: 0x04000022 RID: 34
	public float yaw;

	// Token: 0x04000023 RID: 35
	public GameObject target;

	// Token: 0x04000024 RID: 36
	private List<Renderer> renderers = new List<Renderer>();
}
