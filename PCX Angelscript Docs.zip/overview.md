# Overview

This environment provides a lightweight scripting layer for UI, rendering, memory analysis and interaction in Perception.cx. It uses **AngelScript** with core add-ons and PCX-specific APIs enabled by default.

***

### Core Add-ons

The following standard AngelScript modules are registered:

* **string** — native string support.
* **array** — dynamic arrays with value semantics.
* **dictionary** — key/value associative maps.
* **math** — standard math utilities.
* **any** — variant type for mixed data.
* **grid** — 2D grid storage type.
* **script helper** — Exception helper functions

***

### PCX Addons

Custom host APIs extend the scripting environment:

* **Unicorn** — A CPU Emulator&#x20;
* **Atomic Types**  — thread-safe lock-free integer primitives
* **Render API** — draw shapes, text, images, and gradients
* **Input API** — mouse, keyboard, and scroll input
* **Host Utilities** — logging and script lifecycle helpers
* **Proc API** — memory inspection and manipulation
* **Mutex API** — thread-safety primitives for synchronized access
* **GUI API** — create and interact with UI elements
* **System API** — CPU info, instruction utilities, disassembly
* **Net API** — HTTP, HTTPS, and WebSocket networking
* **File System API** — read, write, and manage files/folders
* **Extended Math API** — vectors, matrices, quaternions, and math helpers
* **Engine Specific API**  — read engine specific structures easier
* **Json API** — JSON parsing and serialization utilities for AngelScript dictionaries
* **Utilities** — encoding, decoding, etc
* **Zydis Encoder**  — Assemble x86/x64 instructions into machine code bytes
* **Intrinsics** — Intrinsics (SSE / Bit Operations)
* **Bit Reinterpret Helpers** — convert values by reinterpreting their underlying bit patterns
* **CS2 Extended API** - For Official CS2 Product
