# Render API

### 📐 Constants

```cpp
const uint8 RR_TOP_LEFT
const uint8 RR_TOP_RIGHT
const uint8 RR_BOTTOM_LEFT
const uint8 RR_BOTTOM_RIGHT
```

> Rectangle-corner rounding flags (bitmask).

```cpp
const int TE_NONE
const int TE_OUTLINE
const int TE_SHADOW
const int TE_GLOW
```

> Text rendering effects.

***

### 🎨 Viewport

```cpp
void get_view(float &out w, float &out h)
float get_view_scale()
double get_fps()
```

* `get_view` — Returns the current viewport width/height in pixels.
* `get_view_scale` — Returns the viewport reference scale (for DPI scaling, etc).
* `get_fps()`    &#x20;

***

### 📏 Basic Shapes

#### Rectangle

```cpp
void draw_rect(float x,float y,float w,float h,
               uint8 r,uint8 g,uint8 b,uint8 a,
               float thickness, float rounding, uint8 rounding_flags)
```

Draws an **outlined rectangle**.

#### Filled Rectangle

```cpp
void draw_rect_filled(float x,float y,float w,float h,
                      uint8 r,uint8 g,uint8 b,uint8 a,
                      float rounding, uint8 rounding_flags)
```

Draws a **filled rectangle**.

#### Line

```cpp
void draw_line(float x1,float y1,float x2,float y2,
               uint8 r,uint8 g,uint8 b,uint8 a, float thickness)
```

Draws a line between `(x1,y1)` and `(x2,y2)`.

#### **Arc**

```cpp
void draw_arc(float cx, float cy, float rx, float ry,
              float start_angle_deg, float sweep_angle_deg,
              uint8 r, uint8 g, uint8 b, uint8 a,
              float thickness, bool filled)
```

Draws an arc or pie-slice centered at `(cx, cy)`.

#### Circle

```cpp
void draw_circle(float cx,float cy,float radius,
                 uint8 r,uint8 g,uint8 b,uint8 a,
                 float thickness, bool filled)
```

#### Triangle

```cpp
void draw_triangle(float ax,float ay,float bx,float by,float cx,float cy,
                   uint8 r,uint8 g,uint8 b,uint8 a,
                   float thickness, bool filled)
```

#### Polygon

```cpp
void draw_polygon(const array<float> &in xy_pairs, uint count_pairs,
                  uint8 r,uint8 g,uint8 b,uint8 a,
                  float thickness, bool filled)
```

* `xy_pairs` — `[x0, y0, x1, y1, …]`
* `count_pairs` — optional; set `0` to use full array length.

#### Four Corner Gradient

```cpp
void draw_four_corner_gradient(float x,float y,float w,float h,
    uint8 tlr,uint8 tlg,uint8 tlb,uint8 tla,
    uint8 trr,uint8 trg,uint8 trb,uint8 tra,
    uint8 blr,uint8 blg,uint8 blb,uint8 bla,
    uint8 brr,uint8 brg,uint8 brb,uint8 bra,
    float rounding)
```

Draws a gradient rectangle with individual RGBA colors for each corner.

***

### 🖼️ Bitmaps

```cpp
uint64 create_bitmap(const array<uint8> &in data)
void   draw_bitmap(uint64 bmp, float x,float y,float w,float h,
                   uint8 r,uint8 g,uint8 b,uint8 a, bool rounded)
```

* `create_bitmap` — Creates a bitmap from raw RGBA or compressed bytes.\
  Returns an **encrypted handle** (`uint64`) used for drawing.
* `draw_bitmap` — Draws the bitmap tinted with color `(r,g,b,a)`.

***

### 🔤 Fonts & Text

```cpp
uint64 create_font(const string &in path, float size, bool antialias, 
bool load_color, array<uint> @glyph_ranges = null)
//load color should only be used for fonts that require texture coloring (e.g. emojis)

/* Automatically resolves font paths within the API directory
   (e.g., verdana_custom.ttf or fonts/verdana_custom.ttf).
   The API may also fall back to searching system font locations.
   If a system font shares the same name, it may be loaded instead.
   Use unique font names to avoid naming conflicts. */

uint64 create_font_mem(const string &in label, float size, const array<uint8> &in buf, 
 bool antialias, bool load_color, array<uint> @glyph_ranges = null)

uint64 get_font18() // default font of size 18
uint64 get_font20() // default font of size 20
uint64 get_font24() // default font of size 24
uint64 get_font28() // default font of size 28

// Using custom glyph ranges
array<uint> ranges = {
    0x0020, 0x00FF,   // Basic Latin + Latin-1 Supplement
    0x0400, 0x04FF,   // Cyrillic
    0
};
uint64 font2 = create_font("Arial", 16.0f, true, false, ranges);
```

#### Text Drawing

```cpp
void draw_text(const string &in text, float x,float y,
               uint8 r,uint8 g,uint8 b,uint8 a,
               uint64 font, int effect,
               uint8 er,uint8 eg,uint8 eb,uint8 ea,
               float effect_amount)
```

* `effect` — One of `TE_NONE`, `TE_OUTLINE`, `TE_SHADOW`, `TE_GLOW`.
* `effect_color` — `(er,eg,eb,ea)`.
* `effect_amount` — Intensity scalar.

#### Text Metrics

```cpp
void get_text_size(uint64 font, const string &in text, int maxw, int maxh,
                   float &out w, float &out h)
int get_char_advance(uint64 font, uint wchar32)
```

> Measure text dimensions or a single character’s advance width.

***

### ✂️ Clipping

```c
void clip_push(float x,float y,float w,float h)
void clip_pop()
```

***

### Example

```cpp
void draw_ui()
{
    float vw, vh; get_view(vw, vh);
    float cx = vw * 0.5f, cy = vh * 0.5f;

    uint64 font = get_font20();

    draw_rect_filled(cx - 100, cy - 50, 200, 100,
                     40, 40, 40, 255, 8.0f, RR_TOP_LEFT|RR_TOP_RIGHT);

    draw_text("Hello World", cx - 60, cy - 10,
              255,255,255,255, font, TE_SHADOW,
              0,0,0,180, 1.0f);
}

```
