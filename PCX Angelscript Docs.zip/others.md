# Others

Required for BF6 CR3 resolution (must be called from `main` or an initialization routine)

`void set_bf6_globals(uint64 client_game_context_offset, uint64 player_manager_offset, uint64 local_player_offset, uint64 player_array_offset, uint64 soldier_offset, uint64 health_component_offset)`
